ace.define("ace/snippets/elm",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "elm";

});
                (function() {
                    ace.require(["ace/snippets/elm"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            