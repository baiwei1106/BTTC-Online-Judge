<html>
<head>
  <title>JudgeOnline Administration</title>
</head>
<frameset cols="20%,*">
  <frame name="menu" src="menu.php">
  <frame name="main" src="help.php">
  <noframes>
  </noframes>
</frameset>
</html>
