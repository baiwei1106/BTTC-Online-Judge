#include <bits/stdc++.h>const int N = 10005 ;const int M = 1000005 ;int n , m ;int in1[N] , in2[M] ;int up[N] , down[M] ;int next[N] ;
void get_next(){    int j = next[0] = -1 ;    int i = 0 ;    while(i < n){        while(-1 != j && up[i] != up[j])            j = next[j] ;        next[++i] = ++ j ;    }}

int solve()
{
    int ans = 0 ;    int i = 0 , j = 0 ;    while(i < m){        while(-1 != j && down[i] != up[j])            j = next[j] ;        i ++ ;        j ++ ;        if(j >= n){            ans ++ ;            j = next[j] ;        }    }
    return ans ;
}

int main(){
    while(~scanf("%d %d",&n,&m)){        int max_n = 0 ;        for(int i = 0 ; i < n ; i ++){            scanf("%d",&in1[i]) ;            max_n = std::max(max_n,in1[i]) ;        }        for(int i = 0 ; i < m ; i ++){            scanf("%d",&in2[i]) ;        }
        if(n == 1){
            printf("%d\n",m) ;
            continue ;
        }
        for(int i = 0 ; i < n - 1; i ++){            up[i] = in1[i] - in1[i+1] ;        }        for(int i = 0 ; i < m - 1 ; i ++){            down[i] = in2[i+1] - in2[i] ;        }        n -- ;        m -- ;        get_next() ;        printf("%d\n",solve()) ;    }    return 0 ;}