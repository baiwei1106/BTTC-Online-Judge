#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<set>
#include<cmath>
#include<sstream>
#include<algorithm>
#include<cstdlib>
#include<stack>
#include<map>
#include<vector>
#include<list>
#include<queue>
using namespace std;
const int INF=0x3f3f3f3f;
int num[10000005];
int s[10000005];
int a[10000005];
struct A{
    long long lazy;
    long long sum;
}tree[400005];
void build(int l,int r,int pre)
{
    tree[pre].lazy=0;
    if(l==r){
        tree[pre].sum=a[l-1];
        return ;
    }
    int m=(l+r)/2;
    build(l,m,pre*2);
    build(m+1,r,pre*2+1);
    tree[pre].sum=tree[pre*2].sum+tree[pre*2+1].sum;
    return ;
}
void push(int l,int r,int pre)
{
    if(tree[pre].lazy){
        int m=(l+r)/2;
        tree[pre*2].sum+=tree[pre].lazy*(m-l+1);
        tree[pre*2].lazy+=tree[pre].lazy;
        tree[pre*2+1].sum+=tree[pre].lazy*(r-m);
        tree[pre*2+1].lazy+=tree[pre].lazy;
        tree[pre].lazy=0;
    }
    return ;
}
void update(int s,int e,int l,int r,int c,int pre)
{
    if(l<=s&&e<=r){
        tree[pre].lazy+=c;
        tree[pre].sum+=(e-s+1)*c;
        return ;
    }
    push(s,e,pre);
    int m=(s+e)/2;
    if(l<=m){
        update(s,m,l,r,c,pre*2);
    }
    if(r>m){
        update(m+1,e,l,r,c,pre*2+1);
    }
    tree[pre].sum=tree[pre*2].sum+tree[pre*2+1].sum;
    return ;
}
void check(int l,int r,int pre)
{
    if(l==r){
        printf("%d ",tree[pre].sum);
        return ;
    }
    int m=(l+r)/2;
    check(l,m,pre*2);
    check(m+1,r,pre*2+1);
    return ;
}
int query(int s,int e,int l,int r,int pre)
{
    if(l<=s&&e<=r){
        return tree[pre].sum;
    }
    push(s,e,pre);
    int m=(s+e)/2;
    int ans=0;
    if(l<=m){
        ans+=query(s,m,l,r,pre*2);
    }
    if(m<r){
        ans+=query(m+1,e,l,r,pre*2+1);
    }
    tree[pre].sum=tree[pre*2].sum+tree[pre*2+1].sum;
    return ans;
}
int main()
{
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
    int t,ks=1;
    scanf("%d",&t);
    while(t--){
        int n;
        scanf("%d",&n);
        for(int i=0;i<n;i++){
            scanf("%d",&num[i]);
            a[i]=num[i];
        }
        sort(a,a+n);
        memset(s,INF,sizeof(s));
        for(int i=0;i<n;i++){
            int k=upper_bound(s,s+n,num[i])-s;
            s[k]=num[i];
        }
        int len=lower_bound(s,s+n,INF)-s;
//        for(int i=0;i<len;i++){
//            cout<<s[i]<<" ";
//        }
//        cout<<endl;
//        printf("%d\n",len);
        build(1,len,1);
//        check(1,len,1);
//        cout<<endl;
        int m;
        scanf("%d",&m);
        char op[10];
        int l,r,c;
        printf("Case#%d:\n",ks++);
        for(int i=0;i<m;i++){
            scanf("%s",op);
            if(op[0]=='s'){
                scanf("%d %d",&l,&r);
                if(l>len) {
                    printf("0\n");
                    continue;
                }
                if(r>len){
                    r=len;
                }
                printf("%d\n",query(1,len,l,r,1));
            }
            else {
                scanf("%d %d %d",&l,&r,&c);
                if(l>len) {
                    continue;
                }
                if(r>len){
                    r=len;
                }
                update(1,len,l,r,c,1);
            }
        }
    }
    return 0;
}
