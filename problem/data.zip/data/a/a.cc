#include <bits/stdc++.h>

struct Point{
public :
    int x , y , cnt ;
    Point(){} ;
    Point(int _x , int _y , int _cnt){
        x = _x ;
        y = _y ;
        cnt = _cnt ;
    }
    bool operator == (const Point temp) const {
        return temp.x == x && temp.y == y ;
    }
} ;

bool map[1005][1005] ;
bool vis[1005][1005] ;

int dir[4][2] = {1,0,0,1,-1,0,0,-1} ;
int n , m , num ;

std::queue<Point> q ;

void init()
{
    while(!q.empty())
        q.pop() ;
    memset(map,false,sizeof map) ;
    memset(vis,false,sizeof vis) ;
}

int bfs(Point finish)
{
    int ans = -1 ;
    while(!q.empty()){
        Point temp = q.front() ;
        q.pop() ;
        if(temp == finish){
            ans = temp.cnt ;
            break ;
        }
        for(int i = 0 ; i < 4 ; i ++){
            int x = temp.x + dir[i][0] ;
            int y = temp.y + dir[i][1] ;
            if(!vis[x][y] && !map[x][y] && x > 0 && x <= n && y > 0 && y <= m){
                q.push(Point(x,y,temp.cnt + 1)) ;
                vis[x][y] = true ;
            }
        }
    }
    return ans ;
}

int main()
{
    while(~scanf("%d %d %d",&n,&m,&num)){
        init() ;
        for(int i = 0 ; i < num ; i ++){
            int x , y ;
            scanf("%d %d",&x,&y) ;
            map[x][y] = true ;
        }
        int start_x , start_y ;
        int finish_x , finish_y ;
        scanf("%d %d %d %d",&start_x,&start_y,&finish_x,&finish_y) ;
        q.push(Point(start_x,start_y,0)) ;
        printf("%d\n",bfs(Point(finish_x,finish_y,0))) ;
    }
    return 0 ;
}
