#include <bits/stdc++.h>

struct Point{
    int x , y ;
};

int judge(Point a , Point b , int x , int y)
{
    int t ;
    a.x -= x ;
    b.x -= x ;
    a.y -= y ;
    b.y -= y ;
    t = a.x*b.y-a.y*b.x ;
    return   t == 0 ? 0 : t > 0 ? 1 : -1 ;
}

bool solve(Point a , Point b , Point c , Point d)
{
    int aa = judge(a,b,c.x,c.y) ;
    int bb = judge(a,b,d.x,d.y) ;
    int cc = (aa^bb) ;
    return cc == -2 || aa == 0 || bb == 0 ;
}

int main()
{
    int n ;
    Point start , end ;
    int ans ;
    while(~scanf("%d %d %d %d %d" , &n , &start.x , &start.y , &end.x , &end.y)){
        ans = 0 ;
        for(int i = 0 ; i < n ; i ++){
            Point a , b ;
            scanf("%d %d %d %d" , &a.x , &a.y , &b.x , &b.y) ;
            ans += solve(start,end,a,b) ;
        }
        printf("%d\n",ans) ;
    }
    return 0 ;
}
