#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<set>
#include<cmath>
#include<sstream>
#include<algorithm>
#include<cstdlib>
#include<stack>
#include<map>
#include<vector>
#include<list>
#include<queue>
using namespace std;
const double pi=acos(-1);
int shi[10]={1,10,100,1000,10000,100000,1000000};
int wei[20];
int main()
{
    int r,n;
    while(~scanf("%d %d",&r,&n)){
        double ans=pi*(double)r*r;
        int ans1=ans*shi[n];
        int ans2=(int) ans;
        int len=1;
        while(ans1){
            wei[len++]=ans1%10;
            ans1/=10;
        }
        if(n == 0 || r == 0){
            printf("%d\n",ans2);
            continue;
        }
        int cnt=0;
        for(int i=len-1;i>0;i--){
            printf("%d",wei[i]);
            cnt++;
            if(cnt==len-n-1){
                printf(".");
            }
        }
        printf("\n");
    }
    return 0;
}
