#include <bits/stdc++.h>

const int N = 1050 ;
const int M = 1000005 ;

struct Point{
    int x , y  ;
    Point(int _x , int _y){
        x = _x ;
        y = _y ;
    }
    Point(){} ;
}point[M];

int dir[4][2] = {0,1,1,0,0,-1,-1,0} ;

int n , m , num ;
int ans ;

bool map[N][N] ;
bool vis[N][N] ;

int cnt=0;

std::queue<Point> q ;

void bfs(int x , int y)
{
    while(!q.empty()) q.pop() ;
    q.push(Point(x,y)) ;
    while(!q.empty()){
        Point temp = q.front() ;
        q.pop() ;
        for(int i = 0 ; i < 4 ; i ++){
            int xx = temp.x + dir[i][0] ;
            int yy = temp.y + dir[i][1] ;
            if(!vis[xx][yy] && xx >= 0 && xx <= n + 1 && yy >= 0 && yy <= m + 1){
                vis[xx][yy] = true ;
                if(!map[xx][yy]){
                    q.push(Point(xx,yy)) ;
                }
            }
        }
    }
}

void dfs(int x , int y)
{
    for(int i = 0 ; i < 4 ; i ++){
        int xx = x + dir[i][0] ;
        int yy = y + dir[i][1] ;
        if(!vis[xx][yy] && xx >= 0 && xx <= n+1 && yy >= 0 && yy <= m+1){
            vis[xx][yy] = true ;
            if(!map[xx][yy]){
                dfs(xx,yy) ;
            }
        }
    }
}

int main()
{
    while(~scanf("%d %d %d",&n,&m,&num)){
        memset(map , false , sizeof map) ;
        memset(vis , false , sizeof vis) ;
        ans = 0 ;
        for(int i = 0 ; i < num ; i ++){
            scanf("%d %d",&point[i].x , &point[i].y) ;
            map[point[i].x][point[i].y] = true ;
        }
        vis[0][1] = true ;
        bfs(0,1);
        for(int i = num - 1 ; i >= 0 ; i --){
            int x = point[i].x ;
            int y = point[i].y ;
            map[x][y] = false ;
            if(vis[x][y]){
                ans ++ ;
                bfs(x,y) ;
            }
        }
        printf("%d\n",ans) ;
    }
    return 0 ;
}
