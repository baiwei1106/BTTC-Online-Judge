#include <bits/stdc++.h>

int num[64] ;

int er[31] ;

void init()
{
    er[0] = 1 ;
    for(int i = 1 ; i < 30 ; i ++){
        er[i] = er[i-1]*2 ;
    }
}

int main()
{
    init() ;
    int n , m ;
    while(~scanf("%d %d",&n,&m)){
        memset(num,0,sizeof num) ;
        int temp ;
        int cnt = 0 ;
        for(int i = 0 ; i < n ; i ++){
            scanf("%d",&temp) ;
            cnt = 0 ;
            while(temp){
                if(temp%2 == 1)
                    num[cnt] ++ ;
                temp/=2 ;
                cnt ++ ;
            }
        }
        while(m--){
            int op ;
            scanf("%d",&op) ;
            if(op == 1){
                long long sum = 0 ;
                for(int i = 0 ; i < 25 ; i ++){
                    sum += num[i]*er[i] ;
                }
                printf("%lld\n",sum) ;
            }
            else if(op == 2){
                int cnt = 0 ;
                int d ;
                scanf("%d",&d) ;
                while(d){
                    if(d%2 == 1)
                        num[cnt] = n - num[cnt] ;
                    d /= 2 ;
                    cnt ++ ;
                }
            }
        }
    }

    return 0 ;
}
