#include <bits/stdc++.h>

const int N = 1000005 ;
const int inf = 0x3f3f3f3f ;

int dp[205][205] ;

int a[205] ;

int solve(int u , int v)
{
    if(u == v)
        return dp[u][v] = a[u] + a[u-1] + a[u+1] ;
    if(dp[u][v] != inf)
        return dp[u][v] ;
    for(int i = u ; i < v ; i ++){
        dp[u][v] = std::min(solve(u,i) + solve(i+1,v) + std::min(a[v+1] - a[i+1] , a[u-1] - a[i]), dp[u][v]) ;
    }
    return dp[u][v] ;
}


int main()
{
    int n ;
    while(~scanf("%d",&n)){
        memset(dp,inf,sizeof dp) ;
        for(int i = 1 ; i <= n ; i ++){
            scanf("%d",&a[i]) ;
        }
        a[0] = 0 ;
        a[n+1] = 0 ;
        int ans = solve(1,n) ;
        printf("%d\n",ans) ;
    }
    return 0 ;
}
