#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
#include <map>

using namespace std;

struct Price
 {
 int v;
 string who;
 int cnt;
 }p[100010];
 bool cmp(const Price &A,const Price &B)
 {
 if(A.cnt==B.cnt)
 return A.v<B.v;
 return A.cnt<B.cnt;
 }
 int num;
 int vis[100010];
int main()
{
 // freopen("//home/fpy/input.txt","r",stdin);
 int n,m;
 memset(vis,0,sizeof(vis));
 int T,cas=0;
 scanf("%d",&T);
 string name;
 int bid;
 while(T--)
 {
 scanf("%d%d",&n,&m);
 num=0;
 memset(vis,0,sizeof(vis));
 for(int i=1;i<=m;i++)
 {
 cin>>name>>bid;
 if(!vis[bid])
 {
 vis[bid]=++num;
 p[num].cnt=0;
 p[num].who=name;
 p[num].v=bid;
 }
 p[vis[bid]].cnt++;
 }
 sort(p+1,p+1+num,cmp);
 // for(int i=1;i<=num;i++)
 // cout<<p[i].who<<" "<<p[i].cnt<<" "<<p[i].v<<endl;
 printf("Case %d:\n",++cas);
 cout<<"The winner is "<<p[1].who<<"."<<endl;
 cout<<"The price is "<<p[1].v<<"."<<endl;
 if(T)
 cout<<endl;
 }
 return 0;
}