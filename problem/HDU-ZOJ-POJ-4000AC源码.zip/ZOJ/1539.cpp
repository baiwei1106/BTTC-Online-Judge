#include <iostream>
using namespace std;
int f[10000005]={0};
int main()
{
	int n,i;
	f[2]=0;
        f[3]=1;
        for(i=4;i<10000005;i++)
           f[i]=f[i/2]+f[i-i/2];
	while(cin>>n)
	     cout<<f[n]<<endl;
	return 0;
}