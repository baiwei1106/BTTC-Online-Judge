#include <iostream>
#include <cstdio>
#include <string.h>
#include <stdlib.h>
using namespace std;
int n,m,t,flag;
int end_x,end_y;
int start_x,start_y;
int dx[]={ -1,1,0, 0 };
int dy[]={ 0,0,1,-1 };
char map[100][100];
char visit[100][100];
void dfs(int x,int y,int c)
{
 if(flag)return ;
 if(c>t)return ;
 if(x<0||x>=n||y<0||y>=m)return ;
 if(map[x][y]=='D'&&c==t)
 {
 flag=1;
 return ;
 }
 int temp=abs(x-end_x)+abs(y-end_y);
 temp=t-temp-c;
 if(temp<0||temp&1)return ;
 if(map[x][y]=='X')return ;
 int tx,ty;
 for(int i=0;i<4;i++)
 {
 tx=x+dx[i];
 ty=y+dy[i];
 if(!visit[tx][ty])
 {
 visit[tx][ty]=1;
 dfs(tx,ty,c+1);
 visit[tx][ty]=0;
 }
 }
 return ;
}
int main()
{
 while(~scanf("%d%d%d",&n,&m,&t)&&(n||m||t))
 {
 memset(visit,0,sizeof(visit));
 for(int i=0;i<n;i++)
 {
 for(int j=0;j<m;j++)
 {
 scanf(" %c",&map[i][j]);
 if(map[i][j]=='S')
 {
 start_x=i;
 start_y=j;
 visit[i][j]=1;
 }
 if(map[i][j]=='D')
 {
 end_x=i;
 end_y=j;
 }
 }
 }
 flag=0;
 dfs(start_x,start_y,0);
 if(flag)printf("YES\n");
 else printf("NO\n");
 }
 return 0;
}
