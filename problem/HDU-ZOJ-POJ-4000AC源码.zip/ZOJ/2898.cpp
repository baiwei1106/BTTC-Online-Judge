#include<cstdio>
#include<cstring>
#include<map>
using namespace std;
typedef long long LL;
int v[25],k[25],trap[25][55],n;
map <LL,int> a;
int main()
{
	int i,j,l;
	int ans;
	map <LL,int>::iterator it;
	while(scanf("%d",&n)!=EOF)
	{
		ans=0;
		a.clear();
		for(i=0;i<n;i++)
		{
			scanf("%d",v+i);
			scanf("%d",k+i);
			for(j=0;j<k[i];j++) scanf("%d",&trap[i][j]);
		}
		for(i=0;i<(1<<(n/2));i++)
		{
			LL x=0;
			int tmpv=0;
			for(j=0;j<n/2;j++)
				if((1<<j)&i)
				{
					for(l=0;l<k[j];l++) x^=(LL)(1LL<<trap[j][l]);
					tmpv+=v[j];
				}
			it=a.find(x);
			if(it!=a.end())
			{
				int last=it->second;
				if(last<tmpv) a[x]=tmpv;
			}
			else
				a[x]=tmpv;
		}
		int before=n/2;
		for(i=0;i<(1<<(n-before));i++)
		{
			LL x=0;
			int tmpv=0;
			for(j=0;j<(n-before);j++)
			{
				if((1<<j)&i)
				{
					for(l=0;l<k[j+before];l++) x^=(LL)(1LL<<trap[j+before][l]);
					tmpv+=v[before+j];
				}
			}
			LL y=(0LL^x);
			it=a.find(y);
			if(it!=a.end())
			{
				int now=it->second;
				tmpv+=now;
				ans=max(ans,tmpv);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
