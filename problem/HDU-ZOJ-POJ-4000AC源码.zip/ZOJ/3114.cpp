#include <cmath>
#include <string>
#include <cstdio>
#include <cstring>
#include <vector>
#include <set>
#include <string>
#include <algorithm>
#include <functional>
using namespace std;
typedef long long LL;

struct Client {
 int id, val;
 Client() { }
 Client(int x, int y) : id(x), val(y) { }
};
struct great {
 bool operator ()(const Client& a, const Client& b) {
 return a.val > b.val;
 }
};
struct small {
 bool operator ()(const Client& a, const Client& b) {
 return a.val < b.val;
 }
};

set<Client, great> s1;
set<Client, small> s2;

int main() {
 int q;
 while (~scanf("%d", &q), q) {
 if (q == 1) {
 int p, q;
 scanf("%d%d", &p, &q);
 s1.insert(Client(p, q));
 s2.insert(Client(p, q));
 }
 if (q == 2) {
 if (s1.empty()) {
 printf("0\n");
 } else {
 Client ans = *(s1.begin());
 printf("%d\n", ans.id);
 s1.erase(ans);
 s2.erase(ans);
 }
 }
 if (q == 3) {
 if (s2.empty()) {
 printf("0\n");
 } else {
 Client ans = *(s2.begin());
 printf("%d\n", ans.id);
 s1.erase(ans);
 s2.erase(ans);
 }
 }
 }
 return 0;
}