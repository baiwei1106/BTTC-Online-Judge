#include<iostream>
#include<cstdio>
#include<memory.h>
#include<queue>
#include<cstdio>
#include<algorithm>

using namespace std;

#define Clear(f, nr) memset(f, nr, sizeof(f))
const int SIZE = 30;

queue<int> q[SIZE];
struct Node
{
 int id;
 char ch;
}node[SIZE];

bool cmp(Node a, Node b)
{
 return a.ch < b.ch;
}

int main()
{
 int T;
 char line[10000], str[SIZE];
 cin >> T;
 while(T --) {
 cin >> str;
 int len1 = strlen(str);
 for(int i = 0; i < len1; i ++) {
 node[i].id = i, node[i].ch = str[i];
 while(!q[i].empty()) q[i].pop();
 }
 //cin >> line;
 getchar();
 cin.getline(line, 10000);
 int len = strlen(line);
 sort(node, node + len1, cmp);
 //for(int i = 0; i < len1; i ++)
 // cout << node[i].ch << " : " << node[i].id << endl;

 bool vis[SIZE];
 Clear(vis, 0);
 int tmp = len % len1;
 for(int i = 0; i < tmp; i ++) {
 vis[i] = 1;
 }
 int tot = len / len1;
 int mark = 0;
 int p = 0;
 for(int i = 0; p < len1; i = mark, p ++) {
 for(int j = i; j < i + tot; j ++) {
 q[node[p].id].push(line[j]);
 }
 mark = i + tot;
 if(vis[node[p].id]) {
 q[node[p].id].push(line[mark]);
 mark ++;
 }
 }
 while(1) {
 bool sign = 0;
 for(int i = 0; i < len1; i ++) {
 if(!q[i].empty()) {
 sign = 1;
 char tt = q[i].front();
 cout << char(tt - 'A' + 'a');
 q[i].pop();
 }
 }
 if(!sign) break;
 }
 cout << endl;
 }
}
