#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#define INF 0x3f3f3f3f
#define NODENUM 250
#define EDGENUM 250*250
using namespace std;
string name[NODENUM],tmp1,tmp2;
int namenum,Edge[NODENUM][NODENUM],d[NODENUM][NODENUM],S,E,N,M;
void init()
{
 namenum=0;
 memset(Edge,INF,sizeof(Edge));
}
int pos(string x)
{
 for(int i=1;i<=namenum;++i) if(x==name[i]) return i;
 name[++namenum]=x;
 return namenum;
}
void build()
{
 S=pos(tmp1); E=pos(tmp2);
 int len;
 scanf("%d",&M);
 for(int i=1;i<=M;++i)
 {
 cin>>tmp1>>tmp2>>len;
 int na=pos(tmp1),nb=pos(tmp2);
 Edge[na][nb]=len;
 }
 N=namenum;
 for(int i=1;i<=N;++i) Edge[i][i]=0;
}
int Floyd(int s,int e)
{
 int ans=INF;
 for(int i=1;i<=N;++i)
 for(int j=1;j<=N;++j) d[i][j]=Edge[i][j];

 for(int k=1;k<=N;++k)
 for(int i=1;i<=N;++i)
 for(int j=1;j<=N;++j) d[i][j]=min(d[i][j],d[i][k]+d[k][j]);

 for(int i=1;i<=N;++i)
 for(int j=1;j<=N;++j) if(Edge[i][j]<INF && i!=j) ans=min(ans,d[S][i]+d[j][E]);

 return ans;
}
int main()
{
	while(cin>>tmp1>>tmp2)
	{
	 init();
	 build();
 printf("%d\n",Floyd(S,E));
	}
	return 0;
}
