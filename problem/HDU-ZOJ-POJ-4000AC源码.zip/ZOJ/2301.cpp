#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <set> 
#include <algorithm>
using namespace std;

class line{
 public:
 int l,r,c;
 line(int l,int r,int c){
 this->l = l;
 this->r = r;
 this->c = c;
 }
};

set<int> s;
vector<line> vec;
int n;

void init(){
 s.clear();
 vec.clear();
}


bool check(int l,int r){
 int c = 1;
 for(int i = 0 ; i < vec.size() ; i++){
 if(l >= vec[i].l && r <= vec[i].r)
 c = vec[i].c; 
 }
 if(c == 0) return true;
 else return false;
}
 
int main(){
 while(scanf("%d",&n)!= EOF ){
 init();
 int l,r,c;
 char cc;
 while(n--){
 cin >> l >> r >> cc;
 c = (cc == 'b'? 1 : 0);
 vec.push_back(line(l-1,r,c));
 s.insert(l-1);
 s.insert(r);
 }
 int ma = -1;
 int tmp = 0;
 bool con = false;
 int last = -1;
 for(set<int>::iterator it = s.begin() ; it != s.end() ; it++){
 int l = *it;
 it++;
 if(it == s.end()){
 it--;break;
 }
 int r = *it;
 it--;
 if(check(l,r)){
 con = true;
 tmp += (r - l);
 if(tmp > ma){
 ma = tmp;
 last = r;
 }
 }
 else{
 con = false;
 tmp = 0;
 }
 
 }
 if(ma == -1)
 puts("Oh, my god");
 else
 printf("%d %d\n",last - ma + 1 ,last);
 }
 
 return 0;
}
