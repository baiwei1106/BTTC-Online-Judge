#include<stdio.h>
#include<string.h>
int main()
{
	int n,f=0;
	while(~scanf("%d",&n))
	{
		if(f)puts("");
		f=1;
		char a[120][100],b[120][100];
		int i,j;
		for(i=0;i<n;i++)
			scanf("%s",a[i]);
		int m;
		scanf("%d",&m);
		int find;
		for(i=0;i<m;i++)
		{
			find=0;
			int first_line=1;
			scanf("%s",b[i]);
			int len=strlen(b[i]);
			char *p=strchr(b[i],'*');
			*p=0;
			char tmp;
			int star=p-b[i];
			for(j=0;j<n;j++)
			{
				tmp=a[j][star];
				a[j][star]=0;
				if(strcmp(a[j],b[i])==0)
				{
					a[j][star]=tmp;
					char *p3=p-b[i]+a[j];
					int ll=strlen(a[j]);
					char *p2=&a[j][ll-1]-(&b[i][len-1]-p-1);
					if(strcmp(p2,p+1)==0&&p3<=p2)
					{
						if(!first_line)printf(", ");
						printf("%s",a[j]);
						first_line=0;
						find=1;
					}
				}
				else a[j][star]=tmp;
			}
			if(find)
				printf("\n");
			else
				printf("FILE NOT FOUND\n");
		}		
	}
	return 0;
}