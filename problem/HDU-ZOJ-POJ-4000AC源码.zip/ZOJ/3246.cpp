#include <cstdio>
#include <algorithm>

using namespace std;

typedef long long ll;
const int T = 10000;
const ll INF = (ll)1 << 60;
const int N = 20010;

ll readdbl()
{
 char ss[110];

 scanf("%s", ss);
 int a = 0, b = 0;
 int i = 0;
 int sign = 1;
 if (ss[i] == '-') {
 i++;
 sign = -1;
 }
 while (ss[i] && ss[i] != '.') {
 a = a * 10 + ss[i] - '0';
 i++;
 }
 if (ss[i] == '.')
 i++;
 while (ss[i]) {
 b = b * 10 + ss[i] - '0';
 i++;
 }
 return ((ll)a * T + b) * sign;
}

struct point {
 ll x, y;

 void read()
 {
 x = readdbl();
 y = readdbl();
 }
};

struct line {
 point s, e;

 void read()
 {
 s.read();
 e.read();
 }
};

line seg[510];
ll hash[N];

int main()
{
 int cn, cns;

 //freopen("input.txt", "r", stdin);

 scanf("%d", &cns);
 for (cn = 0; cn < cns; cn++) {
 int n;
 scanf("%d", &n);
 ll l = INF, r = -INF;
 for (int i = 0; i < n; i++) {
 seg[i].read();
 if (l > min(seg[i].s.x, seg[i].e.x))
 l = min(seg[i].s.x, seg[i].e.x);
 if (r < max(seg[i].s.x, seg[i].e.x))
 r = max(seg[i].s.x, seg[i].e.x);
 }



 for (int i = 0; i < N; i++) {
 hash[i] = -INF;
 }

 l /= T;
 r /= T;
 ll ans = 0;
 for (ll i = l - 1; i <= r + 1; i++) {
 ll x = i * T;

 for (int j = 0; j < n; j++) {
 point s = seg[j].s, e = seg[j].e;
 if (min(s.x, e.x) > x || max(s.x, e.x) < x)
 continue;

 if (s.x == x && e.x == x) {
 ll be = min(s.y, e.y), en = max(s.y, e.y);
 be = be / T - 1;
 en = en / T + 1;
 for (ll k = be; k <= en; k++) {
 ll ret = k * T;
 if (ret >= min(s.y, e.y) && ret <= max(s.y, e.y) && hash[k + T] != i) {
 hash[k + T] = i;
 ans++;
 }
 }
 } else if (s.x == x) {
 if (s.y % T == 0) {
 ll y = s.y / T;
 if (hash[y + T] != i) {
 hash[y + T] = i;
 ans++;
 }
 }
 } else if (e.x == x) {
 if (e.y % T == 0) {
 ll y = e.y / T;
 if (hash[y + T] != i) {
 hash[y + T] = i;
 ans++;
 }
 }
 } else {
 ll dy = e.y - s.y, dx = e.x - s.x;
 ll dd = x - s.x;
 if (dy * dd % dx == 0 && (s.y + dy * dd / dx) % T == 0) {
 ll y = (s.y + dy * dd / dx) / T;
 if (hash[y + T] != i) {
 hash[y + T] = i;
 ans++;
 }
 }
 }
 }

 //printf("%lld %lld\n", x, ans);
 }
 printf("Case %d: %lld\n", cn + 1, ans);

 }

 return 0;
}
