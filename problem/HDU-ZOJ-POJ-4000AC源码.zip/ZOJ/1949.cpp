#include <iostream>
using namespace std;
int matrix[100][100];
int SL[100];
int SC[100];
int main()
{
 int i,j,PL,PC,CountL,CountC;
 int n;
 while(cin>>n)
 {
 if(n==0)
 break;
 PL=0;
 PC=0;
 CountL=0;
 CountC=0;
 for(i=0;i<n;i++)
 {
 SL[i]=0;
 SC[i]=0;
 }
 for(i=0;i<n;i++)
 {
 for(j=0;j<n;j++)
 {
 cin>>matrix[i][j];
 SL[i]=SL[i]+matrix[i][j];
 SC[j]=SC[j]+matrix[i][j];
 }
 }
 for(i=0;i<n;i++)
 {
 if(SL[i]%2!=0)
 {
 PL=i;
 CountL++;
 }
 if(SC[i]%2!=0)
 {
 PC=i;
 CountC++;
 }
 }
 if(CountL==0&&CountC==0)
 cout<<"OK"<<endl;
 else if(CountL==1&&CountC==1)
 cout<<"Change bit ("<<PL+1<<","<<PC+1<<")"<<endl;
 else
 cout<<"Corrupt"<<endl;
 }
 return 0;
}
