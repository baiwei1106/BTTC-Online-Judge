#include <cstdio>
#include <cstring>
#define maxn 50011
int j,n,m,p,a,b;
int res[maxn],pre[maxn],f[32][maxn];
void init()
{
 memset(f,0, sizeof f);
 for(int i=1;i<=n/m;++i)
 f[0][i*m]=i;
 int t=n/m;
 for(int i=1;i<=n;++i)
 if(!f[0][i])
 f[0][i]=++t;
 for(int i=1;i<=31;++i)
 for(int j=1;j<=n;++j)
 f[i][j]=f[i-1][f[i-1][j]];
}
int main()
{
 while(scanf("%d%d%d%d%d",&n,&m,&p,&a,&b)!=EOF)
 {
 for(int i=1;i<=n;++i)
 res[i]=pre[i]=i;
 init();
 for(int i=0;i<32 && p;++i)
 {
 if(p&1)
 {
 for(int j=1;j<=n;++j)
 res[j]=pre[f[i][j]];
 for(int j=1;j<=n;++j)
 pre[j]=res[j];
 }
 p>>=1;
 }
 for(int i=a;i<b;++i)printf("%d ",res[i]);
 printf("%d\n",res[b]);
 }
 return 0;
}