#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long lld;
const int MAX = 55;
const int mod = 100000007; 
#define REP(i,n) for(i = 0; i < n; i++)
int n ;
struct Mat{
	lld mat[MAX][MAX];
	Mat() {
		memset(mat,0,sizeof(mat));
	}
	void init() {
		int i , j;
		REP(i,n) REP(j,n) mat[i][j] = i==j;
	}
	friend Mat operator *(Mat a,Mat b);
	friend Mat operator ^(Mat a,Mat b);
}E;
Mat operator * (Mat a,Mat b)
{
	int i , j ,k;
	Mat ans;
	REP(i,n) REP(j,n) REP(k,n)
	{
		ans.mat[i][j] += a.mat[i][k] * b.mat[k][j];
	}
	REP(i,n) REP(j,n) ans.mat[i][j]%=mod;
	return ans;
}
Mat operator ^(Mat a,int k)
{
	E.init();
	Mat ans = E; 
	while(k) {
		if(k&1) ans = ans*a ;
		a = a * a, k >>= 1;
	}
	return ans;
}
Mat A[65];
int a[MAX][MAX];
int cnt[MAX];
int xx[MAX][MAX];
int main()
{
 	int T, s, t , x, i , j , k;
	while(scanf("%d%d%d%d",&n,&T,&s,&t)!=EOF)
	{
		REP(i,n) REP(j,n) scanf("%d",&xx[i][j]);
		REP(i,n) xx[t][i] = 0;
		REP(i,n)
		{
			scanf("%d",&cnt[i]);
			REP(j,cnt[i]) scanf("%d",&a[i][j]);
		}
	 for(int i = 1; i <= 60; i++)
		{
			REP(j,n)REP(k,n)
 A[i].mat[j][k] = xx[j][k] & (a[j] [ (i-1)%cnt[j] ]);
			REP(j,n) A[i].mat[j][j] = 1;
		}
		A[0].init();
		int up = min(T,60) , left = T % 60;		
		for(i = 1; i <= up; i++) A[i] = A[i-1] * A[i];
		Mat B = A[up];
 B = B ^ (T/60) ;
		B = B * A[left];
		printf("%lld\n",B.mat[s][t]);
	}
	return 0;
}