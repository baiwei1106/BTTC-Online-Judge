#include <stdio.h>
#include <string.h>
#define M 1010

int vis[M][M];
char map[M][M],junk[100];
int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
int cas,n,m,ex,ey,ans;

void dfs1(int x,int y,int val,int fx,int fy)
{
	if(map[x][y]=='#')
	{
		if(val-1>ans)
		{
			ans=val-1;
			ex=fx;
			ey=fy;
		}
		return ;
	}
	int i;
	for(i=0;i<=3;i++)
	{
		if(!vis[x+dir[i][0]][y+dir[i][1]])
		{
			vis[x+dir[i][0]][y+dir[i][1]]=1;
			dfs1(x+dir[i][0],y+dir[i][1],val+1,x,y);
			vis[x+dir[i][0]][y+dir[i][1]]=0;
		}
	}
}

void dfs2(int x,int y,int val)
{
	if(map[x][y]=='#')
	{
		//printf("at %d %d val is %d\n",x,y,val);
		if(val-1>ans)
		{
			ans=val-1;
		}
		return ;
	}
	int i;
	for(i=0;i<=3;i++)
	{
		if(!vis[x+dir[i][0]][y+dir[i][1]])
		{
			vis[x+dir[i][0]][y+dir[i][1]]=1;
			dfs2(x+dir[i][0],y+dir[i][1],val+1);
			vis[x+dir[i][0]][y+dir[i][1]]=0;
		}
	}
}

int main()
{
	int i,j,sx,sy;
	scanf("%d",&cas);
	while(cas--)
	{
		scanf("%d%d",&n,&m);
		gets(junk);
		memset(map,'#',sizeof(map));
		sx=sy=-1;
		for(i=1;i<=m;i++)
		{
			for(j=1;j<=n;j++)
			{
				map[i][j]=getchar();
				//putchar(map[i][j]);
				if(sx==-1&&map[i][j]=='.')
				{
					sx=i;
					sy=j;
				}
			}
			gets(junk);
			//puts("");
		}
		//printf("start at x %d y %d \n",sx,sy);
		ex=sx;
		ey=sy;
		ans=0;
		memset(vis,0,sizeof(vis));
		vis[sx][sy]=1;
		dfs1(sx,sy,0,sx,sy);
		//printf(" length %d end at x %d y %d \n",ans,ex,ey);
		ans=0;
		memset(vis,0,sizeof(vis));
		vis[ex][ey]=1;
		dfs2(ex,ey,0);
		printf("Maximum rope length is %d.\n",ans);
	}
	return 0;
}