/*
 * Author: chlxyd
 * Created Time: 2013/7/25 14:52:52
 * File Name: I.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )
#define maxn 110 
struct big{
 int a[5000] ;
 int l ;
 void clear(){
 clr(a);l=1;
 }
 big operator * ( const int &q ) const { 
 big now ; now.clear() ;
 int dl = 0 , tmp = q ;
 while ( tmp ) {
 dl ++ ;
 tmp /= 10 ;
 }
 now.l = l + dl;
 repf( i , 1 , l ) 
 now.a[i] += a[i] * q ;
 repf( i , 1 , now.l ) {
 if ( now.a[i] >= 10 ){
 now.a[i+1] += now.a[i] / 10 ;
 now.a[i] %= 10 ;
 }
 }
 if ( now.a[now.l] == 0 ) now.l -- ;
 return now ; 
 }
 void show( ) {
 while ( l > 1 && a[l] == 0 ) l -- ;
 repd( i , l , 1 ) 
 printf("%d" , a[i] ) ;
 printf("\n") ;
 }
};
int n[3] ;
int r;
int v[3][maxn] ;
int a[3][maxn];
int top[3] ;
int jl[maxn*2] ;
int flag ;
int bj[3][maxn];
int g[maxn*2][maxn*2] ;
int can[maxn*2];
int scnt ;
int p( int i , int x ) {
 x -- ;
 int now = 0 ;
 int last = 1 ;
 repd( j , n[i] + 1 , 1 ) { 
 now += a[i][j] * last ;
 now %= r ;
 last *= x ;
 last %= r ;
 }
 return now + 1 ;
}
void dfs1( int i ) {
 if ( jl[i] ) return ;
 if ( can[i] ) flag = false ;
 jl[i] = true ;
 repf( j , 1 , top[1] + top[2] ) {
 if ( g[i][j] ) 
 dfs1(j) ;
 }
}
void dfs( int i , int j ) {
 bj[i][j] = true ;
 int tj = p(i,j) ;
 if ( bj[i][tj] ) {
 flag = tj ;
 if ( v[i][j] == 0 )
 v[i][j] = ++ top[i] ;
 return ;
 }
 dfs(i,tj) ;
 if ( flag == tj ) 
 flag = 0 ;
 if ( flag ) {
 if ( v[i][j] == 0 ) 
 v[i][j] = top[i] ;
 }
}
int main(){
 while ( scanf("%d" , &r ) == 1 ) {
 if ( r == 0 ) return 0;
 clr(g) ;clr(v) ;
 clr(bj) ;clr(jl) ; clr(top) ; clr(can) ;
 repf( i , 1 , 2 ) {
 scanf("%d" , &n[i] ) ;
 repf( j , 1 , n[i] + 1 ) {
 scanf("%d" , &a[i][j]);
 }
 }
 repf( j , 1 , 2 )
 repf( i , 1 , r )
 if ( bj[j][i] == false ) {
 clr(bj[j]) ;
 flag = 0 ;
 dfs( j , i ) ;
 }
 int ans = 0;
 repf( i , 1 , r ) { 
 if ( v[1][i] != 0 && v[2][i] != 0 ) {
 g[v[1][i]][top[1]+v[2][i]] = g[top[1]+v[2][i]][v[1][i]] = 1 ;
 }
 if ( v[1][i] == 0 && v[2][i] == 0 ) continue ;
 if ( v[1][i] == 0 ) can[top[1]+v[2][i]] = true ;
 if ( v[2][i] == 0 ) can[v[1][i]] = true ;
 }
 clr(jl) ;
 repf( i , 1 , top[1] + top[2] ) {
 if ( !jl[i] ) {
 flag = true ;
 dfs1(i) ;
 if ( flag ) ans ++ ;
 }
 }
 big a ; a.clear() ; a.a[1] = 1 ;
 repf( i , 1 , ans ) a = a * 2 ;
 a.show();
 }
 
}
