#include <map>
#include <iostream>
#include <cstring>
#include <stdio.h>
#include <string>
using namespace std;
map<string, int> mp;
int main()
{
	int n;
	string s;
	while(scanf("%d", &n), n)
	{
		mp.clear();
		for(int i = 0; i < n; i++)
		{
			cin >> s;
			mp[s]++;
		}
		int maxv = 0; string res;
		for(map<string, int>::iterator p = mp.begin(); p != mp.end(); p++)
		{
			if(p->second > maxv)
			{
				maxv = p->second;
				res = p->first;
			}
		}
		cout << res << "\n";
	}
}
