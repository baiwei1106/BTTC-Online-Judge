//============================================================================
// Name : prob.cpp
// Author : 
// Version :
// Copyright : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<string>
#include<cstdio>
#include<cstring>
#define LL long long
using namespace std;
LL m,n,p,q,i,j,k,l,r,cnt,ans,mi,ma,cnt2;
LL prime[66000];
bool hash[66000];
LL now[1000005];
bool hash_af[1000005];
void fi_prime()
{
	int f_i,f_j;
	memset(hash,0,sizeof(hash));
	hash[0]=hash[1]=true;
	for (f_i=2;f_i<=66000;f_i++)
		if (!hash[f_i])
		{
			prime[cnt++]=f_i;
			for (f_j=2;f_i*f_j<=66000;f_j++)
				hash[f_i*f_j]=true;
		}
}
LL fmax(int x1,int x2)
{
	if (x1>x2)
		return (x1);
	else
		return (x2);
}
int main()
{
	fi_prime();
	while (scanf("%lld%lld",&l,&r)!=EOF)
	{
		memset(hash_af,false,sizeof(hash_af));
		for (i=0;i<cnt;i++)
			for (j=fmax(2,l/prime[i]);prime[i]*j<=r;j++)
				if (prime[i]*j>=l)
					hash_af[prime[i]*j-l]=true;
		for (cnt2=0,i=0;i<r-l+1;i++)
			if (i+l!=0 && i+l!=1 && !hash_af[i])
				now[cnt2++]=(i+l);
		for (i=0,mi=-1,ma=-1;i<cnt2-1;i++)
			if (l<=now[i+1] && now[i+1]<=r && l<=now[i] && now[i]<=r)
			{
				if (ma==-1 || now[i+1]-now[i]>now[ma+1]-now[ma])
					ma=i;
				if (mi==-1 || now[i+1]-now[i]<now[mi+1]-now[mi])
					mi=i;
			}
		if (ma==-1 && mi==-1)
			printf("There are no adjacent primes.\n");
		else
			printf("%lld,%lld are closest, %lld,%lld are most distant.\n",now[mi],now[mi+1],now[ma],now[ma+1]);
	}
	return 0;
}
