#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<iostream>
using namespace std;
int idx[205];
int mtx[205][205];
int main()
{
 int n;
 while(scanf("%d",&n)!=EOF)
 {
 int i,j;
 for(i=0;i<n;i++)
 idx[i]=1;
 int ci=0;
 for(i=0;i<n;i++)
 for(j=0;j<n;j++)
 scanf("%d",&mtx[i][j]);
 int num=0;
 bool found=0;
 while(ci<100000)
 {
 if(num==n)
 {
 found=1;
 break;
 }
 for(i=0;i<n;i++)
 {
 int sum=0;
 for(j=0;j<n;j++)
 sum+=mtx[i][j]*idx[j];
 sum*=idx[i];
 if(sum<0)
 {
 num=0;
 idx[i]*=-1;
 break;
 }
 else
 num++;
 }
 ci++;
 }
 if(found)
 {
 printf("Yes\n");
 for(i=0;i<n;i++)
 {
 if(idx[i]==1)
 printf("+\n");
 else
 printf("-\n");
 }
 }
 else
 printf("No\n");
 }
 return 0;
}
