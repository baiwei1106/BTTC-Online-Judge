#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#include <map>
using namespace std;

#define mxn 105
#define mxe 205

int first[mxn], vv[mxe], nxt[mxe], e;
int dp[mxn][mxn], w[mxn], n, k;

void add( int u, int v ) {
	vv[e] = v; nxt[e] = first[u]; first[u] = e++;
}

void cal( int u, int f ) {
	for( int i = first[u]; i != -1; i = nxt[i] ) {
		int v = vv[i];
		if( v == f ) continue;
		cal( v, u );
		for( int i = k; i >= 0; --i )
			for( int j = 0; j <= i; ++j )
				dp[u][i] = max( dp[u][i], dp[u][i-j] + dp[v][j] );
	}
	for( int i = k; i > 0; --i )
		dp[u][i] = dp[u][i-1] + w[u];
	dp[u][0] = 0;
}

int main()
{
	int u, v;
	while( scanf( "%d%d", &n, &k ) == 2 ) {
		memset( dp, 0, sizeof(dp) );
		memset( first, -1, sizeof(first) ); e = 0;
		for( int i = 0; i < n; ++i )
			scanf( "%d", w + i );
		for( int i = 1; i < n; ++i ) {
			scanf( "%d%d", &u, &v );
			add( u, v ); add( v, u );
		}
		cal( 0, -1 );
		int ans = 0;
		for( int i = 0; i < n; ++i )
			ans = max( ans, dp[i][k] );
		printf( "%d\n", ans );
	}
	return 0;
}