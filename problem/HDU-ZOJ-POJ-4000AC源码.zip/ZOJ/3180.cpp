#include <iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int a[4],b[4];
bool check()
{
	int i,j,k,t;
	for(i=0;i<3;i++)
		for(j=i+1;j<3;j++)
			for(k=0;k<3;k++)
				for(t=k+1;t<3;t++)
					if(a[i]==b[k]&&a[j]==b[t])
						return true;
	return false;
}
int main()
{
	int i,j,m,n,k,t,T;
	scanf("%d",&T);
	while(T--)
	{
		for(i=0;i<3;i++)
			scanf("%d",&a[i]);
		sort(a,a+3);
		for(i=0;i<3;i++)
			scanf("%d",&b[i]);
		sort(b,b+3);
		if(a[0]==b[0]&&a[1]==b[1]&&a[2]==b[2])
		{
			puts("Yes");
			continue;
		}else
			if(a[2]!=a[1]+a[0]-1)
			{
				puts("No");
				continue;
			}
		while(a[0]>1&&!check())
		{
			a[2]=a[1]+1-a[0];
			sort(a,a+3);
		}
		if(check()) puts("Yes");
		else puts("No");
	}
}
