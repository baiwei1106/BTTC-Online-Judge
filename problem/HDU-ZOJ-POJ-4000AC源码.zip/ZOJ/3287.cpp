#include <cstdio>
#include <cstring>

int A, B, C, dian, bian, mian;
int a[10][10][10];

int ok( int x, int y, int z )
{
	if( x < 1 || y < 1 || z < 1 )
		return 0;
	if( x > A || y > B || z > C )
		return 0;
	return a[x][y][z] == 1;
}

void caldian()
{
	int i, j, k, c;
	for( i = 0; i <= A; ++i )
		for( j = 0; j <= B; ++j )
			for( k = 0; k <= C; ++k )
			{
				c = 0;
				c += ok(i, j, k);	c += ok(i+1, j, k);
				c += ok(i, j+1, k);	c += ok(i+1, j+1, k);
				c += ok(i, j, k+1);	c += ok(i+1, j, k+1);
				c += ok(i, j+1, k+1);	c += ok(i+1, j+1, k+1);
				if( c > 0 && c < 8 )
					dian++;
			}
}

void calbian()
{
	int i, j, k, c;
	for( i = 0; i <= A; ++i )
		for( j = 0; j <= B; ++j )
			for( k = 0; k <= C; ++k )
			{
				c = 0;
				c += ok(i, j, k);	c += ok(i, j+1, k);
				c += ok(i, j, k+1);	c += ok(i, j+1, k+1);
				if( c > 0 && c < 4 )
					bian++;
				
				c = 0;
				c += ok(i, j, k);	c += ok(i+1, j, k);
				c += ok(i, j, k+1);	c += ok(i+1, j, k+1);
				if( c > 0 && c < 4 )
					bian++;

				c = 0;
				c += ok(i, j, k);	c += ok(i+1, j, k);
				c += ok(i, j+1, k);	c += ok(i+1, j+1, k);
				if( c > 0 && c < 4 )
					bian++;
			}
}

void calmian()
{
	int i, j, k, c;
	for( i = 1; i <= A; ++i )
		for( j = 1; j <= B; ++j )
			for( k = 1; k <= C; ++k )	if( ok(i, j, k) )
			{
				c = 0;
				c += ok(i-1, j, k);	c += ok(i+1, j, k);
				c += ok(i, j-1, k);	c += ok(i, j+1, k);
				c += ok(i, j, k-1);	c += ok(i, j, k+1);
				mian += 6-c;
			}
}

int main()
{
	int i, j, k;

	while( scanf("%d %d %d", &A, &B, &C) != EOF )
	{
		memset(a, -1, sizeof(a));
		for( i = 1; i <= A; ++i )
			for( j = 1; j <= B; ++j )
				for( k = 1; k <= C; ++k )
					scanf("%d", &a[i][j][k]);

		dian = bian = mian = 0;

		caldian();
		calbian();
		calmian();

		if( dian-bian+mian == 2 )
			puts("APPLE");
		else
			puts("DOUGHNUT");
	}

	return 0;
}