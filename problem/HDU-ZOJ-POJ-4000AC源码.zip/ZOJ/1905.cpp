#include<cstdio>

#define MAXX 1000001

int i,j;
char buf[MAXX];
int fal[MAXX];

int main()
{
 fal[0]=-1;
 while(gets(buf),buf[0]!='.')
 {
 for(i=1,j=-1;buf[i];++i)
 {
 while(j>=0 && buf[j+1]!=buf[i])
 j=fal[j];
 if(buf[j+1]==buf[i])
 ++j;
 fal[i]=j;
 }
 j=i-1;
 if(i%(j-fal[j])==0)
 printf("%d\n",i/(j-fal[j]));
 else
 puts("1");
 }
 return 0;
}