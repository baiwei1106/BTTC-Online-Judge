#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <vector>
#include <map>
#include <set>
#include <queue>

using namespace std;

typedef long long ll;

const ll INF = 0x3fffffffll << 31;
const int MAXL = 19;

int n;
ll ten[MAXL], sum[MAXL];

ll dp(int* a, int high, int pos) {
	if (high == pos && a[pos] == 0)
		return sum[pos];
	if (high - pos + 1 < pos)
		return ten[high / 2 - high + pos];
	int mid = (high + 1) / 2;
	int del = high & 1;
	for (int i = mid - 1; i >= pos; --i)
		if (a[i] != a[mid + mid - i - del])
			return 0;
	return 1;
}

ll calc(ll x) {
	int a[MAXL], high = 0;
	for (int i = 0; i < MAXL; ++i) {
		a[i] = x % 10;
		x /= 10;
		if (a[i] != 0)
			high = i;
	}

	ll ret = 0;
	for (int i = high; i >= 0; --i) {
		int dight = a[i];
		for (int j = 0; j < dight; ++j) {
			a[i] = j;
			ret += dp(a, high, i);
		}
		a[i] = dight;
	}
	return ret;
}

int main() {
	ten[0] = 1;
	for (int i = 1; i < MAXL; ++i)
		ten[i] = ten[i - 1] * 10;
	sum[1] = ten[1] - ten[0];
	for (int i = 2; i < MAXL; ++i)
		sum[i] = sum[i - 1] + 9 * ten[(i - 1) / 2];

	while (scanf("%d", &n) == 1 && n) {
		ll lower = 1, upper = INF;
		while (lower < upper) {
			ll mid = (lower + upper) / 2;
			if (calc(mid) >= n)
				upper = mid;
			else
				lower = mid + 1;
		}
		cout << lower - 1 << endl;
	}
}
