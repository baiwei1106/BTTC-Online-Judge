//zzy2012.9.11AC
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<string>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<map>
#include<vector>
#include<queue>

using namespace std;

#define pfn printf("\n");

typedef struct{
    int x,y;
}node;

int n,w1,s1,w2,s2,w3,s3,d1,d2,d3,c1,c2,c3,d4,ans,top;
int dp[2][501][501];
node st[250000];

void ini(){
    for(int i=0; i<2; i++){
        for(int j=0; j<=500; j++)
            for(int k=0; k<=500; k++)
                dp[i][j][k] = -1;
    }
}

void trans(int u,int v,int i,int j,int k){
    int top2 = top;
    for(int m = 0; m < top; m++){
        int x = st[m].x;
        int y = st[m].y;
        if(dp[u][x][y] > -1 && dp[u][x][y] + k > dp[v][x+i][y+j]){
            dp[v][x+i][y+j] = dp[u][x][y] + k;
            if(dp[u][x+i][y+j] == -1){
                st[top2].x = x+i;
                st[top2].y = y+j;
                top2++;
            }
        }
    }
    top = top2;
}

void DP(int u,int v,int w,int s){
    for(int m = 0; m<top; m++){
        int x = st[m].x;
        int y = st[m].y;
        if(dp[u][x][y] > dp[v][x][y])
            dp[v][x][y] = dp[u][x][y];
    }
    for(int i=0; i*w1 <= w && i*s1 <= s; i++){
        int tempw = i*w1;
        int temps = i*s1;
        for(int j=0; tempw + j*w2 <= w && temps + j*s2 <= s; j++){
            int k = min((w - tempw - j*w2) / w3, (s - temps - j*s2) / s3);
            trans(u,v,i,j,k);
            //printf("%d %d %d ~\n",i,j,k);
        }
    }
}

int solve(int u){
    int ans = 0;
    for(int m=0; m<top; m++){
        int x = st[m].x;
        int y = st[m].y;
        int z = dp[u][x][y];
        //printf("%d %d %d ~\n",x,y,z);
        int s = min(x/c1,y/c2);
        s = min(s,z/c3);
        int temp = s * d4;
        temp += (x - c1*s) * d1;
        temp += (y - c2*s) * d2;
        temp += (z - c3*s) * d3;
        if(temp > ans)
            ans = temp;
    }
    return ans;
}

int main()
{
    int cas = 0;
    while(1){
        scanf("%d",&n);
        if(n == 0) break;
        if(cas > 0)
            printf("\n");
        scanf("%d %d %d",&w1,&s1,&d1);
        scanf("%d %d %d",&w2,&s2,&d2);
        scanf("%d %d %d",&w3,&s3,&d3);
        scanf("%d %d %d %d",&c1,&c2,&c3,&d4);
        ini();
        top = 0;
        st[0].x = 0;
        st[0].y = 0;
        top++;
        dp[0][0][0] = dp[1][0][0] = 0;
        for(int i=0; i<n; i++){
            int u = i%2;
            int v = (i+1)%2;
            int w,s;
            scanf("%d %d",&w,&s);
            DP(u,v,w,s);
        }
        int ans = solve(n%2);
        printf("Case %d: %d\n",++cas,ans);
    }
    return 0;
}
