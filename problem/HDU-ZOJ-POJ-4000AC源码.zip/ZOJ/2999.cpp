#include<stdio.h>
#include<string.h>
#include<vector>
#include<algorithm>
#define N 128
using namespace std;
struct trie{
 int next[ N ];
 int tag;
}data[ 50000 ];
struct _edge{
 int vertex,next;
}edge[ 55000 ];
struct _query{
 int v,order;
};
int ep;
int gra[ 40009 ];
int inp,np,n,m;
int init( int a ){
 memset( data[ a ].next,0,sizeof( data[ a ].next ) );
 data[ a ].tag=0;
 return a;
}
int init( int a,int vertex,int next ){
 edge[ a ].vertex=vertex;
 edge[ a ].next=next;
 return a;
}
int insert( char *a ){
 int p=0;
 for( ;*a;a++ ){
 if( data[ p ].next[ *a ]==0 ) data[ p ].next[ *a ]=init( ++inp );
 p=data[ p ].next[ *a ];
 }
 if( !data[ p ].tag ) data[ p ].tag=++np;
 return data[ p ].tag;
}
int rank[ 40009 ],set[ 40009 ];
void init_set( int a ){
 rank[ a ]=0;
 set[ a ]=a;
}
int find_set( int a ){
 if( set[ a ]!=a )
 set[ a ]=find_set( set[ a ] );
 return set[ a ];
}
void union_set( int a,int b ){
 a=find_set( a ),b=find_set( b );
 if( rank[ a ]>rank[ b ] )
 set[ b ]=a;
 else{
 set[ a ]=b;
 if( rank[ a ]==rank[ b ] ) rank[ b ]++;
 }
}
bool color[ 40009 ];
int anc[ 40009 ],an[ 40009 ],aan[ 40009 ];
vector<_query> query[ 40009 ];
void LCA( int a ){
 init_set( a );
 anc[ find_set( a ) ]=a;
 for( int i=gra[ a ];i;i=edge[ i ].next ){
 LCA( edge[ i ].vertex );
 union_set( edge[ i ].vertex,a );
 anc[ find_set( a ) ]=a;
 }
 color[ a ]=true;
 for( int i=0;i<query[ a ].size( );i++ )
 if( color[ query[ a ][ i ].v ] ){
 int temp=anc[ find_set( query[ a ][ i ].v ) ],order=query[ a ][ i ].order;
 an[ order ]=( aan[ order ]==temp );
 } 
}
char str[ 300 ];
int main( void ){
 int cas=0;
 while( scanf( "%s%d",str,&n )+1 ){
 if( cas ) printf( "\n" );
 ep=inp=np=0;
 init( 0 );
 memset( gra,0,sizeof( gra ) );
 memset( color,false,sizeof( color ) );
 insert( str );
 for( int i=0;i<n;i++ ){
 int a,b;
 scanf( "%s",str );
 a=insert( str );
 scanf( "%s",str );
 b=insert( str );
 gra[ b ]=init( ++ep,a,gra[ b ] );
 }
 n=np;
 for( int i=1;i<=n;i++ ) query[ i ].clear( );
 scanf( "%d",&m );
 for( int i=0;i<m;i++ ){
 _query temp;
 scanf( "%s",str );
 int a=insert( str );
 scanf( "%s",str );
 int b=insert( str );
 aan[ i ]=b;
 temp.v=b,temp.order=i;
 query[ a ].push_back( temp );
 temp.v=a;
 query[ b ].push_back( temp );
 }
 LCA( 1 );
 printf( "Project %d\n",++cas );
 for( int i=0;i<m;i++ ){
 if( an[ i ] ) printf( "Yes\n" );
 else printf( "No\n" );
 }
 
 }
}
