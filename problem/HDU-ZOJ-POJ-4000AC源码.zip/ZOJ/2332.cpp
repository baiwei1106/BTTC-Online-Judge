//node is from 0 to n-1
#include <cstdio>
#include <cstring>
#include <iostream>
#include <vector>
#include <cmath>
#define INT_MAX 0x3f3f3f3f
using namespace std;
const int N = 100000;
const int M = 100000;
namespace MaxFlow{
	int n, m, x[N], y[N];
	int gcnt, ghead[N], to[M], cap[M], next[M], cur[N];
	int source, target, flow, pre[N], sign;

	void addEdge(int u, int v, int w){
		next[gcnt] = ghead[u];
		to[gcnt] = v;
		cap[gcnt] = w;
		ghead[u] = gcnt++;
	}

	void insert(int u, int v, int w){
		addEdge(u, v, w);
		addEdge(v, u, 0);
	}

	int level[N], queue[N];
	bool bfs(int s, int t){
		memset(level, -1, sizeof(level));
		sign = t;
		level[t] = 0;
		int tail = 0, head = 0;
		queue[tail++] = t;
		while(head!=tail && level[s]==-1){
			int v = queue[head++];
			for(int iter = ghead[v];iter!=-1;iter=next[iter]){
				if(cap[iter^1]>0&&level[to[iter]]==-1){
					level[to[iter]] = level[v]+1;
					queue[tail++] = to[iter];
				}
			}
		}
		return level[s]!=-1;
	}

	inline void push(){
		int delta = INT_MAX, u, p;
		for(u=target;u!=source;u=to[p]){
			p = pre[u];
			delta = min(delta, cap[p]);
			p^=1;
		}
		for(u=target;u!=source;u=to[p]){
			p = pre[u];
			cap[p] -= delta;
			if(!cap[p]) sign = to[p^1];
			cap[p^=1]+=delta;
		}
		flow += delta;
	}

	void dfs(int u){
		if(u==target){
			push();
			return ;
		}
		for(int &iter=cur[u];iter!=-1;iter=next[iter]){
			if(cap[iter]>0 && level[u]==level[to[iter]]+1){
				pre[to[iter]] = iter;
				dfs(to[iter]);
				if(level[sign]>level[u]) return;
				sign = target;
			}
		}
		level[u] = -1;
	}

	void initNetwork(int nodes){
		n = nodes;
		gcnt = 0;
		for(int i=0;i<=n;i++)
			ghead[i] = -1;
	}

	int maxFlow (int s, int t){
		source = s;
		target = t;
		flow =0;
		while (bfs(source, target)) {
			for (int i = 0; i < n; ++ i) {
					cur [i] = ghead[i];
			}
			dfs(source);
		}
		return flow ;
	}
}
using namespace MaxFlow;

void init(){
	//initNetwork ...
	// set s&&t
	// maxFlow(s,t)
	int h, l, s, t, i, j, n, m, x, hi, d, i1, i2, j1, j2, tot;
	scanf("%d%d",&n,&m);
	h = n*m+n+m;
	l = h+1;
	s = l+1;
	t = s+1;
	initNetwork(t+1);
	tot = 0;
	for(i=0;i<n;i++)
	for(j=0;j<m;j++){
 scanf("%d",&x);
 tot+=x;
 hi = i*m+j;
 insert(s,hi,x);
 insert(hi,m*n+i,INT_MAX);
 insert(hi,m*n+n+j,INT_MAX);
	}
	scanf("%d",&d);
	while(d--){
 scanf("%d%d%d%d",&i1,&j1,&i2,&j2);
 insert(i1*m+j1,i2*m+j2,INT_MAX);
 insert(i2*m+j2,i1*m+j1,INT_MAX);
	}
	for(i=0;i<n;i++){
 scanf("%d",&x);
 insert(m*n+i,h,x);
	}
	for(i=0;i<m;i++){
 scanf("%d",&x);
 insert(m*n+n+i,l,x);
	}
	insert(h,t,INT_MAX);
	insert(l,t,INT_MAX);
	puts(tot==maxFlow(s,t)?"Yes":"No");
}

int main(){
 int tt;
 scanf("%d",&tt);
 while(tt--)
	init();
	return 0;
}
