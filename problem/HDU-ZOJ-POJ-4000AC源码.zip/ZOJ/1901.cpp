#include<cstdio>
#include<cmath>

#define MAXX 111

struct pv
{
 double x,y;
 pv():x(0),y(0){}
 pv(const double &xx,const double &yy):x(xx),y(yy){}
 inline pv operator-(const pv &i)const
 {
 return pv(x-i.x,y-i.y);
 }
}pnt[MAXX],st,nt,tmp;

inline double sq(const double &a)
{
 return a*a;
}

inline double dist(const pv &a,const pv &b)
{
// return sq(a.x-b.x)+sq(a.y-b.y);
 return sqrt(sq(a.x-b.x)+sq(a.y-b.y));
}

short n,i,j,k;
double ans,re,step,mid,t;
bool flag;

inline double get(const pv &a)
{
 re=0;
 for(short i(0);i<n;++i)
 re+=dist(a,pnt[i]);
 return re;
}

int main()
{
 scanf("%hd",&n);
 for(i=0;i<n;++i)
 scanf("%lf%lf",&pnt[i].x,&pnt[i].y);
 st=pnt[0];
 step=100,mid=get(st);
 while(step>0.2)
 {
 flag=true;
 while(flag)
 {
 flag=false;
 nt=st;

 tmp=pv(st.x,st.y+step);
 t=get(tmp);
 if(t<mid)
 {
 mid=t;
 flag=true;
 nt=tmp;
 }

 tmp=pv(st.x,st.y-step);
 t=get(tmp);
 if(t<mid)
 {
 mid=t;
 flag=true;
 nt=tmp;
 }

 tmp=pv(st.x+step,st.y);
 t=get(tmp);
 if(t<mid)
 {
 mid=t;
 flag=true;
 nt=tmp;
 }

 tmp=pv(st.x-step,st.y);
 t=get(tmp);
 if(t<mid)
 {
 mid=t;
 flag=true;
 nt=tmp;
 }

 st=nt;
 }
 step/=2;
 }
 printf("%lld\n",(long long)(mid+0.5));
 return 0;
}
