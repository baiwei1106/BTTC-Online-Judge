#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

inline double Min( double x, double y )
{
	return x < y ? x : y;
}

struct point
{
	double x, y;
} p[100010];

double dis( point a, point b )
{
	double dx = a.x-b.x;
	double dy = a.y-b.y;
	return sqrt(dx*dx + dy*dy);
}

int cmpx( point a, point b )
{
	return a.x < b.x;
}

int cmpy( point a, point b )
{
	return a.y < b.y;
}

point py[100010];
double close( point* p, int ll, int rr )
{
	if( rr-ll <= 1 )	return 1e100;

	int m = (ll+rr)>>1;
	double midx = p[m].x;
	double res = Min(close(p, ll, m), close(p, m, rr));
	inplace_merge(p+ll, p+m, p+rr, cmpy);
	double x1 = midx-res, x2 = midx+res;

	int len = 0, i, j;
	for( i = ll; i < rr; ++i )	if( p[i].x > x1 && p[i].x < x2 )
		py[len++] = p[i];
	for( i = 0; i < len; ++i )
		for( j = i+1; j < len && py[j].y < py[i].y+res; ++j )
			res = Min(res, dis(py[i], py[j]));

	return res;
}

int main()
{
	int N, i, j;

	while( scanf("%d", &N), N )
	{
		for( i = 0; i < N; ++i )
			scanf("%lf %lf", &p[i].x, &p[i].y);
		sort(p, p+N, cmpx);
		printf("%.2lf\n", close(p, 0, N)/2);
	}

	return 0;
}
