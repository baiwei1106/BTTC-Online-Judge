#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;

struct node
{
	short s[120];	
};

node f[61][61][61];
int n;

node add( node x , node y )
{
	int len;
	len = max(x.s[0],y.s[0]);
	for ( int i = 1 ; i <= len ; ++i )
	{
		x.s[i] += y.s[i] ;
		x.s[i+1] += x.s[i] / 10 ;
		x.s[i] %= 10; 
	}
	if ( x.s[len+1] > 0 ) x.s[0] = len+1 ;
	else x.s[0] = len ;
	return x;
}

int main()
{
	ios::sync_with_stdio(false);
	memset(f,0,sizeof(f));
	for ( int i = 0 ; i <= 60 ; ++i )
	for ( int j = 0 ; j <= 60 ; ++j )
	for ( int k = 0 ; k <= 60 ; ++k )
		f[i][j][k].s[0] = 1 ;
	f[0][0][0].s[1] = 1 ;
	for ( int i = 1 ; i <= 60 ; ++i )
	{
		for ( int j = 0 ; j <= i ; ++j )
		for ( int k = 0 ; k <= j ; ++k)
		{
			if ( i-1 >= j ) f[i][j][k] = add( f[i][j][k],f[i-1][j][k] );
			if ( j-1 >= k ) f[i][j][k] = add( f[i][j][k],f[i][j-1][k] );
			if ( k-1 >= 0 ) f[i][j][k] = add( f[i][j][k],f[i][j][k-1] ); 
		}
	}
	while ( cin >> n )	
	{
		for ( int i = f[n][n][n].s[0] ; i >= 1 ; --i )
		cout << f[n][n][n].s[i] ;
		cout << endl << endl;
	}
}