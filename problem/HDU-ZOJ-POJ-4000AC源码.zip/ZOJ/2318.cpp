#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cmath>

using namespace std;

const int MAXN = 310;
const double DINF = 1000000000.0;
const double eps = 1e-6;

struct Node {
 int v, next;
 double w;
} nodes[MAXN*MAXN];

int n;

struct Circle {
 double x, y, r;
} c[MAXN], p;

int G[MAXN];
bool vi[MAXN];
int in[MAXN];
double d[MAXN];
int alloc;

void add(int a, int b, double c) {
 nodes[alloc].v = b, nodes[alloc].next = G[a];
 nodes[alloc].w = c;
 G[a] = alloc++;
}

bool spfa() {
 queue<int> Q;
 for(int i=1; i<=n; i++) {
 Q.push(i);
 vi[i] = 1;
 in[i] = 0;
 d[i] = 0;
 }
 while(!Q.empty()) {
 int u = Q.front(); Q.pop();
 vi[u] = 0;
 for(int son = G[u]; son != -1; son = nodes[son].next) {
 int v = nodes[son].v;
 double w = nodes[son].w;
 if(d[v] > eps + d[u] + w) {
 d[v] = d[u] + w;
 if(!vi[v]) {
 in[v] ++;
 if(in[v] >= n) return false;
 vi[v] = 1;
 Q.push(v);
 }
 }

 }

 }
 return true;
}

double dist(int i, int j) {
 return sqrt((c[i].x - c[j].x)*(c[i].x - c[j].x) + (c[i].y - c[j].y)*(c[i].y - c[j].y));
}

int main()
{
 int T;
 scanf("%d", &T);
 while(T--) {
 scanf("%d", &n);
 for(int i=1; i<=n; i++) {
 scanf("%lf%lf%lf", &c[i].x, &c[i].y, &c[i].r);
 }
 scanf("%lf%lf%lf", &c[0].x, &c[0].y, &c[0].r);
 for(int i=1; i<=n; i++) {
 c[i].x -= c[0].x;
 c[i].y -= c[0].y;
 c[i].r += c[0].r;
 }

 c[0].x = c[0].y = 0;

 memset(G, -1, sizeof(G));
 alloc = 0;
 for(int i=1; i<=n; i++) {
 for(int j=1; j<=n; j++) {
 if(c[i].r + c[j].r - eps < dist(i, j)) continue;
 double C = acos((c[i].x*c[j].x+c[i].y*c[j].y) / (dist(i, 0) * dist(j, 0)));
 bool flag = (c[i].x*c[j].y - c[j].x*c[i].y) >= 0;
 add(i, j, flag?C:-C);
 add(j, i, !flag?C:-C);
 }
 }

 printf(spfa()?"YES\n":"NO\n");
 if(T) printf("\n");
 }

 return 0;
}