#include<iostream>
#include<cstring>
#include<string>
using namespace std;

int t , n , flag ;
int map[21][21] ;

bool check( int i , int j )
{
	if ( map[i][j] != 0 )
	{
		int a = map[i][j] ;
		if ( i+4 <=19 && map[i+1][j] == a && map[i+2][j] == a && map[i+3][j] == a && map[i+4][j] == a && map[i+5][j] != a && map[i-1][j]!=a ) return true ;
		if ( j+4 <=19 && map[i][j+1]==a && map[i][j+2]==a && map[i][j+3]==a && map[i][j+4]==a && map[i][j+5] != a && map[i][j-1]!=a) return true ;
		if ( i+4 <=19 && j+4 <=19 && map[i+1][j+1]==a && map[i+2][j+2]==a && map[i+3][j+3]==a && map[i+4][j+4]==a && map[i+5][j+5]!=a && map[i-1][j-1]!=a) return true ;
		if ( i-4 >= 0 && j+4 <=19 && map[i-1][j+1]==a && map[i-2][j+2]==a && map[i-3][j+3]==a && map[i-4][j+4]==a &&map[i-5][j+5]!=a && map[i+1][j-1]!=a) return true ;
		
		/*if ( i+4 >=19 && map[i+1][j] == 2 && map[i+2][j] == 2 && map[i+3][j] == 2 && map[i+4][j] == 2 && map[i+5][j] != 2 && map[i-1][j] !=2) return true ;
		if ( j+4 <=19 && map[i][j+1]== 2 && map[i][j+2]== 2 && map[i][j+3]== 2 && map[i][j+4]== 2 && map[i][j+5]!=2 && map[i][j-1] != 2 ) return true ;
		if ( i+4 <=19 && j+4 <=19 && map[i+1][j+1]== 2 && map[i+2][j+2]== 2 && map[i+3][j+3]== 2 && map[i+4][j+4]== 2&&map[i+5][j+5]!=2&&map[i-1][j-1]!=2 ) return true ;
		if ( i-4 >= 0 && j+4 <=19 && map[i-1][j+1]== 2 && map[i-2][j+2]== 2 && map[i-3][j+3]== 2 && map[i-4][j+4]== 2&&map[i-5][j+5]!=2&&map[i+1][j-1]!=2 ) return true ;*/
 /*if(j+4<=19&&map[i][j-1]!=map[i][j]&&map[i][j]==map[i][j+1]&&map[i][j+1]==map[i][j+2]&&map[i][j+2]==map[i][j+3]&&map[i][j+3]==map[i][j+4]&&map[i][j+4]!=map[i][j+5])
 return true;
 if(i+4<=19&&map[i-1][j]!=map[i][j]&&map[i][j]==map[i+1][j]&&map[i+1][j]==map[i+2][j]&&map[i+2][j]==map[i+3][j]&&map[i+3][j]==map[i+4][j]&&map[i+4][j]!=map[i+5][j])
 return true;
 if((i+4<=19&&j+4<=19)&&map[i-1][j-1]!=map[i][j]&&map[i][j]==map[i+1][j+1]&&map[i+1][j+1]==map[i+2][j+2]&&map[i+2][j+2]==map[i+3][j+3]&&map[i+3][j+3]==map[i+4][j+4]&&map[i+4][j+4]!=map[i+5][j+5])
 return true;
 if((i-4>=1&&j+4<=19)&&map[i+1][j-1]!=map[i][j]&&map[i][j]==map[i-1][j+1]&&map[i-1][j+1]==map[i-2][j+2]&&map[i-2][j+2]==map[i-3][j+3]&&map[i-3][j+3]==map[i-4][j+4]&&map[i-4][j+4]!=map[i-5][j+5])
 return true;		*/
	}
	return false ;
}

int main()
{
	int i , j , k ;
	cin >> t ;
	while ( t -- )
	{
		memset( map , -1 , sizeof( map ) ) ;
		for ( i = 1 ; i <= 19 ; i ++ )
			for ( j = 1 ; j <= 19 ; j ++ )
				cin >> map[i][j] ;
		flag = 0 ;	
		for(i=1;i<=19;++i){
			for(j=1;j<=19;++j){
				if(check(i,j)){
					flag=1;
					break;
				}
			}
			if(flag)
				break;
		}
		if ( flag == 0 ) cout << 0 << endl ;	
		else 
		{
			if ( map[i][j] == 1 ) 
			{
				cout << 1 << endl ;
				cout << i << " " << j << endl ; 
			}
			else 
			{
				cout << 2 << endl ;
				cout << i << " " << j << endl ;
			}
		}
	}
	return 0 ;
}