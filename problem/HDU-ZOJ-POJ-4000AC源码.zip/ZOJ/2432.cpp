#include <cstdio>
#include <cstring>

using namespace std;
#define N 550
struct node{
 int x,y;
}path[N][N];

int dp[N][N],s[N],t[N];
int n,m;
int main(){
 int T;
 scanf("%d",&T);
 while(T--){
 memset(path,0,sizeof(path));
 scanf("%d",&n);
 for(int i = 1; i <= n; i++)
 scanf("%d",&s[i]);
 scanf("%d",&m);
 for(int i = 1; i <= m; i++)
 scanf("%d",&t[i]);
 memset(dp,0,sizeof(dp));
 int mx = 0;
 for(int i = 1; i <= n; i++){
 mx = 0;
 int tx = 0,ty = 0;
 for(int j = 1; j <= m; j++){
 dp[i][j] = dp[i-1][j];
 path[i][j].x = i-1;
 path[i][j].y = j;
 if(s[i] > t[j] && mx < dp[i-1][j]){
 mx = dp[i-1][j];
 tx = i-1;
 ty = j;
 }
 if(s[i]==t[j]){
 dp[i][j] = mx+1;
 path[i][j].x = tx;
 path[i][j].y = ty;
 }
 }
 }
 mx = -1;
 int id;
 for(int i = 1; i <= m; i++)
 if(dp[n][i] > mx){
 mx = dp[n][i];
 id = i;
 }
 int save[N];
 int cnt = 0;
 int tx = n,ty = id;
 while(dp[tx][ty] != 0) {
 int tmpx,tmpy;
 tmpx = path[tx][ty].x;
 tmpy = path[tx][ty].y;
 if(dp[tx][ty] != dp[tmpx][tmpy]){
 save[cnt++] = t[ty];
 }
 tx = tmpx; ty = tmpy;
 }
 printf("%d\n",mx);
 for(int i =cnt-1; i >= 0; i--)
 printf("%d ",save[i]);
 printf("\n");
 //if(T) printf("\n");
 }
 return 0;
}