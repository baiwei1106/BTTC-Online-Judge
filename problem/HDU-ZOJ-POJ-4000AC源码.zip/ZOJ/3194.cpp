#include<stdio.h> 
#include <algorithm> 
using namespace std; 
bool cmp(double x,double y) 
{ 
 return x<y; 
} 
int main()
{
	int t,n,i;
	double x[1010],y[1010],a[1010];
	//freopen("in.txt","r",stdin);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(i=1;i<=n;i++)
		scanf("%lf %lf",&x[i],&y[i]);
		sort(y+1,y+n+1,cmp);
		sort(x+1,x+n+1,cmp);
		a[1]=x[2]-x[1];	
		a[n]=x[n]-x[n-1];	
		for(i=3;i<=n;i++)
		a[i-1]=x[i]-x[i-2];
		sort(a+1,a+n+1,cmp);
		double ans=0;
		for(i=1;i<=n;i++)
		ans+=y[i]*a[i];
		printf("%.1f\n",ans/2);
	}
}