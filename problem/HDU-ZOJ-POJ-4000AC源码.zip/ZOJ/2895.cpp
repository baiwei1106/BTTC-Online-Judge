#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<algorithm>
#include<iostream>
#include<string>
#include<cmath>
#include<queue>
#include<vector>
#include<map>
using namespace std;
int Lft[1010],Rgt[1010],C,P[1010],Q[1010];
bool Vis[1010],Done[1010];
void Gao(int i,int limit,int ans)
{
 if(i==limit)
 {
 Vis[ans]=false;
 return;
 }
 int tmp=1;
 for(int j=0;j<=Q[i];j++)
 {
 Gao(i+1,limit,ans*tmp);
 tmp*=P[i];
 }
}
void Sov(int a)
{
 if (Done[a])
 return;
 Done[a]=true;
 C=0;
 for (int i=2;i*i<=a;i++)
 if (a%i==0)
 {
 P[C]=i;
 Q[C]=0;
 while (a%i==0)
 {
 Q[C]++;
 a/=i;
 }
 C++;
 }
 if (a!=1)
 {
 Q[C]=1;
 P[C]=a;
 C++;
 }
 Gao(0,C,1);
}
int main()
{
 int N,i,Cnt,v,j;
 while (~scanf("%d",&N))
 {
 if (N==0)
 {
 puts("0");
 continue;
 }
 memset(Lft,-1,sizeof(Lft));
 memset(Rgt,-1,sizeof(Rgt));
 Cnt=-1;
 for (i=0;i<N;i++)
 {
 scanf("%d",&v);
 if (Lft[v]==-1)
 Lft[v]=Rgt[v]=i;
 else Rgt[v]=i;
 if (v>Cnt)
 Cnt=v;
 }
 for (i=0;i<=Cnt+1;i++)
 Vis[i]=true;
 memset(Done,false,sizeof(Done));
 for (i=0;i<=Cnt;i++)
 {
 if (Lft[i]!=-1)
 for (j=0;j<i;j++)
 if (Lft[j]!=-1)
 if (!(Rgt[i]<Lft[j] || Rgt[j]<Lft[i]))
 Sov(i-j);
 }
 for (i=1;i<=Cnt;i++)
 if (Vis[i])
 break;
 printf("%d\n",i);
 }
}
