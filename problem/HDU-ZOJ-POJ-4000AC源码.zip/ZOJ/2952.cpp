#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;

long long a[100000];

long long Init()
{
	long long t = 1 << 16;
	long long max = (long long)1 << 31;
	long long iNum = 0;
	for ( long long i = 2; i < t; ++i )
	{
		long long temp = i*i;
		while ( temp < max )
		{
			a[iNum++] = temp;
			temp *= i;
		}
	}

	return iNum;
}

int main()
{
	long long num = Init();
	sort( a, a+num );

	long long temp = 0;
	for ( long long i = 0; i < num; ++i )
	{
		if ( a[i] != temp )
		{
			printf( "%lld\n", a[i] );
			temp = a[i];
		}
	}

	return 0;
}