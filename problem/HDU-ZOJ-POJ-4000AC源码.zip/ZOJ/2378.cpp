#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int T, cnt[5200];
char in[5200];

int gao(char* s);

int main()
{
	scanf("%d", &T);
	int i, j, k, odd;
	while (T--)
	{
		for (i = 0; i < 200; ++i) in[i] = cnt[i] = 0;
		scanf("%s", in);
		odd = 0;
		int len = strlen(in);
		for (i = 0; i < len; ++i)
			++cnt[in[i]-'a'];
		for (i = 0; i < 26; ++i)
			if (cnt[i] % 2 == 1)
				++odd;
		if (odd > 1)
			printf("Impossible\n");
		else
			printf("%d\n", gao(in));
	}
	return 0;
}

int gao(char* s)
{
	int i, j, k, len;
	int res= 0, mid;
	len = strlen(s);
	bool past = false;
	for (i = 0; i < len/2; ++i)
	{
		char todo = s[i];
		int des = len - 1 - i, pos = -1;
		if (past)
			des = len - i;
		for (j = i + 1; j <= des; ++j)
			if (s[j] == todo)
				pos = j;
		if (pos == -1)
		{
			past = true;
			continue;
		}
		for (j = pos; j < des; ++j)
		{
			char tmp = s[j];
			s[j] = s[j+1];
			s[j+1] = tmp;
			++res;
		}
	}
	int cntodd = 0;
	for (i = 0; i < len; ++i)
	{
		if (cnt[s[i]-'a'] % 2 == 1)
		{
			++cntodd;
			if (cntodd == cnt[s[i]-'a']/2+1)
			{
				res += (len/2) - i;
				return res;
			}
		}
	}
	return res;
}
