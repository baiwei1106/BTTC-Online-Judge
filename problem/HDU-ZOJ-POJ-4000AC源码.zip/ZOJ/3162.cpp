#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#define len(x) (32-__builtin_clz(x))
#define r2(x) (1<<31-__builtin_clz(x))
using namespace std;
int dp[40][40],n[40];
int dfs(int l,int m,bool z) {
 if(l==-1) return m==0;
 if(!z&&dp[l][m]!=-1) return dp[l][m];
 int res(0),u = z?n[l]:1;
 for(int d(0);d<=u;++d) if(m-d>=0)
 res+=dfs(l-1,m-d,z&&d==u);
 return z?res:dp[l][m] = res;
}
double solve(int x) {
 int l(0);
 double res(0.0);
 for(int t(x);t;t>>=1) n[l++] = t&1;
 for(int i(1);i<=l;++i)
 res+=dfs(l-1,i,1)*i;
 return res;
}
double gao(int x) {
 if(x==0) return 0.0;
 double res(0.0);
 res+=(solve(x)-solve(r2(x))+1)/len(x)/x;
 for(int i(len(x)-1);i;--i)
 res+=(i+1)*(1<<i-1)/2.0/i/x;
 return res;
}
int main() {
 int _,a,b; cin>>_;
 memset(dp,-1,sizeof(dp));
 while(_--) {
 cin>>a>>b;
 printf("%.6f\n",(b*gao(b)-(a-1)*gao(a-1))/(b-a+1));
 }
 return 0;
}
