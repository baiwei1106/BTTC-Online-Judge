#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>

using namespace std;

const double eps = 1e-16;

double b1, t1, b2, t2, l, ds, df, g;
double lower, upper;

double ji(double L, double R, double h, double h2) {
 double hh = L*R/(L+R);
 if(h <= hh && hh <= h2) {
 return sqrt(g*(L+R));
 }
 return min(sqrt((g*L*R + g*h2*h2*(L+R)*(L+R)/L/R)/2.0/h2),
 sqrt((g*L*R + g*h*h*(L+R)*(L+R)/L/R)/2.0/h));
}

double f(double p) {
 return max(ji(ds, p, b1, t1), ji(df, l - p, b2, t2));
}

void gao() {
 double L = 0, R = l;
 for(int i=0; i<100; i++) //while(R - L > eps)
 {
 double p = (R - L) / 3;
 double p1 = L + p;
 double p2 = p1 + p;
 double cur1 = f(p1);
 double cur2 = f(p2);
 if(cur1 < cur2) {
 R = p2;
 }
 else {
 L = p1;
 }
 }
 //cout << L << endl;
 printf("%.6lf\n", f(L));
}

int main()
{
 //freopen("input.txt", "r", stdin);
 int T;
 scanf("%d", &T);
 while(scanf("%lf%lf%lf%lf%lf%lf%lf%lf", &b1, &t1, &b2, &t2, &l, &ds, &df, &g) == 8) {
 gao();
 }
 return 0;
}