#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include <queue>
using namespace std;
#define SZ(v) ((int)(v).size())
#define REP(i, n) for (int i = 0; i < (n); ++i) 
const int maxint = -1u>>1;

const int maxn = 100000 + 10;

int n, m, c, C, a[maxn], b[maxn];

int gaoMin() {
 int res = 0, c1 = 0, c2 = 0;
 REP (i, n) {
 res += a[i];
 }
 while (c2 < m) {
 while (c1 < n && a[c1] < b[c2]) ++c1;
 if (c1 < n && a[c1] == b[c2]) {
 ++c1; ++c2;
 } else {
 res += b[c2++];
 }
 }
 return res * c;
}

int gaoMax() {
 int res = 0, c2 = 0, now = 0;
 REP (i, n) {
 while (c2 < m && b[c2] < a[i]) now += b[c2++];
 res += now + (m - c2) * a[i];
 }
 return res * C;
}

int main() {
 while (scanf ("%d%d", &n, &m), n || m) {
 scanf ("%d%d", &c, &C);
 REP (i, n) {
 scanf ("%d", a + i);
 }
 REP (i, m) {
 scanf ("%d", b + i);
 }
 sort (a, a + n);
 sort (b, b + m);
 if (a[n - 1] != b[m - 1]) {
 puts ("Impossible");
 } else {
 printf ("Minimum: %d, maximum: %d\n", gaoMin(), gaoMax());
 }
 }
 
 return 0;
}
