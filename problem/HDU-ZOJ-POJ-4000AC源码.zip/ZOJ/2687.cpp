#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>
#include <deque>
using namespace std ;
#define For(i , n) for(int i = 0 ; i < (n) ; ++i)
#define Sz(x) (int)((x).size())

const double eps = 1e-7 ;
const int maxn = 1000 + 10 ;
int N , K , W , H , initK ;
int mp[maxn][maxn] ;

struct Pnt {
	typedef const Pnt & pnt ;
	int x , y ;
	Pnt (int x_ = 0 , int y_ = 0) : x(x_) , y(y_) {}
	Pnt (pnt s , pnt e) : x(e.x - s.x) , y(e.y - s.y) {}
	
	Pnt gp_ () const {
		return Pnt(-y , x) ;
	}
	Pnt operator+ (pnt b) const {
		return Pnt(x + b.x , y + b.y) ;
	}
	bool operator== (pnt b) const {
		return x == b.x && y == b.y ;
	}
	bool in() {
		return scanf("%d%d" , &x , &y) == 2 ;
	}
} ;
typedef const Pnt & pnt ;
Pnt S , E ;
vector <Pnt> P ;

bool legi(pnt a) {
	return a.x >= 0 && a.x < W && a.y >= 0 && a.y < H ;
}
int & f(pnt a) {
	return mp[a.y][a.x] ;
}

struct Discretize {
	vector <int> X , Y ;
	void operator () (vector <Pnt> & a) {
		X.clear() ;
		Y.clear() ;
		a.push_back(S) ;
		a.push_back(E) ;
		For(i , Sz(a)){
			X.push_back(a[i].x) ;
			Y.push_back(a[i].y) ;
		}
		sort(X.begin() , X.end()) ;
		sort(Y.begin() , Y.end()) ;
		X.resize( unique(X.begin() , X.end()) - X.begin() ) ;
		Y.resize( unique(Y.begin() , Y.end()) - Y.begin() ) ;
		For(i , Sz(a)){
			int x = lower_bound(X.begin() , X.end() , a[i].x) - X.begin() ;
			int y = lower_bound(Y.begin() , Y.end() , a[i].y) - Y.begin() ;
			a[i] = Pnt(x , y) ;
		}
		E = a.back() ;
		a.pop_back() ;
		S = a.back() ;
		a.pop_back() ;
		W = Sz(X) - 1 ;
		H = Sz(Y) - 1 ;
		K = abs(E.x - S.x) ;
	} 
} D ;

struct Get_map {
	void operator() (const vector <Pnt> & a) {
		For(i , H) For(j , W) mp[i][j] = 1 ; 
		for(int i = Sz(a) - 1 , j = 0 ; j < Sz(a) ; i = j , j++) {
			trans(a[i] , a[j]) ;
		}
	}
	void trans(pnt s , pnt e) {
		Pnt v(s , e) ;
		v.x /= max(abs(v.x) , abs(v.y)) ;
		v.y /= max(abs(v.x) , abs(v.y)) ;
		Pnt w = v.gp_() ;
		for(Pnt i = s ; ! (i == e) ; i = i + v) {
			double x = i.x + (v.x + w.x) / 2.0 ;
			double y = i.y + (v.y + w.y) / 2.0 ;
			f( Pnt( (int)x , (int)y ) ) = false ;
		}
	}
} G ;


struct Sum_que {
	deque <int> q ;
	int sum ;
	void push(int x) {sum += x ; q.push_back(x) ;}
	void pop() {sum -= q.front() ; q.pop_front() ;}
	void clear() {q.clear() ; sum = 0 ;}
} ;
struct Update_map {
	vector <int> X , Y ;
	Sum_que q ;
	void operator() () {
		K = E.x - S.x ;
		X.clear() ;
		Y.clear() ;
		For(j , W) X.push_back(D.X[j + 1] - D.X[j]) ;
		For(i , H) Y.push_back(D.Y[i + 1] - D.Y[i]) ;
		W = W - (K - 1) ;
		H = H - (K - 1) ;
		
		q.clear() ;
		For(k , K - 1) {
			q.push(X[k]) ;
		}
		For(j , W) {
			q.push(X[j + (K - 1)]) ;
			X[j] = q.sum ;
			q.pop() ;
		}
		
		q.clear() ;
		For(k , K - 1) {
			q.push(Y[k]) ;
		}
		For(i , H) {
			q.push(Y[i + (K - 1)]) ;
			Y[i] = q.sum ;
			q.pop() ;
		}
		
		For(i , H + (K - 1)) {
			q.clear() ;
			For(k , K - 1) {
				q.push(mp[i][k]); 
			}
			For(j , W) {
				q.push(mp[i][j + (K - 1)]) ;
				mp[i][j] = q.sum ;
				q.pop() ;
			}
		}
		For(j , W) {
			q.clear() ;
			For(k , K - 1) {
				q.push(mp[k][j]) ;
			}
			For(i , H) {
				q.push(mp[i + (K - 1)][j]) ;
				mp[i][j] = q.sum ;
				q.pop() ;
			}
		}
		For(i , H) For(j , W) mp[i][j] = (bool)(mp[i][j] == K * K) ;
	}
} T ;

const Pnt Dir[8] = {
	Pnt(-1 , 0) , Pnt(-1 , 1) , Pnt(0 , 1) , Pnt(1 , 1) ,
	Pnt(1 , 0) , Pnt(1 , -1) , Pnt(0 , -1) , Pnt(-1 , -1)
} ;
struct BFS {
	deque <Pnt> q ;
	Pnt nex ;
	bool operator() () {
		q.clear() ;
		if(f(S)) q.push_back(S) ;
		while (! q.empty() ) {
			if ( is_bound( q.front() ) ) {
				return true ;
			}
			For(d , 4) {
				nex = q.front() + Dir[d * 2] ;
				if ( legi(nex) && (f(nex) == 1) && ok(q.front() , nex) ) {
					f(nex) = 2 ;
					q.push_back(nex) ;
				}
			}
			q.pop_front() ;
		}
		return false ;
	}
	bool is_bound(pnt a) {
		return a.x == 0 || a.x == (W - 1) || a.y == 0 || a.y == (H - 1) ;
	}
	bool ok(pnt a , pnt b) {
		double x = ( (a.x + 0.5) + (b.x + 0.5) ) / 2.0 ; 
		double y = ( (a.y + 0.5) + (b.y + 0.5) ) / 2.0 ;
		if(x - (int)x < eps || x - (int)x > 1.0 - eps) {
			if( T.Y[(int)y] >= initK ) return true ;
		}
		else {
			if( T.X[(int)x] >= initK ) return true ;
		}
		for(int d1 = 6 , d2 = 7 , d3 = 0 ; d3 < 8 ; d1 = d2 , d2 = d3 , d3 += 2) {
			if(f(b + Dir[d1]) == 2 && f(b + Dir[d2]) == 2 && f(b + Dir[d3]) == 2) {
				return true ;
			}
		}
		return false ;
	}
} R ;


int main(){
	scanf("%*d") ;
	while (S.in()) {
		scanf("%d%d" , &K , &N) ;
		initK = K ;
		E = Pnt(S.x + K , S.y + K) ;
		P.resize(N) ;
		For(i , N) {
			P[i].in() ;
		}
		D(P) ;
		G(P) ;
		T() ;
		bool rst = R() ;
		printf("%s\n" , rst ? "YES" : "NO") ;
	}
	
	return 0 ;
}


