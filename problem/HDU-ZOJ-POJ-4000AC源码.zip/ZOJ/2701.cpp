#include<stdio.h>
int n,i,j,dis[1000][1000],share[1000][1000],flag,v,pos,pos2,pre[100000],maxn,t,sign,js;
int main(void)
{
 while (scanf("%d",&n)!=EOF)
 {
 for (i=1;i<=n;i++)
 for (j=1;j<=n;j++)
 scanf("%d",&dis[i][j]);
 flag=0;
 for (i=1;i<=n;i++)
 for (j=1;j<=n;j++)
 {
 t=dis[1][i]+dis[1][j]-dis[i][j];
 if (i!=j && dis[i][j]==0) flag=1;
 if (i>1 && j>1 && i!=j && (dis[1][i]+dis[i][j]<=dis[1][j] || dis[1][j]+dis[i][j]<=dis[1][i])) flag=1;
 if (t % 2==1) flag=1;
 if (i!=j && i>1 && j>1 && (t / 2==dis[1][i] || t / 2==dis[1][j])) flag=1;
 share[i][j]=t/2;
 }
 if (flag==1)
 {
 printf("-1\n\n");
 continue;
 }
 v=n;pos=2;
 for (i=0;i<=n*3;i++)
 pre[i]=0;
 for (i=1;i<=dis[1][2]-1;i++)
 {
 v++;
 pre[pos]=v;
 pos=v;
 }
 pre[pos]=1;
 for (i=3;i<=n;i++)
 {
 maxn=-1;sign=0;
 for (j=2;j<=i-1;j++)
 if (share[j][i]>maxn)
 {
 maxn=share[j][i];
 sign=j;
 }
 for (j=2;j<=i-1;j++)
 if (share[j][sign]<=maxn && share[sign][j]!=share[i][j] || share[j][sign]>maxn && share[i][j]!=maxn)
 {
 flag=1;
 break;
 }
 if (flag==1) break;
 pos=sign;
 for (j=1;j<=dis[1][sign]-maxn;j++)
 pos=pre[pos];
 pos2=i;
 for (j=1;j<=dis[1][i]-maxn-1;j++)
 {
 v++;
 pre[pos2]=v;
 pos2=v;
 }
 pre[pos2]=pos;
 }
 js=0;
 for (i=2;i<=v;i++)
 if (pre[i]==1) js++;
 if (js>=2)
 flag=1;
 if (flag==1)
 printf("-1\n\n");
 else
 {
 printf("%d\n",v);
 for (i=2;i<=v;i++)
 printf("%d %d\n",i,pre[i]);
 printf("\n");
 }
 }
 return 0;
}
