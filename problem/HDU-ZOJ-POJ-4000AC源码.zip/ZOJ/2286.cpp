//1000000 ���3392928 997920
//10000000 35752992 9979200

#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int maxn = 1000000;
int sum[maxn+10],Max;
int hash[maxn<<2];
void init(){
 Max = 0;
 for(int i = 1; i <= maxn ; i++){
 sum[i] -= i;
 for(int j = i; j <= maxn; j += i){
 sum[j] += i;
 }
 Max = max(Max,sum[i]);
 }
 for(int i = 1; i <= maxn; i++){
 hash[sum[i]]++;
 }
 for(int i = 1; i <= maxn<<2; i++){
 hash[i] += hash[i-1];
 }

}
int main(){
 init();
 int N;
 while(cin>>N){
 if(N >= Max){
 printf("%d\n",hash[Max]);
 }else printf("%d\n",hash[N]);
 }
}
