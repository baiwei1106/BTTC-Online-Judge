#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <iostream>

using namespace std;

const int N = 20 ;
bool map[N][N] ;
char s[N+1] ;
int num[1<<N] ;
int a[N] , n , sta[N];
int p[N+1] ;


int main(){
 //freopen("input.txt","r",stdin);
 //freopen("output.txt","w",stdout);

 num[0] = 0 ;
 for (int i = 1 ; i < (1<<20) ; i++)
 {
 int t=0,x=i;
 while (x){
 t+=(x&1);
 x>>=1;
 }
 num[i] = t ;
 }

 while (scanf("%d",&n)==1 && n){
 for (int i = 0 ; i < N ; i++)
 {
 scanf("%s",s);
 for (int j = 0 ; j < N ; j++)
 map[i][j] = (s[j] == '#') ;
 }

 for (int j = 0 ; j < N ; j++){
 int mask = 0 ;
 for (int i = 0 ; i < N ; i++){
 mask = (mask<<1 | map[i][j]) ;
 }
 sta[j] = mask ;
 }
 int ans = 0 ;
 for (int i = 1 ; i < (1<<20) ; i++){

 if (num[i]>=n || n-num[i]>N) continue ;

 for (int j = 0 ; j <= N ; j++)
 p[j]=0 ;
 for (int j = 0 ; j < N ; j++){
 int mask = sta[j] & i ;
 p[num[mask]]++ ;
 }
 int tmp=0 , last=n-num[i];
 for (int j = 20 ; j >= 1 ; j--){
 if (last>=p[j] && p[j])
 {
 tmp += p[j]*j;
 last -= p[j] ;
 }else if (last<=p[j]){
 tmp += j*last;
 break ;
 }
 }

 ans=max(ans,tmp) ;
 }
 printf("%d\n",ans);
 }
 return 0 ;
}
