#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;

struct Rec {
 int x1,y1,x2,y2,c;
 Rec(int e=0,int a=0,int b=0,int c=0,int d=0):x1(a),y1(b),x2(c),y2(d),c(e){}
 int area() const {return (x2-x1)*(y2-y1);}
};
int area[101];
queue<Rec> qu;

int main() {
 int h,w,n,cas=0;
 bool block=false;
 while(scanf("%d%d",&h,&w),h) {
 if(block) putchar('\n');else block=true;
 printf("Case %d:\n",++cas);
 qu.push(Rec());
 memset(area,0,sizeof(area));
 scanf("%d",&n);
 for(int i=0;i<n;++i) {
 Rec tmp;
 scanf("%d%d%d%d%d",&tmp.y1,&tmp.x1,&tmp.y2,&tmp.x2,&tmp.c);
 while(1) {
 Rec cur=qu.front();qu.pop();
 if(!cur.c) {qu.push(tmp);qu.push(Rec());break;}
 if(cur.x1>=tmp.x2||cur.x2<=tmp.x1||cur.y1>=tmp.y2||cur.y2<=tmp.y1) {qu.push(cur);continue;}
 if(cur.y1<tmp.y2&&tmp.y2<cur.y2) qu.push(Rec(cur.c,cur.x1,tmp.y2,cur.x2,cur.y2));
 if(cur.y1<tmp.y1&&tmp.y1<cur.y2) qu.push(Rec(cur.c,cur.x1,cur.y1,cur.x2,tmp.y1));
 if(cur.x1<tmp.x2&&tmp.x2<cur.x2) qu.push(Rec(cur.c,tmp.x2,max(cur.y1,tmp.y1),cur.x2,min(cur.y2,tmp.y2)));
 if(cur.x1<tmp.x1&&tmp.x1<cur.x2) qu.push(Rec(cur.c,cur.x1,max(cur.y1,tmp.y1),tmp.x1,min(cur.y2,tmp.y2)));
 }
 }
 while(!qu.empty()) {
 Rec cur=qu.front();qu.pop();
 area[cur.c]+=cur.area();
 }
 int cnt=0;
 for(int i=1;i<=100;++i) if(area[i]) {printf("%d %d\n",i,area[i]);++cnt;}
 if(cnt==1) printf("There is 1 color left on the wall.\n");
 else printf("There are %d colors left on the wall.\n",cnt);
 }
 return 0;
}
