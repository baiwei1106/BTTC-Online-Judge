
#include <iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
	double ans,x;
	int l,tt;
	scanf("%d",&tt);
	while(tt--)
	{
		scanf("%lf",&x);
		printf("%.2lf\n",x*20*24);
	}
}
