#include<stdio.h>
#include<string.h>
char map[80][80];
int main(){
 int n,m,i,j;
 int x1,y1,x2,y2;
 int minx,maxx,miny,maxy;
 char str[30],tmp[30];
 while(scanf("%d%d",&m,&n),n+m){
 for(i=0;i<=n+1;i++){
 for(j=0;j<=m+1;j++){
 map[i][j]=' ';
 }
 }
 while(scanf("%s",str)){
 if(strcmp(str,"PRINT")==0) break;
 else if(strcmp(str,"LINE")==0){
 scanf("%d%d%d%d",&y1,&x1,&y2,&x2);
 maxx=x1>x2?x1:x2;
 minx=x1<x2?x1:x2;
 maxy=y1>y2?y1:y2;
 miny=y1<y2?y1:y2;
 int t1,t2;
 if(x1<x2&&y1>y2){
 t1=x1;x1=x2;x2=t1;
 t2=y1;y1=y2;y2=t2;
 }
 else if(x1>x2&&y1>y2){
 t1=x1;x1=x2;x2=t1;
 t2=y1;y1=y2;y2=t2;
 }
 if(x1==x2){
 for(i=miny;i<=maxy;i++){
 if(map[x1][i]=='|'||map[x1][i]=='+') map[x1][i]='+';
 else if(map[x1][i]!=' '&&map[x1][i]!='-')
 map[x1][i]='*';
 else map[x1][i]='-';
 }
 }
 
 else if(y1==y2){
 for(i=minx;i<=maxx;i++){
 if(map[i][y1]=='-'||map[i][y1]=='+') map[i][y1]='+';
 else if(map[i][y1]!=' '&&map[i][y1]!='|')
 map[i][y1]='*';
 else map[i][y1]='|';
 }
 }
 else if(x1>x2&&y1<y2){
 for(i=maxx;i>=minx;i--){
 j=miny+maxx-i;
 if(map[i][j]=='\\'||map[i][j]=='x') map[i][j]='x';
 else if(map[i][j]!=' '&&map[i][j]!='/')
 map[i][j]='*';
 else map[i][j]='/';
 }
 }
 else if(x1<x2&&y1<y2){
 for(i=minx;i<=maxx;i++){
 j=miny+i-minx;
 if(map[i][j]=='/'||map[i][j]=='x') map[i][j]='x';
 else if(map[i][j]!=' '&&map[i][j]!='\\')
 map[i][j]='*';
 else map[i][j]='\\';
 }
 }
 
 }
 else if(strcmp(str,"TEXT")==0){
 scanf("%d%d%s",&y1,&x1,tmp);
 j=y1;
 for(i=0;tmp[i]!='\0';i++){
 if(map[x1][j]!=' '&&map[x1][j]!=tmp[i])
 map[x1][j]='*';
 else map[x1][j]=tmp[i];
 j++;
 }
 }
 else if(strcmp(str,"CLEAR")==0){
 scanf("%d%d%d%d",&y1,&x1,&y2,&x2);
 maxx=x1>x2?x1:x2;
 minx=x1<x2?x1:x2;
 maxy=y1>y2?y1:y2;
 miny=y1<y2?y1:y2; 
 for(i=minx;i<=maxx;i++){
 for(j=miny;j<=maxy;j++){
 map[i][j]=' ';
 }
 } 
 }
 else if(strcmp(str,"POINT")==0){
 scanf("%d%d",&y1,&x1);
 if(map[x1][y1]!=' '&&map[x1][y1]!='o')
 map[x1][y1]='*';
 else map[x1][y1]='o';
 }
 }
 for(i=0;i<=m+1;i++){
 map[0][i]='-';
 map[n+1][i]='-';
 }
 for(i=0;i<=n+1;i++){
 map[i][0]='|';
 map[i][m+1]='|';
 }
 map[0][0]='+';map[0][m+1]='+';
 map[n+1][0]='+';map[n+1][m+1]='+';
 for(i=0;i<=n+1;i++){
 for(j=0;j<=m+1;j++){
 printf("%c",map[i][j]);
 }
 printf("\n");
 }
 printf("\n");
 }
 return 0;
}