#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <map>
using namespace std;
char c ,s[30];
string haves[20000],temp;
map<string,int>mp;
int mtop=0;
int hash( string s ){
	if ( mp[s] != 0 )
		return mp[s];
	mp[s] = ++ mtop;
	return mtop;
} 
int main(){
	//freopen("data.in","r",stdin);
	int top = 0 ;
	while ( scanf("%s" , s ) == 1 ){
		if ( s[0] == 'D' )
			break;
		int l = strlen(s) - 1 ;
		top ++ ;
		temp.clear();
		for ( int i = 0 ; i <= l ; i ++)
			haves[top] += s[i] ; 
		if ( l > 1 )
			stable_sort(s+1,s+l);
		for ( int i = 0 ; i <= l ; i ++)
			temp += s[i] ; 
	 	hash(temp);
	 	memset(s,0,sizeof(s));
	}
	getchar();
	int now = 0 ,l=0;
	int first,last;
	temp.clear();
	while ( scanf("%c" , &c) == 1 ){
		if ( c >= 'a' && c <= 'z' ){
				temp += c;
		}
		else{
			if ( temp != "" ){
				memset(s,0,sizeof(s));
				int l = temp.size();
				for ( int i = 0 ; i < l; i ++)
					s[i] = temp[i];
				if ( l > 2 )
					stable_sort(s+1,s+ l -1);
				temp.clear();
				for ( int i = 0 ; i< l ; i ++)
					temp += s[i] ;
				cout<<haves[hash(temp)];
			}
			temp.clear();
			printf("%c",c);
		}
	}
	if ( temp != "" ){
		memset(s,0,sizeof(s));
		int l = temp.size();
		for ( int i = 0 ; i < l; i ++)
			s[i] = temp[i];
		if ( l > 2 )
			stable_sort(s+1,s+ l -1);
		temp.clear();
		for ( int i = 0 ; i< l ; i ++)
			temp += s[i] ;
		cout<<haves[hash(temp)];
	}
}
