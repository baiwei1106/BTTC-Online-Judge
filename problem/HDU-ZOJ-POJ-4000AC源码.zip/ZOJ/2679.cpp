#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	while(n--)
	{
		int a,b,mid1,mid2,mid3,mid,full;
		int c,flag=0;
		scanf("%d%d%d%d",&c,&mid1,&mid2,&mid3);
		mid=mid1*100+mid2*10+mid3*1;
		for(a=9;a>0;a--)
		{
			for(b=9;b>=0;b--)
			{
				full=a*10000+mid*10+b;
				if(full%c==0)
				{
					printf("%d %d %d\n",a,b,full/c);
					flag=1;
					break;
				}
			}
			if(flag)break;
		}
		if(!flag)printf("0\n");
	}
	return 0;
}
