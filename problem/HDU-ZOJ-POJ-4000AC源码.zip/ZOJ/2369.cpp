#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <queue>
#include <map>
#include <set>
#include <vector>
#include <cstring>
#include <math.h>
using namespace std;

const double eps = 1e-4;
double r1, r2;

double f(double x)
{
	return 8. * sqrt((r1*r1 - x*x) * (r2*r2 - x*x));
}

double simpson(double a, double b)
{
	int n, k;
	double h, t1, t2, s1, s2, ep, p, x;
	n = 1, h = b - a;

	t1 = h * ( f(a) + f(b) ) / 2.;		//����T1 = (b-a)/2*[f(a) + f(b)]
	s1 = t1;		//T1����S1
	ep = eps + 1.;
	while(ep >= eps)
	{
		p = 0;
		for(k = 0; k <= n-1; k++)
		{
			x = a + (k + 0.5) * h;
			p += f(x);
		}
		t2 = (t1 + h * p) / 2.;	//����T2n = Tn/2 + h/2 * [(�ۼ�)f(xk + 0.5)];
		s2 = (4. * t2 - t1) / 3.; //����Sn = (4*Tn - Tn) / 3;
		ep = fabs(s2 - s1); //���㾫��
		t1 = t2, s1 = s2, n += n, h /= 2.;
	}
	return s2;
}

int main()
{
	int CASE;
	//freopen("zoj2369.txt", "r", stdin);
	cin >> CASE;
	while(CASE--)
	{
		scanf("%lf%lf", &r1, &r2);
		if(r2 < r1)	swap(r1, r2);
		double t = simpson(0., r1);
		printf("%.4lf\n", t);

	}
	return 0;
}
