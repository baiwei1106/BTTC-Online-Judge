#include<iostream>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<cstdio>

using namespace std;
double dp[50020];
int rear1=0;
int rear2=0;
double tt[50020];

void init(int w)
{
	rear2=0;
	rear1=0;
	for(int i=0;i<=w;i++)
	{
		tt[i]=0.0;
		dp[i]=-1;
	}
}
struct Tot
{
	int tot;
	int v;
	double dan;
}num[2][200];
int cmp(const void *a,const void *b)
{
	return ((Tot*)a)->dan<((Tot*)b)->dan;
}
int main()
{
	int n;
	int w;
	int a,b,c;
	while(scanf("%d%d",&n,&w)!=EOF)
	{
		init(w);
		for(int i=1;i<=n;i++)
		{
			scanf("%d%d%d",&a,&b,&c);
			if(c==0)
			{
				num[0][rear1].tot=a;
				num[0][rear1++].v=b;
			}
			else
			{
				num[1][rear2].dan=(double)b/a;
				num[1][rear2].tot=a;
				num[1][rear2++].v=b;
			}
		}		
		double mm=0.0;
		dp[0]=0;
		for(int i=0;i<rear1;i++)
		{
			for(int j=w-num[0][i].tot;j>=0;j--)
			{
				if(dp[j]>=0)
				{
					dp[j+num[0][i].tot]=max(dp[j]+num[0][i].v,dp[ j + num[0][i].tot ]);
					if(mm<	dp[j+num[0][i].tot])
						mm=	dp[j+num[0][i].tot];
				}
			}
		}
		qsort(num[1],rear2,sizeof(num[1][1]),cmp);
		for(int j=0;j<rear2;j++)
		{
			double dan=((double)num[1][j].v/num[1][j].tot);
			for(int i=w-1;i>=0;i--)
			{
				if(w-i<=num[1][j].tot)
				{
					dp[w]=max(dp[i]+dan*(w-i),dp[w]);
					if(mm<dp[w])
						mm=dp[w];
				}
				else
				{
					dp[i+num[1][j].tot]=max(dp[i]+num[1][j].v,dp[1+num[1][j].tot]);
					if(mm<dp[i+num[1][j].tot])
						mm=dp[i+num[1][j].tot];
				}
			}
		}
		printf("%.2lf\n",mm);
	}
}
