#include<cstdio>

int mat[210][210],ans[210][210],n;

int abs(int a)
{
 return a>0?a:-a;
}

void work(int a,int b)
{
 int t=0,x,y,ax,ay;
 for(int l=1; l<=n*2&&t==0; l++)
 {
 for(int i=-l; i<=l; i++)
 {
 x=a+abs(l-abs(i)),y=b+i;
 if(x>=0&&x<n&&y>=0&&y<n&&mat[x][y])
 t++,ax=x,ay=y;
 if(x!=a)
 {
 x=a-abs(l-abs(i));
 if(x>=0&&x<n&&y>=0&&y<n&&mat[x][y])
 t++,ax=x,ay=y;
 }
 }
 }
 if(t==1)
 ans[a][b]=mat[ax][ay];
 else
 ans[a][b]=0;
}

int main()
{
 int t;
 scanf("%d",&t);
 while(t--)
 {
 scanf("%d",&n);
 for(int i=0; i<n; i++)
 for(int j=0; j<n; j++)
 scanf("%d",&mat[i][j]);

 for(int i=0; i<n; i++)
 for(int j=0; j<n; j++)
 {
 if(mat[i][j]!=0)
 ans[i][j]=mat[i][j];
 else
 work(i,j);
 }

 for(int i=0; i<n; i++)
 {
 for(int j=0; j<n; j++)
 {
 if(j)
 printf(" ");
 printf("%d",ans[i][j]);
 }
 printf("\n");
 }
		if(t)
			printf("\n");
 }
 return 0;
}
