#include <cstdio>
#include <cstring>
#include <algorithm>
#define LL long long
#define lowbit(x) (x&-x)

using namespace std;

const int N = 50007, M = 2001000, Q = 100010;
int root[N], bit[N], lc[M], rc[M], cnt[M], tot;
int num[N], hash[N+Q], counts;
struct CMD
{
 char s[3];
 int l, r, k;
}cmd[Q];
int lq[200], lqcnt, rq[200], rqcnt;
int ncase, n, m;

void init()
{
 tot = counts = 1;
 memset(bit,0,sizeof(bit));
 memset(lc,0,sizeof(lc));
 memset(rc,0,sizeof(rc));
 memset(cnt,0,sizeof(cnt));
}
void build(int l, int r, int &p)
{
 p = tot++;
 cnt[p]=0;
 if (l>=r) return;
 int mid = l+r>>1;
 build(l,mid,lc[p]);
 build(mid+1,r,rc[p]);
}
void insert(int pre, int &now, int l, int r, int key)
{
 now = tot++;
 lc[now]=lc[pre];rc[now]=rc[pre];cnt[now]=cnt[pre]+1;
 if (l>=r) return;
 int mid = l+r>>1;
 if (key<=mid) insert(lc[pre],lc[now],l,mid,key);
 else insert(rc[pre],rc[now],mid+1,r,key);
}
void change(int &now, int l, int r, int key, int chg)
{
 if (!now) now = tot++;
 cnt[now]+=chg;
 if (l>=r) return;
 int mid = l+r>>1;
 if (key<=mid) change(lc[now],l,mid,key,chg);
 else change(rc[now],mid+1,r,key,chg);
}
void update(int l, int key, int chg)
{
 for ( int i = l ; i < counts ; i+=lowbit(i) )
 change(bit[i],1,counts-1,key,chg);
}
int search(int l, int r, int k)
{
 if (l>=r) return l;
 int sum = 0, mid = l+r>>1;
 for ( int i = 0 ; i < rqcnt ; i++ )
 sum+=cnt[lc[rq[i]]];
 for ( int i = 0 ; i < lqcnt ; i++ )
 sum-=cnt[lc[lq[i]]];
 if (sum>=k)
 {
 for ( int i = 0 ; i < rqcnt ; i++ ) rq[i]=lc[rq[i]];
 for ( int i = 0 ; i < lqcnt ; i++ ) lq[i]=lc[lq[i]];
 return search(l,mid,k);
 }
 else
 {
 for ( int i = 0 ; i < rqcnt ; i++ ) rq[i]=rc[rq[i]];
 for ( int i = 0 ; i < lqcnt ; i++ ) lq[i]=rc[lq[i]];
 return search(mid+1,r,k-sum);
 }
}
int query(int l, int r, int k)
{
 lqcnt=rqcnt=1;
 lq[0]=root[l];
 rq[0]=root[r];
 for ( int i = l ; i ; i-=lowbit(i))
 lq[lqcnt++]=bit[i];
 for ( int i = r ; i ; i-=lowbit(i))
 rq[rqcnt++]=bit[i];
 return search(1,counts-1,k);
}
int main()
{
 scanf("%d", &ncase);
 while (ncase--)
 {
 init();
 scanf("%d%d", &n, &m);
 for ( int i = 1 ; i <= n ; i++ )
 {
 scanf("%d", num+i);
 hash[counts++]=num[i];
 }
 for ( int i = 0 ; i < m ; i++ )
 {
 scanf("%s", cmd[i].s);
 if ('Q'==cmd[i].s[0])
 scanf("%d%d%d", &cmd[i].l, &cmd[i].r, &cmd[i].k);
 else
 {
 scanf("%d%d", &cmd[i].l, &cmd[i].r);
 hash[counts++]=cmd[i].r;
 }
 }
 sort(hash+1,hash+counts);
 counts=unique(hash+1,hash+counts)-hash;
 build(1,counts-1,root[0]);
 for ( int i = 1 ; i <= n ; i++ )
 {
 num[i]=lower_bound(hash+1,hash+counts,num[i])-hash;
 insert(root[i-1], root[i],1,counts-1,num[i]);
 }
 for ( int i = 0 ; i < m ; i++ )
 if ('Q'==cmd[i].s[0])
 printf("%d\n", hash[query(cmd[i].l-1,cmd[i].r,cmd[i].k)]);
 else
 {
 update(cmd[i].l,num[cmd[i].l],-1);
 num[cmd[i].l]=lower_bound(hash+1,hash+counts,cmd[i].r)-hash;
 update(cmd[i].l,num[cmd[i].l],1);
 }
 }
 return 0;
}
