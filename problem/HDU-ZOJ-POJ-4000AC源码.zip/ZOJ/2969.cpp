//By Brickgao
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
using namespace std;
#define out(v) cerr << #v << ": " << (v) << endl
#define SZ(v) ((int)(v).size())
const int maxint = -1u>>1;
template <class T> bool get_max(T& a, const T &b) {return b > a? a = b, 1: 0;}
template <class T> bool get_min(T& a, const T &b) {return b < a? a = b, 1: 0;}

int t;
int n;
int c[1010];

int main() {
 scanf("%d", &t);
 while(t --) {
 scanf("%d", &n);
 bool flag = false;
 for(int i = n; i >= 0; i --) {
 scanf("%d", &c[i]);
 c[i] *= i;
 if(c[i]) {
 flag = true;
 }
 }
 if(!flag) {
 printf("0");
 }
 for(int i = n; i >= 1; i --) {
 printf("%d", c[i]);
 if(i - 1 > 0) {
 printf(" ");
 }
 }
 printf("\n");
 }
 return 0;
}
