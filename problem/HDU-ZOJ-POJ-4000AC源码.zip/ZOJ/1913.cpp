#include <cstdio>
#include <iostream>
#include <utility>
#include <map>
#include <memory.h>
using namespace std;

int dfs(int a,int b){
 int l,s;
 l=a>b?a:b;
 s=a<b?a:b;
 if(s==0){
 return -1;
 }
 else if((double)l/(double)s>2.0){
 return 1;
 }
 return -dfs(l%s,s);
}
int main(){
 //freopen("i.txt","r",stdin);
 int a,b,l,s;

 while(cin>>a>>b){
 if(!a&&!b)
 break;
 l=a>b?a:b;
 s=a<b?a:b;
 if(s!=0&&(double)l/(double)s>2.0){
 cout<<"Stan wins"<<endl;
 //cout<<"asd"<<endl;
 continue;
 }
 if(dfs(l,s)==1)
 cout<<"Stan wins"<<endl;
 else
 cout<<"Ollie wins"<<endl;
 }
 return 0;
}

