/*
 * Author: xioumu
 * Created Time: 2013/7/29 19:48:50
 * File Name: E.cpp
 * solve: E.cpp
 */
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
#include<set>
#include<iostream>
#include<vector>
#include<queue>

using namespace std;
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clr(x) memset(x,0,sizeof(x))
#define clrs( x , y ) memset(x,y,sizeof(x))
#define out(x) printf(#x" %d\n", x)
#define sqr(x) ((x) * (x))
typedef long long lint;

const int maxint = -1u>>1;
const int maxn = 1000 + 10;
const double eps = 1e-8;

int sgn(const double &x) { return (x > eps) - (x < -eps); }

struct node {
 int x, y;
 node(int _x = 0, int _y = 0) : x(_x), y(_y) {
 }
};

int two(int x) {
 return 1 << x;
}

bool bit(int mark, int x) {
 return (mark & (1 << x)) != 0;
}
int n;
int mainy, have[maxn], v[maxn], fa[maxn];
vector<node> a, b;
vector<int> e[maxn];

int getX(char c) {
 if ('0' <= c && c <= '9') return c - '6';
 else if (c == 'T') return 4;
 else if (c == 'J') return 5;
 else if (c == 'Q') return 6;
 else if (c == 'K') return 7;
 else return 8;
}

int getY(char c) {
 if (c == 'S') return 0;
 else if (c == 'C') return 1;
 else if (c == 'D') return 2;
 else if (c == 'H') return 3;
}

void init() {
 clr(have);
 a.clear();
 b.clear();
 char s[10];
 rep (i, n * 2) {
 scanf("%s", s);
 int x = getX(s[0]);
 int y = getY(s[1]);
 if (s[2] == '*')
 have[x] = 1;
 if (i < n)
 a.push_back(node(x, y));
 else b.push_back(node(x, y));
 //printf("%d %d\n", x, y);
 }
 //printf("%d %d\n", sz(a), sz(b));
}

bool xiong(int w) {
 rep (i, sz(e[w])) {
 int j = e[w][i];
 if (!v[j]) {
 v[j] = 1;
 if (fa[j] == -1 || xiong(fa[j])) {
 fa[j] = w;
 return true;
 } 
 }
 }
 return false;
}

bool gao(int mark) {
 int need = 0;
 //rep (i, 9)
 //printf("%d", have[i]);
 //puts("");
 rep (i, 9)
 if ( bit(mark, i) == 0 && have[i])
 return false;
 rep (i, n * 2)
 fa[i] = -1;
 rep (i, 2 * n)
 e[i].clear();
 rep (i, sz(a)) {
 //printf("%d\n", a[i].x);
 rep (j, sz(b)) {
 if (bit(mark, a[i].x) && bit(mark, b[j].x)) {
 //printf("%d %d %d\n", mark, a[i].x, b[j].x);
 if ((a[i].y == b[j].y && a[i].x < b[j].x) ||
 (a[i].y != mainy && b[j].y == mainy)) {
 e[i].push_back(j + n);
 e[j + n].push_back(i);
 }
 } 
 }
 if (bit(mark, a[i].x))
 need++;
 }
 int cnt = 0;
 rep (i, n) {
 clr(v);
 if (xiong(i)) {
 cnt++; 
 }
 }
 //printf("%d %d\n", need, cnt);
 return need == cnt;
}

int main() {
 char ch[5];
 while (scanf("%d%s", &n, ch) == 2) {
 mainy = getY(ch[0]);
 init();
 int ans = 0;
 rep (i, two(9)) {
 if (gao(i)) {
 //printf("%d\n", i);
 ans = 1;
 break;
 }
 }
 if (ans) printf("COVER\n");
 else printf("TAKE\n");
 puts("");
 } 
 return 0;
}
