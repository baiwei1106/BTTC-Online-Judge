#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<algorithm>
#include<iostream>
#include<string>
#include<cmath>
#include<queue>
#include<vector>
#include<map>
using namespace std;
const int maxn=505;
struct A{
 int x1, y1, x2, y2;
}g[maxn];
int n;
vector<int> ans;
bool vis[maxn];
void run(int xl, int yl, int xr, int yr, int k)
{
 while (k<=n && (xl>=g[k].x2 || xr<=g[k].x1 || yl>=g[k].y2 || yr<=g[k].y1)) k++;
 if (k>n) return;
 if (xl<g[k].x1)
 {
 run(xl, yl, g[k].x1, yr, k+1);
 xl = g[k].x1;
 }
 if (xr>g[k].x2)
 {
 run(g[k].x2, yl, xr, yr, k+1);
 xr = g[k].x2;
 }
 if (yl<g[k].y1)
 {
 run(xl, yl, xr, g[k].y1, k+1);
 }
 if (yr>g[k].y2)
 {
 run(xl, g[k].y2, xr, yr, k+1);
 }
 if (!vis[k])
 {
 ans.push_back(k);
 vis[k]=1;
 }
}

int main()
{
 //freopen ("in.txt", "r", stdin);
 int i, j, k, m;
 while (scanf ("%d", &n)!=EOF)
 {
 for (i=1; i<=n; i++) scanf ("%d%d%d%d", &g[i].x1, &g[i].y1, &g[i].x2, &g[i].y2);

 scanf ("%d", &m);
 while (m--)
 {
 ans.clear();
 memset (vis, 0, sizeof(vis));
 scanf ("%d", &k);
 run(g[k].x1, g[k].y1, g[k].x2, g[k].y2, k+1);
 sort(ans.begin(), ans.end());
 printf ("%d", ans.size());
 for (j=0; j<ans.size(); j++)
 printf (" %d", ans[j]);
 printf ("\n");
 }
 printf ("\n");
 }
}
