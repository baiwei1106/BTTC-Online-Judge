#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
using namespace std;
typedef long long LL;

LL n,K,ans1,ans2;
LL f[20][200],s[20][200]; int A[20],B[20],C[20],T[20];

void prework()
{
 f[0][0]=1;
 for(int i=1;i<=19;i++)
 for(int j=0;j<=i*9;j++)
 for(int k=0;k<=9;k++) if(j>=k) f[i][j]+=f[i-1][j-k];
 for(int i=0;i<=19;i++) s[i][0]=1;
 for(int i=0;i<=19;i++)
 for(int j=1;j<=9*19;j++) s[i][j]=s[i][j-1]+f[i][j];
}

LL count(int w,int *x)
{
 if(!x[1]) return 0;
 LL Tas=0;
 for(int i=1;i<=x[0];i++)
 {
 Tas+=s[x[0]-i][w];
 if(w>=x[i]) Tas-=s[x[0]-i][w-x[i]];
 w-=x[i]; if(w<=0) {if(!w) Tas++; break;}
 }
 return Tas;
}

bool Cmp(int *X,int *Y)
{
 for(int i=1;i<=X[0];i++)
 {
 if(X[i]<Y[i]) return true;
 if(X[i]>Y[i]) return false;
 }
 return false;
}

LL calc(int *x)
{
 if(!x[1]) return 0;
 if(A[0]==x[0] && Cmp(A,x)) return K+1;
 
 LL Tas=0; int w=0,len=x[0];
 for(int i=1;i<=x[0];i++) w+=x[i];
 for(int i=1;i<w;i++) Tas+=count(i,A);
 x[0]=A[0];
 if(Cmp(A,x))
 {
 memset(T,0,sizeof(T));
 x[0]--; T[0]=x[0];
 for(int j=1;j<=T[0];j++) T[j]=9;
 Tas+=count(w,A)-count(w,T);
 }
 for(int i=1;i<=x[0];i++)
 {
 int tmp=i==1?1:0;
 for(int j=0;j<=x[0]-i;j++) Tas+=s[j][w-tmp]-s[j][w-x[i]];
 w-=x[i]; if(!w) {Tas+=x[0]-i+1; break;}
 }
 Tas-=x[0]-len; x[0]=len;
 return Tas;
}

void get1(int k,int w)
{
 for(int i=k;i<=C[0];i++)
 for(int j=0;j<=9;j++)
 if(w>=j && f[C[0]-i][w-j]) {C[i]=j; w-=j; break;}
}

void get2(int k,int w)
{
 for(int i=k;i<=C[0];i++)
 for(int j=9;j>=0;j--)
 if(w>=j && f[C[0]-i][w-j]) {C[i]=j; w-=j; break;}
}

bool check(int len,int w)
{
 memset(C,0,sizeof(C)); C[0]=len;
 for(int i=1;i<=len;i++)
 {
 int u=-1,tmp=i==1?1:0; LL k1,k2;
 for(int j=tmp;j<=9;j++)
 {
 if(w<j || !f[C[0]-i][w-j]) continue; C[i]=j;
 get1(i+1,w-j); k1=calc(C);
 get2(i+1,w-j); k2=calc(C);
 if(k1<=K && K<=k2) {u=j; break;}
 }
 if(u==-1) return false; w-=u;
 }
 return true;
}

void work()
{
 LL sum=0; int w;
 ans1=calc(B);
 for(int i=1;i<=A[0]*9;i++)
 {
 sum+=count(i,A);
 if(sum>=K) {w=i; break;}
 }
 for(int i=1;i<=A[0];i++)
 if(check(i,w))
 {
 for(int j=1;j<=i;j++) ans2=ans2*10+C[j];
 break;
 }
}

void translate(LL x,int *D)//����������������!!!!!
{
 if(x==0) {D[0]=1; return;}
 int cnt=0,tmp[20];
 for(;x;x/=10) tmp[++cnt]=x%10;
 for(int i=1;i<=cnt;i++) D[i]=tmp[cnt-i+1];
 D[0]=cnt;
}

int main()
{
 prework();
 for(scanf("%lld %lld",&n,&K);n;scanf("%lld %lld",&n,&K))
 {
 for(int i=0;i<20;i++) A[i]=B[i]=0;
 ans1=ans2=0;
 translate(n,A);
 translate(K,B);
 work();
 printf("%lld %lld\n",ans1,ans2);
 }
 return 0;
}
