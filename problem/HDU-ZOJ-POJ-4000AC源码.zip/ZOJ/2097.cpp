//#pragma comment(linker,"/STACK:102400000,102400000")
#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<cstdlib>
#include<queue>
#include<stack>
#include<climits>
#include<set>
#include<map>
#include<vector>
#include<algorithm>
#define fst first
#define scd second
#define sf scanf
#define mkp make_pair
#define pf printf
#define cls(a) memset(a,0,sizeof a)
#define _cls(a) memset(a,-1,sizeof a)

using namespace std;
typedef long long LL;
typedef pair < int , int > pii;

int g[10][10];
int vis[10][10][5];
const int dir[][2]={{1,0},{-1,0},{0,1},{0,-1}};
inline int bfs(int sx,int sy,int ex,int ey){
    _cls(vis);
    queue< pair < pii , pii > >q;
    pair<pii,pii >u,v;
    q.push(mkp(mkp(sx,sy),mkp(0,1) ) );
    vis[sx][sy][1]=0;
    int i,ret=INT_MAX;
    while(q.size()){
        u=q.front();q.pop();
        //pf("%d %d %d %d\n",u.fst.fst,u.fst.scd,u.scd.fst,u.scd.scd);
        if(u.fst.fst==ex && u.fst.scd==ey){
            if(ret>u.scd.fst)
                ret=u.scd.fst;
            continue;
        }
        for(i=0;i<4;++i){
            v.fst.fst=u.fst.fst+dir[i][0];
            v.fst.scd=u.fst.scd+dir[i][1];
            if(v.fst.fst<1 || v.fst.fst>8 || v.fst.scd>8 || v.fst.scd<1) continue;
            v.scd.fst=u.scd.fst+u.scd.scd*g[v.fst.fst][v.fst.scd];
            v.scd.scd=u.scd.scd*g[v.fst.fst][v.fst.scd]%4+1;
            //pf("%d %d %d %d %d\n",v.fst.fst,v.fst.scd,v.scd.fst,v.scd.scd,vis[v.fst.fst][v.fst.scd][v.scd.scd]);
            if(vis[v.fst.fst][v.fst.scd][v.scd.scd]<0 || vis[v.fst.fst][v.fst.scd][v.scd.scd]>v.scd.fst){
                vis[v.fst.fst][v.fst.scd][v.scd.scd]=v.scd.fst;
                q.push(v);
            }
        }
    }
    return ret;
}

int main(){
    int sx,sy,ex,ey,i,j;
    while(~sf("%d%d%d%d",&sx,&sy,&ex,&ey),sx||sy||ex||ey){
        for(i=1;i<9;++i)
            for(j=1;j<9;++j)
                sf("%d",&g[i][j]);
        pf("%d\n",bfs(sx,sy,ex,ey));
    }
    return 0;
}