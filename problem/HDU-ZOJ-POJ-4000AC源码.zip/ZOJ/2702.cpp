#include<iostream>
#include<cstring>
#include<vector>
#include<algorithm>
using namespace std;
int mainw(int n){
 int data[10000],a[10000],c[10000],i,j,k;

 vector<int> ans;
 memset(a,0,sizeof(a));
 memset(c,0,sizeof(c));
 for(i=1;i<=n;i++)
 cin>>data[i];
 for(i=2;i<=n;i++)
 for(j=i-1;j>0;j--)
 if(data[i] == data[j]){
 if(a[j] == 0)
 a[j] = i;
 c[i] = j;
 break;
 }
 for(i=1;i<=n;){
 j = i + 1;
 while(c[j] == 0 && j <= n)
 ++j;
 //cout<<c[j]<<' '<<j<<' '<<data[j]<<endl;
 if(j > n)
 break;
 else if(a[j] != 0){
 c[a[j]] = 0;
 }
 k = j + 1;
 while(c[k] == 0 && k <= n)
 ++k;
 //<<c[k]<<' '<<k<<' '<<data[k]<<endl;
 if(k > n)
 break;
 else if(a[k] != 0){
 c[a[k]] = 0;
 }
 ans.push_back(c[j]);
 ans.push_back(j);
 ans.push_back(c[k]);
 ans.push_back(k);
 for(;i<=k;++i){
 c[a[i]] = 0;
 //cout<<"clear"<<a[i]<<endl;
 }
 }
 cout<<ans.size()/4<<endl;
 sort(ans.begin(),ans.end());
 for(i=0;i<ans.size();i++){
 cout<<ans[i];
 if((i+1)%4)
 cout<<' ';
 else
 cout<<endl;
 }
}
int main(){
 int n;
 bool flag = false;
 while(cin>>n){
 if(flag)
 cout<<endl;
 mainw(n);
 flag = true;
 }
 return 0;
}
