#include<stdio.h>
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int n;
void solve()
{
 int rt;
 rt=0;
 if(n>=25)
 {
 rt=n/25;
 n=n%25;
 }
 printf("%d QUARTER(S), ",rt);
 rt=0;
 if(n>=10)
 {
 rt=n/10;
 n=n%10;
 }
 printf("%d DIME(S), ",rt);
 rt=0;
 if(n>=5)
 {
 rt=n/5;
 n=n%5;
 }
 printf("%d NICKEL(S), ",rt);
 printf("%d PENNY(S)\n",n);
 return;
}
int main()
{
 int cs,cnt=0;
 scanf("%d",&cs);
 while(cs--)
 {
 scanf("%d",&n);
 printf("%d ",++cnt);
 solve();
 }
 return 0;
}
