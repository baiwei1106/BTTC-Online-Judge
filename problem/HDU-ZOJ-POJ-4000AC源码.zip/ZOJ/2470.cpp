#include <cmath>
#include <string>
#include <cstdio>
#include <cstring>
#include <stack>
#include <vector>
#include <string>
#include <algorithm>
#include <functional>
#include <queue>
using namespace std;
typedef long long LL;
const double EPS = 1e-8;
const int INF = 0x7f7f7f7f;
const int M = 400005;
const int N = 4010;

struct Edge {
 int u, v, c, next;
} e[M];
stack<int> s;
bool instack[N];
int belong[N], bcnt, dfn[N], low[N], indx;
int head[N], k;

void tarjan(int u) {
 dfn[u] = low[u] = ++indx;
 instack[u] = true;
 s.push(u);
 for (int i = head[u]; i != -1; i = e[i].next) {
 if (!dfn[e[i].v]) {
 tarjan(e[i].v);
 low[u] = min(low[u], low[e[i].v]);
 } else if (instack[e[i].v]) {
 low[u] = min(low[u], low[e[i].v]);
 }
 }
 if (dfn[u] == low[u]) {
 bcnt++;
 int tmp;
 do {
 tmp = s.top();
 s.pop();
 instack[tmp] = false;
 belong[tmp] = bcnt;
 } while (u != tmp);
 }
}

void addEdge(int u, int v) {
 e[k].u = u;
 e[k].v = v;
 e[k].next = head[u];
 head[u] = k++;
}

void init() {
 indx = bcnt = k = 0;
 while (!s.empty()) s.pop();
 memset(head, -1, sizeof(head));
 memset(low, 0, sizeof(low));
 memset(dfn, 0, sizeof(dfn));
 memset(instack, 0, sizeof(instack));
}

void solve(int n) {
 for (int i = 1; i <= n; i++) {
 if (!dfn[i])
 tarjan(i);
 }
}

bool check[N][N];

int main() {
 int n, ki, pc;
 while (~scanf("%d", &n)) {
 init();
 memset(check, 0, sizeof(check));
 for (int i = 1; i <= n; i++) {
 scanf("%d", &ki);
 for (int j = 0; j < ki; j++) {
 scanf("%d", &pc);
 check[i][pc] = true;
 pc += n;
 addEdge(i, pc);
 }
 }
 for (int i = 1; i <= n; i++) {
 scanf("%d", &pc);
 pc += n;
 addEdge(pc, i);
 }
 solve(n << 1);
 for (int i = 1; i <= n; i++) {
 vector<int> d;
 for (int j = n + 1; j <= (n << 1); j++) {
 if (!check[i][j - n]) continue;
 if (belong[i] == belong[j]) {
 d.push_back(j);
 }
 }
 printf("%d", d.size());
 for (unsigned int j = 0; j < d.size(); j++) {
 int vv = d[j] - n;
 printf(" %d", vv);
 }
 printf("\n");
 }
 printf("\n");
 }
 return 0;
}