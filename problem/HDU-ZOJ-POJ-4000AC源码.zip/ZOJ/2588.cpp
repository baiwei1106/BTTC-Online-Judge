#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>
using namespace std;

const int V = 11111;
vector<int> vec[V];
vector<int> ans;
map<int,int> tab;
int dfn[V],low[V];
int n,m;

int hash(int s,int e){
 if(s <= e){
 return s*10000 + e;
 }else{
 return e*10000 + s;
 }
}

void init(int n){
 for(int i = 0 ; i <= n ; i ++){
 vec[i].clear();
 }
 ans.clear();
 tab.clear();
 memset(dfn,0,sizeof(dfn));
 memset(low,0,sizeof(low));
}


void dfs(int cur,int fa,int dept){
 dfn[cur] = low[cur] = dept;
 for(int i = 0 ; i < vec[cur].size() ; i++){
 int tmp = vec[cur][i];
 if(dfn[tmp] != 0 ){
 if(tmp != fa){
 if(dfn[tmp] < low[cur]) low[cur] = dfn[tmp];
 }
 }else{
 dfs(tmp,cur,dept+1);
 if(low[tmp] < low[cur]) low[cur] = low[tmp];
 if(low[tmp] > dfn[cur]) {
 int temp = tab[hash(tmp,cur)];
 if(temp != -1) ans.push_back(temp);
 }
 }
 }
}

void add(int s,int e,int p){
 vec[s].push_back(e);
 vec[e].push_back(s);
 int tmp = hash(s,e);
 if(tab.count(tmp) == 0){
 tab[tmp] = p;
 }else{
 tab[tmp] = -1;
 }
}



int main(){
 int T;
 scanf("%d",&T);
 for(int cas = 0 ; cas < T ; cas++){
 if(cas != 0) puts("");
 scanf("%d%d",&n,&m);
 init(n);
 int s,e;
 for(int i = 0 ; i < m ; i ++){
 scanf("%d%d",&s,&e);
 add(s,e,i+1);
 }
 dfs(1,-1,1);
 
 //for(int i = 1 ; i <= n ; i ++) printf("%d ",dfn[i]); puts("");
 //for(int i = 1 ; i <= n ; i ++) printf("%d ",low[i]); puts("");
 
 sort(ans.begin(),ans.end());
 printf("%d\n",ans.size());
 for(int i = 0 ; i < ans.size() ; i ++){
 if(i == ans.size() - 1) printf("%d\n",ans[i]);
 else printf("%d ",ans[i]);
 }
 }
 return 0;
}
