#include<stdio.h>
#include<string.h>
#include<math.h>
#define LL long long
LL f[20],m,n,mm;
int pri[5]={2,3,5,7,11};
LL oula()
{
 LL ans=f[m];
 if(m>=2)ans=ans/2;
 if(m>=3)ans=ans/3*2;
 if(m>=5)ans=ans/5*4;
 if(m>=7)ans=ans/7*6;
 if(m>=11)ans=ans/11*10;
 return ans;
}
LL modstyle(LL s,LL mod)
{
 if(s>mm)s=s%mod+mod;
 return s;
}
LL powmod(LL a,LL p,LL mod)
{
 LL ans=1;
 while(p)
 {
 if(p&1)ans=modstyle(ans*a,mod);
 a=modstyle(a*a,mod);
 p>>=1;
 }
 return ans;
}
LL solve(LL s,LL p)
{
 LL ans1=s,tmp=p;
 LL ans2=powmod(n,tmp,m)%m,ans3=powmod(n,tmp,mm);
 if(ans1==ans2&&p==ans3)return ans1;
 return solve(ans2,ans3);
}
int main()
{
 f[1]=1;
 for(int i=2;i<=12;i++)
 f[i]=f[i-1]*i;
 int flag = 0;
 while(scanf("%lld%lld",&n,&m)!=-1)
 {
 if(flag) puts("");
 mm=oula();m=f[m];
 LL ans=solve(n,n);
 printf("%lld\n",ans);
 flag = 1;
 }
 return 0;
}
