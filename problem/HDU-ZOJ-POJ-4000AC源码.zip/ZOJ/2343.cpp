#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>

using namespace std;

struct Node {
 int x, y, id;
 int val, com;
 bool operator < (const Node & _n) const {
 //if(com == _n.com) return id > _n.id;
 return com < _n.com;
 }
} p[1005];

int ans[1005];
int n, m, y;

int main()
{
 int T;
 scanf("%d", &T);
 for(int kase=1; kase<=T; kase++) {
 scanf("%d%d%d", &n, &m, &y);
 int x;
 for(int i=0; i<n; i++)
 {
 scanf("%d", &x);
 p[i].id = i + 1;
 p[i].x = x * m;
 p[i].y = y;
 p[i].val = p[i].x / p[i].y;
 p[i].com = p[i].y - 2*p[i].x + 2*p[i].y*p[i].val;
 }

 sort(p, p + n);
 int cur = 0;
 for(int i=0; i<n; i++) {
 cur += p[i].val;
 }
 for(int i=0; i<n; i++) {
 if(cur == m) break;
 cur ++;
 p[i].val ++;
 }
 for(int i=0; i<n; i++) {
 //printf("%d ", p[i].id);
 ans[p[i].id] = p[i].val;
 }
 for(int i=1; i<=n; i++) {
 printf("%d%c", ans[i], i==n?'\n':' ');
 }

 if(kase != T) printf("\n");
 }
 return 0;
}