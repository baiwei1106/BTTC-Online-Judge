#include<cstdio>
bool F[1010];
void init(){
	int n,m,f,s,t,S;
	for(n=0;n<=999;n++){
		m=n;
		t=m%10;
		m/=10;
		s=m%10;
		m/=10;
		f=m;
		S=f*f*f+s*s*s+t*t*t;
		F[n]=(S==n);
	}
}
int main(){
	init();
	int N;
	while(~scanf("%d",&N)){
		printf("%s",F[N]?"Yes\n":"No\n");
	}
	return 0;
}
