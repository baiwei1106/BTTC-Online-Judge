#include <cstdio>
#include <cstring>


const int Bit=1<<15;
const int Mask=Bit-1;
const int BLen=15;
int x[32][32],len[32];
void add(int x[],int &lx,int y[],int ly){
	int i,c=0;
	for(i=0;i<lx || i<ly || c>0;++i){
		x[i]+=y[i]+c;
		c=(x[i]>>BLen);
		x[i]&=Mask;
	}
	lx=i;
}
void mul(int x[],int &lx,int y){
	int i,c=0;
	for(i=0;i<lx || c>0;++i){
		x[i]=x[i]*y+c;
		c=(x[i]>>BLen);
		x[i]&=Mask;
	}
	lx=i;
}
int mod(const int x[],int lx,int m){
	int c=0;
	for(int i=lx-1;i>=0;--i){
		c=((c<<BLen)|x[i])%m;
	}
	return c;
}
int main() {
 int TT;
	scanf("%d",&TT);
 for(int cas=1;cas<=TT;++cas){
 int n,t;
		scanf("%d",&n);
		memset(x[0],0,sizeof(x[0]));
 x[0][0]=1,len[0]=1;
 for(int i=0;i<n-1;++i){
			scanf("%d",&t);
			memset(x[i+1],0,sizeof(x[i+1]));
			x[i+1][0]=1,len[i+1]=1;
 for(int j=i;j>=0;--j){
 mul(x[j],len[j],t);
 if(j>0) add(x[j],len[j],x[j-1],len[j-1]);
 }
 }
 for(int i=0;i<n;++i){
			int m=mod(x[i],len[i],i+1);
 if(m==0)
 printf("0%s",(i<n-1?" ":"\n"));
 else{
 while(m<i+1) m*=10;
 printf("%d%s",m/(i+1),(i<n-1?" ":"\n"));
 }
 }
 }
 return 0;
}
