#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <memory.h>
#include <cstdio>
#include <cmath>
#include <stack>
#include <algorithm>
using namespace std;
const long long MAX=505,INF=1<<30;
long long m,k,a[MAX],sum;
stack<long long> ans;

bool tryIt(const long long &Sum){
 long long s=0,splash=0;
 for(long long i=m-1;i>=0;i--){
 if(i>=(k-1)-splash&&s+a[i]<=Sum){
 s+=a[i];
 }
 else{
 s=a[i];
 if(i==m-1||s>Sum)
 return 0;//ע���ұ߽�
 ++splash;
 }
 }
 if(s>Sum)
 return 0;//ע����߽�
 return splash==k-1;
}

long long bsearch(){
 long long l=0,r=sum+1,m;
 while(l<r){
 m=l+(r-l)/2;
 if(tryIt(m)) r=m;
 else l=m+1;
 }
 return l;
}

int main()
{
 //freopen("i.txt","r",stdin);
 //freopen("castle.in","r",stdin);
 //freopen("castle.out","w",stdout);
 long long s,nCase,p,splash;
 cin>>nCase;
 while(nCase--){
 while(!ans.empty())
 ans.pop();
 sum=0;
 cin>>m>>k;
 for(long long i=0;i<m;i++){
 cin>>a[i];
 sum+=a[i];
 }

 p=bsearch();
 //cout<<p<<endl;
 s=0; splash=0;
 for(long long i=m-1;i>=0;i--){
 if(i>=(k-1)-splash&&s+a[i]<=p){
 s+=a[i];
 }
 else{
 s=a[i];
 ans.push(i);
 ++splash;
 }
 }
 for(long long i=0;i<m;i++){
 if(i)
 cout<<" ";
 cout<<a[i];
 if(!ans.empty()&&i==ans.top()){
 cout<<" /";
 ans.pop();
 }
 }
 cout<<endl;
 }
 return 0;
}

