/*
 * Author: fatboy_cw
 * Created Time:  2011/2/26 12:11:22
 * File Name: N.cpp
 */
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;
#define SZ(v) ((int)(v).size())
typedef unsigned long long lint;
lint n;
queue<lint> Q;

int main() {
    while(scanf("%llu",&n)==1 && n){
        Q=queue<lint>();
        Q.push(1);
        while(!Q.empty()){
            lint num=Q.front();
            Q.pop();
            if(num%n==0){
                printf("%llu\n",num);
                break;
            }
            Q.push(num*10);
            Q.push(num*10+1);
        }
    }
    return 0;
}

