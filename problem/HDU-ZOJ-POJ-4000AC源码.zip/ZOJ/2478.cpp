#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main(){
	int N;
	cin>>N;
	while(N--){
		char s[105];
		cin>>s;
		int len=strlen(s);
		int cnt=1;
		for(int i=0;i<len;i++){
			if(s[i]==s[i+1])cnt++;
			else {
				if(cnt!=1) cout<<cnt;
				 cout<<s[i];
				 cnt=1;
			}
		}
		printf("\n");
	}
	return 0;
}