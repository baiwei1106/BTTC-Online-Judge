/*
 * ee.cpp
 *
 * Created on: 2012-7-10
 * Author: Administrator
 */

#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n;
int dp[22][22][22][111];
char card[111];
int value[111];
int main() {
	while (cin >> n && n) {
		memset(dp, -1, sizeof(dp));
		for (int i = 0; i != n; i++) {
			cin >> card[i];
			if (card[i] >= '1' && card[i] <= '9')
				value[i] = card[i] - '0';
			else
				if(card[i]=='A')
					value[i]=1;
			else if (card[i] != 'F')
				value[i] = 10;
			else
				value[i] = 21;
		}
		dp[0][0][0][0] = 0;
		for (int l = 0; l != n; l++)
			for (int i = 0; i < 22; i++)
				for (int j = 0; j < 22; j++)
					for (int k = 0; k < 22; k++) {
						if (dp[i][j][k][l] == -1)
							continue;
						//i
						if (i != 21) {
							if (value[l] == 21 || (i + value[l] == 21))
								dp[0][j][k][l + 1] = max(dp[0][j][k][l + 1],
										dp[i][j][k][l] + 150);
							else if (i + value[l] > 21) {
								dp[21][j][k][l + 1] = max(dp[21][j][k][l + 1],
										dp[i][j][k][l] + 50);
							} else {
								dp[i + value[l]][j][k][l + 1] = max(
										dp[i + value[l]][j][k][l + 1],
										dp[i][j][k][l] + 50);
							}
						}
						//j
						if (j != 21) {
							if (value[l] == 21 || (j + value[l] == 21))
								dp[i][0][k][l + 1] = max(dp[i][0][k][l + 1],
										dp[i][j][k][l] + 250);
							else if (j + value[l] > 21) {
								dp[i][21][k][l + 1] = max(dp[i][21][k][l + 1],
										dp[i][j][k][l] + 50);
							} else {
								dp[i][j + value[l]][k][l + 1] = max(
										dp[i][j + value[l]][k][l + 1],
										dp[i][j][k][l] + 50);
							}
						}
						//k
						if (k != 21) {
							if (value[l] == 21 || (k + value[l] == 21))
								dp[i][j][0][l + 1] = max(dp[i][j][0][l + 1],
										dp[i][j][k][l] + 350);
							else if (k + value[l] > 21) {
								dp[i][j][21][l + 1] = max(dp[i][j][21][l + 1],
										dp[i][j][k][l] + 50);
							} else {
								dp[i][j][k + value[l]][l + 1] = max(
										dp[i][j][k + value[l]][l + 1],
										dp[i][j][k][l] + 50);
							}
						}
					}
		int ans=-1;
		for (int l = 0; l <= n; l++)
			for (int i = 0; i < 22; i++)
				for (int j = 0; j < 22; j++)
					for (int k = 0; k < 22; k++)
						ans=max(ans,dp[i][j][k][l]);
		cout<<ans<<endl;
	}
}
