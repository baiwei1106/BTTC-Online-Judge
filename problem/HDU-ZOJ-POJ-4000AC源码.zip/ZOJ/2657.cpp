#include <stdio.h>
#include <string.h>
#define llt long long

llt extended_gcd(llt a,llt b,llt &x,llt &y)
{
	llt res,t;
	if(b==0) {res=a;x=1;y=0;}
	else {
		res=extended_gcd(b,a%b,x,y);
		t=x;x=y;y=t-(a/b)*y;
	}
	return res;
}

void equation(llt a,llt b,llt n)
{
	llt x,y,e;
	//printf("a=%d n=%d x=%d y=%d\n",a,n,x,y);
	if(a<0) a=-a,b=-b;
	while(b<0) b+=n;
	//printf("a=%d n=%d x=%d y=%d\n",a,n,x,y);
	llt d=extended_gcd(a,n,x,y);
	//printf("a=%d n=%d x=%d y=%d\n",a,n,x,y);
	//printf("b=%d d=%d\n",b,d);
	if(b%d) printf("Pat\n");
	else
	{
		e=x*(b/d)%n;
		if(e<0) e+=n;
		printf("%lld\n",e);
	}
	/*
	for(int i=0;i<=d-1;i++)
	{
		int t=(e+i*n/d)%n;
		printf("%d\n",t);
	}
	*/
}

int main()
{
	llt x,y,m,n,l;
	while(scanf("%lld%lld%lld%lld%lld",&x,&y,&m,&n,&l)!=EOF)
	{
		equation(n-m,x-y,l);
	}

	return 0;
}