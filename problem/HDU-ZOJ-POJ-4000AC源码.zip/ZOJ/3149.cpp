#include<stdio.h>
#include<iostream>
using namespace std;
#define MAXN 1234567890
int N,K;
typedef long long LL;
LL f[100];
int main()
{
	while(cin>>N>>K){
		if(N==0)break;
		if(K==0){
			cout<< min((N-1),MAXN+1) <<endl;
		}
		else if(K==1){
			LL tmp=(LL)N*(N-1)/2;
			cout<< min( tmp,1234572895ll) << endl;
		}
		else{
			f[0]=0;
			LL ans=0;
			for(int i=1;i<N;i++){
				f[i]=i;
				for(int j=i-1;j>=0&&j>=i-K;j--)
					f[i]+=f[j];
				ans=f[i];
				if(f[i]>MAXN)break;
			}
			cout<<ans<<endl;
		}
	}
	return 0;
}
