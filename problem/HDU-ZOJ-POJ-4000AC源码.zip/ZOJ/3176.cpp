#include<cstdio>
#include<algorithm>

#define MAXX 1111

char ot[4][22]={"Neither","Rounding","Truncation","Either"};
char buf[333];

int T;
int n;

int m[MAXX],p[MAXX];

int i,j,k;
int ans;
int l,r,a,b;

int main()
{
 scanf("%d",&T);
 while(T--)
 {
 ans=0;
 scanf("%d",&n);
 for(i=0;i<n;++i)
 {
 scanf("%d %d",m+i,p+i);
 gets(buf);
 }
 l=0;
 r=1<<30;
 for(i=0;i<n;++i)
 {

 if(p[i]<100)
 a=200*m[i]/(2*p[i]+1)+1;
 else
 a=200*m[i]/(2*p[i]);

 if(p[i]>0)
 b=200*m[i]/(2*p[i]-1);
 else
 b=r;
// b=200*m[i]/(2*p[i]);
 l=std::max(l,a);
 r=std::min(r,b);
// printf("%d %d\n",a,b);
 }
 if(l<=r)
 ans|=1;
// printf("%d %d\n",l,r);
 
 l=0;
 r=1<<30;
 for(i=0;i<n;++i)
 {
 if(p[i]!=100)
 {
 a=100*m[i]/(p[i]+1)+1;
 if(p[i])
 b=100*m[i]/p[i];
 else
 b=r;
 }
 else
 a=b=m[i];
 l=std::max(l,a);
 r=std::min(r,b);
 }
 if(l<=r)
 ans|=2;
// printf("%d %d\n",l,r);
 puts(ot[ans]);
 }
 return 0;
}