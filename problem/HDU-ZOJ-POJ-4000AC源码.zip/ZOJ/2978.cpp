#include <stdio.h>
#include <cstring>
#include <algorithm>
#include <math.h>
#include <vector>
using namespace std;

const double eps = 1e-8;
const double pi = acos(-1.0);
int cmp(double x)
{
	if (fabs(x) < eps) return 0;
	if (x > 0) return 1;
	return -1;
}
inline double sqr(double x){return x*x;}
struct point
{
	double x,y;
	point(){}
	point(double a, double b):x(a), y(b){}
	void input()
	{
		scanf("%lf%lf",&x,&y);
	}
	friend point operator + (const point &a, const point &b)
	{
		return point(a.x+b.x, a.y+b.y);
	}
	friend point operator - (const point &a, const point &b)
	{
		return point(a.x-b.x, a.y-b.y);
	}
	friend point operator * (const point &a, const double &b)
	{
		return point(a.x*b, a.y*b);
	}
	friend point operator * (const double &a, const point &b)
	{
		return point(a*b.x, a*b.y);
	}
	friend bool operator == (const point &a, const point &b)
	{
		return cmp(a.x-b.x)==0 && cmp(a.y-b.y)==0;
	}
	double norm()
	{
		return sqrt(sqr(x) + sqr(y));
	}
};

bool cmp_less(pair<double, int> p, pair<double, int> q)
{
	if (cmp(p.first - q.first) != 0) return cmp(p.first - q.first)<=0;
	return p.second>q.second;
}

vector<point> q;
vector<pair<double,int> > que;
int n,r;

double norm(double x)
{
	while(cmp(x)<0) x+=2*pi;
	while(cmp(x-2*pi)>=0) x-=2*pi;
	return x;
}

void solve(double r)
{
	int ans=1;
	r*=2.0;
	for (int i=0; i<q.size(); i++)
	{
		que.clear();
		for (int j=0; j<q.size(); j++)
		{
			double dis=(q[i]-q[j]).norm();
			if (i==j || cmp(dis-r)>0) continue;
			if (cmp(dis) == 0)
			{
				que.push_back(make_pair(0, 1));
				que.push_back(make_pair(0, -1));
				continue;
			}
			double a = norm(atan2((q[j]-q[i]).y, (q[j]-q[i]).x));
			double b = acos(dis/r);
			double c = norm(a-b);
			double d = norm(a+b);
			if (cmp(c-d)>0)
			{
				que.push_back(make_pair(c, 1));
				que.push_back(make_pair(2*pi, -1));
				que.push_back(make_pair(0, 1));
				que.push_back(make_pair(d, -1));
			}
			else
			{
				que.push_back(make_pair(c, 1));
				que.push_back(make_pair(d,-1));
			}
		}
		sort(que.begin(), que.end(), cmp_less);
		int ret=1;
		for (int i=0; i<que.size(); i++)
		{
			ret+=que[i].second;
			ans = max(ans, ret);
		}
	}
	printf("It is possible to cover %d points.\n", ans);
}

int main()
{
	while(scanf("%d%d",&n,&r)!=EOF)
	{
		if (n==0 && r==0) break;
		q.clear();
		for (int i=0; i<n; i++)
		{
			point tmp;
			tmp.input();
			q.push_back(tmp);
		}
		solve(r);
	}
	return 0;
}