#include <cstdio>
#include <cstring>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>

using namespace std;

int dp[1<<16] ;
int n , m ;

int main(){
 while (scanf("%d%d",&n,&m)==2){
 for (int i = 0 ; i < (1<<n) ; i++)
 dp[i]=0;
 for (int i = 0 ; i < m ; i++){
 int k = 0 , st = 0 ;
 scanf("%d",&k);
 for (int j = 0 ; j < k ; j++){
 int tmp ; scanf("%d",&tmp);
 st |= (1<<(tmp-1)) ;
 }
 dp[st]=1 ;
 }
 int ans=0;
 for (int i = 1 ; i <(1<<n) ; i++){
 for (int j = (i-1)&i ; j != 0 ; j = (j-1)&i){
 dp[i] = max(dp[i] , dp[j] + dp[i^j]);
 }
 ans = max(ans,dp[i]);
 }
 printf("%d\n",ans);
 }
 return 0 ;
}
