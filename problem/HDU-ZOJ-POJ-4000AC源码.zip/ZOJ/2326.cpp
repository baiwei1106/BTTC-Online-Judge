#include <cstdio>
#include <iostream>
#include <algorithm>
#include <map>
#include <cstdlib>
#include <string>
#include <cstring>
using namespace std;

#define E 111111

struct Edge {
	int u, v; 
	double len;
};

int n, m;
map <string, int> id;
int idx, fa[E];
double tot;
char s1[30], s2[30];
Edge eg[E];

int ID(char *s) {
	if (id[s] == 0) id[s] = ++idx;
	return id[s];
}

bool cmp(const Edge &x, const Edge &y) {
	return x.len < y.len;
}

int find(int x) {
	if (fa[x] != x) fa[x] = find(fa[x]);
	return fa[x];
}

void Union(int x, int y) {
	fa[find(x)] = find(y);
}

int main() {
	idx = 0;
	scanf("%lf", &tot);
	scanf("%d", &n);
	for (int i = 0; i < n; ++i) {
		fa[i + 1] = i + 1;
		scanf("%s", s1);
		ID(s1);
	}
	scanf("%d", &m);
	for (int i = 0; i < m; ++i) {
		scanf("%s%s%lf", s1, s2, &eg[i].len);
		eg[i].u = ID(s1), eg[i].v = ID(s2);
	}
	sort(eg, eg + m, cmp);
	double ans = 0;
	for (int i = 0; i < m; ++i) {
		if (find(eg[i].u) != find(eg[i].v)) {
			Union(eg[i].u, eg[i].v);
			ans += eg[i].len;
		}
	}
	if (ans > tot) {
		puts("Not enough cable ");
		return 0;
	}
	int cnt = 0;
	int t = find(1);
	for (int i = 1; i <= n; ++i) {
		if (find(i) != t) {
			puts("Not enough cable ");
			return 0;
		}
	}
	printf("Need %.1f miles of cable\n", ans);
	return 0;
}