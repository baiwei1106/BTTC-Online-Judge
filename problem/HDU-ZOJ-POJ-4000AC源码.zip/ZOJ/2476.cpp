#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<algorithm>
using namespace std;
#define N 10010
int a[N],b[N];
int n;
char s[16];
int main()
{
 while(scanf("%d",&n)&&n)
 {
 int i,j,l,tag;
 memset(a,0,sizeof(a));
 memset(b,0,sizeof(b));

 for(i=0;i<n;i++)
 {
 scanf("%s",s);
 l=strlen(s);
 tag=1;
 for(j=1;j<l;j++)
 {
 if(s[j]==',')
 continue;
 if(s[j]=='.')
 {
 tag=0;
 continue;
 }
 if(tag)
 a[i]=a[i]*10+(s[j]-'0');
 else
 b[i]=b[i]*10+(s[j]-'0');
 }
 }
 int ans1=0;
 int ans2=0;
 for(i=0;i<n;i++)
 {
 ans1+=a[i];
 ans2+=b[i];
 }
 char p[16];
 ans1+=ans2/100;
 ans2%=100;
 printf("$");
 sprintf(p,"%08d",ans1);
 int flag=-1;
 for(i=0;i<8;i++)
 {
 if(p[i]!='0')
 {
 flag=i;break;
 }
 }
 if(flag==-1)
 printf("0");
 else
 {
 for(i=flag;i<8;i++)
 {
 printf("%c",p[i]);
 if(i==1||i==4)
 printf(",");
 }
 }
 printf(".%02d\n",ans2);
 }
}
