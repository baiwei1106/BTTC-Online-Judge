#include<iostream>
using namespace std;
int main(){
 long i,times,ans=0,a,n;
 cin>>times;
 for(;times>0;times--){
 ans = 0;
 cin>>n;
 for(i=1;i<=n;i++){
 cin>>a;
 ans += a;
 }
 ans = ans<0?0:ans;
 cout<<ans<<endl;
 }

}
