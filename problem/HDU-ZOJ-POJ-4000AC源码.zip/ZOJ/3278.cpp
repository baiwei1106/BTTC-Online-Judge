#include"stdio.h"
#include"algorithm"
using namespace std;
typedef long long ll;
int n,m;
ll k;
ll M[100010],N[100010];
int find(ll now,ll max)
{
 int ans=0;
 ll L=0,R=m-1;
 ll mid;
 while(L<=R)
 {
 mid=(L+R)/2;
 if(M[mid]*now>=max)
 {
 ans+=mid-L+1;
 L=mid+1;
 }
 else
 R=mid-1;
 }
 return ans;
}
bool check(ll max)
{
 ll ans=0;
 for(int i=0;i<n;i++)
 {
 ans+=find(N[i],max);
 if(ans>=k)
 return true;
 }
 return false;
}
ll BinarySearch(ll L,ll R)
{
 ll mid,ans=-1;
 while(L<=R)
 {
 mid=(L+R)/2;
 if(check(mid))
 {
 L=mid+1;
 ans=mid;
 }
 else
 R=mid-1;
 }
 return ans;
}
int main()
{
 while(~scanf("%d %d %lld",&n,&m,&k))
 {
 for(int i=0;i<n;i++) scanf("%d",&N[i]);
 for(int i=0;i<m;i++) scanf("%d",&M[i]);
 sort(N,N+n);sort(M,M+m);
 reverse(N,N+n);reverse(M,M+m);
 printf("%lld\n",BinarySearch(0,N[0]*M[0]));
 }
 return 0;
}
