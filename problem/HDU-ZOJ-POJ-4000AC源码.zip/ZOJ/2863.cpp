#include<iostream>
#include<cstring>
#include<cstdio>
#include<string>
#include<queue>
#include<map>
#include<algorithm>
using namespace std;
#define ll long long
#define inf 100000000000LL
#define M 4000
#define N 400
int vv[M], nxt[M], h[N], e;
int pre[N], vis[N];
int mp[20][20];
const int ee[8]={-1,-1,-1,0,1,1,1,0};
const int r[8]={-1,0,1,1,1,0,-1,-1};
void add( int u, int v )
{
	vv[e] = v, nxt[e] = h[u], h[u] = e++;
}
bool inmap(int x,int y)
{
	return x<16&&x&&y&&y<16;
}
bool dfs( int u )
{
	for( int i = h[u]; i+1; i = nxt[i] ){
		if( vis[vv[i]] ) continue;
		int v = vv[i];
		vis[v] = 1;
		if( pre[v] == -1 || dfs(pre[v]) ){
			pre[v] = u;
			return 1;
		}
	}
	return 0;
}
int solve( int n )
{
	memset( pre, -1, sizeof(pre) );
	for( int i = 1; i <= n; ++i ){
		memset( vis, 0, sizeof(vis) );
		if( !dfs(i) ) return 0;
	}
	return 1;
}

int main()
{
	int n,T, t;
	scanf("%d",&T);
	for (int tt=1;tt<=T;tt++)
	{
		memset(h,-1,sizeof(h));
		e=0;
		int cnt=1;
		for (int i=1;i<=15;i++)
			for (int j=1;j<=15;j++)
			{
				scanf("%d",&mp[i][j]);
				if (mp[i][j]==1)
				{
					mp[i][j]=cnt;
					cnt+=2;
				}
			}
		n=0;
		int x,y;
		for (int i=1;i<=15;i++)
			for (int j=1;j<=15;j++)
				if (mp[i][j]&&(mp[i][j]%2==0))
				{
					t=mp[i][j]/2;
					if (t>n) n=t;
					for (int ii=0;ii<8;ii++)
					{
						x=i+ee[ii];
						y=j+r[ii];
						if (!inmap(x,y)) continue;
						if (mp[x][y]%2)
						add(t,(mp[x][y]+1)/2);
					}
				}
 printf( "Round #%d:\n", tt );
		if (!solve(n)) printf("No solution.\n");
		else
		for (int i=1;i<=15;i++)
			for (int j=1;j<=15;j++)
			{
				if (mp[i][j]%2)
				{
					int temp=(mp[i][j]+1)/2;
					if (pre[temp]==-1) printf("%d",cnt);
					else
					printf("%d",pre[temp]*2-1);
				}
				else
					printf("%d",mp[i][j]);
				if (j<15) printf(" ");
				else
					printf("\n");
			}
 puts("");
	}
}
