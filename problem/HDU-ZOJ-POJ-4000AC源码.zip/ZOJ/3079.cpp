/*
 * Author: mybestwishes
 * Created Time: 2011/7/31 23:12:10
 * File Name: zoj3079.cpp
 */
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <string>
#include <vector>
#include <map>
#include <stack>
#include <queue>
#include <set>
#include <time.h>
using namespace std;
typedef long long lint;
vector <string> words ; 

bool space(char c){
 if(c == '\n' || c == ' ' || c == '\t')
 return true ;
 else return false ;
}
bool punct(char c){
 if(c == '.' || c == '?' || c == '!')
 return true ;
 else return false ;
}
bool bd(char c){
 if(punct(c) || c == ',')
 return true ;
 else return false ;
}
bool letter(char c){
 if(space(c) || bd(c))
 return false ;
 else return true ;
}
void caplock(string& s){ //ת������ĸΪ��д
 int len = s.length() ;
 int first = 1 ;
 int tag = 0 ;
 for(int i = 0 ; i < len ; i++){
 if(letter(s[i])){
 if(first == 1 || tag == 1){
 if(s[i] > 'Z')
 s[i] -= 32 ;
 first = 0 ; 
 tag = 0 ; 
 }
 }
 else{
 if(punct(s[i]))
 tag = 1 ; 
 }
 }
}
string del_line(string s){ //�ϲ��������ӷ�
 string tmp ; 
 tmp.clear() ;
 int len = s.length() ;
 for(int i = 0 ; i < len ; i++){
 if(s[i] == '-'){
 i++ ;
 while(space(s[i])){
 i++ ;
 }
 tmp = tmp + s[i] ;
 }
 else
 tmp = tmp + s[i] ;
 }
 return tmp ;
}

void get_word(string s){
 int len = s.length() ;
 string tmp ;
 tmp.clear() ;
 for(int i = 0 ; i < len ; i++){
 if(space(s[i])){
 if(tmp.length() != 0){
 words.push_back(tmp) ;
 tmp.clear() ;
 }
 }
 else{
 if(letter(s[i])){
 tmp += s[i] ;
 }
 else{
 if(tmp.length() != 0){
 words.push_back(tmp) ;
 tmp.clear() ;
 }
 tmp = s[i] ;
 words.push_back(tmp) ;
 tmp.clear() ;
 }
 }
 }
}
void print(){
 int len = words.size() ;
 int cnt = 0 ; 
 for(int i = 0 ; i < len ; i++){
 int k = words[i].length() ; 
 int tag = 0 ; 
 if(i+1 < len && bd(words[i+1][0])){
 if(cnt > 0){
 if(cnt+2+k <= 80){
 cout<<" "<<words[i]<<words[i+1] ;
 cnt += 2 + k ;
 }
 else{
 cout<<endl;
 cout<<words[i]<<words[i+1] ;
 cnt = k+1 ; 
 }
 }
 else{
 cout<<words[i]<<words[i+1] ;
 cnt = 1+k ;
 }
 i++ ;
 tag = 1 ; 
 }
 if(tag == 0){
 if(cnt > 0){
 if(cnt+1+k <= 80){
 cout<<" "<<words[i] ;
 cnt += k+1 ;
 }
 else{
 cout<<endl;
 cout<<words[i] ;
 cnt = k ;
 }
 }
 else{
 cout<<words[i];
 cnt = k ; 
 }
 }
 }
 cout<<endl;
}
int main() {
 int T ;
 //freopen("1.txt" , "w" , stdout) ;
 cin>>T ;
 for(int i = 0 ; i < T ; i++){
 string s , tmp ; 
 s.clear() ; tmp.clear() ;
 words.clear() ;
 while(true){
 getline(cin , tmp) ;
 if(tmp == "###") break ;
 s = s + tmp + " " ;
 }
 caplock(s) ;
 s = del_line(s) ;
 get_word(s) ;
 print() ;
 if(i != T-1)
 cout<<endl;
 }
 return 0;
}
