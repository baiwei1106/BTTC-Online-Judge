/*
 * Author: chlxyd
 * Created Time: 2013/7/25 13:36:38
 * File Name: G.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )
int n ;
char s[110][110] ;
bool check( int i ) {
 if ( i == 1 ) {
 int now = -1 ;
 repd( j , n , 1 ) {
 int a = j , b = j * 2 - 1 ;
 int last = s[a][b] , ret = 2 + s[a][b] ;
 while ( a <= n ) {
 if ( b % 2 == 0 ) b -- ;
 else {
 a ++ ; b ++ ;
 }
 if ( a > n ) break ;
 if ( s[a][b] != last ) 
 ret = ret * 2 + s[a][b] ;
 last = s[a][b] ;
 if ( ret > 7 ) return false ;
 }
 if ( ret == 2 || ret == 3 ) continue ; 
 if ( now == -1 ) now = ret ;
 if ( now != ret ) return false ;
 }
 return true ;
 } 
 else if ( i == 2 ) {
 int now = -1 ;
 repf( j , 1 , n ) {
 int a = j , b = 1 ;
 int last = s[a][b] , ret = 2 + s[a][b] ;
 while ( a <= n ) {
 if ( b % 2 == 0 ) b ++ ;
 else {
 a ++ ; b ++ ;
 }
 if ( a > n ) break ;
 if ( s[a][b] != last ) 
 ret = ret * 2 + s[a][b] ;
 last = s[a][b] ;
 if ( ret > 7 ) {
 //cout<<ret<<endl;
 return false ;
 }
 }
 //cout<<ret<<endl;
 if ( ret == 2 || ret == 3 ) continue ; 
 if ( now == -1 ) now = ret ;
 if ( now != ret ) return false ;
 }
 return true ;
 } 
 else if ( i == 3 ) {
 int now = -1 ;
 repf( j , 1 , n ) {
 int a = j , b = 1 ;
 int last = s[a][b] , ret = 2 + s[a][b] ;
 while ( b <= j*2-1 ) {
 b ++ ;
 if ( b > j * 2 - 1 ) break ;
 if ( s[a][b] != last ) 
 ret = ret * 2 + s[a][b] ;
 last = s[a][b] ;
 if ( ret > 7 ) {
 //cout<<ret<<endl;
 return false ;
 }
 }
 if ( ret == 2 || ret == 3 ) continue ; 
 if ( now == -1 ) now = ret ;
 //cout<<now<<" "<<ret<<endl;
 if ( now != ret ) return false ;
 }
 return true ;
 }
}
int main(){
 int ca = 0 ;
 while ( scanf("%d" , &n ) == 1 ) {
 clr(s) ;
 if ( n == 0 ) return 0 ;
 repf( i , 1 , n ) 
 scanf("%s" , s[i] + 1 ) ;
 repf( i , 1 , n ) 
 repf( j , 1 , i * 2 - 1 )
 s[i][j] -= '0' ;
 printf("Puzzle %d\n" , ++ca ) ;
 if ( check(1) || check(2) || check(3) ) 
 puts("Parts can be separated");
 else puts("Parts cannot be separated");
 }
}
