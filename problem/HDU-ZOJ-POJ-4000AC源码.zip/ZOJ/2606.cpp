#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <vector>
#include <map>
#define maxn 5050
#define ll long long
using namespace std;

const char Month[13][10] = {"", "January", "February", "March", "April",
 "May", "June", "July", "August", "September", "October", "November", "December"
 };
map<string,int> mm;
int TO,FROM;
int sum_leap[2500];

bool is_leap(int y)
{
 if (y % 4 == 0 && y % 100 != 0 || y % 400 == 0) return true;
 return false;
}
int dp[110][110];
int pre[110][110];
struct Date
{
 int m,d;
 bool operator<(const Date& rhs)const
 {
 if(m==rhs.m)
 {
 return d<rhs.d;
 }
 return m<rhs.m;
 }
 bool operator==(const Date& rhs)const
 {
 return m==rhs.m&&d==rhs.d;
 }

} d1[110],d2[110];
int N;
int sy[110];
void init()
{
 int i,j;
 mm.clear();
 mm["January"]=1;
 mm["February"]=2;
 mm["March"]=3;
 mm["April"]=4;
 mm["May"]=5;
 mm["June"]=6;
 mm["July"]=7;
 mm["August"]=8;
 mm["September"]=9;
 mm["October"]=10;
 mm["November"]=11;
 mm["December"]=12;
 sum_leap[0]=0;
 for(i=1; i<=2300; i++)
 {
 if(is_leap(i))
 {
 sum_leap[i]=sum_leap[i-1]+1;
 }
 else
 {
 sum_leap[i]=sum_leap[i-1];
 }
 }
}
void read()
{
 int i,j;
 for(i=0; i<N; i++)
 {
 string s1,s2,s3,s4,s5;
 cin>>s1>>s2>>s3>>s4>>s5;
 d1[i].m=mm[s1];
 if(s2.size()==2)
 {
 d1[i].d=s2[0]-'0';
 }
 else
 {
 d1[i].d=(s2[0]-'0')*10+s2[1]-'0';
 }
 if(s3=="added")
 {
 sy[i]=1;
 }
 else
 {
 sy[i]=-1;
 }
 d2[i].m=mm[s4];
 if(s5.size()==1)
 {
 d2[i].d=s5[0]-'0';
 }
 else
 {
 d2[i].d=(s5[0]-'0')*10+s5[1]-'0';
 }
 }
}
void print(int cur,int u)
{
 if(cur<0) return;
 print(cur-1,pre[cur][u]);
 printf("%s %d %d, ",Month[d1[cur].m],d1[cur].d,TO+u);
 if(sy[cur]==1)
 {
 printf("added ");
 }
 else
 {
 printf("removed ");
 }
 printf("%s %d\n",Month[d2[cur].m],d2[cur].d);
}

int main()
{
 //freopen("input.txt","r",stdin);
 int i,j,k;
 int T;
 init();
 scanf("%d",&T);
 while(T--)
 {
 scanf("%d %d",&TO,&FROM);
 scanf("%d",&N);
 read();
 int tot=FROM-TO+1;
 memset(dp,-1,sizeof(dp));
 for(i=0; i<tot; i++)
 {
 if(d1[0].m==2&&d1[0].d==29&&!is_leap(TO+i))
 {
 continue;
 }
 if(d2[0].m==2&&d2[0].d==29)
 {
 if(d1[0]<d2[0])
 {
 dp[0][i]=sum_leap[FROM]-sum_leap[TO+i-1];
 }
 else
 {
 dp[0][i]=sum_leap[FROM]-sum_leap[TO+i];
 }
 }
 else
 {
 if(d1[0]<d2[0])
 {
 dp[0][i]=FROM-(TO+i)+1;
 }
 else
 {
 dp[0][i]=FROM-(TO+i);
 }
 }

 }

 for(i=1; i<N; i++)
 {
 for(j=0; j<tot; j++)
 {
 int temp;
 if(d1[i].m==2&&d1[i].d==29&&!is_leap(TO+j))
 {
 continue;
 }
 if(d2[i].m==2&&d2[i].d==29)
 {
 if(d1[i]<d2[i])
 {
 temp=sum_leap[FROM]-sum_leap[TO+j-1];
 }
 else
 {
 temp=sum_leap[FROM]-sum_leap[TO+j];
 }
 }
 else
 {
 if(d1[i]<d2[i])
 {
 temp=FROM-(TO+j)+1;
 }
 else
 {
 temp=FROM-(TO+j);
 }
 }


 for(k=0; k<=j; k++)
 {
 if(k==j&&(d1[i]<d1[i-1]||d1[i]==d1[i-1])) continue;
 if(dp[i-1][k]==-1) continue;
 if(dp[i][j]<dp[i-1][k]+sy[i]*temp)
 {
 dp[i][j]=dp[i-1][k]+sy[i]*temp;
 pre[i][j]=k;
 }
 }
 }
 }

 int ans=-1;
 int end;
 for(i=0; i<tot; i++)
 {
 if(ans<dp[N-1][i])
 {
 ans=dp[N-1][i];
 end=i;
 }
 }
 if(ans!=-1)
 {
 printf("%d\n",ans);
 print(N-1,end);
 }
 else
 {
 puts("-1");
 }
 if(T)
 {
 puts("");
 }
 }
 return 0;
}
