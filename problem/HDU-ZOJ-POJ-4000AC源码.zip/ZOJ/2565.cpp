/*
 * Author: Eyelids
 * Created Time: 2013/7/30 14:08:36
 * File Name: g.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )
int x[110];
int f[110][30];
int last[110][30], w[110][110];
int n, m;
vector <int> ret;

int main() {
 while(scanf("%d%d", &n, &m) == 2) {
 for (int i = 1; i <= n - 1; i ++)
 scanf("%d", &x[i]);
 for (int i = 1; i <= m; i ++)
 for (int j = 1; j <= m; j ++)
 scanf("%d", &w[i][j]);
 
 memset(f, -1, sizeof(f));
 memset(last, 0, sizeof(last));
 for (int i = 1; i <= m; i ++)
 f[1][i] = 0;
 
 int Min = 100000000, t = 0;
 for (int i = 1; i <= n - 1; i ++)
 for (int j = 1; j <= m; j ++) {
 if (f[i][j] == -1) continue;
 
 for (int k = 1; k <= m; k ++)
 if (abs(w[j][k] - x[i]) + f[i][j] < f[i + 1][k] || f[i + 1][k] == -1) {
 f[i + 1][k] = abs(w[j][k] - x[i]) + f[i][j];
 last[i + 1][k] = j;
 
 //cout <<i<<" "<<j<<" "<<f[i][j]<<" "<<i + 1<<" "<<k<<" "<<f[i + 1][k]<<endl; 
 if (i + 1 == n && f[i + 1][k] < Min) {
 //cout <<i + 1<<" "<<k<<" "<<f[i + 1][k]<<endl;
 Min = f[i + 1][k];
 t = k;
 }
 }
 }
 
 //cout <<Min<<" "<<t<<endl; 
 ret.clear();
 for (int i = n; i >= 1; i --) {
 ret.push_back(t);
 t = last[i][t];
 }
 
 for (int i = (int)ret.size() - 1; i >= 0; i --)
 printf("%c", (char)ret[i] - 1 + 'a');
 printf("\n"); 
 }
 
 return 0;
}











