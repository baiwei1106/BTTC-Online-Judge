//By Brickgao
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
using namespace std;
#define out(v) cerr << #v << ": " << (v) << endl
#define SZ(v) ((int)(v).size())
const int maxint = -1u>>1;
template <class T> bool get_max(T& a, const T &b) {return b > a? a = b, 1: 0;}
template <class T> bool get_min(T& a, const T &b) {return b < a? a = b, 1: 0;}

vector <string> v;
int t;
char st[100000];

int main() {
 scanf("%d", &t);
 getchar();
 while(t --) {
 v.clear();
 gets(st);
 int len = strlen(st);
 string tmp;
 for(int i = 0; i < len; i ++) {
 if(st[i] == ' ') {
 v.push_back(tmp);
 tmp = "";
 continue;
 }
 tmp += st[i];
 }
 v.push_back(tmp);
 len = SZ(v);
 int rec = 0, ans = 0;
 for(int i = 0; i < len; i ++) {
 if(v[i] == "one" && i + 1 < len && v[i + 1] == "hundred") {
 rec += 100;
 continue;
 }
 if(v[i] == "two" && i + 1 < len && v[i + 1] == "hundred") {
 rec += 200;
 continue;
 }
 if(v[i] == "three" && i + 1 < len && v[i + 1] == "hundred") {
 rec += 300;
 continue;
 }
 if(v[i] == "four" && i + 1 < len && v[i + 1] == "hundred") {
 rec += 400;
 continue;
 }
 if(v[i] == "five" && i + 1 < len && v[i + 1] == "hundred") {
 rec += 500;
 continue;
 }
 if(v[i] == "six" && i + 1 < len && v[i + 1] == "hundred") {
 rec += 600;
 continue;
 }
 if(v[i] == "seven" && i + 1 < len && v[i + 1] == "hundred") {
 rec += 700;
 continue;
 }
 if(v[i] == "eight" && i + 1 < len && v[i + 1] == "hundred") {
 rec += 800;
 continue;
 }
 if(v[i] == "nine" && i + 1 < len && v[i + 1] == "hundred") {
 rec += 900;
 continue;
 }
 //
 if(v[i] == "one")
 rec += 1;
 if(v[i] == "two")
 rec += 2;
 if(v[i] == "three")
 rec += 3;
 if(v[i] == "four")
 rec += 4;
 if(v[i] == "five")
 rec += 5;
 if(v[i] == "six")
 rec += 6;
 if(v[i] == "seven")
 rec += 7;
 if(v[i] == "eight")
 rec += 8;
 if(v[i] == "nine")
 rec += 9;
 if(v[i] == "ten")
 rec += 10;
 if(v[i] == "eleven")
 rec += 11;
 if(v[i] == "twelve")
 rec += 12;
 if(v[i] == "thirteen")
 rec += 13;
 if(v[i] == "fourteen")
 rec += 14;
 if(v[i] == "fifteen")
 rec += 15;
 if(v[i] == "sixteen")
 rec += 16;
 if(v[i] == "seventeen")
 rec += 17;
 if(v[i] == "eighteen")
 rec += 18;
 if(v[i] == "nineteen")
 rec += 19;
 //
 if(v[i] == "twenty")
 rec += 20;
 if(v[i] == "thirty")
 rec += 30;
 if(v[i] == "forty")
 rec += 40;
 if(v[i] == "fifty")
 rec += 50;
 if(v[i] == "sixty")
 rec += 60;
 if(v[i] == "seventy")
 rec += 70;
 if(v[i] == "eighty")
 rec += 80;
 if(v[i] == "ninety")
 rec += 90;
 //
 if(v[i] == "thousand") {
 rec *= 1000;
 ans += rec;
 rec = 0;
 }
 if(v[i] == "million") {
 rec *= 1000000;
 ans += rec;
 rec = 0;
 }
 }
 ans += rec;
 printf("%d\n", ans);
 }
 return 0;
}
