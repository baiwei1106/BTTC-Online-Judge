#include<stdio.h>
#include<algorithm>
#include<iostream>
#include<map>
#include<string.h>
using namespace std;
map<string,int> name;

const int maxn=10200;

int now,n,ttt;

int use[maxn],a[maxn],here[maxn];
bool bo[maxn];

int get(string &s)
{
	if ( name.find(s)==name.end() )
		name[s]=++now;
	return name[s];
}

bool check(int sta)
{
	int mode=1;
	//memset(use,0,sizeof(use));
	int num=0;
	
	ttt++;
	
	for (int i=sta;i<=n;i++)
	{
		int t=a[i];
		if ( here[t]!=ttt )
		{
			here[t]=ttt;
			use[t]=0;
		}	
		use[t]++;
		if ( use[t]==mode )
		{
			num++;
			if ( num==now )
			{
				mode++;
				num=0;
			}
		}
		else
			return 0;
	}		
	return 1;
}

int main()
{
	string s;
	char ss[100];
	int t,mode,len,num;
	
	while ( scanf("%d",&n)!=EOF)
	{
		
		now=0;
		memset(here,0,sizeof(here));
		
		bool ans=true;
		name.clear();
		
		getchar();		
		for (int i=1;i<=n;i++)
		{
			gets(ss);
			s = string(ss);
			a[i] = get(s);				
		}
		
		memset(bo,0,sizeof(bo));
		
		ans=0;
		ttt++;
		for (int i=1;i<=n;i++)
		if ( !bo[a[i]] )
		{
			bo[a[i]]=1;
			if ( check(i) )
			{
				ans=1;
				break;
			}
		}
		else
		{
			if ( check(i) ) ans=1; 
			break;
		}
		
		if ( ans )
			printf("Either\n");
		else
			printf("Random\n");
	}
}











