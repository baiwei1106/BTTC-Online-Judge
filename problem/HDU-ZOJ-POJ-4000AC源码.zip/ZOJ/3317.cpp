#include <iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
struct g
{
	int t1,t2,id,rom;
}s[105];
bool cmp(g x,g y)
{
	return x.t1<y.t1;
}
bool cmpid(g x,g y)
{
	return x.id<y.id;
}
bool bo[105];
int main()
{
	int mx,n,m,i,h,now,j,k;
	while(scanf("%d%d",&n,&m)&&(n+m))
	{
		memset(s,0,sizeof(s));
		memset(bo,0,sizeof(bo));
		mx=0;
		for(i=0;i<n;i++)
		{
			scanf("%d%d",&s[i].t1,&s[i].t2);
			if(s[i].t1>mx)
				mx=s[i].t1;
			s[i].id=i;
			s[i].rom=0;
		}
		sort(s,s+n,cmp);
		now=1;h=0;
		while(now<=mx)
		{
			for(i=0;i<n;i++)
				if(s[i].t2==now)
					bo[s[i].rom]=false;
			while(s[h].t1==now)
			{
				for(i=1;i<=m;i++)
					if(!bo[i])
					{
						s[h].rom=i;
						bo[i]=true;
						break;
					}
				h++;
			}
			now++;
		}
		sort(s,s+n,cmpid);
		for(i=0;i<n;i++)
			printf("%d\n",s[i].rom);
	}
}
