#include <cstdio>
#include <cstring>
#include <cmath>
#include <queue>
#include <stack>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
typedef long long ll;
const double inf=1000000000.0;
const int N=405;
const int mod=1007;
const double eps=1e-16;
//------------------------------

struct Edge {
 int b,c,nxt;
 double w;
}e[99999];
int n,m;
int p[N];
int cnt;
struct point {
 double x,y;
}pt[N];

int pre[N],path[N];
double dis[N];
bool vis[N];
bool spfa(int s,int t,int n) {
 int i,u;
 queue<int>q;
 for(i=1;i<=n;i++) dis[i]=inf+0.0;
 memset(vis,0,sizeof(bool)*(n+1));
 dis[s]=0; q.push(s);
 while(!q.empty()) {
 u=q.front(); q.pop();
 vis[u]=0;
 for(i=p[u];i!=-1;i=e[i].nxt) {
 int v=e[i].b;
 int c=e[i].c;
 double w=e[i].w;
 if(c>0&&dis[v]>dis[u]+w) {
 dis[v]=dis[u]+w;
 pre[v]=u , path[v]=i;
 if(!vis[v]) q.push(v),vis[v]=1;
 }
 }
 }
 if(dis[t]+eps>=inf) return 0;
 return 1;
}
double mfmc(int s,int t,int n) {
 int i;
 int aug,maxflow=0;
 double maxcost=0;
 while(spfa(s,t,n)) {
 aug=inf;
 for(i=t;i!=s;i=pre[i])
 if(aug>e[path[i]].c) aug=e[path[i]].c;
 for(i=t;i!=s;i=pre[i])
 e[ path[i] ].c-=aug , e[ path[i]^1 ].c+=aug;
 maxcost+=dis[t]*aug;
 maxflow+=aug;
 }
 return maxcost;
}

void addedge(int a,int b,int c,double w) {
 e[cnt].b=b; e[cnt].c=c; e[cnt].w=w; e[cnt].nxt=p[a]; p[a]=cnt++;
 e[cnt].b=a; e[cnt].c=0; e[cnt].w=-w; e[cnt].nxt=p[b]; p[b]=cnt++;
}
void init() {
 memset(p,-1,sizeof(p));
 cnt=0;
}

int main()
{
 int i,j,t,cas=0;
 while(scanf("%d",&n)!=EOF) {
 init();
 for(i=1;i<=n;i++) scanf("%lf%lf",&pt[i].x,&pt[i].y);
 for(i=1;i<=n;i++) {
 for(j=i+1;j<=n;j++) {
 double w=sqrt((pt[i].x-pt[j].x)*(pt[i].x-pt[j].x)+(pt[i].y-pt[j].y)*(pt[i].y-pt[j].y));
 addedge(i+n,j,1,w);
 }
 addedge(i,i+n,1,-inf);
 if(i==1||i==n) addedge(i,i+n,1,0.0);
 }

 double ret=mfmc(1,n+n,n+n);
 printf("%.2f\n",ret+n*inf);
 }
 return 0;
}
