#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

const int N=1005;
const int zl[8][2]={0, 1, 0, -1, 1, 0, -1, 0, 1, 1, 1, -1, -1, 1, -1, -1};

char buff[N][N];
bool vs[N][N];
int fa[2000005];
int cnt[2000005];
int n, m;

bool in1(int x, int y)
{
	return x>=0 && x<=n+1 && y>=0 && y<=m+1;
}

int find_fa(int x)
{
	if(fa[x]!=x) fa[x]=find_fa(fa[x]);
	return fa[x];
}

void DFS1(int x, int y)
{
	vs[x][y]=1;
//	printf("buff[%d][%d]=%c\n", x, y, buff[x][y]);
	for(int k=0; k<4; k++)
	{
		int i=x+zl[k][0];
		int j=y+zl[k][1];
		if(in1(i, j) && buff[i][j]!='P' && !vs[i][j]) DFS1(i, j);
	}
}

bool in2(int x, int y)
{
	return x>=0 && x<=n && y>=0 && y<=m;
}

void DFS2(int x, int y, int pre)
{
	vs[x][y]=1;

	int f1=find_fa(pre);
	int f2=find_fa(x*m+y);

	if(f1!=f2) fa[f1]=f2;

	for(int k=0; k<8; k++)
	{
		int i=x+zl[k][0];
		int j=y+zl[k][1];
		if(in2(i, j) && buff[i][j]=='P' && !vs[i][j]) DFS2(i, j, x*m+y);
	}
}

int main()
{
	while(scanf("%d%d", &n, &m)!=EOF)
	{
		for(int i=1; i<=n; i++)
			scanf("%s", buff[i]+1);
		memset(vs, 0, sizeof vs);

		DFS1(0, 0);

//		for(int i=1; i<=n; i++)
//			for(int j=1; j<=m; j++)
//			{
//				printf("%d", vs[i][j]?1:0);
//				if(j==m) printf("\n");
//			}

		for(int i=1; i<=n; i++)
			for(int j=1; j<=m; j++)
			{
				if(buff[i][j]!='P') continue;
				bool flag=0;
				for(int k=0; k<4; k++)
				{
					int x=i+zl[k][0];
					int y=j+zl[k][1];
					if(vs[x][y])
					{
						flag=1;
						break;
					}
				}
				if(!flag) buff[i][j]='G';
			}

//		for(int i=1; i<=n; i++)
//			for(int j=1; j<=m; j++)
//			{
//				printf("%c", buff[i][j]);
//				if(j==m) printf("\n");
//			}

		for(int i=1; i<=n; i++)
			for(int j=1; j<=m; j++)
				fa[i*m+j]=i*m+j;
		memset(vs, 0, sizeof vs);
		for(int i=1; i<=n; i++)
			for(int j=1; j<=m; j++)
			{
				if(buff[i][j]!='P') continue;
				if(!vs[i][j]) DFS2(i, j, i*m+j);
			}
		int ans=0;
		memset(cnt, 0, sizeof cnt);
		for(int i=1; i<=n; i++)
			for(int j=1; j<=m; j++)
			{
				if(buff[i][j]!='P') continue;
				cnt[find_fa(i*m+j)]++;
			}
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<=m; j++)
				if(ans<cnt[i*m+j]) ans=cnt[i*m+j];
		}
		printf("%d\n", ans);
	}
	return 0;
}
