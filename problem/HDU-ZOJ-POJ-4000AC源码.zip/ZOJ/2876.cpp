#include<cstdio>
#include<cstring>
#include<cmath>
#define LL int
struct Node{
 struct Node *br[10];
 Node(){
 for(LL i=0;i<10;i++)
 br[i]=NULL;
 }
};
Node *head;
bool add_tree(char *st){
 LL len=strlen(st),k,i,flag,d;
 Node *s=head;
 for(k=0;k<len;k++){
 d=st[k]-'0';
 if(s->br[d]){
 s=s->br[d];
 if(k==len-1){
 return true;
 } 
 flag=0;
 for(i=0;i<10;i++)
 if(s->br[i]){
 flag=1; break;
 }
 if(!flag) return true;
 }
 else{
 s->br[d]=new Node;
 s=s->br[d];
 }
 }
 return false;
}
bool del(Node *p){
 if(!p) return false;
 for(LL i=0;i<10;i++){
 if(p->br[i])
 del(p->br[i]);
 }
 delete p;
 return false;
}
int main(){
 LL t,n,k,flag,i;
 char st[11];
 scanf("%d",&t);
 while(t--){
 head=new Node;
 for(i=0;i<10;i++)
 head->br[i]=NULL;
 flag=0;
 scanf("%d",&n);
 while(n--){
 scanf("%s",st);
 k=add_tree(st);
 if(k) flag=1;
 }
 if(flag) puts("NO");
 else puts("YES");
 del(head);
 }
 return 0;
}