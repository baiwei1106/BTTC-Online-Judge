#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cassert>
#include <iostream>
#include <sstream>
#include <fstream>
#include <map>
#include <set>
#include <vector>
#include <queue>
#include <algorithm>
#include <iomanip>
using namespace std;
#define max(x,y) ((x)>(y)?(x):(y))
#define min(x,y) ((x)<(y)?(x):(y))
#define abs(x) ((x)>=0?(x):-(x))
#define i64 long long
#define u32 unsigned int
#define u64 unsigned long long
#define clr(x,y) memset(x,y,sizeof(x))
#define PI acos(-1.0)
#define lowbit(x) (x&(-x))
#define sqr(x) ((x)*(x))
#define LL long long
#define N 3003


int n;
short dp[N][N];
int path[N];
LL a[N];
int pos[N];
int b[N];


struct treearray{
 int f[N + 100];
 void init()
 {
 memset(f,0,sizeof(f));
 }
 void update(int x,int val)
 {
 while( x <= N )
 {
 f[x] += val;
 x += lowbit(x);
 }
 }
 int query(int x)
 {
 int res;
 res = 0 ;
 while(x > 0 )
 {
 res += f[x];
 x -= lowbit(x);
 }
 return res;
 }
 int getp(int x)
 {
 return query(x) - query(x-1);
 }
 void up1(int x,int val)
 {
 update(x,val-getp(x));
 }
};
treearray ta;

int main()
{
 int n1;
 int flag = 0;
 while (scanf("%d",&n)==1){
 if (flag)
 puts("");
 flag = 1;
 for (int i=0;i<n;i++)
 scanf("%lld",&a[i]);
 if (n == 1){
 printf("1\n");
 printf("%lld\n",a[0]);
 continue;
 }
 // init();
 // puts("jkj");
 memset(dp,0,sizeof(dp));
 int ans = 0;
 int ansi,ansj;

 ta.init();
 for(int i = 0; i < n ; i++ ) b[i] = a[i];
 sort(b,b+n);
 n1 = unique(b,b+n) - b;

 for(int i = 0 ; i < n ; i ++ )
 pos[i] = lower_bound(b,b+n1,a[i]) - b + 1 ;


 for (int j=0;j<n;j++)
 {
 for (int i=j+1;i<n;i++){
 int x = a[i] - a[j];

 int k;
 int p = lower_bound(b,b+n1,x) - b ;
 if(b[p] != x)
 k = -1;
 else
 {
 p = p + 1;
 int tmp = ta.getp(p);
 if(tmp == 0 )
 {
 k = -1;
 }
 else
 k= tmp - 1;
 }


 if (k!=-1){
 dp[i][j] = dp[j][k] + 1;
 }else{
 dp[i][j] = 2;
 }
 if (dp[i][j] > ans){
 ans = dp[i][j];
 ansi = i;
 ansj = j;
 }
 }
 ta.up1(pos[j],j+1);
 }

 printf("%d\n",ans);
 int tot = 0;
 path[++tot] = ansi;
 path[++tot] = ansj;
 while (tot < ans){
 int x = a[ansi] - a[ansj];
 int k;
 for (k=0;k<ansj;k++){
 if (a[k] == x && dp[ansj][k] + 1 == dp[ansi][ansj]){
 break;
 }
 }
 if (k < ansj){
 path[++tot] = k;
 ansi = ansj;
 ansj = k;
 }else
 break;
 }
 for (int i=1;i<ans;i++)
 printf("%lld ",a[path[ans-i+1]]);
 printf("%lld\n",a[path[1]]);
 }

	return 0;
}