#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>

using namespace std;
int Sum;
int n,ans;
int dp[110][2200];
int main()
{
 while(scanf("%d",&n))
 {
 if(n<0) break;
 Sum=0;
 memset(dp,-1,sizeof(dp));
 dp[0][0]=0;
 ans=0;
 int x;
 for(int i=1;i<=n;i++)
 {
 scanf("%d",&x);
 for(int j=0;j<=2000;j++)
 dp[i][j]=dp[i-1][j];
 for(int j=0;j<=2000;j++)
 {
 if(dp[i-1][j]!=-1)
 {
 dp[i][j+x]=max(dp[i][j+x],dp[i-1][j]+x);
 if(j>=x)
 dp[i][j-x]=max(dp[i][j-x],dp[i-1][j]);
 else
 dp[i][x-j]=max(dp[i][x-j],dp[i-1][j]+x-j);
 }
 }
 }
 if(dp[n][0]>0) printf("%d\n",dp[n][0]);
 else printf("Sorry\n");
 }

 return 0;
}
