#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

#define N 500005
#define M 1000005

typedef long long ll;

struct Edge {
 int u, v;
 ll cost;
} e[M];

int r[M], p[N], n, m;

bool ff[M];
int sta[M];

int cmp(const int i, const int j) {
 if(e[i].cost == e[j].cost) return i > j;
 return e[i].cost > e[j].cost;
}
int find(int x) {return p[x] == x ? x : p[x] = find(p[x]);}
void Kruskal() {
 for(int i=1; i<=n; i++) p[i] = i;
 for(int i=1; i<=m; i++) r[i] = i;
 sort(r + 1, r + m + 1, cmp);

 for(int i=1; i<=m; i++) {
 //printf("%d ", r[i]);
 }
 //printf("\n");

 for(int i=1; i<=m; i++) {
 int id = r[i];
 int x = find(e[id].u);
 int y = find(e[id].v);
 if(x != y) {
 ff[id] = 1;
 p[x] = y;
 }
 }
}

int main()
{
 ll s;
 int flag = 1;
 while(cin >> n >> m >> s) {
 if(flag == 0) printf("\n");
 flag = 0;

 memset(e, 0, sizeof(e));
 memset(ff, 0, sizeof(ff));

 int x, y, ct;
 for(int i=1; i<=m; i++) {
 scanf("%d%d%d", &x, &y, &ct);
 e[i].u = x; e[i].v = y; e[i].cost = ct;
 //e[x][y].cost = e[y][x].cost = ct;
 }

 Kruskal();
 for(int i=1; i<=m; i++) {
 //printf("#%d ", ff[i]);
 }
 //printf("\n");

 int ans = 0;
 for(int i=1; i<=m; i++) {
 int id = r[m+1-i];
 //printf("id=%d, ", id);
 if(ff[id] == 0) {
 if(s < e[id].cost) break;
 s -= e[id].cost;
 sta[ans++] = id;
 }
 }
 //printf("\n");
 sort(sta, sta + ans);
 printf("%d\n", ans);
 for(int i=0; i<ans; i++) {
 printf("%d%c", sta[i], i==ans-1?'\n':' ');
 }
 if(ans == 0) printf("\n");
 }

 return 0;
}