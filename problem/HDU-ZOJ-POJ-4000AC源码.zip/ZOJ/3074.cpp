/*
 * Author: alpc32
 * Created Time: 2011��07��31�� ������ 16ʱ08��15��
 * File Name: b1.cpp
 */
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#define pb push_back
#define mp make_pair
#define SZ(v) ((int)(v).size())
#define out(v) cerr << #v << ": " << (v) << endl
using namespace std;
const int maxint = -1u>>1;
int T[4][20]=
{
 {1, 1, 2, 3, 4, 2, 1, 2, 3, 4, 3, 1, 2, 3, 4},
 {1, 9, 4, 8, 7, 4, 5, 2, 6, 7, 2, 5, 7, 6, 2},
 {2, 9, 4, 8, 7, 4, 9, 7, 8, 4, 3, 5, 7, 6, 2},
 {1, 5, 7, 6, 2, 3, 9, 4, 8, 7, 4, 1, 4, 3, 2}
};
// 0, 5, 10
char R[5][15];
void init()
{
 char C[10]=" RGBY";
 //puts("aa");
 for (int i=1; i<=4; i++)
 for (int j=1; j<=9; j++) R[i][j]=C[i];
}


void tran(int id, int s)
{
 char tmp[5];
 if (s==0)
 {
 for (int i=1; i<=4; i++)
 tmp[i]=R[ T[id][10] ][ T[id][10+i] ];
 for (int i=1; i<=4; i++)
 R[ T[id][10] ][ T[id][10+i] ] = R[ T[id][5] ][ T[id][5+i] ];
 for (int i=1; i<=4; i++)
 R[ T[id][5] ][ T[id][5+i] ] = R[ T[id][0] ][ T[id][0+i] ];
 for (int i=1; i<=4; i++)
 R[ T[id][0] ][ T[id][0+i] ]=tmp[i];
 } else
 {
 for (int i=1; i<=4; i++)
 tmp[i]=R[ T[id][10] ][ T[id][10+i] ];
 for (int i=1; i<=4; i++)
 R[ T[id][10] ][ T[id][10+i] ] = R[ T[id][0] ][ T[id][0+i] ];
 for (int i=1; i<=4; i++)
 R[ T[id][0] ][ T[id][0+i] ] = R[ T[id][5] ][ T[id][5+i] ];
 for (int i=1; i<=4; i++)
 R[ T[id][5] ][ T[id][5+i] ]=tmp[i];
 }
}

void print()
{
 for (int i=0; i<4; i++) putchar(32); printf("/%c\\", R[1][1]);
 for (int i=0; i<8; i++) putchar(32); printf("/%c\\", R[2][1]);
 for (int i=0; i<8; i++) putchar(32); printf("/%c\\", R[3][1]);
 putchar(10);
 for (int i=0; i<2; i++) putchar(32); printf("/%c\\%c/%c\\", R[1][2], R[1][3], R[1][4]);
 for (int i=0; i<4; i++) putchar(32); printf("/%c\\%c/%c\\", R[2][2], R[2][3], R[2][4]);
 for (int i=0; i<4; i++) putchar(32); printf("/%c\\%c/%c\\", R[3][2], R[3][3], R[3][4]);
 putchar(10);
 for (int i=1; i<=3; i++)
 printf("/%c\\%c/%c\\%c/%c\\", R[i][5], R[i][6], R[i][7], R[i][8], R[i][9]);
 putchar(10);
 
 for (int i=0; i<11; i++) putchar(32);
 printf("\\%c/%c\\%c/%c\\%c/", R[4][5], R[4][6], R[4][7], R[4][8], R[4][9]);
 putchar(10);
 for (int i=0; i<13; i++) putchar(32); printf("\\%c/%c\\%c/", R[4][2], R[4][3], R[4][4]); 
 putchar(10);
 for (int i=0; i<15; i++) putchar(32); printf("\\%c/", R[4][1]);
 putchar(10);
}

int main()
{
 char s[100];
 int t=0;
 //freopen("b1.in", "r", stdin);
 while (scanf("%s", s)!=-1)
 {
 if (t) putchar(10);
 t++;
 init();
 while (scanf("%s", s), s[0]!='E')
 {
 tran(s[0]-'A', s[1]=='+');
 }
 print();
 }
 return 0;
}

