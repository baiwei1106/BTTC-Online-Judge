/* 
 * File:   main.cpp
 * Author: Administrator
 *
 * Created on 2011年3月16日, 下午4:50
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<iostream>
#include <vector>
#include<algorithm>
using namespace std;
#define max(a,b) (a>b?a:b)
char num[10][8][9] = {
    "  XXXX  ",
    " XX  XX ",
    " XX  XX ",
    " XX  XX ",
    " XX  XX ",
    " XX  XX ",
    " XX  XX ",
    "  XXXX  ",
    "   XX   ",
    " XXXX   ",
    "   XX   ",
    "   XX   ",
    "   XX   ",
    "   XX   ",
    "   XX   ",
    " XXXXXX ",
    "  XXXX  ",
    " XX  XX ",
    " XX  XX ",
    "     XX ",
    "    XX  ",
    "   XX   ",
    "  XX    ",
    " XXXXXX ",
    "  XXXX  ",
    " X   XX ",
    "     XX ",
    "   XXX  ",
    "     XX ",
    "     XX ",
    " X   XX ",
    "  XXXX  ",
    "    XX  ",
    "   XXX  ",
    "   XXX  ",
    "  X XX  ",
    " X  XX  ",
    " XXXXXX ",
    "    XX  ",
    "  XXXXX ",
    "  XXXXX ",
    "  XX    ",
    "  XXXX  ",
    "  X  XX ",
    "     XX ",
    "     XX ",
    " X   XX ",
    "  XXXX  ",
    "   XXXX ",
    "  XX    ",
    " XX     ",
    " XXXXX  ",
    " XX  XX ",
    " XX  XX ",
    " XX  XX ",
    "  XXXX  ",
    " XXXXXX ",
    " X   XX ",
    "     XX ",
    "    XX  ",
    "    XX  ",
    "    XX  ",
    "   XX   ",
    "   XX   ",
    "  XXXX  ",
    " XX  XX ",
    " XX  XX ",
    "  XXXX  ",
    " XX  XX ",
    " XX  XX ",
    " XX  XX ",
    "  XXXX  ",
    "  XXXX  ",
    " XX  XX ",
    " XX  XX ",
    " XX  XX ",
    "  XXXXX ",
    "     XX ",
    "    XX  ",
    " XXXX   "
};
char mat[8][200];
int dx[8] = {0, 0, 1, -1,1,1,-1,-1};
int dy[8] = {1, -1, 0, 0,1,-1,1,-1};
int N, M;
bool mark[8][200];

bool isin(int x, int y) {
    return x >= 0 && x < N && y >= 0 && y<M;
}
int sum;

void dfs(int i, int j, int ox, int oy) {
    mark[i][j] = true;
   // if (ox==3&&oy==27) printf("%d %d\n",i,j);
    sum += abs(i - ox) + abs(j - oy);
    for (int k = 0; k < 8; k++) {
        int xx = i + dx[k], yy = j + dy[k];
        if (isin(xx, yy) && !mark[xx][yy] && mat[xx][yy] == 'X') {
            dfs(xx, yy, ox, oy);
        }
    }
}
char res[8][200];

void copy(int n, int x, int y) {
    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++)
            res[i][y + j] = num[n][i][j];
}
int cnt[10];
int main() {
    int tt, i, j, k;
    N = M = 8;
    for (i = 0; i < 10; i++) {
        sum = 0;
        memset(mark, false, sizeof (mark));
        for (j = 0; j < 8; j++)
            for (k = 0; k < 8; k++)
                mat[j][k] = num[i][j][k];
               
        for (j = 0; j < 8; j++)
            if (mat[3][j] == 'X') {
                dfs(3, j, 3, j);
                break;
            }
        cnt[i] = sum;
       //printf("%d : %d\n",i,cnt[i]);
    }
    scanf("%d", &tt);
    getchar();
    bool first = true;
    while (tt--) {
        if (first) first = false;
        else printf("\n");
        M = 0;
        for (i = 0; i < 8; i++)
            gets(mat[i]),M = max(M,strlen(mat[i]));
        //for (i=0;i<8;i++) printf("%s\n",mat[i]);
        memset(mark, false, sizeof (mark));
        //for (i = 0; i < 8; i++) printf("%s\n",mat[i]);
        N = 8;// M = strlen(mat[0]);
        int A = 0;
        for (i = 0; i <M; i++)
            if (!mark[3][i]&&mat[3][i]=='X') {
                sum = 0;
                dfs(3, i, 3, i);
              //  printf("%d\n",sum);
                for (j = 0; j < 10; j++)
                    if (sum == cnt[j]) break;

                if (j == 10) break;
                A = A * 10 + j;
            }
        int B = 0;
        for (i++; i < M; i++)
            if (!mark[3][i]&&mat[3][i]=='X') {
                sum = 0;
                dfs(3, i, 3, i);
                //printf("%d %d\n",3,i);
              //  printf("%d---\n",sum);
                for (j = 0; j < 10; j++)
                    if (sum == cnt[j]) break;
                        if (j==10) while(1);
                B = B * 10 + j;
            }
        int C = A + B;
       // printf("%d %d\n",A,B);
        int bb[100], t = 0;
        while (C) {
            bb[t] = C % 10;
            t++;
            C /= 10;
        }
        if (t == 0) {
            bb[0] = 0;
            t = 1;
        }
        for (i = t - 1; i >= 0; i--) {
            copy(bb[i], 0, (t - i - 1)*8);
        }
        for (i = 0; i < 8; i++) {
            for (j = 0; j < 8 * t; j++) {
                printf("%c", res[i][j]);
            }
            printf("\n");
        }
        if (tt)
        getchar();
    }
}
