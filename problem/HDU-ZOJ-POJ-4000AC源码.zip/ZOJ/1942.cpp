#include<iostream>
#include<stdlib.h>
#include<stdio.h>
#include<cmath>
#include<iomanip>
using namespace std;

struct
{
	double x, y;
}a[201];

double d[201][201];
int n;

void doing ()
{
	int i,j,k;
	double temp;
	for (k=1;k<=n;k++)
	 for (i=1;i<=n;i++)
	 for (j=1;j<=n;j++)
 {
 temp = d[i][k] > d[k][j] ? d[i][k] : d[k][j];
 if ( temp < d[i][j] )
 d[i][j] = d[j][i] = temp;
 }

}


void init ()
{
	int count=0;
	int i,j;
	while (cin>>n&&n)
	{
		for (i=1;i<=n;i++)
		 cin>>a[i].x>>a[i].y;
		for (i=1;i<=n;i++)
 for (j=i;j<=n;j++)
 d[i][j] = d[j][i] = sqrt( (a[i].x-a[j].x)*(a[i].x-a[j].x)
 + (a[i].y-a[j].y)*(a[i].y-a[j].y) ); 
 doing (); 
		cout << setprecision(3) << fixed; 
 cout<<"Scenario #"<<++count<<"\nFrog Distance = "<<d[1][2]<<endl<<endl;
 }
}

int main()
{
 init ();
 return 0;
}
