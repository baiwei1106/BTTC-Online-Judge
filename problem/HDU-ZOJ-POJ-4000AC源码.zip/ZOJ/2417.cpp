#include <stdio.h>
#include <string.h>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

int a[1005];
int dp[1005];

int main()
{
 int i,j,n,T,s,x,y,z,ans,up;
 while(1)
 {
 scanf("%d",&n);
 if (n==0) break;
 s=1;
 while(n)
 {
 if (n%2!=0) break;
 s*=2;
 n/=2;
 }
 printf("%d\n",s);
 }
 return 0;
}
