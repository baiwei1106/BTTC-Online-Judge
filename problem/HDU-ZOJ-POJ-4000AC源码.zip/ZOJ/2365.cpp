#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#define INF 405
#define inf 0x0f0f0f0f

using namespace std;
vector <int> vec[INF], ans[INF], id[INF];
int Dis[INF], vis[INF];
void _addedge(int i, int j, int n)
{
	vec[i].push_back(j); id[i].push_back(n);
}
int bfs(int s, int e)
{
	int i, j, t;
	queue <int> q;
	memset(vis, 0, sizeof(vis));
	memset(Dis, 0, sizeof(Dis));
	for (q.push(s), vis[s]=1; q.empty()==0; )
	{
		i=q.front(), q.pop();
		int siz=vec[i].size(), d=Dis[i];
		for (j=0; j<siz; j++)
		{
		 if (t=vec[i][j], vis[t]==0)
				q.push(t), vis[t]=1, Dis[t]=d+1;
			if (Dis[t]==d+1) ans[d+1].push_back(id[i][j]);
		}
	}
	return Dis[e];
}
int main()
{
	//freopen("1.txt", "r", stdin);
	int i, j, h, t;
	for (h=scanf("%d", &t); h<=t; h++)
	{
		if (h>1) puts("");
		int n, m, st, et;
		scanf("%d%d%d%d", &n, &m, &st, &et);
		for (i=1; i<=n; i++) vec[i].clear(), ans[i].clear(), id[i].clear();

		for (i=1; i<=m; i++)
		{
			int x, y;
			scanf("%d%d", &x, &y);
			_addedge(x, y, i); _addedge(y, x, i);
		}

		int cnt=bfs(st, et);
		printf("%d\n", cnt);

		for (i=1; i<=cnt; i++)
		{
			printf("%d", ans[i].size());
			for (j=0; j<ans[i].size(); j++) printf(" %d", ans[i][j]);
			puts("");
		}
	}
	return 0;
}
