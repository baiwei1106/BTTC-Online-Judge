#include <cstdio>
#include <cstring>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <map>

using namespace std ;

map<string,int> num ;
set< pair<int , int> > s ;

const int MAXN = 10001 ;

char s1[MAXN] , s2[MAXN] ;
char name[MAXN][101] ;

int cur[MAXN] ;

int main(){
 //freopen("input.txt","r",stdin);
 int _;
 while (scanf("%d",&_)==1){
 num.clear() ; s.clear() ;
 int m = 0 ;
 while (_--){
 scanf("%s",s1) ;
 if (s1[0]=='n'){

 scanf("%s",s2);
 num[s2] = ++m ;
 cur[m] = _ ;
 memcpy(name[m],s2,sizeof(s2)) ;
 s.insert(make_pair(_,m)) ;

 }else if (s1[0]=='s'){
 int t = 0 ;
 for (set< pair< int , int> >::iterator it = s.begin() ; it != s.end() ; it++){
 t++ ; if (t > 100) break ;
 printf("%s\n",name[(*it).second]) ;
 }
 printf("###\n");

 }else if (s1[0]=='t'){
 scanf("%s",s2);
 int i = num[s2] ;
 s.erase(make_pair(cur[i],i));
 }else if (s1[0]=='r'){
 scanf("%s",s2);
 int i = num[s2] ;
 s.erase(make_pair(cur[i],i)) ;
 cur[i] = _ ;
 s.insert(make_pair(_,i));
 }
 }
 printf("\n");
 }
 return 0 ;
}
