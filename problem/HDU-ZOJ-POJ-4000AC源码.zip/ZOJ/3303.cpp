#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<ctime>
#include<algorithm>
#include<vector>
#include<map>
#include<queue>

#define LL __int64
#define INF (1<<30)
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)>(b)?(b):(a))
#define sqr(x) ((x)*(x))
#define EPS 1e-10
using namespace std;

// 0_, 1., 2/, 3\, 4|
char ma[1050][1050];
double pro[2][3][1050];
int pre, now, h, w;

void Wo( int fl )
{
 int i, j, k, qu[1050], l(0), t;
 for( i = 0; i < w; i ++ )
 if( ma[fl][i] == '_' )
 pro[now][1][i+1] = 0;
 else
 qu[ l++ ] = i;
 qu[ l ] = w;
 ma[fl][w] = '.';
 if( l )
 {
 t = qu[0]+1;
 switch( ma[fl][ qu[0] ] )
 {
 case( '.' ):
 for( j = 0; j < 3; j ++ )
 pro[now][j][t] = pro[pre][j][t];
 break;
 case( '/' ):
 for( j = 0; j < 3; j ++ )
 pro[now][j][t] = 1;
 break;
 case( '\\' ):
 if( ma[fl][ qu[1] ] == '.' )
 pro[now][1][t] = pro[pre][2][ qu[1]+1 ];
 else
 pro[now][1][t] = 0;
 pro[now][0][t] = pro[now][2][t] = pro[now][1][t];
 break;
 case( '|' ):
 pro[now][1][t] = 1;
 if( ma[fl][ qu[1] ] == '.' )
 pro[now][1][t] += pro[pre][2][ qu[1]+1 ];
 pro[now][1][t] /= 2;
 pro[now][0][t] = pro[now][2][t] = pro[now][1][t];
 }
 for( i = 1; i < l; i ++ )
 {
 t = qu[i] + 1;
 switch( ma[fl][ qu[i] ] )
 {
 case( '.' ):
 for( j = 0; j < 3; j ++ )
 pro[now][j][t] = pro[pre][j][t];
 break;
 case( '/' ):
 if( ma[fl][ qu[i-1] ] == '.' )
 pro[now][0][t] = pro[pre][0][ qu[i-1]+1 ];
 else
 pro[now][0][t] = 0;
 pro[now][1][t] = pro[now][2][t] = pro[now][0][t];
 break;
 case( '\\' ):
 if( ma[fl][ qu[i+1] ] == '.' )
 pro[now][2][t] = pro[pre][2][ qu[i+1]+1 ];
 else
 pro[now][2][t] = 0;
 pro[now][0][t] = pro[now][1][t] = pro[now][2][t];
 break;
 case( '|' ):
 if( ma[fl][ qu[i-1] ] == '.' )
 pro[now][0][t] = pro[pre][0][ qu[i-1]+1 ];
 else
 pro[now][0][t] = 0;
 if( ma[fl][ qu[i+1] ] == '.' )
 pro[now][0][t] += pro[pre][2][ qu[i+1]+1 ];
 pro[now][0][t] /= 2;
 pro[now][1][t] = pro[now][2][t] = pro[now][0][t];
 }
 }
 }
 for( k = 1; k <= qu[0]; k ++ )
 pro[now][0][k] = 1;
 if( ma[fl][ qu[0] ] == '.' )
 for( k = 1; k <= qu[0]; k ++ )
 pro[now][2][k] = pro[pre][2][ qu[0]+1 ];
 else
 for( k = 1; k <= qu[0]; k ++ )
 pro[now][2][k] = 0;

 for( i = 0; i < l; i ++ )
 {
 if( ma[fl][ qu[i] ] == '.' )
 for( k = qu[i]+2; k <= qu[i+1]; k ++ )
 pro[now][0][k] = pro[pre][0][ qu[i]+1 ];
 else
 for( k = qu[i]+2; k <= qu[i+1]; k ++ )
 pro[now][0][k] = 0;
 if( ma[fl][ qu[i+1] ] == '.' )
 for( k = qu[i]+2; k <= qu[i+1]; k ++ )
 pro[now][2][k] = pro[pre][2][ qu[i+1]+1 ];
 else
 for( k = qu[i]+2; k <= qu[i+1]; k ++ )
 pro[now][2][k] = 0;
 }


 pre = 1-pre;
 now = 1-now;
}

int main()
{
 int i, j;
 double ans;
 //in
 while( gets( ma[0] ) )
 {
 h = 0;
 while( ma[h][0] != '\0' )
 gets( ma[ ++h ] );
 w = strlen( ma[0] );
 pre = 0;
 now = 1;
 for( i = 0; i <= w+1; i ++ )
 for( j = 0; j < 3; j ++ )
 pro[pre][j][i] = 1;
 for( j = 0; j < 3; j ++ )
 pro[now][j][0] = pro[now][j][w+1] = 1;
 for( i = h-1; i >= 0; i -- )
 Wo(i);
 ans = 0;
 for( i = 1; i <= w; i ++ )
 ans += pro[pre][1][i];
 ans *= 100;
 ans /= w;
 printf( "%.2lf\n", ans+EPS );
 }

	//out
	return 0;
}
