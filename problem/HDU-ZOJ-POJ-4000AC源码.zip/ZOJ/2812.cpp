#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
 char ch;
 int i=1;
 int sum=0;
 while(cin.get(ch))
 {
 if(ch=='#')
 break;
 if(ch!='\n')
 {
 if(ch!=' ')
 sum+=i*(ch-64);
 i++;
 }
 if(ch=='\n')
 {
 cout<<sum<<endl;
 sum=0;
 i=1;
 }
 }
 return 0;
}
