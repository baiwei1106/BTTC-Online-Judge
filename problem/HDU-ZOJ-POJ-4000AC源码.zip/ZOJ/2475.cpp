#include<iostream>
#include<string>
#include<algorithm>
#include<stdio.h>
#include<cstring>
#include<vector>
using namespace std;
int n,m;
vector<int> v[111];
bool ans;
void dfs(int now,string s)
{
	//cout<<fro<<" "<<now<<endl;
	if(ans)
	{
		string ns;
		for(int i=0;i<v[now].size();i++)
		{
			char b=char(v[now][i]);
			//cout<<"@------- "<<s<<" "<<b<<endl;
			ns=s+b;
			//cout<<ns<<" @-------------"<<endl;
			bool f=true;
			for(int j=0;j<s.length();j++)
			{
				if(s[j]==b)
				{ 
					ans=false;
					f=false;
					break;
				}
			}
			if(f)
			dfs(v[now][i],ns);
		}
	}
}
int main()
{
	int i,j,k;
	while(cin>>n && n!=-1)
	{
		for(int i=0;i<=105;i++)
			v[i].clear();
		int a,b;
		for(i=1;i<=n;i++)
		{
			cin>>a>>b;
			if(a!=b)
			v[a].push_back(b);
		}
		cin>>m;
		ans=true;
		string s="";
		s+=char(m);
		for(int j=0;j<v[m].size();j++)
		{
			dfs(v[m][j],s);
		}
		if(ans) cout<<"Yes"<<endl;
		else cout<<"No"<<endl;
	}
}