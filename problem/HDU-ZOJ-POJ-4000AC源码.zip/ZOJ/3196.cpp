
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <queue>
#include <string>
#include <map>
#include <set>
#pragma comment(linker, "/STACK:1024000000,1024000000") 
using namespace std;
#define N 2000000
long long c[10],a[N],b[N];
int main()
{
	int n,m,i,j,T,num,tmp;
	long long x;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++)
			scanf("%lld",&c[i]);
		num=1;
		a[1]=c[1];
		for(i=2;i<=n;i++)
		{
			tmp=0;
			for(j=1;j<=num;j++)
			{
				if(c[i])
				{
					b[++tmp]=a[j]/c[i];
				}
				b[++tmp]=a[j]*c[i];
				b[++tmp]=a[j]+c[i];
				b[++tmp]=a[j]-c[i];
				if(b[tmp]<0) b[tmp]=-b[tmp];
			}
			for(j=1;j<=tmp;j++)
				a[j]=b[j];
			num=tmp;
		}
		long long ans=-1;
		bool f;
		for(i=1;i<=num;i++)
		{
			x=a[i];
			f=0;
			if(x==m)
				f=1;
			while(x>0)
			{
				if(x%10==m)
				{
					f=1;
					break;
				}
				x/=10;
			}
			if(f==0&&a[i]>ans)
				ans=a[i];
		}
		if(ans==-1)
			printf("No result\n");
		else
			printf("%lld\n",ans);
	}
	return 0;
}








