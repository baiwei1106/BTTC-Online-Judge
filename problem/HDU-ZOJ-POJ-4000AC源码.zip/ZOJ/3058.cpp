#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
#define PI acos(-1)
using namespace std;
double dis(double x1,double y1,double x2,double y2)
{
	return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
double sum(double x1,double y1,double r1,double x2,double y2,double r2)
{
	double s,d,t1,t2,coss1,coss2,o1,o2,ts;
	d=dis(x1,y1,x2,y2);
	if(r1<r2)
	{
		t1=r1;
		t2=r2;
	}
	else 
	{
		t1=r2;
		t2=r1;
	}
	if(d>=t1+t2||t1==0||t2==0)
		s=0;
	else
		if(d<=t2-t1)
			s=PI*t1*t1;
		else
		{
			coss1=(r1*r1+d*d-r2*r2)/(2*r1*d);
			coss2=(r2*r2+d*d-r1*r1)/(2*r2*d);
			o1=acos(coss1);
			o2=acos(coss2);
			ts=r1*d*(sqrt(1-coss1*coss1));
			s=r1*r1*o1+r2*r2*o2-ts;
		}
		return s;
}
int main()
{
	double x1,y1,x2,y2,r,r1,r2;
	double s1,s2,s;
	while(scanf("%lf%lf%lf%lf%lf%lf%lf",&x1,&y1,&r,&x2,&y2,&r1,&r2)!=EOF)
	{
		s1=sum(x1,y1,r,x2,y2,r1);
		s2=sum(x1,y1,r,x2,y2,r2);
		s=s2-s1;
		if(s<0)
			s*=-1;
		printf("%.3lf\n",s);
	}
	return 0;
}