
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<algorithm>
#include<map>
#include<vector>
#include<iostream>
using namespace std;

int main()
{
 double n,k,l,m;
 long long sum,ss;
 while(cin>>n>>k>>l>>m)
 {

 //if(l<=1.0) {puts("-1");continue;}
 if(k<=l) {puts("0");continue;}

 double sta=k+0.0499999999999;
 sta=min(sta,n*1.0);
 l+=0.0499999999999;
 l=min(n*1.0,l);
 long long low,mid,high,tmp;
 sum=sta*m;
 sum=(long long)sum;
 low=0;ss=tmp=high=0x7f7f7f7f7f7f7fll;
 while(low<=high)
 {
 mid=(low+high)>>1;
 tmp=(long long)(l*(mid+m));
 if((sum+mid)<=tmp)
 high=mid-1;
 else
 low=mid+1;
 }
 if(low>ss)
 {
 cout<<"-1"<<endl;continue;
 }

 cout<<low<<endl;
 }
}
