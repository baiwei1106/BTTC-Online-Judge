#include<iostream>
#include<cstdio>
#include<vector>
#include<string>
#include<queue>
#include<cstring>
#include<map>
#include<cmath>
#include<algorithm>
using namespace std;
#define ll int
#define N 1000010

int n;
char ch[N];
int f[N];

void getFail()
{
	f[0] = f[1] = 0;
	for(int i=1;i<n;i++)
	{
		int j = f[i];
		while(j&&ch[i]!=ch[j]) j = f[j];
		if(ch[i]==ch[j]) f[i+1] = j+1;
		else f[i+1] = 0;
	}
}
void kmp()
{
	getFail();
	for(int i=1;i<=n;i++)
		if(f[i]>0&&i%(i-f[i])==0) printf("%d %d\n",i,i/(i-f[i]));
	puts("");
}
int main()
{
	int cas = 0;
	while(scanf("%d",&n)!=EOF&&n)
	{
		scanf("%s",ch);
		printf("Test case #%d\n",++cas);
		kmp();
		
	}
}