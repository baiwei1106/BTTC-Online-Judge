#include<string>
#include<cstdio>
#include<algorithm>
#define INF 0x3f3f3f3f
using namespace std;
char name[2001][8];
int N;
struct minheap{int num,lowcost;} minh[2001];
bool cmp(minheap a,minheap b) {return a.lowcost>b.lowcost;}
int dis(int x,int y)
{
 int d=0;
 for(int i=0;i<7;++i) d+=name[x][i]!=name[y][i];
 return d;
}
int main()
{
 while(~scanf("%d",&N) && N)
 {
 getchar();
 for(int i=1;i<=N;++i) scanf("%s",name[i]);
		int ans=0;
		for(int i=2;i<=N;++i) minh[i-2].num=i,minh[i-2].lowcost=dis(1,i);
		make_heap(minh,minh+N-1,cmp);
		for(int cnt=1,v;cnt<N;++cnt)
		{
		v=minh[0].num;
		ans+=minh[0].lowcost;
		pop_heap(minh,minh+N-cnt,cmp);
		for(int i=0;i<N-1-cnt;++i) 
			if(dis(v,minh[i].num)<minh[i].lowcost)
				{
					minh[i].lowcost=dis(v,minh[i].num);
					push_heap(minh,minh+i+1,cmp);
				}
		}
 printf("The highest possible quality is 1/%d.\n",ans);
 }
 return 0;
}
