/* 
 * File: main.cpp
 * Author: xiaodai
 *
 * Created on 2011��9��21��, ����12:58
 */

#include <cstdio>
#include <algorithm>
#include <cstring>
#define esp 1e-8
using namespace std;

/*
 * 
 */
struct point {
 double x, y;

} all[2008];
int n, mark[2008];

double aabs(double a) {
 if (a < 0) return -a;
 return a;
}

bool cmp(point p1, point p2) {
 return (p1.y < p2.y && aabs(p1.y - p2.y) > esp) || (aabs(p1.y - p2.y) <= esp && p1.x < p2.x);
}

bool mult(point sp, point ep, point op) {
 return (sp.x - op.x)*(ep.y - op.y) >= (ep.x - op.x)*(sp.y - op.y) - esp;
}

void hull() {
 sort(all, all + n, cmp);
 int res[2009];
 memset(mark, 0, sizeof (mark));
 int i, len, top = 1;
 if (n <= 2) return;
 mark[0] = mark[1] = 1;
 res[0] = 0;
 res[1] = 1;
 for (i = 2; i < n; i++) {
 while (top && mult(all[i], all[res[top]], all[res[top - 1]])) {
 mark[res[top--]]--;
 }
 res[++top] = i;
 mark[i]++;
 }
 len = top;
 res[++top] = n - 2;
 mark[res[top]]++;
 for (i = n - 3; i >= 0; i--) {
 while (top != len && mult(all[i], all[res[top]], all[res[top - 1]])) {
 mark[res[top--]]--;
 }
 res[++top] = i;
 mark[i]++;
 }
 int now = 0;
 for (i = 0; i < n; i++)
 if (mark[i] <= 0) all[now++] = all[i];
 n = now;
}

int main(int argc, char** argv) {
 while (scanf("%d", &n) == 1) {
 for (int i = 0; i < n; i++) {
 scanf("%lf %lf", &all[i].x, &all[i].y);
 }
 int ans = 0;
 while (n > 2) {
 hull();
 ans++;
 }
 printf("%d\n", ans);
 }
 return 0;
}

