#include<stdio.h>
#include<math.h>
#include<algorithm>
#define MAXV 2000
#define PI 3.14159265358979323846
#define eps 1e-8
#define zero( x ) ( fabs( x ) < eps )
#define _sign( x ) ( ( x ) > eps ?1 : ( ( x ) < -eps ?2 : 0 ) )
using namespace std;
		
struct pt
{
 double x , y;
 pt() {}
 pt( double _x , double _y )
 {
 x = _x;
 y = _y;
 }
 pt operator - ( const pt p1 ) { return pt( x - p1.x , y - p1.y ); }
 pt operator + ( const pt p1 ) { return pt( x + p1.x , y + p1.y ); }
 pt operator / ( double r ) { return pt( x / r , y / r ); }
 pt operator * ( double r ) { return pt( x * r , y * r ); }
 bool operator == ( const pt p1 ) const{ return fabs( x-p1.x ) < eps && fabs( y-p1.y ) < eps; }
 bool operator != ( const pt p1 ) const{ return fabs( x-p1.x ) > eps || fabs( y-p1.y ) > eps; }
 bool operator < ( const pt p1 ) const{ return y < p1.y-eps || y < p1.y+eps && x < p1.x; }
};

double cpr( const pt &a , const pt &b , const pt &c ) { return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x); }
double dpr( const pt &a , const pt &b , const pt &c ) { return (b.x-a.x)*(c.x-a.x)+(b.y-a.y)*(c.y-a.y); }

double cpr( const pt &a , const pt &b ) { return a.x*b.y-a.y*b.x; }
double dpr( const pt &a , const pt &b ) { return a.x*b.x+a.y*b.y; }

double dis( const pt &a , const pt &b ) { return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)); }

double disptoseg( pt p , pt a , pt b )
{
	 pt t = p;
	 t.x += a.y - b.y;
	 t.y += b.x - a.x;
	 if ( cpr( p , a , t )*cpr( p , b , t ) > eps ) return min( dis( p , a ) , dis( p , b ) );
	 return fabs( cpr( b , p , a ) ) / dis( a , b );	
}

pt its( const pt &a , const pt &b , const pt &c , const pt &d )
{
 pt ret = a;
 double t = ( ( c.x - a.x )*( d.y - c.y ) - ( c.y - a.y )*( d.x - c.x ) ) /
 ( ( b.x - a.x )*( d.y - c.y ) - ( b.y - a.y )*( d.x - c.x ) );
 ret.x += ( b.x - a.x )*t;
 ret.y += ( b.y - a.y )*t;
 return ret;
}

void half_its( pt &a , pt &b , pt pol[] , int &polcnt , pt exch[] )
{
 int i , p2 = 0;
 bool now , last = cpr( a , b , pol[ polcnt-1 ] ) > -eps;
 for ( int i = 0 ; i < polcnt ; i++ )
 {
 now = cpr( a , b , pol[ i ] ) > -eps;
 if ( now ^ last )
 exch[ p2++ ] = its( a , b , pol[ i ] , pol[ ( i+polcnt-1 ) % polcnt ] );
 if ( now )
 exch[ p2++ ] = pol[ i ];
 last = now;
 }
 polcnt = p2;
 for ( i = 0 ; i < p2 ; i++ ) pol[ i ] = exch[ i ]; 
}

const			int maxn = 1007;
				double maxnum = 1000000000000ll;
				int n , tot , test;
				pt num[ maxn ] , pol[ maxn ] , exch[ maxn ];
		
void work()
{
	 	 scanf( "%d" , &n );
	 	 for ( int i = 1 ; i <= n ; i++ ) scanf( "%lf %lf" , &num[ i ].x , &num[ i ].y );
	 	 tot = 4;
	 	 pol[ 0 ].x = -maxnum; pol[ 0 ].y = maxnum;
	 	 pol[ 1 ].x = -maxnum; pol[ 1 ].y = -maxnum;
	 	 pol[ 2 ].x = maxnum; pol[ 2 ].y = -maxnum;
	 	 pol[ 3 ].x = maxnum; pol[ 3 ].y = maxnum;
	 	 for ( int i = 1 ; i <= n-1 ; i++ ) 
	 	 half_its( num[ i ] , num[ i+1 ] , pol , tot , exch );
	 	 double ans = maxnum , tmp;
	 	 pt tt;
				for ( int i = 1 ; i <= n ; i++ )
				 for ( int j = 0 ; j <= tot-2 ; j++ )
				 if ( num[ i ].x > pol[ j ].x && num[ i ].x < pol[ j+1 ].x )
				 {
				 tt.x = num[ i ].x;
				 tt.y = 0;
				 tt = its( num[ i ] , tt , pol[ j ] , pol[ j+1 ] );
				 tmp = dis( num[ i ] , tt );
				 if ( tmp < ans ) ans = tmp;
				 } 
				for ( int i = 0 ; i <= tot-1 ; i++ )
				 for ( int j = 1 ; j <= n-1 ; j++ )
				 if ( pol[ i ].x > num[ j ].x && pol[ i ].x < num[ j+1 ].x )
				 {
				 tt.x = pol[ i ].x;
				 tt.y = 0;
				 tt = its( pol[ i ] , tt , num[ j ] , num[ j+1 ] );
				 tmp = dis( pol[ i ] , tt );
				 if ( tmp < ans ) ans = tmp; 
				 }
				if ( ans > 1000+eps )
				{
				 printf( "IMPOSSIBLE\n" );
				 return;
				}
	 	 printf( "%.1lf\n" , ans );
}

int main()
{
	 scanf( "%d" , &test );
	 for ( int run = 1 ; run <= test ; run++ ) work();
}
