#include<stdio.h>
#include<string.h>
#include<algorithm>

int cards[20];
int count[10];
int resu[10];
int used[20];

int dfs(int cnt)
{
 int i,j,k;
 if (cnt>4)
 return 1;
 for (i=cnt;i<=12;i++)
 if (!used[i])
 for (j=i+1;j<=13;j++)
 if (!used[j])
 for (k=j+1;k<=14;k++)
 if (!used[k])
 {
 if ((cards[i]==cards[j]&&cards[j]==cards[k])||(cards[i]+1==cards[j]&&cards[j]+1==cards[k]))
 {
 used[i]=used[j]=used[k]=1;
 if (dfs(cnt+1))
 {
 used[i]=used[j]=used[k]=0;
 return 1;
 }
 used[i]=used[j]=used[k]=0;
 }
 }
 return 0;
}

int main()
{
 int i,j,k,flag;
 while (scanf("%d%d%d%d%d%d%d%d%d%d%d%d%d",&cards[1],&cards[2],&cards[3],&cards[4],&cards[5],&cards[6],\
&cards[7],&cards[8],&cards[9],&cards[10],&cards[11],&cards[12],&cards[13])==13)
 {
 memset(count,0,sizeof(count));
 memset(resu,0,sizeof(resu));
 memset(used,0,sizeof(used));
 for (i=1;i<=13;i++)
 count[cards[i]]++;
 cards[14]=0;
 int pre=0;
 for (i=1;i<=9;i++)
 if (count[i]<4)
 {
 for (j=1;j<=14;j++)
 if (cards[j]==pre)
 {
 cards[j]=i;
 break;
 }
 pre=i;
 flag=0;
 std::sort(cards+1,cards+15);
 for (j=1;j<=13&&!flag;j++)
 for (k=j+1;k<=14&&!flag;k++)
 if (cards[j]==cards[k])
 {
 used[j]=1;
 used[k]=1;
 if(dfs(1))
 {
 flag=1;
 resu[0]++;
 resu[resu[0]]=i;
 }
 used[j]=0;
 used[k]=0;
 }
 }
 for (i=1;i<=resu[0];i++)
 printf("%d%c",resu[i],(i==resu[0])?'\n':' ');
 }
 return 0;
}
