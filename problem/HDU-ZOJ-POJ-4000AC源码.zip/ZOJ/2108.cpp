#include <iostream>
using namespace std;
int main()
{
 int n;
 while(cin>>n, n)
 {
 int now = 0;
 int next;
 int ans = 0;
 for(int i = 0; i < n; ++i)
 {
 cin>>next;
 if(next > now)
 ans += (next - now) * 6;
 else
 ans += (now - next) * 4;
 ans += 5;
 now = next;
 }
 cout<<ans<<endl;
 }
}
