#include<iostream>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<vector>
#include<algorithm>
#include <iomanip>
using namespace std;
#define lim 81
#define len sizeof(struct p)
struct p
{
	int r,num;
};
char a[lim][lim];


int main ()
{
	int i,j,x,y,m,n;
	while (scanf("%d%d%d",&m,&x,&y)!=EOF)
	{
		m=(m-1>0?m-1:0);
		printf("%d\n",m);
	}
	return 0;
}

/*
INPUT START
* 5 0
* 7 0
< 30 2
< 31 2
< 32 2
< 33 2
< 34 2
* 5 3
* 13 3
* 24 3
* 7 4
* 11 4
* 11 0
* 13 0
= 2 2
= 3 2
= 4 2
= 5 2
= 6 2
= 7 2
= 8 2
* 17 0
* 22 0
* 24 0
* 3 1
* 9 1
* 15 1
* 19 1
* 26 1
< 0 2
= 1 2
* 15 2
= 16 2
= 17 2
* 26 2
= 27 2
= 28 2
< 29 2
* 17 4
* 22 4
* 9 5
* 19 5
INPUT END


*/

