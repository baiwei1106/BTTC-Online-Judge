#include <stdio.h>
#include <vector>
#include <algorithm>
#include <string>
#include <map>
#include <iostream>
using namespace std;
struct point
{
	int id,size;
	point(){}
	point(int _p,int _size)
	{
		id=_p;size=_size;
	}
	bool operator<(const point &a)const
	{
		return size>a.size;
	}	
};
const int maxn=1100;
const double INF=1e20;
int value;
int v[maxn*2],next[maxn*2],start[maxn],nume;
void bui(int a,int b)
{
	nume++;
	v[nume]=b;
	next[nume]=start[a];
	start[a]=nume;
}
double dp[maxn][maxn],need[maxn];
int size[maxn];
void dfs(int now,int pa)
{
	vector<point> a;
	for(int p=start[now];p!=-1;p=next[p])
	if(v[p]!=pa)
	{
		dfs(v[p],now);
		a.push_back(point(v[p],size[v[p]]));
	}
	//sort(a.begin(),a.end());
	size[now]=1;
	for(int i=0;i<=size[now];i++)
		dp[now][i]=INF;
	dp[now][1]=0;
	for(int p=0;p<a.size();p++)
	{
		for(int i=size[now]+1;i<=size[now]+a[p].size;i++)
			dp[now][i]=INF;
		size[now]+=a[p].size;
		for(int i=size[now]-a[p].size;i>0;i--)
			for(int j=1;j<=a[p].size;j++)
				dp[now][i+j]=min(dp[now][i+j],dp[now][i]+dp[a[p].id][j]);
	}
	for(int i=1;i<=size[now];i++)
	{
		if(i==1&&size[now]!=1)dp[now][i]=INF;
		else dp[now][i]+=need[now]/(value+i-1);
	}
	//printf("%d %d %f\n",now,size[now],dp[now][2]);
}
map<string,int> id;
int main()
{
	int n;
	while(scanf("%d%d",&n,&value)!=EOF)
	{
		id.clear();
		for(int i=1;i<=n;i++)start[i]=-1;
		nume=0;
		for(int i=1;i<=n;i++)
		{
			static string a;
			cin>>a;
			id[a]=i;
			scanf("%lf",&need[i]);
		}
		for(int i=1;i<n;i++)
		{
			static string a,b;
			cin>>a>>b;
			bui(id[b],id[a]);
		}
		string c;
		cin>>c;
		dfs(id[c],-1);
		double ans=INF;
		for(int i=1;i<=size[id[c]];i++)
			ans=min(ans,dp[id[c]][i]);
		printf("%.2f\n",ans);
	}
}