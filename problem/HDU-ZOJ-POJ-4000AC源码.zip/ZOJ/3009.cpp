#include <stdio.h>
#include <string.h>
#include<iostream>
#include<string>
#define inf 0x3f3f3f3f
using namespace std;
int mat[805][800];
string s[805][800];
int n, m;
void init()
{
	memset(mat, 0x3f, sizeof(mat));
}

int getdigits(string a)
{
	int l = a.size();
	int i=0;
	bool flag = false;
	if(a[0]=='-')
	{
		flag = true;
		i ++;
	}
	int ans = 0;
	for(; i<l; i++)ans = ans * 10 + a[i] - '0';
	if(flag == true)ans *= -1;
	return ans;	
}


int solve(int i, int j)
{
	//printf("inf = %d\n",inf);
	if(mat[i][j] != inf)return mat[i][j];
	
	int l = s[i][j].size();
	//printf("%s\n", s[i][j]);
	int ans = 0;
	for(int k=0; k<l; k++)
	{
		int x=0,y=0;
		if(s[i][j][k] != '=' && s[i][j][k] != '+' )
		{
			int temp = 0 ;
			while(s[i][j][k] >= '0' && s[i][j][k] <= '9' && k < l)
			{
				temp = temp * 10 + s[i][j][k] - '0';
				k++;
			}
			ans += temp;
			while(s[i][j][k] >= 'A' && s[i][j][k] <= 'Z' && k < l)
			{
				x = x * 26 + s[i][j][k] - 'A' + 1;
				k++;
			}
			while(s[i][j][k] >= '0' && s[i][j][k] <= '9' && k < l)
			{
				y = y * 10 + s[i][j][k] - '0';
				k++;
			}
			if(x-1 >=0 && x-1<n && y-1 >=0 && y-1 <m)
			{
				mat[y-1][x-1] = solve(y-1, x-1);
				ans += mat[y-1][x-1];
			} 
		}
		
	}
	mat[i][j] = ans;
	return ans;
}
int main()
{
	int cas;
	scanf("%d", &cas);
	while(cas --)
	{
		scanf("%d%d", &n, &m);
		init();
		for(int i=0; i<m; i++)
		for(int j=0; j<n; j++)
		{
			cin>>s[i][j];
			if(s[i][j][0] != '=')
			{
				mat[i][j] = getdigits(s[i][j]);
				//printf("i = %d j = %d map = %d\n",i,j,mat[i][j]);
			}
		}
		
			
		for(int i=0; i<m; i++)
		for(int j=0; j<n; j++)
		{
			if(mat[i][j] == inf)
			{
				mat[i][j] = solve(i, j);
			}
		}
		
		for(int i=0; i<m; i++)
		{
			for(int j=0; j<n; j++)
			{
				if(j == 0)printf("%d",mat[i][0]);
				else printf(" %d", mat[i][j]);
			}
			printf("\n");
		}
		printf("\n");		
	}
	return 0;
}