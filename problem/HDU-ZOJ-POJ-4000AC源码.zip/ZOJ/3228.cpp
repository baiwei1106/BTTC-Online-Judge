#include<cstdio>
#include<map>
#include<cstring>
#include<queue>
#include<algorithm>
using namespace std;
const int N = (int)1e6+10;
const int M = (int)1e5+5;
struct node{
	node *ch[26],*fail;
	int index,deep;
	void clear(){
		for(int i = 0;i < 26;i++)ch[i] = NULL;
		fail = NULL;
		index = 0;
		deep = 0;
	}
};
node stk[N];
bool type[M];
int last[M],vis[M][2];
struct Trie{
	node *root;
	int top;
	node* new_node(){
		node *p = &stk[top++];
		p -> clear();
		return p;
	}
	void init(){
		top = 0;
		root = new_node();
	}
	void insert(char *s,int index){
		node *p = root;
		for(int i = 0;s[i];i++){
			int id = s[i] - 'a';
			if(p -> ch[id] == NULL)
				p -> ch[id] = new_node();
			p = p -> ch[id];
			p -> deep = i + 1;
		}
		p -> index = index;
	}
	void build(){ 
		queue<node*> Q;
		root -> fail = NULL;
		for(int i = 0;i < 26;i++)
			if(root -> ch[i] == NULL)
				root -> ch[i] = root;
			else{
				Q.push(root -> ch[i]);
				root -> ch[i] -> fail = root;
			}
		while(!Q.empty()){
			node *p = Q.front();Q.pop();
			for(int i = 0;i < 26;i++)
				if(p -> ch[i] == NULL)
					p -> ch[i] = p -> fail -> ch[i];
				else{
					Q.push(p -> ch[i]);
					p -> ch[i] -> fail = p -> fail -> ch[i];
				}
		}
	}
	void solve(char *s){
		node *p = root;
		for(int i = 0;s[i];i++){
			int id = s[i] - 'a';
			p = p -> ch[id];
			node *u = p;
			while(u != root){
				int cur = u -> index;
				if(cur){
					vis[cur][0]++;
					if(last[cur] == -1){
						vis[cur][1]++;
						last[cur] = i;
					}else if(i - last[cur] >= u->deep){
						vis[cur][1]++;
						last[cur] = i;
					}
				}
				u = u -> fail;
			}
		}
	}
};
Trie AC;
char s[M];
typedef unsigned long long ull;
map<pair<ull,ull>,int>Map;
int number[M];
inline pair<ull,ull> geths(char *s){
	pair<ull,ull> ans(0,0);
	int len = strlen(s);
	for(int i = 0;i < len;i++){
		ans.first = ans.first * 31 + s[i];
		ans.second = ans.second * 131 + s[i];
	}
	return ans;
}
int main(){
	int cas = 1,n;
	while(~scanf("%s",s)){
		scanf("%d",&n);
		AC.init();
		int cnt = 0;
		Map.clear();
		for(int i = 1;i <= n;i++){
			char x[10];int flag;
			scanf("%d%s",&flag,x);
			type[i] = flag;
			vis[i][0] = vis[i][1] = 0;
			last[i] = -1;
			pair<ull,ull> hs = geths(x);
			if(!Map.count(hs)){
				Map[hs] = ++cnt;
				AC.insert(x,Map[hs]);
			}
			number[i] = Map[hs];
		}
		AC.build();
		AC.solve(s);
		printf("Case %d\n",cas++);
		for(int i = 1;i <= n;i++)
			printf("%d\n",vis[number[i]][type[i]]);
		puts(""); 
	}
	return 0;
}