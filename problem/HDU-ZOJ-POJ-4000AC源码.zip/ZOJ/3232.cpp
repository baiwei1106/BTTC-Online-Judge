#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
#include <cstdlib>
#include <vector>
#include <set>
#include <map>
#include <cmath>

using namespace std;

const int N = 256;

int g[N][N];
int cnt[N];
int idx[N];

bool cmp(int a, int b) {
 return cnt[a] > cnt[b];
}

int main() {
 int n;
 while (scanf("%d", &n) == 1) {
 memset(g, 0, sizeof (g));
 memset(idx, 0, sizeof (idx));
 memset(cnt, 0, sizeof (cnt));
 int tot = n * (n - 1);
 for (int i = 0; i < n; i++) {
 idx[i] = i;
 for (int j = 0; j < n; j++) {
 scanf("%d", &g[i][j]);
 if (g[i][j] == 1)
 cnt[i]++;
 }
 }
 sort(idx, idx + n, cmp);

 for (int i = 0; i < n; i++) {
 int ddd = (i + 1) % n;
 for (int j = ddd; j != i; j = (j + 1) % n) {
 int eee = (j + 1) % n;
 if (g[idx[i]][idx[j]] == 0) {
 tot--;
 continue;
 }
 for (int k = ddd; k != j; k = (k + 1) % n) {
 if (g[idx[i]][idx[k]] == 1 && g[idx[k]][idx[j]] == 1) {
 tot--;
 break;
 }
 }
 }
 }
 printf("%d\n", tot);
 }
 return 0;
}
