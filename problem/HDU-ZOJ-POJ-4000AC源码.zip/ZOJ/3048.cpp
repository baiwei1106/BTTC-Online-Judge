#include <cstdio>
#include <cstring>

using namespace std;

char g[30][30];
bool vis[30][30];
int currx, curry;
int dir[4][2] = {0, 1, 0, -1, 1, 0, -1, 0};
int n, m;
int cc;
const int INF = 1 << 30;

void dfs(int x, int y)
{
 if (vis[x][y])
 return;
 if (currx == x) {
 if (curry > y)
 curry = y;
 } else {
 if (currx > x) {
 currx = x;
 curry = y;
 }
 }
 vis[x][y] = true;
 cc++;
 for (int d = 0; d < 4; d++) {
 int nx = x + dir[d][0];
 int ny = y + dir[d][1];
 if (nx >= 0 && nx < n && ny >= 0 && ny < m && g[nx][ny] == g[x][y]) {
 dfs(nx, ny);
 }
 }
}

void clear(int x, int y)
{
 if (vis[x][y])
 return;
 vis[x][y] = true;
 for (int d = 0; d < 4; d++) {
 int nx = x + dir[d][0];
 int ny = y + dir[d][1];
 if (nx >= 0 && nx < n && ny >= 0 && ny < m && g[nx][ny] == g[x][y]) {
 clear(nx, ny);
 }
 }
 g[x][y] = '0';
}

int main()
{
 //freopen("input.txt", "r", stdin);
 while (scanf("%d%d", &n, &m) == 2) {
 for (int i = 0; i < n; i++) {
 scanf("%s", g[i]);
 }
 int total = 0;
 int ans = 0;
 while (true) {
 memset(vis, false, sizeof(vis));
 int maxv = 0, maxx, maxy;
 for (int i = 0; i < n; i++) {
 for (int j = 0; j < m; j++) {
 if (!vis[i][j] && g[i][j] != '0') {
 cc = 0;
 currx = INF;
 curry = INF;
 dfs(i, j);
 if (cc > maxv) {
 maxv = cc;
 maxx = currx;
 maxy = curry;
 } else if (maxv == cc) {
 if (maxx == currx) {
 if (maxy > curry) {
 maxy = curry;
 }
 } else {
 if (maxx > currx) {
 maxx = currx;
 maxy = curry;
 }
 }
 }
 }
 }
 }
 if (maxv > 1) {
 //printf("%d %d %d\n", maxv, maxx, maxy);
 if (maxx == 2) {
 maxx = 2;
 }
 ans += maxv * (maxv - 1);
 total += maxv;
 memset(vis, false, sizeof(vis));
 clear(maxx, maxy);

 for (int i = 0; i < m; i++) {
 for (int j = n - 1; j >= 0; ) {
 if (g[j][i] == '0') {
 bool ok = true;
 for (int k = j; k > 0; k--) {
 g[k][i] = g[k - 1][i];
 if (g[k][i] != '0') {
 ok = false;
 }
 }
 if (ok) {
 break;
 }
 g[0][i] = '0';
 } else {
 j--;
 }
 }
 }
 for (int i = 0; i < m; ) {
 bool ok = true;
 for (int j = n - 1; j >= 0; j--) {
 if (g[j][i] != '0') {
 ok = false;
 break;
 }
 }
 if (ok) {
 bool flag = true;
 for (int j = i; j < m - 1; j++) {
 for (int k = 0; k < n; k++) {
 g[k][j] = g[k][j + 1];
 if (g[k][j] != '0')
 flag = false;
 }
 }
 if (flag)
 break;
 for (int k = 0; k < n; k++)
 g[k][m - 1] = '0';
 } else {
 i++;
 }
 }
 /*for (int i = 0; i < n; i++) {
 for (int j = 0; j < m; j++) {
 printf("%c", g[i][j]);
 }
 printf("\n");
 }
 printf("\n");*/
 } else {
 break;
 }
 }
 if (total == n * m) {
 printf("0\n");
 } else {
 printf("%d\n", ans);
 }
 }
 return 0;
}
