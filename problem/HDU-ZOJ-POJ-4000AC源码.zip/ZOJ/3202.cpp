 #include <vector>
#include <string>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <ctype.h>
#include <bitset>
#include <assert.h>

using namespace std;

#define REP(i, n) for(int i=0; i<(n); i++)
#define FOR(i, a, b) for(int i=(a); i<(b); i++)
#define IFOR(i, a, b) for(int i=(a); i>=(b); i--)
#define FORD(i, a, b, c) for(int i=(a); i<(b); i+=(c))

#define SS ({int x;scanf("%d", &x);x;})
#define SI(x) ((int)x.size())
#define PB(x) push_back(x)
#define MP(a,b) make_pair(a, b)
#define SORT(a) sort(a.begin(),a.end())
#define ITER(it,a) for(typeof(a.begin()) it = a.begin(); it!=a.end(); it++)
#define ALL(a) a.begin(),a.end()
#define INF 1000000000
#define V vector
#define S string
#define FST first
#define SEC second
typedef V<int> VI;
typedef V<S> VS;
typedef long long LL;
typedef pair<int, int> PII;

long long gcd(long long u,long long v) {
long long t;
while (v) {
t = u;
u = v;
v = t % v;
}
return u < 0 ? -u : u; /* abs(u) */
}
int main()
{
 int t,m,n,i,j,a;
 m=1;
 scanf("%d",&t);
 while(t--)
 {
 scanf("%d",&n);
 int max1,max2,pos1,pos2;
 max1=max2=0;
 pos1=pos2=-1;
 for(i=0;i<n;i++)
 {
 scanf("%d",&a);
 if(!i)
 {
 max1=a;
 pos1=i;
 }
 else
 {
 if(a>max1)
 {
 pos2=pos1;
 pos1=i;
 max2=max1;
 max1=a;
 }
 else
 {
 if(max2<a)
 {
 max2=a;
 pos2=i;
 }
 }
 }
 }
 cout<<pos1+1<<" "<<max2<<"\n";

 }
return 0;
}
