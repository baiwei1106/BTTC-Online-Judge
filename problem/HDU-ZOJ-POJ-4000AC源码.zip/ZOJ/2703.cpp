/*
 * Author: chlxyd
 * Created Time: 2013/8/1 14:38:26
 * File Name: H.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )

const int maxn = 11;
const int maxp = 40;
struct node {
 int h, t;
 vector<int> id;
};

int two(int x) {
 return 1 << x;
}

int now[maxn][maxn], ans, ansp[maxn][maxn];
vector<node> a[10]; 

bool can(int now[maxn][maxn], int *v, vector<node> &a) {
 rep (i, sz(a)) 
 if (v[i]) {
 bool flag = false;
 rep (j, 9) {
 int cnt = a[i].t;
 rep (k, 4) {
 if (now[j][k] == 0)
 cnt--; 
 } 
 if (cnt <= 0) {
 flag = true;
 int ai = 0;
 rep (k, 4)
 if (now[j][k] == 0) {
 if (ai >= a[i].t) break;
 now[j][k] = a[i].id[ai++];
 }
 break;
 }
 } 
 if (!flag) return false;
 }
 return true;
}

void gao1(vector<node> *a, int have) {
 //printf("%d %d\n", have, sz(a[1]));
 if (have < ans) return;
 int v[maxp];
 rep (i, sz(a[1]))
 v[i] = 1;
 if (!can(now, v, a[1])) {
 printf("error!\n");
 }
 if (have > ans) {
 ans = have;
 memcpy(ansp, now, sizeof(now));
 }
 //rep (i, 9) {
 //rep (j, 4) {
 //if (j != 0) printf(" ");
 //printf("%02d", now[i][j]);
 //}
 //puts("");
 //}
}

void gao2(vector<node> *a, int have) {
 //printf("%d\n", sz(a[1]));
 vector<node> b[10];
 int nnow[maxn][maxn];
 int nn = sz(a[2]);
 memcpy(nnow, now, sizeof(now));
 repf (i, 0, nn) {
 int add = 0;
 repf (j, 1, 4)
 b[j] = a[j];
 memcpy(now, nnow, sizeof(now));
 int v[maxp] = {0};
 rep (j, i) {
 int k = -1;
 rep (r, nn) {
 if (v[r]) continue;
 if (k == -1 || b[2][r].h > b[2][k].h)
 k = r;
 }
 v[k] = 1;
 add += b[2][k].h * 2;
 }
 if (!can(now, v, b[2])) {
 continue;
 }
 rep (j, nn) 
 if (!v[j]) {
 node x;
 x.h = b[2][j].h;
 x.t = 1;
 x.id.push_back(b[2][j].id.back());
 b[2][j].t = 1;
 b[2][j].id.pop_back();
 b[1].push_back(x);
 b[1].push_back(b[2][j]); 
 }
 gao1(b, have + add);
 }
}

void gao3(vector<node> *a, int have) {
 //printf("%d %d\n", sz(a[1]), sz(a[2]));
 vector<node> b[10];
 int nnow[maxn][maxn];
 int nn = sz(a[3]);
 memcpy(nnow, now, sizeof(now));
 repf (i, 0, nn) {
 int add = 0;
 repf (j, 1, 4)
 b[j] = a[j];
 memcpy(now, nnow, sizeof(now));
 int v[maxp] = {0};
 rep (j, i) {
 int k = -1;
 rep (r, nn) {
 if (v[r]) continue;
 if (k == -1 || b[3][r].h > b[3][k].h)
 k = r;
 } 
 v[k] = 1;
 add += b[3][k].h * 2 * 3;
 }

 if (!can(now, v, b[3])) {
 continue;
 }
 rep (j, nn) 
 if (!v[j]) {
 node x;
 x.h = b[3][j].h;
 x.t = 1;
 x.id.push_back(b[3][j].id.back());
 b[3][j].t = 2;
 b[3][j].id.pop_back();
 b[2].push_back(b[3][j]);
 b[1].push_back(x);
 }
 gao2(b, have + add);
 } 
}

void gao4(vector<node> *a, int have) {
 //printf("%d %d\n", sz(a[3]), sz(a[4]));
 vector<node> b[10];
 int nnow[maxn][maxn]; 
 memcpy(nnow, now, sizeof(now));
 repf (i, 0, sz(a[4])) { 
 int nn = sz(a[4]);
 int add = 0;
 repf (j, 1, 4)
 b[j] = a[j]; 
 memcpy(now, nnow, sizeof(now));
 int v[maxp] = {0};
 repf (j, 1, i) {
 int k = -1;
 rep (r, nn) {
 if (v[r]) continue;
 if (k == -1 || b[4][r].h > b[4][k].h) {
 k = r;
 }
 } 
 v[k] = 1;
 add += b[4][k].h * 12;
 } 
 
 if (!can(now, v, b[4])) {
 continue;
 } 
 if (nn == i) {
 gao3(b, have + add);
 }
 else {
 //puts("test");
 vector<node> cc;
 rep (j, nn)
 if (v[j] == 0)
 cc.push_back(b[4][j]);
 rep (k, two(nn - i)) { 
 vector<node> c = cc;
 repf (j, 1, 4)
 b[j] = a[j]; 
 rep (j, sz(c)) 
 if (two(j) & k){ //3
 node x;
 x.t = 1;
 x.h = c[j].h;
 x.id.push_back(c[j].id.back());
 c[j].t = 3;
 c[j].id.pop_back();
 b[3].push_back(c[j]);
 b[1].push_back(x);
 }
 else { //4
 node x;
 x.t = 2;
 x.h = c[j].h;
 x.id.push_back(c[j].id.back());
 c[j].id.pop_back();
 x.id.push_back(c[j].id.back());
 c[j].id.pop_back();
 c[j].t = 2;
 b[2].push_back(c[j]);
 b[2].push_back(x);
 }
 gao3(b, have + add);
 }
 }
 }
} 

void putAns() {
 printf("%d\n", ans);
 rep (i, 9) {
 rep (j, 4) {
 if (j != 0) printf(" ");
 printf("%d", ansp[i][j]);
 }
 puts("");
 }
 puts("");
}

int main(){
 int n;
 while (scanf("%d", &n) == 1) {
 repf (i, 1, 4)
 a[i].clear();
 rep (i, n) {
 node x;
 scanf("%d", &x.t);
 scanf("%d", &x.h);
 rep (i, x.t) {
 int y;
 scanf("%d", &y);
 x.id.push_back(y);
 }
 a[x.t].push_back(x); 
 //printf("%d\n", x.t);
 } 
 //printf("%d %d\n", sz(a[3]), sz(a[4]));
 memset(now, 0, sizeof(now));
 ans = -1;
 gao4(a, 0);
 putAns();
 }
 return 0;
}
