#include<stdio.h>
#include<math.h>
#include<algorithm>
#define MAXV 2000
#define PI 3.14159265358979323846
#define eps 1e-8
#define zero(x) (fabs(x)<eps)
#define _sign(x) ((x)>eps?1:((x)<-eps?2:0))
using namespace std;

const int dy[] = {-1, 0, 1, 0};
const int dx[] = {0, 1, 0, -1};

//��ά��
struct pt
{
	double x, y;
	pt(){}
	pt(double _x, double _y)
	{
		x = _x;
		y = _y;
	}
	pt operator - (const pt p1){return pt(x - p1.x, y - p1.y);}
	pt operator + (const pt p1){return pt(x + p1.x, y + p1.y);}
	pt operator / (double r){return pt(x / r, y / r);}
	pt operator * (double r){return pt(x * r, y * r);}
	bool operator == (const pt p1)const{return fabs(x-p1.x)<eps && fabs(y-p1.y)<eps;}
	bool operator != (const pt p1)const{return fabs(x-p1.x)>eps || fabs(y-p1.y)>eps;}
	bool operator < (const pt p1)const{return y < p1.y-eps || y < p1.y+eps && x < p1.x;}
	void read()
	{
		scanf("%lf %lf", &x, &y);
	}
	void disp()
	{
		printf("%.10lf %.10lf", x, y);
	}
	double len()
	{
		return sqrt(x*x + y*y);
	}
	pt unify()
	{
		return *this / len();
	}
};

//��� ���(�����) 
double cpr(const pt &a,const pt &b,const pt &c){return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);}
double dpr(const pt &a,const pt &b,const pt &c){return (b.x-a.x)*(c.x-a.x)+(b.y-a.y)*(c.y-a.y);}

//��� ���(��������) 
double cpr(const pt &a,const pt &b){return a.x*b.y-a.y*b.x;}
double dpr(const pt &a,const pt &b){return a.x*b.x+a.y*b.y;}

double dis(const pt &a, const pt &b){return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));}
double dis2(const pt &a, const pt &b){return (a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y);}

//��ֱ��ab��ֱ��cd�Ľ���
pt its(const pt &a, const pt &b, const pt &c, const pt &d)
{
	pt ret = a;
	double t = ((c.x - a.x)*(d.y - c.y) - (c.y - a.y)*(d.x - c.x))/
				((b.x - a.x)*(d.y - c.y) - (b.y - a.y)*(d.x - c.x));
	ret.x += (b.x - a.x) * t;
	ret.y += (b.y - a.y) * t;
	return ret;
}

//����ֱ����Բ�Ľ���,��ֱ֤����Բ�н���
//�����߶���Բ�Ľ����������������е��Ƿ����߶���
void intersection_line_circle(pt c, double r, pt l1, pt l2, pt &p1, pt &p2)
{
	pt p = c;
	p.x += l1.y - l2.y;
	p.y += l2.x - l1.x;
	p = its(p, c, l1, l2);
	double d = dis(p,c), t = sqrt(r*r - d*d) / dis(l1,l2);
	p2.x = p.x + (l2.x-l1.x)*t;
	p2.y = p.y + (l2.y-l1.y)*t;
	p1.x = p.x - (l2.x-l1.x)*t;
	p1.y = p.y - (l2.y-l1.y)*t;
}

//��p��ֱ��ab���� 
double disptoline(const pt &p, const pt &a, const pt &b)
{
	return fabs(cpr(p, a, b)) / dis(a, b);
}


///////////////////////////////////////////

double s1, s2, s3, r2[4];
double ang[4];
pt p[4], q[4], X;
double H, W;

bool ok(int idx, double sb)
{
//	printf("sb = %lf\n", sb);
	
	pt tmp[4];
	for (int i = 0; i < 4; i++)
	{
		tmp[i] = X + pt(cos(sb + ang[i] - ang[idx]) * r2[i], sin(sb + ang[i] - ang[idx]) * r2[i]);
	}
	for (int i = 0; i < 4; i++)
	for (int j = 0; j < 4; j++)
	{
		if (cpr(q[i], q[(i + 1) % 4], tmp[j]) < -eps)return false;
		if (cpr(tmp[i], tmp[(i + 1) % 4], p[j]) < -eps)return false;
	}
	tmp[0].disp();
	printf(" ");
	tmp[1].disp();
	printf(" ");
	tmp[2].disp();
	printf(" ");
	tmp[3].disp();
	printf("\n");
	
	return true;	
}

void solve()
{
	scanf("%lf %lf %lf", &s1, &W, &H);
	scanf("%lf", &s2);
	scanf("%lf", &s3);
	for (int i = 0; i < 4; i++)
		p[i].read();
	q[0] = pt(0.0, 0.0);	
	q[1] = pt(W, 0.0);	
	q[2] = pt(W, H);	
	q[3] = pt(0.0, H);
	
	double a = p[0].x, b = p[0].y;
	double x1 = p[1].x - p[0].x;
	double y1 = p[1].y - p[0].y;
	double x2 = p[3].x - p[0].x;
	double y2 = p[3].y - p[0].y;
	
	X.y = (b * (W - x1) + a * y1) / ((W - x1) * (H - y2) - x2 * y1);
	X.x = (a + x2 * X.y) / (W - x1);
	X.x *= W;
	X.y *= H;
	
//	X.disp();puts("");
//	puts(okk(X) ? "YES" : "NO");
	
	for (int i = 0; i < 4; i++)
	{
		ang[i] = atan2(p[i].y - X.y, p[i].x - X.x);
		r2[i] = dis(X, p[i]) * s2 / s3;
	}
	
	pt X1, X2;
	double r;
	
	pt f[4];
	for (int i = 0; i < 4; i++)
	{
		f[i] = X + (p[i] - X) * s2 / s3;
	}
		
	if (ok(0, 0.0))return;
	for (int i = 0; i < 4; i++)
	{
		r = dis(X, p[i]) * s2 / s3;
		for (int j = 0; j < 4; j++)
		{
			if (disptoline(X, q[j], q[(j + 1) % 4]) < r)
			{
				intersection_line_circle(X, r, q[j], q[(j + 1) % 4], X1, X2);
				if (ok(i, atan2(X1.y - X.y, X1.x - X.x)))return;
				if (ok(i, atan2(X2.y - X.y, X2.x - X.x)))return;
			}
		}

		r = dis(X, p[i]);
		for (int j = 0; j < 4; j++)
		{
			if (disptoline(X, f[j], f[(j + 1) % 4]) < r)
			{
				intersection_line_circle(X, r, f[j], f[(j + 1) % 4], X1, X2);
				if (ok(i, 2 * ang[i] - atan2(X1.y - X.y, X1.x - X.x)))return;
				if (ok(i, 2 * ang[i] - atan2(X2.y - X.y, X2.x - X.x)))return;
			}
		}
	}
	
	puts("impossible");
}

int main()
{
	int tc;
	scanf("%d", &tc);
	while (tc--)
	{
		solve();
	}
	return 0;
}
