#include<stdio.h>

const long long f[6][6][6]={
	2ll, 3ll, 4ll, 5ll, 6ll, 7ll, 
	3ll, 6ll, 10ll, 15ll, 21ll, 28ll, 
	4ll, 10ll, 20ll, 35ll, 56ll, 84ll, 
	5ll, 15ll, 35ll, 70ll, 126ll, 210ll, 
	6ll, 21ll, 56ll, 126ll, 252ll, 462ll, 
	7ll, 28ll, 84ll, 210ll, 462ll, 924ll, 
	
	3ll, 6ll, 10ll, 15ll, 21ll, 28ll, 
	6ll, 20ll, 50ll, 105ll, 196ll, 336ll, 
	10ll, 50ll, 175ll, 490ll, 1176ll, 2520ll, 
	15ll, 105ll, 490ll, 1764ll, 5292ll, 13860ll, 
	21ll, 196ll, 1176ll, 5292ll, 19404ll, 60984ll, 
	28ll, 336ll, 2520ll, 13860ll, 60984ll, 226512ll, 
	
	4ll, 10ll, 20ll, 35ll, 56ll, 84ll, 
	10ll, 50ll, 175ll, 490ll, 1176ll, 2520ll, 
	20ll, 175ll, 980ll, 4116ll, 14112ll, 41580ll, 
	35ll, 490ll, 4116ll, 24696ll, 116424ll, 457380ll, 
	56ll, 1176ll, 14112ll, 116424ll, 731808ll, 3737448ll, 
	84ll, 2520ll, 41580ll, 457380ll, 3737448ll, 24293412ll, 
	
	5ll, 15ll, 35ll, 70ll, 126ll, 210ll, 
	15ll, 105ll, 490ll, 1764ll, 5292ll, 13860ll, 
	35ll, 490ll, 4116ll, 24696ll, 116424ll, 457380ll, 
	70ll, 1764ll, 24696ll, 232848ll, 1646568ll, 9343620ll, 
	126ll, 5292ll, 116424ll, 1646568ll, 16818516ll, 133613766ll, 
	210ll, 13860ll, 457380ll, 9343620ll, 133613766ll, 1447482465ll, 
	
	6ll, 21ll, 56ll, 126ll, 252ll, 462ll, 
	21ll, 196ll, 1176ll, 5292ll, 19404ll, 60984ll, 
	56ll, 1176ll, 14112ll, 116424ll, 731808ll, 3737448ll, 
	126ll, 5292ll, 116424ll, 1646568ll, 16818516ll, 133613766ll, 
	252ll, 19404ll, 731808ll, 16818516ll, 267227532ll, 3184461423ll, 
	462ll, 60984ll, 3737448ll, 133613766ll, 3184461423ll, 55197331332ll, 
	
	7ll, 28ll, 84ll, 210ll, 462ll, 924ll, 
	28ll, 336ll, 2520ll, 13860ll, 60984ll, 226512ll, 
	84ll, 2520ll, 41580ll, 457380ll, 3737448ll, 24293412ll, 
	210ll, 13860ll, 457380ll, 9343620ll, 133613766ll, 1447482465ll, 
	462ll, 60984ll, 3737448ll, 133613766ll, 3184461423ll, 55197331332ll, 
	924ll, 226512ll, 24293412ll, 1447482465ll, 55197331332ll, 1478619421136ll
};

int main()
{
	int n,m,h;
	while ( scanf("%d%d%d",&n,&m,&h)!=EOF )
		printf("%lld\n",f[n-1][m-1][h-1]);
}
