#include <stdio.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <string>
#include <map>
#include <stack>
#include <queue>
#include <algorithm>
#define N
#define M
#define inf 0x3f3f3f3f
#define eps 1e-8
#define clr(a,b) memset(a,b,sizeof(a))
#define LL long long
#define ULL unsigned long long
using namespace std;

const int INF = 0x3f3f3f3f;

int nextN(int n)
{
 int x = n&(-n);
 int t = n+x;
 return ((n^t)/x)>>2|t;
}

//1...1(m&Icirc;&raquo;)0..0(n-m&Icirc;&raquo;)
//(1<<n)-(1<<(n-m))

int cntbit(int x)
{
 x = (x & 0x55555555) + ((x >> 1) & 0x55555555);
 x = (x & 0x33333333) + ((x >> 2) & 0x33333333);
 x = (x & 0x0F0F0F0F) + ((x >> 4) & 0x0F0F0F0F);
 x = (x & 0x00FF00FF) + ((x >> 8) & 0x00FF00FF);
 x = (x & 0x0000FFFF) + ((x >> 16) & 0x0000FFFF);
 return x;
}

int num[2100];
int p[29000][2];
int cnt,tot;
int T;


map<int,int> mp;

const int NV = 2100,NE = 29000*2;
int e,head[NV],d[NV],vd[NV],pre[NV],cur[NV];
struct E
{
 int u,v,w,next;
}edge[NE];

struct FlowNetwork{
 FlowNetwork(){e=0;clr(head,-1);}
 inline void addedge(int u,int v,int w)
 {
 edge[e].u = u;edge[e].v = v;edge[e].w = w;edge[e].next = head[u];head[u] = e++;
 edge[e].u = v;edge[e].v = u;edge[e].w = 0;edge[e].next = head[v];head[v] = e++;
 }

 int sap(int s,int t,int n)
 {
 int i,u,mini,ans = 0;
 clr(d,0);clr(vd,0);
 vd[0] = n;
 cur[u=s] = head[s];
 pre[s] = -1;

 if(s == t) return 0;
 while(d[s] < n)
 {
 if(u == t)
 {
 for(mini = INF,i=pre[u];~i;i=pre[edge[i].u])
 mini = min(mini,edge[i].w);
 for(i = pre[u];~i;i=pre[ edge[i].u ] )
 edge[i].w -= mini,edge[i^1].w += mini;
 ans += mini;u=s;
 }

 for(i = cur[u];~i; i=edge[i].next)
 {
 if(edge[i].w > 0&& d[u] == d[edge[i].v]+1)
 {
 cur[u] = i;
 pre[u = edge[i].v] = i;
 break;
 }
 }

 if(i == -1)
 {
 cur[u] = head[u];
 if(--vd[d[u] ] == 0) break;
 vd[++d[u]]++;
 if(u!= s) u = edge[pre[u]].u;
 }
 }
 return ans;
 }
};

int main()
{
 int num1 = (1<<12)-1;
 cnt = 0,tot = 0;
 mp.clear();
 for(int i=num1; i<=100000; i++)
 if(cntbit(i)>11)
 {
 if(cntbit(i)== 12 && (i&1)) continue;
 num[++cnt] = i;
 mp.insert(make_pair(i,cnt));
 }

 for(int i=1; i<=cnt; i++)
 for(int j=i+1; j<=cnt; j++)
 {
 int t = (num[i] & num[j]);
 if(t%2 == 0 && cntbit(t)>=12 && t>=50001)
 {
 p[++tot][0] = num[i];
 p[tot][1] = num[j];
 }
 }

 int a,b;
 while(~scanf("%d%d",&a,&b))
 {
 if(a == b)
 {
 puts("150");
 continue;
 }
 if(a > b || mp.find(a) == mp.end() || mp.find(b) == mp.end())
 {
 puts("0");
 continue;
 }

 int ans;
 FlowNetwork ob;

 int st = 0,ed = mp[b];
 for(int i=1; i<=cnt; i++)
 if(num[i] == a)
 ob.addedge(st,mp[a],150);

 for(int i=1; i<=tot; i++)
 {
 if(p[i][0]<a || p[i][1] > b) continue;
 ob.addedge(mp[p[i][0]],mp[p[i][1]],1);
 }

 ans = ob.sap(st,ed,cnt+1);

 printf("%d\n",ans);
 }
 return 0;
}


