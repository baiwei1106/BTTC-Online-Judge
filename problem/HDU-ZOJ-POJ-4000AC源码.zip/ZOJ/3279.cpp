#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
const int maxn=100010;
int n,a[maxn];

void ins(int k,int x)
{
 for(;k<=n;k+=k&-k) a[k]+=x;
}
int get(int k)
{
 int sum=0;
 for(;k;k-=k&-k) sum+=a[k];
 return sum;
}
int main()
{
 int q,x,y;
 char op[2];
 while(cin>>n)
 {
 memset(a,0,sizeof(a));
 for(int i=1;i<=n;i++) cin>>x,ins(i,x);
 cin>>q;
 while(q--)
 {
 scanf("%s%d",op,&x);
 if(op[0]=='p')
 {
 scanf("%d",&y);
 ins(x,y-get(x)+get(x-1));
 }
 else
 {
 int low=1,up=n+1,ans=0;
 while(low<=up)
 {
 int mid=(low+up)/2,tmp=get(mid-1);
 if(get(mid-1)<x) ans=mid,low=mid+1;//rank(mid)<=x
 else up=mid-1;
 }
 printf("%d\n",ans);
 }
 }
 }
 return 0;
}
