#include <cstdio>

using namespace std;

struct TT {
    int x, y;
};

TT a, b, sa, sb;

bool isless(const TT &cmp1, const TT &cmp2)
{
    if (cmp1.x == cmp2.x)
        return cmp1.y < cmp2.y;
    return cmp1.x < cmp2.x;
}

inline
void add(TT &t)
{
    t.y++;
    t.x += t.y / 60;
    t.y = t.y % 60;
}

const double E = 1e-12;

inline
int dblcmp(double x)
{
    if (x > -E && x < E)
        return 0;
    return x > 0 ? 1 : -1;
}

bool solve(TT &t)
{
    double ang1 = t.y * 6;
    double ang2 = t.x % 12 * 30 + t.y * 0.5;
    if (dblcmp(ang1 + 5.5 - ang2) > 0 && dblcmp(ang1 - ang2) <= 0)
        return true;
    return false;
}

int main()
{
    //freopen("input.txt", "r", stdin);
    printf("Program 3 by team X\n");
    printf("Initial time  Final time  Passes\n");
    while (scanf("%d%d%d%d", &a.x, &a.y, &b.x, &b.y) == 4) {
        sa = a;
        sb = b;
        a.x %= 12;
        b.x %= 12;
        if (!isless(a, b)) {
            b.x += 12;
        }
        TT tm = a;
        int ans = 0;
        while (isless(tm, b)) {
            if (solve(tm)) {
                ans++;
            }
            add(tm);
        }

        double ang1 = b.y * 6;
        double ang2 = b.x % 12 * 30 + b.y * 0.5;
        if (dblcmp(ang1 - ang2) == 0)
            ans++;
        printf("       %02d:%02d       %02d:%02d%8d\n", sa.x, sa.y, sb.x, sb.y, ans);
    }
    printf("End of program 3 by team X\n");
    return 0;
}
