#include <iostream>
#include <string>
using namespace std;
int main()
{
 int t;
 cin >> t;
 while(t--)
 {
 string s;
 int n,m,ans=0;
 cin >> s;
 if(s[0]=='F')
 {
 cin >> n;
 cin >> m;
 ans = m;
 for(int i = 1;i < n;i ++)
 {
 cin >> m;
 if(m < ans)
 ans = m;
 }
 }
 else
 {
 cin >> n;
 cin >> m;
 ans = m;
 for(int i = 1;i < n;i ++)
 {
 cin >> m;
 if(m > ans)
 ans = m;
 }
 }
 cout << ans << endl;
 } 
 return 0;
}
