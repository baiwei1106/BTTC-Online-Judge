#include <stdio.h>
int main()
{
 int n ;
 while(scanf("%d",&n) !=EOF)
 {
 if( n == 0)
 break;
 if( n<= 4 )
 {
 printf("10\n") ;
 continue;
 }
 double sum ;
 double s ;
 int t = n /8 ;
 sum =(double) t * 18 ;
 int k = n % 8 ;
 if( k <= 4 )
 s = 10 ;
 else
 s= 10 + ( k-4) * 2 ;
 if(k < 5 && t )
 s = k * 1.0 * 2.4 ;
 sum += s ;
 k = int(sum) ;
 if( sum - k <= 0.000000 )
 printf("%.0lf\n",sum ) ;
 else
 printf("%.1lf\n",sum ) ;
 }
 return 0 ;
}