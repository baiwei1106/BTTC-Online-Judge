/*
 * Author: OpenLegend
 * Created Time: 2010-8-21 14:22:52
 * File Name: e.cpp
 */
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
using namespace std;
const int maxn = 305;
const int K = 101;
int T1[maxn], T2[maxn], a[maxn], b[maxn];
int dp[maxn][maxn][205];
void update(int& x, int v){
 if(x == -1 || x > v) x = v;
}
int main() {
 int test, n, n1, n2;
 scanf("%d", &test);
 while(test --){
 scanf("%d", &n);
 for(int i = 0; i < n; i ++) scanf("%d", &T1[i]);
 for(int i = 0; i < n; i ++) scanf("%d", &T2[i]);
 scanf("%d%d", &n1, &n2);
 for(int i = 0; i < n1; i ++){
 scanf("%d", &a[i]);
 a[i] --;
 }
 for(int i = 0; i < n2; i ++){
 scanf("%d", &b[i]);
 b[i] --;
 }
 for(int i = 0; i <= n1; i ++){
 for(int j = 0; j <= n2; j ++){
 for(int l = 0; l <= 2*K; l ++){
 dp[i][j][l] = -1;
 }
 }
 }
 dp[0][0][K] = 0;
 int ans = -1;
 for(int i = 0; i <= n1; i ++){
 for(int j = 0; j <= n2; j ++){
 for(int l = 0; l <= 2*K; l ++){
 if(dp[i][j][l] == -1) continue;
 //printf("i = %d j = %d l = %d %d\n", i, j, l-K, dp[i][j][l]);
 if(i == n1 && j == n2){
 int x = dp[i][j][l] + max(0, l-K);
 update(ans, x);
 }
 if(i != n1){
 int v = l - K, tmp = dp[i][j][l];
 //if(i == 1 && j == 1) printf("%d %d %d %d %d\n", v, tmp, b[j-1], a[i], T1[a[i]]);
 if(v < 0 && b[j-1] == a[i]) v = 0;
 if(v > 0){
 tmp += v;
 v = 0;
 }
 update(dp[i+1][j][T1[a[i]]+v + K], tmp);
 }
 if(j != n2){
 int v = l - K, tmp = dp[i][j][l];
 if(v > 0 && a[i-1] == b[j]){
 tmp += v;
 v = 0;
 }
 if(v < 0) v = 0;
 update(dp[i][j+1][-T2[b[j]]+v + K], tmp + T2[b[j]]);
 }
 }
 }
 }
 printf("%d\n", ans);
 }
 return 0;
}

