#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

using namespace std;

typedef long long ll;
typedef vector <int> vi;

#define FOR(i, a, b) for (i = (a); i <= (b); i++)
#define FORD(i, a, b) for (i = (a); i >= (b); i--)
#define REP(i, a) for (i = 0; i < (a); i++)
#define REPD(i, a) for (i = (a) - 1; i >= 0; i--)

#define ALL(v) (v).begin(), (v).end()
#define SET(a, x) memset((a), (x), sizeof(a))
#define SZ(a) ((int)(a).size())
#define CL(a) ((a).clear())

#define SORT(x) sort(ALL(x))


#define PB push_back

#define filer() freopen("in.txt","r",stdin)
#define filew() freopen("out.txt","w",stdout)

//template<typename T> inline T max(T a, T b) { return (a > b ? a : b); }
//template<typename T> inline T min(T a, T b) { return (a < b ? a : b); }
#define NN 2004

// adjacency matrix (fill this up)
int cap[NN][NN];

// flow network
int fnet[NN][NN];

// BFS
int q[NN], qf, qb, prev[NN];

int fordFulkerson( int n, int s, int t )
{
 // init the flow network
 memset( fnet, 0, sizeof( fnet ) );

 int flow = 0;

 while( true )
 {
 // find an augmenting path
 memset( prev, -1, sizeof( prev ) );
 qf = qb = 0;
 prev[q[qb++] = s] = -2;
 while( qb > qf && prev[t] == -1 )
 for( int u = q[qf++], v = 0; v < n; v++ )
 if( prev[v] == -1 && fnet[u][v] - fnet[v][u] < cap[u][v] )
 prev[q[qb++] = v] = u;

 // see if we're done
 if( prev[t] == -1 ) break;

 // get the bottleneck capacity
 int bot = 0x7FFFFFFF;
 for( int v = t, u = prev[v]; u >= 0; v = u, u = prev[v] )
 bot =min(bot, cap[u][v] - fnet[u][v] + fnet[v][u]);

 // update the flow network
 for( int v = t, u = prev[v]; u >= 0; v = u, u = prev[v] )
 fnet[u][v] += bot;

 flow += bot;
 if(flow==2)break;
 }

 return flow;
}

void init()
{
 SET(cap,0);
}

int SRC,TNK;
int main()
{
 int u,v,i,t,N,M;
 scanf("%d",&t);
 while(t--)
 {
 scanf("%d%d",&N,&M);
 init();


 SRC=0;
 TNK=2*N+1;


 FOR(i,1,N)cap[i][N+i]=1;

 REP(i,M)
 {
 scanf("%d%d",&u,&v);
 cap[u+N][v]=cap[v+N][u]=1;
 }

 int u,v;

 scanf("%d%d",&u,&v);
 cap[SRC][v]=cap[SRC][u]=1;
 cap[u+N][v]=cap[v+N][u]=0;

 scanf("%d%d",&u,&v);
 cap[u+N][TNK]=cap[v+N][TNK]=1;
 cap[u+N][v]=cap[v+N][u]=0;

 int F;
 scanf("%d",&F);
 REP(i,F)
 {
 scanf("%d%d",&u,&v);
 cap[u+N][v]=cap[v+N][u]=0;
 }

 if(fordFulkerson(2*N+2,SRC,TNK)==2)printf("YES\n");
 else printf("NO\n");

 }
 return 0;
}
