#include <stdio.h>
#include <string.h>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

int a[1000];
int main()
{
 int i,j,n,T,s,x,y,z,ans;
 while(1)
 {
 scanf("%d",&n);
 if (n==0) break;
 ans=0;
 while(n>2)
 {
 ans=ans+n/3;
 n=n%3+n/3;
 }
 if (n==2) ans++;
 printf("%d\n",ans);
 }
 return 0;
}
