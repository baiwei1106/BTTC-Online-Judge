/*
 * 1.cpp
 *
 * Created on: 2011-5-28
 * Author: zcoder
 */

#include<iostream>
#include<fstream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
using namespace std;
#define FF(i,n) for(int i=0;i<n;i++)
#define FOR(i,a,b) for(int i=a;i<b;i++)
#define CC(n,what) memset(n,what,sizeof(n))
#define N 60
char mm[N][N][N];
int vis[N][N][N];
int p,k,m;
int res[4][125000];
int sp[4];
const int dx[6] = {0,0,1,-1,0,0};
const int dy[6] = {-1,1,0,0,0,0};
const int dz[6] = {0,0,0,0,-1,1};
int order[4];
int ord;
int valid(int x,int y,int z){
	if(x>=0&&x<p&&y>=0&&y<k&&z>=0&&z<m)
		return 1;
	return 0;
}
void dfs(char ty,int x,int y,int z){
	res[ty-'a'][sp[ty-'a']]++;
	vis[z][x][y] = 1;
	FF(di,6){
		int nx = x+dx[di];
		int ny = y+dy[di];
		int nz = z+dz[di];
		if(valid(nx,ny,nz)&&(!vis[nz][nx][ny])&&(mm[nz][nx][ny]==ty))
			dfs(ty,nx,ny,nz);
	}
}
int main(){
//	freopen("test.in","r",stdin);
	int nc = 0;
	while(cin>>p>>k>>m){
		if(nc)
			cout<<endl;
		CC(vis,0);
		CC(mm,0);
		CC(res,0);
		CC(sp,0);
		CC(order,-1);
		ord = 0;
		FF(i,m){
			FF(j,p){
				cin>>mm[i][j];
				/*
				FF(kk,k){
					if(mm[i][j][kk]!='*'&&order[mm[i][j][kk]-'a']==-1){
						order[ord++] = mm[i][j][kk]-'a';
					}
				}
				*/
			}
		}
		FF(z,m){
			FF(x,p){
				FF(y,k){
					if(mm[z][x][y]!='*'&&!vis[z][x][y]){
						dfs(mm[z][x][y],x,y,z);
						sp[mm[z][x][y]-'a']++;
					}
				}
			}
		}
		order[0] = 0;
		order[1] = 1;
		order[2] = 2;
		order[3] = 3;
		cout<<"Case "<<++nc<<":"<<endl;
		FF(i,4){
			cout<<(char)(order[i]+'a');
			sort(res[order[i]],res[order[i]]+sp[order[i]]);
			for(int j=sp[order[i]]-1;j>=0;j--)
				cout<<" "<<res[order[i]][j];
			cout<<endl;
		}
	}
	return 0;
}
