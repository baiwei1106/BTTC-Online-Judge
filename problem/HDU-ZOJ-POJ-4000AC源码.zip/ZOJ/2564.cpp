#include <algorithm>
#include <cstring>
#include <cstdio>
#include <map>
#include <set>
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
typedef long long LL;
typedef pair<double, int> pii;
#define foreach(i,n) for( __typeof(n.begin()) i = n.begin(); i!=n.end(); i++)
#define X first
#define Y second

const double eps = 1e-8;
int sgn(double x){
 return (x > eps) - (x < -eps);
}
const double PI = acos(-1);
bool cmp(const pii& a, const pii& b){
 return a.X < b.X;
}

int n;
double r, h;
double mi;

vector<int> doit(vector<pii> &v1, vector<pii> & v2){
 vector<int>ans;
 double tot = 1e14;
 for (int i = 0; i < n; i++){
 double d = fabs(v2[i].X - v1[0].X);

 if (sgn(d - PI) > 0 )d = 2*PI - d;
 double res = hypot(d*r, h/2);
 vector<int > tmp;
 tmp.push_back(v2[i].Y);
 for (int j = 1, k = (i+1)%n; j < n; j++, k = (k+1)%n){
 tmp.push_back(v2[k].Y);
 double d = fabs(v2[k].X - v1[j].X);

 if (sgn(d - PI) > 0 )d = 2*PI - d;
 res += hypot(d*r, h/2);
 }
 if (res < tot){
 tot = res;
 ans = tmp;
 }
 }
 mi += tot;
 return ans;

}


int main(){
 // freopen("in.txt", "r", stdin);

 while (scanf ("%d%lf%lf", &n, &r, &h) == 3){
 mi = 0;
 vector<pii> v1, v2, v3;
 double x;
 for (int i = 0; i < n; i++){
 scanf ("%lf", &x);
 if (sgn(x) < 0)x += 2*PI;
 v1.push_back(pii(x, i));
 }
 for (int i = 0; i < n; i++){
 scanf ("%lf", &x);
 if (sgn(x) < 0)x += 2*PI;
 v2.push_back(pii(x, i));
 }
 for (int i = 0; i < n; i++){
 scanf ("%lf", &x);
 if (sgn(x) < 0)x += 2*PI;
 v3.push_back(pii(x, i));
 }

 sort(v1.begin(), v1.end(), cmp);
 sort(v2.begin(), v2.end(), cmp);
 sort(v3.begin(), v3.end(), cmp);
 vector<int> ans1 = doit(v2, v1);
 vector<int> ans3 = doit(v2, v3);
 printf ("%.14f\n", mi);
 for (int i = 0; i < n; i++){
 printf ("%d %d %d\n", ans1[i]+1, v2[i].Y+1, ans3[i]+1);

 }
 }

 return 0;
}
