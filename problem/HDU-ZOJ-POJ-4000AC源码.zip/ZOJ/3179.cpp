#include <iostream>
#include <string>
#include <algorithm>
#include <cstring>
#include <cstdio>

using namespace std;

char str[8][10];

int main()
{
 int n;
 int x,y;
 int T;
 cin>>T;
 while(T--)
 {
 cin>>x>>y;
 if(x>y)swap(x,y);
 for(int i=0; i<8; i++)
 cin>>str[i];
 int sum=0;
 for(int i=0; i<6; i++)
 {
 sum*=10;
 if(str[0][i]=='|')sum+=5;
 if(str[4][i]=='|')sum+=1;
 if(str[5][i]=='|')sum+=2;
 if(str[6][i]=='|')sum+=3;
 if(str[7][i]=='|')sum+=4;
 }
 int ret=(x+y)*(y-x+1)/2;
 if(sum==ret)puts("No mistake");
 else puts("Mistake");
 
 }
 return 0;
}