/*
 * Author: xioumu
 * Created Time: 2013/7/28 14:06:14
 * File Name: F.cpp
 * solve: F.cpp
 */
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
#include<set>
#include<iostream>
#include<vector>
#include<queue>

using namespace std;
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clr(x) memset(x, 0, sizeof(x))
#define clrs( x , y ) memset(x, y, sizeof(x))
#define out(x) printf(#x" %d\n", x)
#define sqr(x) ((x) * (x))
typedef long long lint;

const int maxint = -1u>>1;
const double eps = 1e-8;
const int maxn = 30 * 30 * 2 + 10;

int sgn(const double &x) { return (x > eps) - (x < -eps); }

struct Graph1 {
 struct Adj {
 int v, c, b;
 Adj(int _v, int _c, int _b) :
 v(_v), c(_c), b(_b) {}
 Adj(){}
 };
 int n, S, T, h[maxn], cnt[maxn];
 vector<Adj> adj[maxn];
 void clear() {
 for (int i = 0; i < n; i++) {
 adj[i].clear();
 }
 n = 0;
 }
 void insert(int u, int v, int c, int d = 0) {
 n = max(n, max(u, v) + 1);
 adj[u].push_back(Adj(v, c, adj[v].size()));
 adj[v].push_back(Adj(u, c * d, adj[u].size() - 1));
 }
 int maxflow(int _S, int _T) {
 S = _S, T = _T;
 fill(h, h + n, 0);
 fill(cnt, cnt + n, 0);
 int flow = 0;
 while (h[S] < n) {
 flow += dfs(S, maxint);
 }
 return flow;
 }
 int dfs(int u, int flow) {
 if (u == T) {
 return flow;
 }
 int minh = n - 1, ct = 0;
 for (vector<Adj>::iterator it = adj[u].begin(); flow && it != adj[u].end(); ++it) {
 if (it->c) {
 if (h[it->v] + 1 == h[u]) {
 int k = dfs(it->v, min(it->c, flow));
 if (k) {
 it->c -= k;
 adj[it->v][it->b].c += k;
 flow -= k;
 ct += k;
 }
 if (h[S] >= n) {
 return ct;
 }
 }
 minh = min(minh, h[it->v]);
 }
 }
 if (ct) {
 return ct;
 }
 if (--cnt[h[u]] == 0) {
 h[S] = n;
 }
 h[u] = minh + 1;
 ++cnt[h[u]];
 return 0;
 }
}G;

struct node {
 int x, y1, y2, t;
 char w;
 node (int _x = 0, int _y1 = 0, int _y2 = 0, int _t = 0, char _w = 0) : 
 x(_x), y1(_y1), y2(_y2), t(_t), w(_w){
 }
};

char s[maxn][maxn];
int hid[maxn][maxn], vid[maxn][maxn];
vector<node> a;
int S, T, ss, hh, vv;
int n, m;

void init() {
 a.clear();
 rep (i, n) {
 int h = sz(a);
 int j = 0, last = 0;
 while (j < m) {
 if (j == 0 || s[i][j] == s[i][j - 1]) {
 hid[i][j] = h;
 }
 else {
 a.push_back(node(i, last, j - 1, 0, s[i][j - 1]));
 h++; 
 last = j;
 hid[i][j] = h;
 }
 j++;
 }
 a.push_back(node(i, last, j - 1, 0, s[i][j - 1]));
 }
 rep (j, m) {
 int h = sz(a);
 int i = 0, last = 0; 
 while (i < n) {
 if (i == 0 || s[i][j] == s[i - 1][j]) {
 vid[i][j] = h;
 }
 else {
 a.push_back(node(j, last, i - 1, 1, s[i - 1][j]));
 h++;
 last = i;
 vid[i][j] = h;
 }
 i++;
 }
 a.push_back(node(j, last, i - 1, 1, s[i - 1][j]));
 }
}

void getG() {
 G.clear();
 S = sz(a);
 T = sz(a) + 1;
 //rep (i, n) {
 //rep (j, m)
 //printf("%d ", hid[i][j]);
 //puts("");
 //}
 //rep (i, n) {
 //rep (j, m)
 //printf("%d ", vid[i][j]);
 //puts("");
 //}
 rep (i, n)
 rep (j, m) {
 G.insert(hid[i][j], vid[i][j], ss); 
 //printf("%d %d %d\n", hid[i][j], vid[i][j], ss);
 }
 rep (i, sz(a)) {
 if (a[i].t == 0) {
 G.insert(S, i, hh);
 //printf("%d %d %d\n", S, i, hh);
 }
 else {
 G.insert(i, T, vv);
 //printf("%d %d %d\n", i, T, vv);
 }
 }
}

int v[maxn];
vector<node> ans;

void dfs(int w) {
 if (v[w]) return;
 v[w] = 1;
 rep (i, sz(G.adj[w])) {
 int j = G.adj[w][i].v;
 if (G.adj[w][i].c > 0)
 dfs(j);
 }
}
void getAns() {
 int flow = G.maxflow(S, T);
 printf("%d", flow);
 clr(v);
 dfs(S);
 ans.clear();
 //printf("%d\n", v[T]);
 rep (i, T + 1) {
 rep (k, sz(G.adj[i])) {
 int j = G.adj[i][k].v;
 if (v[i] && !v[j]) {
 //printf("%d %d\n", i, j);
 if (i == S) {
 //printf("h %d %d %d %d %c\n", a[j].x + 1, a[j].y1 + 1, a[j].x + 1, a[j].y2 + 1, a[j].w);
 ans.push_back(a[j]);
 }
 else if (j == T) {
 //printf("v %d %d %d %d %c\n", a[i].y1 + 1, a[i].x + 1, a[i].y2 + 1, a[i].x + 1, a[i].w); 
 ans.push_back(a[i]);
 }
 else { 
 int x = a[i].x, y = a[j].x;
 if (a[i].t == 1) {
 continue;
 swap(x, y);
 }
 //printf("w : %c %c %d %d %d\n", a[i].w, a[j].w, i, j, S);
 ans.push_back(node(x, y, 0, 2, a[i].w));
 //printf("s %d %d %c\n", x + 1, y + 1, a[i].w); 
 }
 }
 }
 } 
 printf(" %d\n", sz(ans));
 rep (i, sz(ans)) {
 if (ans[i].t == 0) {
 printf("h %d %d %d %d %c\n", 
 ans[i].x + 1, ans[i].y1 + 1, ans[i].x + 1, ans[i].y2 + 1, ans[i].w);
 }
 else if (ans[i].t == 1) {
 printf("v %d %d %d %d %c\n", 
 ans[i].y1 + 1, ans[i].x + 1, ans[i].y2 + 1, ans[i].x + 1, ans[i].w); 
 }
 else {
 printf("s %d %d %c\n", ans[i].x + 1, ans[i].y1 + 1, ans[i].w); 
 }
 }
}

int main() {
 int T;
 bool blank = 0;
 //freopen("painter.in", "r", stdin);
 //freopen("painter.out", "w", stdout);
 scanf("%d", &T);
 while (T--) {
 if (blank) puts("");
 blank = 1;
 scanf("%d%d%d%d%d", &n, &m, &hh, &vv, &ss);
 rep (i, n)
 scanf("%s", s[i]);
 init();
 getG(); 
 getAns(); 
 }
 return 0;
}
