#include <iostream>
using namespace std;

#define INF 1000000000
#define Min(a,b) ((a)<(b)?(a):(b))

int dp[10005];

int main()
{
 int m,n,T;
 cin>>T;
 while(T--)
 {
 int i,j;
 int a[101],maxA=0,limit;
 cin>>m>>n;
 for(i=0;i<m;i++)
 {
 cin>>a[i];
 maxA=a[i]>maxA?a[i]:maxA;
 }
 limit=maxA*maxA;
 if(n%maxA==0)
 {
 cout<<n/maxA<<endl;
 continue;
 }
 for(i=1;i<=10000;i++)
 dp[i]=INF;
 for(dp[0]=0,i=0;i<m;i++)
 {
 for(j=a[i];j<=limit;j++)
 {
 dp[j]=Min(dp[j],dp[j-a[i]]+1);
 }
 }
 if(n<=limit)
 {
 if(dp[n]!=INF)
 cout<<dp[n]<<endl;
 else
 cout<<"-1\n";
 }
 else
 {
 if(dp[n%limit]!=INF)
 cout<<n/limit*maxA+dp[n%limit]<<endl;
 else
 cout<<"-1\n";
 }
 }
 return 0;
}
