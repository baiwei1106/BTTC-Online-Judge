#include <iostream>
#include <algorithm>
#include <string>
#include <string.h>
#include <cstdio>
#include <math.h>
#include <vector>
using namespace std;
#define inf 1000000000
#define eps 1e-8
#define G 9.8

int dd(double x,double y){ return fabs(x-y)<eps;} // x==y
int dy(double x,double y){ return x>y+eps;} // x>y
int xy(double x,double y){ return x<y-eps;} //x<y
int dyd(double x,double y){ return x>y-eps;} //x>=y
int xyd(double x,double y){ return x<y+eps;} //x<=y

int main() {
	int m;
 double L,W,H,v,w,vx,vy,wei;
 string name;
 while(scanf("%d",&m) == 1) {
		vector<string> ans(0);
 scanf("%lf%lf%lf",&L,&W,&H);
 while(m--) {
 cin >> name;
			scanf("%lf%lf",&wei,&v);
 if(dy(H, L)) 
				continue;
 w = sqrt(H*(2.0*L-H));
 if(dy(w, W)) 
				continue;
 if(dy(2.0*G*H,v*v))
				continue;
 v = sqrt(fabs(v*v - 2.0*G*H));
 double vx = v * (L-H) / L;
 double vy = v * w / L;
 w += 2.0*vx * vy / G;
 if(xy(w, W)) 
				continue;
 ans.push_back(name);
 }
 sort(ans.begin(), ans.end());
 cout << ans.size() << endl;
 for(int i = 0; i < ans.size(); ++i)
 cout << ans[i] << endl;
 }
	return 0;
}