#include<iostream>
#include<queue>
#include<cstring>
using namespace std;
int s;
struct tnode
{
	int x;
	int y,z;
}snode;
char map[30][30][30];
int vis[30][30][30];
int l[]={-1,1,0,0,0,0};
int r[]={0,0,-1,1,0,0};
int c[]={0,0,0,0,-1,1};
bool bfs(int ,int ,int);
int main()
{
 
	int L,R,C,i,j,k;
	while(cin>>L>>R>>C)
	{
		if(L==0&&R==0&&C==0)
			return 0;
		memset(vis,0,sizeof(vis));
		for(i=0;i<L;i++)
			for(j=0;j<R;j++)
				for(k=0;k<C;k++)
				{
					cin>>map[i][j][k];
					if(map[i][j][k]=='S')
					{
						snode.x=i;
						snode.y=j;
						snode.z=k;
					}
				}
		if(bfs(L,R,C))
			cout<<"Escaped in"<<" "<<s<<" "<<"minute(s)."<<endl;
		else 
			cout<<"Trapped!"<<endl;
	}
	return 0;
}
bool bfs(int L,int R,int C)
{
	int i;
	queue<tnode>q;
	q.push(snode);
	while(!q.empty())
	{
	 
		for(i=0;i<6;i++)
		{	
			tnode n;
				n.x=q.front().x+l[i];n.y=q.front().y+r[i];n.z=q.front().z+c[i];
			
			if((map[n.x][n.y][n.z]=='.'||map[n.x][n.y][n.z]=='E')&&vis[n.x][n.y][n.z]==0&&n.x>=0&&n.x<L&&n.y<R&&n.y>=0&&n.z>=0&&n.z<C)
			{ 
			
				vis[q.front().x+l[i]][q.front().y+r[i]][q.front().z+c[i]]=vis[q.front().x][q.front().y][q.front().z]+1;
				s=vis[q.front().x+l[i]][q.front().y+r[i]][q.front().z+c[i]];
				q.push(n);
				if(map[q.front().x+l[i]][q.front().y+r[i]][q.front().z+c[i]]=='E')
				 return true;
			}
			
		}
		q.pop();
	}
	return false;
}