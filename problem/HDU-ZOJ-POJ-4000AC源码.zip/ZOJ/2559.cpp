/*
 * Author: Eyelids
 * Created Time: 2013/7/30 12:42:24
 * File Name: a.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )
struct Point {
 double x, y;
} a, b, c;

double Dis(Point p1, Point p2) {
 return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}

int main() {
 double A, B, C;
 //double ans1, ans2, ans3;
 while (scanf("%lf%lf", &a.x, &a.y) == 2) {
 scanf("%lf%lf", &b.x, &b.y);
 scanf("%lf%lf", &c.x, &c.y);
 
 double Dab = Dis(a, b);
 double Dac = Dis(a, c);
 double Dbc = Dis(b, c);
 //double Max = 0;
 
 B = (Dab - Dac + Dbc) / 2;
 C = Dbc - B;
 A = Dab - B;
 /*if (A + B + c > Max) {
 Max = A + B + C;
 ans1 = A, ans2 = B, ans3 = C;
 } */
 
 printf("%.6f\n", A);
 printf("%.6f\n", B);
 printf("%.6f\n", C);
 /*if (A + B + c > Max) {
 Max = A + B + C;
 ans1 = A, ans2 = B, ans3 = C;
 } 
 
 B = (Dab - Dac + Dbc) / 2;
 C = Dbc - B;
 A = Dab - B;
 if (A + B + c > Max) {
 Max = A + B + C;
 ans1 = A, ans2 = B, ans3 = C;
 } */
 } 
}








