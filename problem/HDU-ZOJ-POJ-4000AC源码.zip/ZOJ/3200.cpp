#include <stdio.h>
#include <string.h>
#include <algorithm>

using namespace std;

#define MAXN 100

double dp[2][MAXN][MAXN];
double ans[MAXN * MAXN];

bool cmp(double d1, double d2) {
	return d1 > d2;
}

int main() {
	int cases;
	scanf("%d", &cases);
	for(int caseT = 1; caseT <= cases; ++caseT) {
		int n;
		double p;
		scanf("%d%lf", &n, &p);
		bool id = false;
		for(int i = 0; i <= n + 1; ++i)
			for(int j = 0; j <= n + 1; ++j) dp[id][i][j] = 0.0;
		dp[id][n / 2 + 1][n / 2 + 1] = 1.0;
		int steps = 2500;
		while(steps--) {
			id = !id;
			for(int i = 0; i <= n + 1; ++i)
				for(int j = 0; j <= n + 1; ++j) dp[id][i][j] = 0.0;
			for(int i = 1; i <= n; ++i) {
				dp[id][0][i] = dp[!id][0][i];
				dp[id][n + 1][i] = dp[!id][n + 1][i];
				dp[id][i][0] = dp[!id][i][0];
				dp[id][i][n + 1] = dp[!id][i][n + 1];
			}
			for(int i = 1; i <= n; ++i)
				for(int j = 1; j <= n; ++j) {
					dp[id][i + 1][j] += dp[!id][i][j] * 0.25;
					dp[id][i - 1][j] += dp[!id][i][j] * 0.25;
					dp[id][i][j + 1] += dp[!id][i][j] * 0.25;
					dp[id][i][j - 1] += dp[!id][i][j] * 0.25;
				}
		}

		int total = 0;
		for(int i = 1; i <= n; ++i) {
			ans[total++] = dp[id][0][i];
			ans[total++] = dp[id][n + 1][i];
			ans[total++] = dp[id][i][0];
			ans[total++] = dp[id][i][n + 1];
		}
		sort(ans, ans + total);
		double pe = (double)(100 - p) / 100;
		int pos = 0, res = 4 * n;

		while(pos < total && pe - ans[pos] >= 0.0) {
			pe -= ans[pos];
			--res;
			++pos;
		}
		printf("%d\n", res);
	}
	return 0;
}
