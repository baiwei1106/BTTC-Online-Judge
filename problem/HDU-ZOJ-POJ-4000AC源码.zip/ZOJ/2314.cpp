#include <iostream>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <set>
#include <vector>
#include <cstdlib>
#include <queue>
#define M0(a) memset(a, 0, sizeof(a))
#define MXN 55000
#define MXM 2000001
#define Inf 0x3ffffff
using namespace std;
struct oo{int y, f, next; } edge[MXM];
int n, TT, m, len, S, T;
int M[MXN], son[MXN];
int c[MXN];
bool flag;
int gap[MXN], dis[MXN];

void add_edge(int x, int y, int f){
 edge[++len].y = y; edge[len].f = f; 
 edge[len].next = son[x]; son[x] = len;
}

void init(){
 scanf("%d%d", &n, &m); 
 M0(M);
 M0(c);
 M0(son);
 M0(edge);
 len = 1;
 int x, y, f;
 for (int i = 1; i <= m; ++i){
 scanf("%d%d%d%d", &x, &y, &c[i], &f);
 f -= c[i];
 M[x] -= c[i];
 M[y] += c[i];
 add_edge(x, y, f);
 add_edge(y, x, 0);
 }
 S = n + 1; T = n + 2;
 for (int i = 1; i <= n; ++i){
 if (M[i] > 0) {
 add_edge(S, i, M[i]);
 add_edge(i, S, 0);
 }
 if (M[i] < 0){
 add_edge(i, T, -M[i]);
 add_edge(T, i, 0);
 }
 } 
 n += 2;
}

int sap(int x, int aug){
 if (x == T) return aug;
 int mind = n;
 int sum = 0;
 int p = son[x], y;
 while (p){
 y = edge[p].y;
 if (dis[y] + 1 == dis[x] && edge[p].f > 0){
 int f = sap(y, min(aug - sum, edge[p].f)); 
 sum += f;
 edge[p].f -= f;
 edge[p^1].f += f;
 if (sum == aug || dis[S] >= n) return sum;
 } 
 if (edge[p].f > 0) mind = min(mind, dis[y]);
 p = edge[p].next;
 }
 if (!sum){
 if (!(--gap[dis[x]])) dis[S] = n;
 ++gap[dis[x] = mind + 1]; 
 }
 return sum;
}

int maxflow(){
 M0(gap);
 M0(dis);
 gap[0] = n;
 int ans = 0;
 while (dis[S] < n) ans += sap(S, Inf);
 // printf("%d\n", ans);
}



void solve(){
 maxflow();
 int p = son[S];
 bool ans = true;
 while (p){
 if (edge[p].f > 0){
 ans = false;
 break;
 }
 p = edge[p].next;
 }
 if (!ans){
 puts("NO");
 return;
 }
 p = son[T];
 while (p){
 if (edge[p ^ 1].f > 0){
 ans = false;
 break;
 }
 p = edge[p].next;
 }
 if (!ans){
 puts("NO");
 return;
 }
 puts("YES");
 p = 3;
 for (int i = 1; i <= m; ++i){
 printf("%d\n", edge[p].f + c[i]);
 p += 2;
 }
}

int main(){
 // freopen("sgu194.in", "r", stdin);
 // freopen("sgu194.out", "w", stdout);
 scanf("%d", &TT);
 // TT = 1;
 for (int i = 1; i <= TT; ++i){
 init();
 solve();
 if (i < TT) puts("");
 }
 fclose(stdin); fclose(stdout); 
}
