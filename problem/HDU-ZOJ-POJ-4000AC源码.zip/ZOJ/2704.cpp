/*
 * Author: DreamHigh
 * Created Time: 2013/7/30 16:06:58
 * File Name: E.cpp
 * solve: E.cpp
 */
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
#include<set>
#include<stack>
#include<iostream>
#include<vector>
#include<queue>

using namespace std;
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clr(x) memset(x,0,sizeof(x))
#define clrs( x , y ) memset(x,y,sizeof(x))
#define out(x) printf(#x" %d\n", x)
#define sqr(x) ((x) * (x))
typedef long long LL;

const int INF = -1u>>1;
const double eps = 1e-8;
const int maxn = 100010;
char str[maxn];
int ok[maxn];
stack <int> s;
int main() 
{
 //freopen("in.txt","r",stdin);
 while(scanf("%s",str)==1)
 {
 memset(ok,0,sizeof(ok));
 while(!s.empty())
 s.pop();
 
 int len = strlen(str);
 for(int i = 0;i<len;++i)
 {
 if(str[i] == '(' || str[i] == '[')
 s.push(i);
 else if(!s.empty()&&((str[i] == ')' && str[s.top()] == '(') || str[i] == ']'&&str[s.top()] == '['))
 {
 ok[i] = 1;
 ok[s.top()] = 1;
 s.pop();
 } else while (!s.empty()) s.pop();
 }
 
 int R = -1;
 int cnt = 1;
 int max_num = 1;
 for(int i = 0;i<len-1;++i)
 {
 if(ok[i] == 1&&ok[i] == ok[i+1])
 {
 cnt++;
 if(i==len-2)
 {
 if(cnt > max_num)
 {
 max_num = cnt;
 R = i+1; 
 }
 }
 }else
 {
 if(cnt > max_num)
 {
 max_num = cnt;
 R = i; 
 }
 cnt = 1;
 }
 }
 if(max_num == 1)
 {
 cout<<endl;
 cout<<endl;
 continue;
 }
 int L = R - max_num + 1;
 for(int i = L;i<=R;++i)
 printf("%c",str[i]);
 cout<<endl;
 cout<<endl;
 
 }
 return 0;
}
