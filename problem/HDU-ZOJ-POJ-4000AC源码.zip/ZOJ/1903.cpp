#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int min(int a,int b)
{
	return (a<b?a:b);
}

const int MAXN = 1000, INF = 10000000;

int n, m, t1, t2, t3, ans, mp[MAXN][MAXN], deg[MAXN], u[MAXN];


int dfs()
{
int i, j, rnt=INF;
for(i=0; i<n; i++) 
 if(!u[i]) break;
if(i == n) return 0;

u[i] = 1;
for(j=i+1; j<n; j++)
 if(!u[j]) u[j]=1, rnt=min(rnt,dfs()+mp[i][j]), u[j]=0;
u[i] = 0;
return rnt;
}

int main()
{
while(scanf("%d",&n),n)
{
	scanf("%d",&m);
	int i,j;
 ans=0, memset(deg,0,sizeof(deg)), memset(u,0,sizeof(u));
 for(i=0; i<n; i++) 
 for( j=0; j<n; j++) 
 mp[i][j]=INF;
 for( i=0; i<m; i++)
 {
 scanf("%d%d%d",&t1,&t2,&t3);
 t1--, t2--, ans+=t3, deg[t1]++, deg[t2]++;
 mp[t1][t2] = mp[t2][t1] = min(mp[t1][t2],t3);
 }
 for(int k=0; k<n; k++)
 for( i=0; i<n; i++)
 for( j=0; j<n; j++)
 mp[i][j] = min(mp[i][j], mp[i][k]+mp[k][j]);
 for( i=0; i<n; i++)
 if(deg[i]%2 == 0)
 u[i] = 1;
 printf("%d\n", ans+dfs());
}


return 0; 
}