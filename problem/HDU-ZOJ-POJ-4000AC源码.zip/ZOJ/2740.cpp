#include <stdio.h>
#include <string.h>

#define MAXN 1001

class DisjointSet
{
public:
DisjointSet()
{
}

void Make_Set(int s)
{
size = s;
for(int i = 0;i < s; i++)
{
parent[i] = -1;
}
}

int Find_Set(int i)
{

int j, k, t;

for(j = k = i; parent[j] >= 0; j = parent[j]);

while(k != j)
{
t = parent[k];
parent[k] = j;
k = t;
}

return j;

/*
if(parent[i] != i)
parent[i] = Find_Set(parent[i]);
return parent[i];
*/
}

void Union(int x, int y)
{
if(x == y)
return;

int root_x = Find_Set(x);
int root_y = Find_Set(y);

if(root_x == root_y)
return;

 if(parent[root_x] < parent[root_y])
{
parent[root_x] += parent[root_y];
parent[root_y] = root_x;
}
else
{
parent[root_y] += parent[root_x];
parent[root_x] = root_y;
}

/*
if(x == y)
return;

int root_x = Find_Set(x);
int root_y = Find_Set(y);

if(root_x == root_y)
return;

if(rank[x] > rank[y])
{
parent[y] = x;
}else
{
parent[x] = y;
if(rank[x] == rank[y])
rank[y]++;
}
*/
}

protected:
int parent[MAXN];
//int rank[MAXN];
int size;
};

int main(int argc,char **argv)
{
int N,M,i,a,b,x,y;
bool duplicated = false;
int flag[MAXN];

 DisjointSet ds;
while(true)
{
scanf("%d %d",&N, &M);

if(N==0 && M ==0)
break;

ds.Make_Set(N);
//memset(flag, 0 ,N);
duplicated = false;

for(i = 0; i < M; i++)
{
scanf("%d %d",&a, &b);
x = ds.Find_Set(a-1);
y = ds.Find_Set(b-1);

if(x == y)
duplicated = true;

ds.Union(x,y);
flag[a-1] = flag[b-1] = 1;
}

int v = 0;
for(i=0; i< N; i++)
v += flag[i];

if(v == N && v == M+1 && !duplicated)
{
printf("Yes\n");
}
else
{
printf("No\n");
}
}

return 0;
}