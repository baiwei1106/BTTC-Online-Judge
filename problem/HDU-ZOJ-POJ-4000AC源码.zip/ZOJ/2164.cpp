#include<stdio.h>
int card[60];
int temp[60];
int n,r;

void initial();

int main()
{
 
 while( scanf("%d%d",&n,&r) != EOF )
 {
 if(n==0 && r==0) break;
 initial();
 while(r--)
 {
 int p,c;
 scanf("%d%d",&p,&c);
 for(int i=0; i!=c; ++i)
 temp[i]=card[p+i];
 for(int i=p-1; i>=1; --i)
 card[i+c]=card[i];
 for(int i=0; i!=c; ++i)
 card[i+1]=temp[i];
 }
 printf("%d\n",card[1]);
 }
 return 0;
}

void initial()
{
 for(int i=1; i<=n; ++i)
 card[i]=n-i+1;
}
