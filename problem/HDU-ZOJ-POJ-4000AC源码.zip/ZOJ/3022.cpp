#include <iostream>
#include <cstdio>
#include <cmath>
#include <string>
#include <cstring>
using namespace std;
double dp[2][20][20];
int pre, now;
int n;

int main()
{
	while (scanf("%d", &n) != EOF)
	{
		int i, j;
		pre = 0;
		now = 1;
		char a[20];
		int w = 0, k = 0;
		memset(dp, 0, sizeof(dp));
		dp[pre][n][0] = 1;
		while (scanf("%s", a) != EOF)
		{
			if (strcmp(a, "End") == 0)
				break;
			for (i = 0; i <= n; i++)
			{
				j = n - i;
				if (a[0] == 'W')
				{
					if (w >= n) break;
					if (i > 0)
						dp[now][i - 1][j + 1] += dp[pre][i][j] * i/(n - w);
					dp[now][i][j] += dp[pre][i][j] * (j - w)/(n - w);
				}
				else if (a[0] == 'K')
				{
					if (k >= n) break;
					if (j > 0)
						dp[now][i + 1][j - 1] += dp[pre][i][j] * j/(n - k);
					dp[now][i][j] += dp[pre][i][j] * (i - k)/(n - k);
				}
			}
			if (i != n + 1)
				memcpy(dp[now], dp[pre], sizeof(dp[0]));
			if (a[0] == 'W')
			{
				w++;
				k = 0;
			}
			else
			{
				k++;
				w = 0;
			}	
			int m = pre;
			pre = now;
			now = m;	
			memset(dp[now], 0, sizeof(dp[now]));
		}
		printf("%.2f\n", dp[pre][n][0]);
	}
	return 0;
}