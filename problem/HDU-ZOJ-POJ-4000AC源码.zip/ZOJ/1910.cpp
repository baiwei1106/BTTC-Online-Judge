#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <cassert>
#include <sstream>
#include <numeric>
#include <climits>
#include <string>
#include <cctype>
#include <ctime>
#include <cmath>
#include <vector>
#include <queue>
#include <list>
#include <map>
#include <set>
using namespace std;

int main() {
	int tests;
	cin >> tests;
	while (tests--) {
		int n;
		cin >> n;
		int ans = ~ 0u >> 1;
		for (int i = 1; i <= n; ++i)
			if (n % i == 0)
				for (int j = 1; j <= n; ++j)
					if (n % (i * j) == 0) {
						int k = n / i / j;
						ans = min(ans, (i * j + j * k + k * i) * 2);
					}
		cout << ans << endl;
	}
}
