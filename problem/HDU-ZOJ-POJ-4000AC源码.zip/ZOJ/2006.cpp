//============================================================================
// Name : lk.cpp
// Author : 
// Version :
// Copyright : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <map>
#include <vector>
using namespace std;

char temp[100010];

int smallString(int n, char temp[])
{
 int i, j;
 i = 0; j = 1;
 int k;
 while(i < n && j < n)
 {
 k = 0;
 while(k < n && temp[(i + k) % n] == temp[(j + k) % n])
 k++;
 if(k >= n)
 break;
 if(temp[(i + k) % n] > temp[(j + k) % n])
 i = i + k + 1;
 else
 j = j + k + 1;
 if(i == j)
 j = i + 1;
 }
 if(i < j)
 return i;
 return j;
}

void slove()
{
 int n;
 scanf("%s", temp);
 n = strlen(temp);
 int ans = smallString(n, temp);
 printf("%d\n", ans + 1);
}

int main(void)
{
 int t;
 scanf("%d", &t);
 while(t--)
 {
 slove();
 }
 return 0;
}