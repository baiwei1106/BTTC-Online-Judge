#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <cmath>
#include <string>
#include <string.h>
#include <iterator>
#include <cstdlib>
#include<stack>
#include<map>
#include<set>
#define inff 0x1f
#define EPS 1e-8
#define maxm 200000000
#define MAXN 33
#define inf 1000000000
#define L(x) (x<<1)
#define R(x) (x<<1|1)
#define N -505290271
#define mod 1000000009
//#define pi acos(-1.0)
#define pi 3.1415926535
using namespace std;
int f[1000002];
void init()
{
	int i,j;
	 f[1]=0;
for (i=2;i<=1000000;i++)
 f[i]=1;
for (i=2;i<=1000000;i++)
 for (j=2;j*i<=1000000;j++)
	 f[i*j]+=i;
}
int main() {
 //freopen("E:\\in.txt","r",stdin);
	// freopen("E:\\out.txt","w",stdout); 
 init();
	//sort(f+1,f+1+1000000);
	int m;
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&m);
		printf("%d\n",f[m]);
	}
 return 0;
}