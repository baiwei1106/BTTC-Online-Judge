#include <iostream>
#include <cstdio>
#include <cstring>
#include <sstream>
using namespace std ;

const int N = 110000 ;

int price[N] , value[N] , limit[N] , group[N] ;
pair<int, int> interval[N];
long long g[10][N] , f[N] , temp[N] ;
int n , m , money , tot ;

inline void init() {
#define clr(x) memset ( (x) , 0 , sizeof (x) )
	clr ( interval ) , clr ( group ) , clr ( limit ) , clr ( value ) , clr ( price ) ;
	tot = n ;
}

int main() {
	while ( scanf ( "%d%d" , &n , &money ) != EOF ) {
		init() ;
		for ( int i = 1 ; i <= n ; ++i ) {
			scanf ( "%d%d%d" , &limit[i] , &value[i] , &price[i] ) ;
			if ( limit[i] == 0 )
				limit[i] = money / price[i] ;
			else limit[i] = min ( limit[i] , money / price[i] ) ;
			if ( limit[i] == 0 ) continue ;
			interval[i].first = tot + 1 ;
			int pivot ;
			for ( pivot = 1 ; 2 * pivot - 1 <= limit[i] ; pivot <<= 1 ) {
				tot ++ ;
				price[tot] = pivot * price[i] ;
				value[tot] = pivot * value[i] ;
			}
			pivot -- ;
			if ( pivot != limit[i] ) {
				tot ++ ;
				price[tot] = (limit[i] - pivot) * price[i] ;
				value[tot] = (limit[i] - pivot) * value[i] ;
			}
			interval[i].second = tot ;
		}
		memset ( g , 200 , sizeof ( g ) ) ;
		memset ( f , 200 , sizeof ( f ) ) ;
		f[0] = 0 ;
		scanf ( "%d" , &m ) ;
		getchar() ;
		for ( int i = 0 ; i < m ; ++i ) {
			string s ;
			getline ( cin , s ) ;
			stringstream buffer ;
			buffer << s ;
			g[i][0] = 0 ;
			int index ;
			while ( buffer >> index ) {
				group[index] = i + 1 ;
				for ( int j = 1 ; j <= limit[index] ; ++ j )
#define updateMax(a, b) if ((a) < (b)) (a) = (b)
					updateMax ( g[i][j * price[index]] , j * value[index] ) ;
			/*
				for ( int j = interval[index].first ; j <= interval[index].second ; ++ j ) {
					for ( int k = money ; k >= price[j] ; -- k )
						updateMax ( g[i][k] , g[i][k - price[j]] + value[j] ) ;
				}
				*/
			}
			memcpy ( temp , f , sizeof ( f ) ) ;
			for ( int j = money ; j >= 1 ; -- j )
				for ( int k = money ; k >= j ; -- k )
					updateMax ( f[k] , temp[k - j] + g[i][j] ) ;
		}
		for ( int i = 1 ; i <= n ; ++i ) {
			if ( group[i] || !limit[i] ) continue ;
			for ( int j = interval[i].first ; j <= interval[i].second ; ++ j ) {
				for ( int k = money ; k >= price[j] ; -- k )
					updateMax ( f[k] , f[k - price[j]] + value[j] ) ;
			}
		}
		if ( f[money] >= 0 ) printf ( "%lld\n" , f[money] ) ;
		else printf ( "i'm sorry...\n" ) ;
	}
	return 0 ;
}