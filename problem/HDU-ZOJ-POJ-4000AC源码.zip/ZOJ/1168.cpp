#include<stdio.h>
#include<string.h>
#define N 101
struct Node{
	long long a;
	bool isshow;
}flag[N][N][N];
long long findans(int a,int b,int c)
{
	//printf("%d %d %d\n",a,b,c);
//	getchar();
	if(a>=0&&b>=0&&c>=0&&a<N&&b<N&&c<N&&flag[a][b][c].isshow)
		return flag[a][b][c].a;

	if(a<=0||b<=0||c<=0) return 1;
	if(a>20||b>20||c>20)
	{
		if(a<N&&b<N&&c<N)
		{
			flag[a][b][c].a=findans(20,20,20);
			flag[a][b][c].isshow=1;
			return flag[a][b][c].a;
		}
		return findans(20,20,20);
	}
	if(a<b&&b<c)
	{
		if(a>=0&&b>=0&&c>=0&&a<N&&b<N&&c<N)
		{
			flag[a][b][c].a=findans(a,b,c-1)+findans(a,b-1,c-1)-findans(a,b-1,c);
			flag[a][b][c].isshow=1;
			return flag[a][b][c].a;
		}
		return findans(a,b,c-1)+findans(a,b-1,c-1)-findans(a,b-1,c);
	}
	if(a>=0&&b>=0&&c>=0&&a<N&&b<N&&c<N)
	{
		flag[a][b][c].a=findans(a-1,b,c)+findans(a-1,b-1,c)+findans(a-1,b,c-1)-
			findans(a-1,b-1,c-1);
		flag[a][b][c].isshow=1;
		return flag[a][b][c].a;
	}
	return findans(a-1,b,c)+findans(a-1,b-1,c)+findans(a-1,b,c-1)-
			findans(a-1,b-1,c-1);
}
int main()
{
	int a,b,c;
	memset(flag,0,sizeof(flag));
	while(scanf(" %d %d %d",&a,&b,&c)==3&&!(a==-1&&b==-1&&c==-1))
	{
		printf("w(%d, %d, %d) = %lld\n",a,b,c,findans(a,b,c));
	}
	return 0;
}


