#include <stdio.h>
#include <cstring>
#define maxl 2010

int n, m, p, out[maxl], c[maxl];
int list[maxl], top;

int get_survive(int n, int m)
{
	int ans = 0;
	for(int i=1; i<=n; ++i) ans = (ans + m) % i;
	return ans;
}

int get_kth(int k)
{
	if(m == 1) return k;
	int D = m * k;
	while(D > n)
	{
		D = (D - n - 1) / (m - 1) + D - n;
	}
	return D;
}

int mod(int x, int m)
{
	return (x % m + m) % m;
}

//////////////////////////////////////////////////////////////////////////
int lowbit(int x){ return x & -x; }
void add(int idx, int x)
{
	for(idx++; idx<maxl; idx+=lowbit(idx)) c[idx] += x;
}
int Sum(int idx)
{
	int ans = 0;
	for(idx++; idx; idx-=lowbit(idx)) ans += c[idx];
	return ans;
}
int getSum(int a, int b)
{
	if(a > b) return 0;
	else return Sum(b) - Sum(a - 1);
}
//////////////////////////////////////////////////////////////////////////

int getValue(int x)
{
	int l = 1, r = n, mid, ans = -1;
	while(l <= r)
	{
		mid = (l + r) / 2;
		int k = Sum(mid);
		if(k >= x)
		{
			ans = mid;
			r = mid - 1; 
		}
		else l = mid + 1;
	}
	return ans;
}

void solve()
{
	for(int i=0; i<=n; ++i) out[i] = 0;
	memset(c, 0, sizeof c);

	for(int i=1; i<=n; ++i) add(i, 1);
	int cnt, k = 0;
	for(cnt=1; cnt<=n; ++cnt)
	{
		//k = get_kth(cnt);

		int x = (k + 1 > n) ? 1 : k + 1;
		int lsum = getSum(1, k - 1);
		int rsum = getSum(k, n);

		//printf("%d %d %d\n", cnt, lsum, rsum);

		int pp = (lsum + m - 1) % (lsum + rsum);
		k = getValue(pp + 1);

		add(k, -1);

		//if(cnt < 10) printf("%d %d\n", cnt, k);
		if(k == p) break;
		out[k-1] = 1;
	}

	cnt--;
	int left = n - cnt;

	top = 0;
	for(int i=0; i<n; ++i)
	{
		int x = (p - 1 + i) % n;
		if(!out[x]) list[top++] = x + 1;
	}
	//printf("here %d\n", top);
	//for(int i=0; i<top; ++i) printf("%d ", list[i]);
	//puts("");
	k = get_survive(left, m);

	k = mod(k - m + 1, top);


	//printf("no %d %d\n", top, k);
	int nk = mod(-k, top);
	printf("%d\n", list[nk]);
}

int main()
{
	//printf("aha %d\n", get_survive(8, 4));
	while(scanf("%d%d%d", &n, &m, &p), (n + m + p))
	{
		int k = get_survive(n, m);
		if(k == p - 1) printf("%d\n", p);
		else
		{
			solve();
		}
	}
	return 0;
}
