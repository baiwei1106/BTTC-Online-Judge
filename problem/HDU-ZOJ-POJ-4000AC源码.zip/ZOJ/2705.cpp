#include<stdio.h>
typedef long long ll;
ll fac[50];
int main(){
 fac[0]=fac[1]=1;
 for(int i=2;i<50;i++) fac[i]=fac[i-1]+fac[i-2];
 ll n,m;
 //printf("%lld\n",fac[49]);
 while(scanf("%lld%lld",&n,&m)!=EOF){
 ll sum=n*m;
 int i=49;
 for(;i>1;i--) if(n%fac[i]==0||m%fac[i]==0) break;
 printf("%lld\n\n",sum-sum/fac[i]);
 }
}
