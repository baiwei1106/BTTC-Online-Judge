#include<stdio.h>
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main()
{
 int len,n,Min,Max,a,mid,cs;
 scanf("%d",&cs);
 while(cs--)
 {
 scanf("%d%d",&len,&n);
 Min=9999999;
 Max=-1;
 mid=0;
 for(int i=1;i<=n;i++)
 {
 scanf("%d",&a);
 mid=max(mid,min(a,len-a));
 Min=min(Min,a);
 Max=max(Max,a);
 }
 printf("%d ",mid);
 if(Min+Max>len) printf("%d\n",Max);
 else printf("%d\n",len-Min);
 }
 return 0;
}
