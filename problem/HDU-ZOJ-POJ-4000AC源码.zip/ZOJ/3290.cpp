#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int maxn = 100010;
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
//typedef __int64 lld;
typedef unsigned long long lld;
lld ans[110];
int main()
{
 // printf("%I64d\n",((lld)1<<63 )- 1);
	int i , j , k;
 lld n;
 int ca = 0;
	while(cin>>n)
	{
	 if(ca) cout<<endl;
	 ca++;
	 int tot = 0;
	 lld sum = 1;
		ans[1] = 1;
		for(i=2;;i++)
		{
			ans[i] = 2*ans[i-1] + 1;
			sum += ans[i];
			if(sum > n)
			{
				sum -= ans[i];
				sum -= ans[i-1];
				ans[i-1] = n - sum ;
				break;
			}
			else if(sum == n)
			
 {
 break;
 }
		}
		tot = i - 1;
		//printf("%d\n",tot);
		cout<<tot<<endl;
		for(i = tot; i >=1; i--)
		{
			if(i<tot) cout<<" ";
			//printf("%llu",ans[i]);
			cout<<ans[i];
		}
	 cout<<endl;
	}
	return 0;
}