#include<iostream>
#include<stdio.h>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<map>
#include<set>
#include<queue>
#include<vector>
#define Maxinf 2147483647
using namespace std;

double f[1005][1005];

void Init()
{
	for ( int i = 0; i <= 1000; ++i )
	{
		f[i][0] = 0;
		f[0][i] = 0;
	}
	
	for ( int i = 1; i <= 1000; ++i )
	{
		for ( int j = 1; j <= 1000; ++j )
			f[i][j] = ( f[i][j-1] + 1 + f[i-1][j] + 1 ) / 2 ;
	}
}

int main()
{
	Init();

	int t;
	cin >> t;
	while ( t-- )
	{
		int n;
		cin >> n;

		printf( "%.2lf\n", f[n][n] );
	}

	return 0;
}