#include <cstdio>
#include <cmath>
int n,m;
double map[200][200];
double f[200];
int v[200];
int main()
{
 while(scanf("%d%d",&n,&m)&& n!=0){
 int i,j;
 for(i=1;i<=n;i++)
 for(j=1;j<=n;j++)map[i][j]=-100;
 for(i=1;i<=n;i++)f[i]=-100;
 for(i=1;i<=n;i++)v[i]=0;
 for(i=0;i<m;i++){
 int x,y;
 double p;
 scanf("%d%d%lf",&x,&y,&p);
 map[x][y]=log(p/100);
 map[y][x]=log(p/100);
 }
 f[1]=0;
 for( i = 1 ; i <=n; i++){
 int x, y;
 double m = -100;
 for(y=1;y <=n;y++)if((v[y]==0) && (f[y]> m)) m= f[x=y];
 //printf("%d %.6lf\n",x,exp(f[x])*100);
 v[x]=1;
 for(y=1;y<=n;y++)f[y] =f[y]<f[x] + map[x][y]?f[x] + map[x][y]:f[y];
 }
 printf("%.6lf percent\n",exp(f[n])*100);
 }
}