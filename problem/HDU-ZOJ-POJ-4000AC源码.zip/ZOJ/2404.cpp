#include<stdio.h>
#include<string.h>
#include<iostream>
#include<queue>
#include<math.h>
#define maxn 305
#define inf 0x7fffffff
using namespace std;
struct Edge
{
 int v,cap,cost,next;
}edge[110*110*2];
int head[maxn],en,s,t;
void addedge(int u,int v,int cap,int cost)
{
 edge[en].v=v,edge[en].cap=cap,edge[en].cost=cost;
 edge[en].next=head[u];
 head[u]=en++;
 swap(u,v);
 edge[en].v=v,edge[en].cap=0,edge[en].cost= - cost;
 edge[en].next=head[u];
 head[u]=en++;
}
void mcmf()
{
 int c=0,f=0;
 queue<int> q;
 int dis[maxn],pre[maxn];
 while(1)
 {
 bool vis[maxn]={0};
 int top=0;
 for(int i=0;i<=t;i++)
 dis[i]=(i==s? 0:inf);
 q.push(s);
 while(!q.empty())
 {
 int u=q.front();
 q.pop();
 vis[u]=0;
 for(int e=head[u];e!=-1;e=edge[e].next)
 {
 int v=edge[e].v;
 if(edge[e].cap>0&&dis[v]>dis[u]+edge[e].cost)
 {
 dis[v]=dis[u]+edge[e].cost;
 pre[v]=e;
 if(!vis[v])
 {
 q.push(v);
 vis[v]=1;
 }
 }
 }
 }
 if(dis[t]==inf)
 break;
 int a=inf;
 int p;
 for(int u=t;u!=s;u=edge[p^1].v)
 {
 p=pre[u];
 a=(a<edge[p].cap? a:edge[p].cap);
 }
 for(int u=t;u!=s;u=edge[p^1].v)
 {
 p=pre[u];
 edge[p].cap -= a;
 edge[p^1].cap += a;
 }
 c+=dis[t]*a;
 }
 printf("%d\n",c);
}
char g[110][110];
struct Pos
{
 int x,y;
}mp[110],hp[110];
int main()
{
 int n,a,b,c;
 int N,M;
 int i,j;
 while(cin>>N>>M)
 {
 if(!N&&!M)
 break;
 en=0;
 memset(head,-1,sizeof(head));
 for(i=0;i<N;i++)
 scanf("%s",g[i]);

 int mm=0,hh=0;

 for(i=0;i<N;i++)
 for(j=0;j<M;j++)
 {
 if(g[i][j]=='H')
 {
 hp[hh].x=i;
 hp[hh++].y=j;
 }
 if(g[i][j]=='m')
 {
 mp[mm].x=i;
 mp[mm++].y=j;
 }
 }
 s=0,t=hh+mm+1;
 for(i=1;i<=mm;i++)
 addedge(s,i,1,0);
 for(i=mm+1;i<=mm+hh;i++)
 addedge(i,t,1,0);

 for(i=0;i<hh;i++)
 for(j=0;j<mm;j++)
 {
 int d=fabs(hp[i].x-mp[j].x)+fabs(hp[i].y-mp[j].y);
 addedge(j+1,i+1+mm,1,d);
 }
 mcmf();
 }
 return 0;
}
