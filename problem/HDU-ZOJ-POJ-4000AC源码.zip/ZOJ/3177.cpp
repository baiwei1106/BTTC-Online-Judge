#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

#define eps 1e-8
#define inf 1e15

struct pv
{
 double x,y;
 pv(){}
 pv(double a,double b):x(a),y(b){}
 pv operator-(const pv &i)const
 {
 return pv(x-i.x,y-i.y);
 }
 pv operator+(const pv &i)const
 {
 return pv(x+i.x,y+i.y);
 }
 pv operator*(const double a)const
 {
 return pv(x*a,y*a);
 }
 double dot(const pv &i)const
 {
 return x*i.x+y*i.y;
 }
 double cross(const pv &i)const
 {
 return x*i.y-y*i.x;
 }
 void input()
 {
 scanf("%lf %lf",&x,&y);
 }
 double len()
 {
 return sqrt(x*x+y*y);
 }
};

inline double dist_point_to_line(const pv &a,const pv &b,const pv &p)
{
 return fabs((p-a).cross(b-a))/(a-b).len();
}

inline double dist_point_to_seg(const pv &a,const pv &b,const pv &p)
{
 if((p-b).dot(a-b)<-eps || (p-a).dot(b-a)<-eps)
 return std::min((p-a).len(),(p-b).len());
 return dist_point_to_line(a,b,p);
}

int T;

pv pom,d,s,t;
double v;
double r0,r1;
double l,r,ans,mid;

inline double sqr(double a)
{
 return a*a;
}

inline bool ok(double t)
{
 static double dist,a;
 dist=sqrt(sqr(pom.x-s.x-d.x*t)+sqr(pom.y-s.y-d.y*t));
 a=r0+r1+v*t;
 /*
 if(dist<a+eps)
 printf("%lf\n",t);
 */
 return dist<a+eps;
}

inline void go(double l,double r)
{
 while(l+eps<r)
 {
 mid=(l+r)/2;
 if(ok(mid))
 r=ans=mid;
 else
 l=mid;
 }
}

double a,b,c;
double dx,dy;

int main()
{
 scanf("%d",&T);
 while(T--)
 {
 s.input();
 pom.input();
 d.input();
 scanf("%lf %lf",&r0,&r1);
 r=r0+r1;
 scanf("%lf",&v);

 a=sqr(d.x)+sqr(d.y)-sqr(v);
 dx=pom.x-s.x;
 dy=pom.y-s.y;
 b=-2*(dx*d.x+dy*d.y+v*r);
 c=sqr(dx)+sqr(dy)-sqr(r);

 ans=-1;
// printf("%lf %lf %lf\n",a,b,c);

 if(a<eps)
 go(eps,inf);
 else
 {
 mid=-b/(2*a);
 if(mid>eps && a*sqr(mid)+b*mid+c<-eps)
 {
 ans=mid;
 go(0,mid);
 }
 }

 if(ans<0)
 puts("Impossible");
 else
 {
 printf("%.4lf\n",ans);
 }
 }
 return 0;
}