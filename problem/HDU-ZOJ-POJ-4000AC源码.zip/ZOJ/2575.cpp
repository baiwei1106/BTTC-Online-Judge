#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cstdio>
#include <queue>
#include <stack>
#include <cmath>
#include <time.h>
#include <set>

using namespace std;
#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))
#define OUT freopen("c:\\users\\Administrator\\desktop\\output.txt", "w", stdout)

#define LL __int64
#define POW(x) (x)*(x)
#define clr(x) memset(x,0,sizeof(x))
#define eps 1e-3
#define ee 2.7182818284590452354
#define PI 3.1415926535897932384626433832795028 
#define N 105
#define M 100000009
#define inf 1<<29

double dp[33][33][205];
//��ʾ i �ĺ���״̬��j ����ɫ״̬��k ��ʣ�³����µ���С����

double col[6];
int len[6],l[6],r[6],m,n;

vector<int> e[6];

void init()
{
	for(int i=0;i<5;i++) e[i].clear();
	for(int i=0;i<(1<<5);i++)
	{
		int ans=0;
		for(int j=0;j<5;j++)
			if(i&(1<<j)) ans++;
		e[ans].push_back(i);
	}
}

void solve()
{
	int i,j,k;
	dp[0][0][m]=0;
	for(int pp=0;pp<=n;pp++)
	{
		for(int ii=0;ii<e[pp].size();ii++)
			for(int jj=0;jj<e[pp].size();jj++)
			{
				for(i=0;i<n;i++)
				{
					if((1<<i)&e[pp][ii]) continue;
					for(j=0;j<n;j++)
					{
						if((1<<j)&e[pp][jj]) continue;
						int aa=(1<<i)|e[pp][ii];
						int bb=(1<<j)|e[pp][jj];
						for(int tt=m;tt>=l[i];tt--)
						{
							for(k=l[i];k<=r[i];k++)
							{
								if(tt<k) continue;
								if(dp[aa][bb][tt-k]>dp[e[pp][ii]][e[pp][jj]][tt]+col[j]*((double)(k*k)))
									dp[aa][bb][tt-k]=dp[e[pp][ii]][e[pp][jj]][tt]+col[j]*((double)(k*k));
							}
						}
					}
				}
			}
	}
	if(dp[(1<<n)-1][(1<<n)-1][0]==1.0*(inf)) printf("Impossible\n");
	else printf("%.3lf\n",dp[(1<<n)-1][(1<<n)-1][0]);
}

int main()
{
	int i,j,k;
	init();
	while(scanf("%d %d",&n,&m)==2)
	{
		for(i=0;i<n;i++)
			scanf("%lf",&col[i]);
		for(j=0;j<n;j++)
			scanf("%d %d",&l[j],&r[j]);

		for(int i=0;i<(1<<n);i++)
			for(int j=0;j<(1<<n);j++)
				for(int k=m;k>=0;k--)
					dp[i][j][k]=1.0*(inf);
		solve();
	}
	return 0;
}