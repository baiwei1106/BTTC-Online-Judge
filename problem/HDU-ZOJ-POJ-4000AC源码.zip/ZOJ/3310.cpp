#include <cstdio>
#include <cstring>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>

using namespace std;

const int N = 1000000 ;
int n ;
int v[N] ;
int g[N] ;

int main(){
 while (~scanf("%d",&n)){
 for (int i = 0 ; i < n ; i++)
 scanf("%d",&v[i]);

 if (n == 1){
 printf("%d\n",v[0]) ;
 continue ;
 }

 if (n == 2){
 printf("%d\n",0);
 continue ;
 }

 // n >= 3
 memset(g,0,sizeof(g)) ;
 int ret = 0 ;
 for (int i = 1 ; i < n ; i++){
 int pre = (i>2)?g[i-2]:0 ;
 int cur = pre + v[i] ;
 ret = max(ret,cur) ;
 g[i] = max(g[i-1],cur) ;
 }
 memset(g,0,sizeof(g)) ;
 for (int i = 0 ; i <n-1 ; i++)
 {
 int pre = (i>1)?g[i-2]:0 ;
 int cur = pre + v[i] ;
 ret = max(ret , cur) ;
 g[i] = max(g[i-1] , cur) ;
 }
 printf("%d\n",ret);
 }
 return 0 ;
}
