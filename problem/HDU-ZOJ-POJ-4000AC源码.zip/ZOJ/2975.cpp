#include<cstdio>
#include<cstring>
int J(char ch)
{
 switch(ch)
 {
 case 'B':return 1;
 case 'J':return 2;
 case 'H':return 3;
 case 'Y':return 4;
 case 'N':return 5;
 }
}
int main()
{
 char s[251][251];
 int t,m,n,m1,n1,a[6];
 scanf("%d",&t);
 while(t--)
 {
 scanf("%d%d",&m,&n);
 int ans=0;
 for(int i=0;i<m;i++)
 scanf("%s",s[i]);
 for(int i=0;i<m;i++)
 for(int j=i+1;j<m;j++)
 {
 memset(a,0,sizeof(a));
 for(int k=0;k<n;k++)
 if(s[i][k]==s[j][k])a[J(s[i][k])]++;
 for(int k=1;k<6;k++)
 ans+=(a[k]-1)*a[k]/2;
 }
 printf("%d\n",ans);
 }
 return 0;
}
