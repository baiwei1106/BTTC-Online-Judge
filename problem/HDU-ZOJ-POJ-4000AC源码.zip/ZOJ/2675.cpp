/*
 * Author: xioumu
 * Created Time: 2013/7/21 15:24:58
 * File Name: F.cpp
 * solve: F.cpp
 */
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
#include<set>
#include<iostream>
#include<vector>
#include<queue>

using namespace std;
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clr(x) memset(x,0,sizeof(x))
#define clrs( x , y ) memset(x,y,sizeof(x))
#define out(x) printf(#x" %d\n", x)
#define sqr(x) ((x) * (x))
typedef long long lint;

const int maxint = -1u>>1;
const double pi = acos(-1.0);
const double eps = 1e-8;

int sgn(const double &x) { return (x > eps) - (x < -eps); }

struct point {
 double x, y;
 point (double _x = 0, double _y = 0) : x(_x), y(_y) {
 }
 double operator * (const point &p) const {
 return (x * p.y) - (y * p.x);
 }
 point operator - (const point &p) const {
 return point(x - p.x, y - p.y);
 }
 point operator + (const point &p) const {
 return point(x + p.x, y + p.y);
 }
 void output() {
 printf("%.3f %.3f\n", x, y);
 }
};

point operator * (const double &l, const point &p) {
 return point(l * p.x, l * p.y);
}

vector<point> p;

void gao(point u, point v, double r) {
 double a = sqr(v.x - u.x) + sqr(v.y - u.y);
 double b = 2 * ((v.x - u.x) * u.x + (v.y - u.y) * u.y);
 double c = sqr(u.x) + sqr(u.y) - sqr(r);
 double det = b * b - 4 * a * c;
 p.push_back(u);
 if (det < 0) {
 return;
 }
 double t1 = (-b + sqrt(det)) / 2 / a;
 double t2 = (-b - sqrt(det)) / 2 / a;
 //printf("%f %f\n", t1, t2);
 if (t1 > t2) 
 swap(t1, t2);
 if (sgn(t1) > 0 && sgn(t1 - 1) < 0) {
 p.push_back(u + t1 * (v - u));
 }
 if (sgn(t2) > 0 && sgn(t2 - 1) < 0 && sgn(t1 - t2) != 0) {
 p.push_back(u + t2 * (v - u));
 } 
}

double tri(point a, point b) {
 return abs( (a * b) / 2 );
}

double sec(point a, point b, double r) {
 double ang1 = atan2(a.y, a.x);
 double ang2 = atan2(b.y, b.x);
 if (ang1 < 0) ang1 = 2 * pi + ang1;
 if (ang2 < 0) ang2 = 2 * pi + ang2;
 double dang = abs(ang2 - ang1);
 if (dang > pi) 
 dang = 2 * pi - dang;
 return r * r * dang / 2;
}

//double sec(const point& u, const point& v, double r) {
	//double t = atan2(v.y, v.x) - atan2(u.y, u.x);
	//while (t > pi) {	// WA!!
		//t -= 2 * pi;
	//}
	//while (t < -pi) {
		//t += 2 * pi;
	//}
	//return abs(r * r * t) / 2;
//}


int main() {
 bool blank = false;
 double x, y, r, x1, y1, x2, y2;
 while (scanf("%lf%lf%lf", &x, &y, &r) == 3) {
 if (blank) puts("");
 blank = 1;
 scanf("%lf%lf%lf%lf", &x1, &y1, &x2, &y2);
 x1 -= x;
 y1 -= y;
 x2 -= x;
 y2 -= y;
 
 p.clear();
 gao(point(x1, y1), point(x1, y2), r);
 gao(point(x1, y2), point(x2, y2), r);
 gao(point(x2, y2), point(x2, y1), r);
 gao(point(x2, y1), point(x1, y1), r);
 
 double ans = 0;
 p.push_back(p.front());
 rep (i, sz(p) - 1) {
 if (sgn( hypot((p[i].x + p[i + 1].x) / 2, (p[i].y + p[i + 1].y) / 2) - r) >= 0) {
 ans += sgn(p[i] * p[i + 1]) * sec(p[i], p[i + 1], r);
 //printf("sec : %f\n", sgn(p[i] * p[i + 1]) * sec(p[i], p[i + 1], r));
 }
 else {
 ans += sgn(p[i] * p[i + 1]) * tri(p[i], p[i + 1]);
 //printf("tri : %f\n", sgn(p[i] * p[i + 1]) * tri(p[i], p[i + 1]));
 } 
 //p[i].output();
 }
 printf("%.11f\n", abs(ans)); 
 }
 return 0;
}
