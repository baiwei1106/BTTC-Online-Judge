#include <iostream>
#include <algorithm>
#include <cstring>

using namespace std;


struct people
{ 
 int x,y,id;
}p[100010];

bool cmp(const people &a,const people &b)
{
 if(a.x!=b.x)
 return a.x<b.x;
 else return a.y>b.y;
}

int main()
{
 int index,l,r,m,i,k,n,s2[100001],s1[100001];
 cin>>index;
 while(index--!=0)
 {
 cin>>n;
 for(i=1;i<=n;i++)
 {
 cin>>p[i].x>>p[i].y;p[i].id=i;
 }
 sort(p+1,p+n+1,cmp);
 s1[1]=1;k=1;s2[1]=0;
 for(i=2;i<=n;i++)
 {
 if(p[i].y>p[s1[k]].y)
 {
 s1[++k]=i;
 s2[i]=s1[k-1]; 
 }
 else
 {
 l=1;r=k;
 while(l<r)
 {
 m=(l+r)/2;
 if(p[s1[m]].y<p[i].y) l=m+1;
 else r=m;
 }
 s1[l]=i;
 s2[i]=s1[l-1];
 }
 }
 cout<<k<<endl;
 l=s1[k];i=k;
		s1[k]=p[l].id;
 while(k--!=1)
 {
 l=s2[l];
 s1[k]=p[l].id; 
 }
		for(k=1;k<i;k++)
		 cout<<s1[k]<<" ";
 cout<<s1[i]<<endl;
 if(index!=0)
 cout<<endl;
 }
 return 0;
}