#include<cstdio>
#include<cstring>

int T, N, M;

int main() {
	for (scanf ("%d", &T); T--;) {
		scanf ("%d%d", &N, &M);
		int dna[1001][4]={}, dic[27]={}, tot=0;
		dic[0] = 1, dic['C'-'A'] = 2, dic['G'-'A'] = 3, dic['T' - 'A'] = 4;
		for (int i=0; i<N; i++) {
			char buf[1024]="";
			scanf ("%s", buf);
			for (int j=0; j<M; j++) {
				dna[j][dic[buf[j]-65]]++;
			}
		}
		for (int i=0; i<M; i++) {
			int ans = 1, sum = 0;
			for (int j=1; j<5; j++) {
				if (dna[i][j] > dna[i][ans]) ans = j;
			}
			for (int j=1; j<5; j++) {
				if (j != ans) sum += dna[i][j];
			}
			printf ("%c", ans<2? 'A': ans<3 ? 'C': ans<4 ? 'G': ans<5 ? 'T':0);
			tot += sum;
		}
		printf ("\n%d\n", tot);
	}
	return 0;
}
