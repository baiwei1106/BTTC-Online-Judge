#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

#define LL long long

LL f[34], g[34];
void init(){
	int i;
	f[0] = 1;
	g[0] = 2;
	for(i = 1; i < 31; i ++){
		f[i] = 2 * f[i-1] + 1;
	//	printf("%d - %I64d\n", i, f[i]);
	}
	for(i = 1; i < 31; i ++){
		g[i] = 2 * g[i-1] + f[i-1] * ((LL)1 << i) + ((1 << (i+1)));
	}
}

LL cala(int n){
	if(n == 0) return 0;
	int k;
//	cout << n << endl;
	int i;
	for(i = 0; i < 31; i ++){
		if(n >= f[i])
			k = i;
	}
	return g[k] + cala(n-f[k]) + (LL)(n-f[k]) * ((LL)1 << (k+1));
}

int main(){
	init();
	int n, m;
	while(scanf("%d%d", &n, &m) != EOF){
		LL l = cala(n-1);
		LL r = cala(m);
//		printf("l = %I64d, r = %I64d\n", l, r);
		printf("%lld\n", r-l);
	}	
	return 0;
}