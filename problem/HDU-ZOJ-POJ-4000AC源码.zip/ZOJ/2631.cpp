/* 
 * File: main.cpp
 * Author: Administrator
 *
 * Created on 2010��10��22��, ����9:39
 */
#include <cstdlib>
#include <stdio.h>
#include <queue>
#include <cmath>
#include <string.h>
#include <iostream>

using namespace std ;
const int Con = 500 ;
const short inf = 3500 ;
/*
 * 
 */

int dx[] = { -1,-2,-2,-1,1,2, 2, 1 } ;
int dy[] = { -2,-1, 1, 2,2,1,-1,-2 } ;

short step[1009][1009][8] ;

struct Node {
 short x,y,dir;
}out,in;
short n, m ;
short px0,py0,px1,py1,px,py ;
bool adjacent(short from, short to) {
 if(from==to) return true ;
 if(from==0) {
 if(to == 1 || to == 7) return true ;
 }
 if(from==7) {
 if(to == 0 || to == 6) return true ;
 }
 else {
 if(to == from+1 || to == from-1) return true ;
 }
 return false ;
}
int bfs() {
 for (int i=-n; i<=n; i++) for (int j=-n; j<=n; j++) {
 for (int k=0;k<8;k++) {
 step[i+Con][j+Con][k] = inf ;
 }
 }
 queue<Node>all ;
 for (int k=0;k<8;k++) {
 if (px0 + dx[k] == px1 && py0 + dy[k] == py1) {
 in.x = px1, in.y = py1, in.dir = k ;
 step[in.x+Con][in.y+Con][k] = 1 ;
 all.push(in) ;
 break ;
 }
 }
 short from, to, cost ;
 while (!all.empty()) {
 out = all.front();
 all.pop() ;
 cost = step[out.x+Con][out.y+Con][out.dir] ; 
 if (cost > m) return -1 ;
 if (out.x == px && out.y == py) 
 return cost ; 
 for (int k=0; k<8; k++) 
 {
 in.x = out.x + dx[k], in.y = out.y + dy[k], in.dir = k ;
 from = out.dir, to = k ;
 	 if(k==(out.dir+3)%8||k==(out.dir+4)%8||k==(out.dir+5)%8) 
 continue ; 
 if(abs(in.x)+abs(in.y)>n) continue ;
 if (step[in.x+Con][in.y+Con][in.dir] > cost + 1 && step[out.x+Con][out.y+Con][out.dir] + 1 <= m) {
 step[in.x+Con][in.y+Con][in.dir] = cost + 1 ;
 all.push(in) ;
 }
 }
 }
 return -1 ;
}
int main() {
 while (scanf("%d%d",&n,&m) && (n+m)) {
 scanf("%d%d%d%d%d%d",&px0,&py0,&px1,&py1,&px,&py) ;
 printf("%d\n",bfs());
 }
 return 0;
}

