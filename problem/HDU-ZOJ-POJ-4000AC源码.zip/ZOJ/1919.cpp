#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cassert>
using namespace std;
#define MAXV 5005<<2
#define MAXE 2005<<2
//************dinic+declear************// 
const int INF = 1<<29;
int flag[MAXV], used[MAXV], head[MAXV], q[MAXV], ind[MAXV], outd[MAXV], level[MAXV];
int mp[27][27];
int st, ed, e;//src, desc
struct node{
	int v, nxt, dup;//next
	int cap, f, used;
	string str;
	node(){}
	node(int _v, int _nxt, int _dup=0, int _cap=0, int _f=0, int _used=0, string s=""):v(_v), nxt(_nxt), dup(_dup), cap(_cap), f(_f), used(_used), str(s){}
}Elist[MAXE];
int stack[MAXE];
/***************/

inline void add_edge(int u, int v, int cap=0, int f = 0){
	Elist[e] = node(v, head[u], e+1, cap, f);
	head[u] = e++;
}
/*****************Dinic******************/
#define MM(x) memset(x, -1, sizeof(x))
bool dinic_bfs(){
	int qhead(0),qtail(1),p;
	MM(level);
	level[st] = 0;//src
	q[0] = st;//src
	while(qhead < qtail){
		for(int p = head[q[qhead]]; p != -1; p = Elist[p].nxt){
			if(level[Elist[p].v] == -1 && Elist[p].cap > Elist[p].f){
				level[Elist[p].v] = level[q[qhead]] + 1;
				q[qtail++] = Elist[p].v;
			}
		}
		qhead++;
	}
	return level[ed] != -1; 
}

int Dinic(){
	int sh, cur, u, i, p, ans(0);
	stack[0] = st;
	while(dinic_bfs()){
		for(int sh = 1; sh != -1; ){
			int cur = stack[sh - 1];
			if(cur == ed){
				int m = (1 << 30);
				for(int i = 1; i < sh; ++i, ++i)
					if(m > Elist[stack[i]].cap - Elist[stack[i]].f){
						m = Elist[stack[i]].cap - Elist[stack[i]].f;
						u = i;
					}
				for(int i = 1; i < sh; ++i, ++i){
					Elist[stack[i]].f += m;
					Elist[Elist[stack[i]].dup].f -= m;	
				}
				ans += m;
				break;
			} else {
				for(p = head[cur]; p != -1; p = Elist[p].nxt){
					if(level[Elist[p].v] == level[cur] + 1 && Elist[p].cap > Elist[p].f){
						stack[sh++] = p, stack[sh++] = Elist[p].v;
						break;
					}
				}
				if(p == -1){
					level[cur] = -1;
					--sh, --sh;
				}
			}
		}
	}
	return ans;
}
int sp;
void dfs(int x){
	//printf("%c\n", x+'a');
	for(int p = head[x]; p != -1; p = Elist[p].nxt){
		if(!used[p]){
			used[p] = 1;
			//printf("%d -> %d with name : %s\n", x, Elist[p].v, Elist[p].str.c_str());
			dfs(Elist[p].v);
			stack[sp++] = p;
		}
	}
}
void dfs_check(int x)
{
	//printf("%c\n", x+'a');
 //for(int p = head[x]; p != -1; p = Elist[p].nxt)
 //	if(!flag[Elist[p].v]){
			//printf("%d -> %d with name : %d\n", x, Elist[p].v, Elist[p].dup);
 //		dfs_check(Elist[p].v);
	 //	}
 flag[x]=1;
	for(int i = 0; i < 26; i++)
		if(used[i] && mp[x][i] && !flag[i]){
			dfs_check(i);
		}
}
struct Node{
	char s[105];
}sc[MAXE];
bool cmp(Node a, Node b){
	return strcmp(a.s, b.s)>0;
}
int main()
{
	//freopen("test.in", "r", stdin);
	//freopen("test.out", "w", stdout);
	int CC, n;
	scanf("%d", &CC);
	while(CC--){
		scanf("%d", &n);
		#define M(x) memset(x, 0, sizeof(x))
		MM(head);
		M(ind), M(outd), M(used);
		e = 0;
		for(int i = 1; i <= n; i++){
			scanf("%s", sc[i].s);	
		} 
		sort(sc+1, sc+1+n, cmp);
		for(int i = 1; i <= n; i++){
			char *str = sc[i].s;
			int u = str[0] - 'a', v = str[strlen(str) - 1] - 'a';
			string tmp(str);
			Elist[e] = node(v, head[u], 0,0,0,0,tmp);
			head[u] = e++;
			++used[u], ++used[v], ++ind[u], ++outd[v];
			++mp[u][v], ++mp[v][u];
		}
		M(flag);
		for(int i = 0; i < MAXV; i++){
			if(used[i]){
				dfs_check(i);break;
			}	
		}
		//dfs_check(st);
		int idx = -1;
		for(int i = 0; i < MAXV; i++){
			if(used[i] && !flag[i]){
				idx = i; break;	
			}
		}
		if(idx != -1) printf("***\n");
		if(idx == -1){
			int total(0), cnt1(0), cnt2(0), cnt3(0);
			st = -1;
			for(int i = 0; i < MAXV; i++)
				if(used[i]){
					++total;
					if(st == -1) st = i;
					if(ind[i] - outd[i] == 1) ++cnt1, st = i;
					if(outd[i] - ind[i] == 1) ++cnt2;
					if(ind[i] == outd[i]) ++cnt3;
				}
			//printf("total = %d %d %d %d\n", total, cnt1, cnt2, cnt3);
			if(total == cnt3 || (cnt1 == 1 && cnt2 == 1 && cnt3 == total - 2)){
				sp = 0;
				M(used);
				dfs(st);
				for(int i = sp-1; i >= 0; i--){
					if(i < sp-1) printf(".");
					printf("%s", Elist[stack[i]].str.c_str());
				}
				printf("\n");
			} else printf("***\n");
		}
	}
}
