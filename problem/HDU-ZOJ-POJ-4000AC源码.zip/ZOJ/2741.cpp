#include <iostream>
#include <cstdio>
#include <sstream>
#include <string>
#include <algorithm>
#include <cmath>
using namespace std;

const int N = 0xFFFF, M = 0xF;
const double EPS = 1E-4;

char buf[N];
double pos[M];

int main()
{
	while (gets(buf))
	{
		istringstream sin(buf);
		string str;
		double x, y;
		int p = 0;
		while (sin >> str)
		{
			sscanf(str.c_str(), "(%lf,%lf)", &x, &y);
			pos[p++] = x;
		}
		if (pos[0] <= 0)
		{
			puts("PlayOn");
			continue;
		}
		sort(pos+2, pos+p);
		if (fabs(pos[0]-pos[p-2]) < EPS)
		{
			puts("PlayOn");
			continue;
		}
		if (pos[0] > pos[1] && pos[0] > pos[p-2])
			puts("Offside");
		else
			puts("PlayOn");
	}
	return 0;
}
