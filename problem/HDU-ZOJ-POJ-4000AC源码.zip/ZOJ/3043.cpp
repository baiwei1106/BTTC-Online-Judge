#define PIG 49
#define SHP 22
#define CHG 8
#include <iostream>
using namespace std;

string name[5], st;
string su[5], v[5];
int win, round;
int col[5], sco[5];

void init(){
	cin>>name[0]>>name[1]>>name[2]>>name[3];
	cin>>st;
	for (int i=0; i<4; i++) 
		if (st==name[i]) {
			win=i;
			break;
		}
	cin>>round;
}

int cardv(const string &v){
	if (v[0] == 'A') return 14;
	if (v[0] == 'J') return 11;
	if (v[0] == 'Q') return 12;
	if (v[0] == 'K') return 13;
	if (v[0] == '1') return 10;
	return (v[0]-'0');
}

int cardid(const string &su, const string &v){
	int vi = cardv(v), f;
	if (su[0] == 'C') f=0;
	if (su[0] == 'D') f=1;
	if (su[0] == 'H') f=2;
	if (su[0] == 'S') f=3;
	return f*13 + vi - 2;
}

int score(int x){
	if (col[x] == 65535) return 800;
	if (col[x] == 32768) return 50;
	int ret = 0;
	if ((col[x]&32764)==32764){
		ret += 200;
		if (col[x]&1) ret-=100;
		if (col[x]&2) ret+=100;
	} else {
		for (int i=0; i<15; i++){
			int k=(1<<i);
			if (col[x]&k){
				if (i==0) ret -= 100;
				if (i==1) ret += 100;
				if (i>=2 && i<=4) ret += 0;
				if (i>=5 && i<= 10) ret -= 10;
				if (i==11) ret -= 20;
				if (i==12) ret -= 30;
				if (i==13) ret -= 40;
				if (i==14) ret -= 50;
			}
		}
	}
	if (col[x]&32768) ret*=2;
	return ret;
}

void solve(){
	col[0] = col[1] = col[2] = col[3] = 0;
	while (round--){
		cin>>su[0]>>v[0]>>su[1]>>v[1]>>su[2]>>v[2]>>su[3]>>v[3];
		int now = win-1, mv = cardv(v[0]);
		char ch = su[0][0];
		int stat = 0;
		for (int i=0; i<4; i++){
			now++; now%=4;
			int nv = cardv(v[i]);
			int ni = cardid(su[i], v[i]);
			if (su[i][0] == ch && nv > mv) {
				win = now;
				mv = nv;
			}
			if (ni>=26 && ni<39) stat|=(1<<(ni-24));
			if (ni == 49) stat|=(1<<0);
			if (ni == 22) stat|=(1<<1);
			if (ni == 8) stat|=(1<<15);
		}
		col[win]|=stat;
	}
	for (int i=0; i<4; i++)
		cout<<name[i]<<" "<<score(i)<<endl;
}

int main(){
	int cas; cin>>cas;
	while (cas--){
		init();
		solve();
		if (cas) cout<<endl;
	}
	return 0;
}
