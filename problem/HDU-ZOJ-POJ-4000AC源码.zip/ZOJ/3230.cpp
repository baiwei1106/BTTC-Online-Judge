#include<stdio.h>
#include<string.h>
#include<queue>
#include<stdlib.h>
#include <algorithm>
#define N 100100
using namespace std;
struct nd
{
 int a,b;
 bool operator < (const nd &a) const
 {
 return a.b>b;
 }
}node[N];
int n,m,p;
bool cmp(nd a,nd b)
{
 if(a.a!=b.a)return a.a<b.a;
 return a.b>b.b;
}
int main()
{
 while(scanf("%d%d%d",&n,&m,&p)!=EOF)
 {
 for(int i=0;i<n;i++)
 scanf("%d%d",&node[i].a,&node[i].b);
 sort(node,node+n,cmp);
 int cnt=0;
 int flag=0;
 int cp=0;
 priority_queue<nd> q;
 while(node[cnt].a<=p)
 {
 q.push(node[cnt]);
 cnt++;
 if(cnt>=n)
 {
 flag=1;
 break;
 }
 }
 //printf("%d\n",cnt);
 while(!q.empty())
 {
 nd gg=q.top();
 q.pop();
 p+=gg.b;
 cp++;
 if(cp>=m)break;
 if(flag)continue;
 while(node[cnt].a<=p)
 {
 q.push(node[cnt]);
 cnt++;
 if(cnt>=n)
 {
 flag=1;
 break;
 }
 }
 }
 printf("%d\n",p);
 }
 return 0;
}
