#include<iostream>
#include<cstring>
#include<cstdio>
#include<vector>
using namespace std;

vector<int> G1[210];
int color[210];
int tmp[210];

void DFS(int u) {
 memset(tmp, 0, sizeof(tmp));
 for(int i = 0; i < G1[u].size(); ++i) {
 int v = G1[u][i];
 tmp[color[v]] = 1;
 }
 for(int i = 1; ; ++i) {
 if(!tmp[i]) {
 color[u] = i;
 break;
 }
 }
}

int main() {
 int n, m;
 while(scanf("%d %d", &n, &m)!=EOF) {
 memset(G1, 0, sizeof(G1));
 memset(color, 0, sizeof(color));
 int a, b;
 while(m--) {
 scanf("%d %d", &a, &b);
 G1[a].push_back(b);
 G1[b].push_back(a);
 }
 for(int i = 1; i <= n; ++i) {
 if(!color[i]) DFS(i);
 }
 int ans = 0;
 for(int i = 1; i <= n; ++i)
 ans = max(ans, color[i]);
 cout<<ans<<endl;
 }
 return 0;
}
