/*
ID:1192432
PROG: castle
LANG: C++
*/
#include <iostream>
#include <string>
#include <stack>
#include <memory.h>
#include <list>
#include <cstdio>
#include <queue>


using namespace std;
const int MAX=250,base=(int)'A';

struct Ope{
 bool isNum;
 char c;
 bool alp[26];
};

Ope t,ttt;//һ��t������
string s;
stack<Ope> stack1,stack2;

void init(Ope & ooo){
 ooo.isNum=0;
 ooo.c=0;
 memset(ooo.alp,0,sizeof(ooo.alp));
}

bool ApriorB(const char &c1,const char &c2){
 if(c1=='(')
 return 0;
 if(c1=='*')
 return 1;
 if(c2=='*')
 return 0;
 return 1;
}

void built(){
 for(int i=0,j;i<(int)s.size();i++){
 init(t);
 if(s[i]=='{'){
 t.isNum=1;
 for(j=i+1;s[j]!='}';j++){
 if(s[j]){
 t.alp[s[j]-base]=1;
 }
 }
 i=j;
 stack2.push(t);
 }
 else if(s[i]=='('){
 t.c=s[i];
 stack1.push(t);
 }
 else if(s[i]==')'){
 while(stack1.top().c!='('){
 t=stack1.top(); stack1.pop();
 stack2.push(t);
 }
 stack1.pop(); //pop "("
 }
 else{
 t.c=s[i];
 while(!stack1.empty()
 &&ApriorB(stack1.top().c,t.c)){
 ttt=stack1.top(); stack1.pop();
 stack2.push(ttt);
 }
 stack1.push(t);
 }
 }
 while(!stack1.empty()){
 t=stack1.top(); stack1.pop();
 stack2.push(t);
 }
}

Ope plusss(){
 Ope o1,o2,result;
 o1=stack1.top(); stack1.pop();
 o2=stack1.top(); stack1.pop();
 init(result);
 result.isNum=1;
 for(int i=0;i<26;i++)
 if(o1.alp[i]||o2.alp[i])
 result.alp[i]=1;
 return result;
}

Ope minusss(){

 Ope o1,o2,result;
 o1=stack1.top(); stack1.pop();
 o2=stack1.top(); stack1.pop();

 init(result);
 result.isNum=1;

 memcpy(result.alp,o2.alp,sizeof(result.alp));

 for(int i=0;i<26;i++)
 if(o1.alp[i])
 result.alp[i]=0;
 return result;
}

Ope mulll(){
 Ope o1,o2,result;
 o1=stack1.top(); stack1.pop();
 o2=stack1.top(); stack1.pop();
 init(result);
 result.isNum=1;
 for(int i=0;i<26;i++)
 if(o1.alp[i]&&o2.alp[i])
 result.alp[i]=1;
 return result;
}

void cal(){//now as stack is empty,use it for calculate
 while(!stack2.empty()){
 t=stack2.top(); stack2.pop();
 if(t.isNum)
 stack1.push(t);
 else{
 if(t.c=='+'){ ttt=plusss();}
 else if(t.c=='-'){ ttt=minusss();}
 else if(t.c=='*'){ ttt=mulll();}
 stack1.push(ttt);
 }
 }
}

int main()
{
 // freopen("i.txt","r",stdin);
 //freopen("castle.in","r",stdin);
 //freopen("castle.out","w",stdout);
 Ope ans;
 queue<Ope> q;
 while(getline(cin,s)){
 while(!stack1.empty()) stack1.pop();
 while(!stack2.empty()) stack2.pop();

 built();
 while(!stack2.empty()){
 q.push(stack2.top());
 stack2.pop();
 }
 while(!q.empty()){
 stack2.push(q.front());
 q.pop();
 }
 // while(!stack2.empty()){
// t=stack2.top(); stack2.pop();
// if(t.isNum){
// for(int i=0;i<26;i++)
// if(t.alp[i]){
// cout<<(char)(i+base);
// //cout<<"I "<<i<<endl;
// }
// }
// else
// cout<<t.c;
// cout<<endl;
// }
 cal();

 ans=stack1.top(); stack1.pop();
 cout<<"{";
 for(int i=0;i<26;i++)
 if(ans.alp[i])
 cout<<(char)(i+base);
 cout<<"}"<<endl;

 }
 return 0;
}
