#include<cstdio>
#include<cstdlib>
#include<cctype>
#include<cstring>
#include<cmath>
#include<ctime>
#include<vector>
#include<map>
#include<set>
#include<list>
#include<deque>
#include<stack>
#include<bitset>
#include<functional>
#include<numeric>
#include<utility>
#include<sstream>
#include<iomanip>
#include<algorithm>
#include<limits>
#include<iostream>
#include<fstream>
#include<string.h>
#include<string>
#include<queue> 
using namespace std;
#define max(a,b) ((a>b)?a:b) //finding max
#define min(a,b) ((a<b)?a:b) //finding min
#define Max(a,b,c) max(a,max(b,c)) //finding max between 3 numbers
#define Min(a,b,c) min(a,min(b,c)) //finding min between 3 numbers
#define Pi acos(-1.0) //defining Pi for mathematical uses
#define Clear(a) memset(a,0,sizeof(a)) //clearing memory of an array
#define setfalse(a) memset(a,false,sizeof(a)) //setting the array into false
#define settrue(a) memset(a,true,sizeof(a)) //setting the array into true
#define clrstr(a) memset(a,'\0',sizeof(a)) //setting string array to null
#define open freopen("input.txt","r",stdin) //opening input file
#define close freopen ("output.txt","w",stdout) //opening output file
#define Case(a) printf("Case %d: ",a) //printing case number
#define caseh(a) printf("Case #%d: ",a) //printing case number having '#'
#define getcase(a) scanf("%d",&a) //scanning case number
#define caseloop(a,b) for(a=1;a<=b;a++) //making case loop
#define EPS 1e-9 //small value for avoiding preccesion error
#define LL long long //__int64 //long long short form
#define MX 50000 //MAX size/value
#define PB(x) push_back(x) //push in vector/string
#define PP pop_back() //pop from vector
#define PF(x) push_front(x) //push in vector/string/deque from front
#define PPF(x) pop_front() //pop from vector/deque from front
#define IN(x) insert(x) //insert element in set
#define PS(x) push(wax) //push element in stack/queue
#define P(x) pop() //pop element from stack/queue
template<class T>inline void checkmin(T &a,T b){if(b<a)a=b;}
template<class T>inline void checkmax(T &a,T b){if(b>a)a=b;}
const double eps=1e-15;
const double pi=acos(-1.0);
#define two(X) (1<<(X))
#define twoL(X) (((int64)(1))<<(X))
#define contain(S,X) (((S)&two(X))!=0)
#define containm(S,X) (((S)&twoL(X))!=0)
#define SIZE(A) ((int)A.size())
#define LENGTH(A) ((int)A.length())
#define MP(A,B) make_pair(A,B)
#define MUL(a,b) (int)(((int64)a*b%MOD))
#define FOR(i,a,b) for(i=(a);i<(b);i++)
#define REP(i,n) for(int i=0;i<(n);i++)
typedef pair<int,int>ipair;
#define MOD (1000000007)
using namespace std;
const int size=203;
#define ll double
int n;
struct two_matrix{
 ll array[size][size];
};
two_matrix pw;
two_matrix unit;
two_matrix ret;
int main(){
	int i,t,u,v,j,k;
	int x;
	double num[size],f;
	double ans;
	//two_matrix unit;
#ifndef ONLINE_JUDGE
	freopen("a.txt","r",stdin);
#endif
	while(cin>>n>>x,n+x){
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				if(i==j){
					pw.array[i][i]=1.0;
					unit.array[i][j]=1.0;
				}
				else{
					pw.array[i][i]=0.0;
					unit.array[i][j]=0.0;
				}
			}
		}
		for(i=0;i<n;i++){
			cin>>num[i];
		}
		cin>>t;
		for(i=0;i<t;i++){
			cin>>u>>v>>f;
			unit.array[u][u]-=f;
			unit.array[v][u]+=f;
		}
		while(x>0){
			if(x&1)
				for(i=0;i<n;i++)
					for(j=0;j<n;j++){
						ret.array[i][j]=0;
						for(k=0;k<n;k++)
							ret.array[i][j]=(ret.array[i][j]+(pw.array[i][k]*unit.array[k][j]));
					}
				for(i=0;i<n;i++)	
					for(j=0;j<n;j++)
						pw.array[i][j]=ret.array[i][j];
				for(i=0;i<n;i++)
					for(j=0;j<n;j++){
						ret.array[i][j]=0;
						for(k=0;k<n;k++)
							ret.array[i][j]=(ret.array[i][j]+(unit.array[i][k]*unit.array[k][j]));
					}	
					for(i=0;i<n;i++)
						for(j=0;j<n;j++)
							unit.array[i][j]=ret.array[i][j];
							x>>=1;
		}
		for(ans=0,j=0;j<n;j++){
			ans+=pw.array[n-1][j]*num[j];
		}
		printf("%.0lf\n",ans);
	}
	return 0;
}







