/*
 * Author: chlxyd
 * Created Time: 2013/7/29 16:08:56
 * File Name: D.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )
int flag ;
struct poly{
 int a[300] ;
 int l ;
 void clear() {
 clr(a) ;
 l = 1 ;
 }
 bool zero() {
 if ( l == 1 && a[1] == 0 ) return true ;
 return false ;
 }
 bool operator == ( const poly & q ) const {
 if ( l != q.l ) return false ;
 repf( i , 1 , l )
 if ( a[i] != q.a[i] ) return false ;
 return true ;
 }
 poly operator + ( const poly & q ) const {
 poly ret ; ret.clear() ;
 ret.l = max( l , q.l ) ;
 repf( i , 1 , ret.l ) 
 ret.a[i] = q.a[i] ^ a[i] ;
 int tmp = ret.l ;
 ret.l = 1 ;
 repd( i , tmp , 1 ) {
 	if ( ret.a[i] != 0 ) {
	 	ret.l = i ;
	 	break ;
	 }
 }
 return ret ;
 } 
 poly operator - ( const poly & q ) const {
 poly ret ; ret.clear() ;
 ret.l = max( l , q.l ) ;
 repf( i , 1 , ret.l ) 
 ret.a[i] = q.a[i] ^ a[i] ;
 int tmp = ret.l ;
 ret.l = 1 ;
 repd( i , tmp , 1 ) {
 	if ( ret.a[i] != 0 ) {
	 	ret.l = i ;
	 	break ;
	 }
 }
 return ret ;
 }
 poly operator * ( const poly & q ) const {
 poly ret ; ret.clear() ;
 repf( i , 1 , l )
 repf( j , 1 , q.l ) 
 ret.a[i+j-1] ^= a[i] * q.a[j] ;
 repd( i , q.l + l , 1 )
 if ( ret.a[i] != 0 ) {
 ret.l = i ;
 break ;
 }
 return ret ;
 }
 poly operator / ( const poly & q ) const {
 poly ret ; ret.clear() ;
 poly now ; now.clear() ;
 ret.l = l ;
 repf( i , 1 , l ) 
 ret.a[i] = a[i] ;
 flag = false ;
 if ( l == 1 && q.a[1] == 0 ) { 
 ret.clear() ;
 return ret ;
 }
 if ( ret.l < q.l ) {
 flag = true ;
 ret.clear() ; 
 return ret ;
 }
 repd( i , l - q.l + 1 , 1 ) {
 if ( ret.a[i+q.l-1] == 1 ) {
 now.a[i] = 1 ;
 repd( j , i + q.l - 1 , i ) 
 ret.a[j] ^= q.a[j-i+1] ;
 }
 }
 repd( i , l , 1 ) {
 	if ( now.a[i] != 0 ) {
 		now.l = i ;
 		break ;
 	}
 }
 repf( i , 1 , q.l - 1 ) 
 if ( ret.a[i] != 0 ) {
 flag = true ;
 }
 return now ;
 }
 int readin() {
 	clr(a) ;
 if ( scanf("%d" , &l) != 1 ) return 0 ;
 l ++ ;
 repd( i , l , 1 ) scanf("%d" , &a[i] ) ;
		if ( l == 0 ) l = 1 ;
 return 1 ;
 }
 void show() {
 if ( l == 1 && a[1] == 0 ) puts("-1") ;
 else {
 	printf("%d" , l - 1 ) ;
 	repd( i , l , 1 ) {
 	printf(" %d" , a[i] ) ;
 	}
 	puts("") ;
 }
 }
};
poly a[2] , b[2] , c[2] ;
poly ansx , ansy ;
poly extgcd( poly a , poly b , poly &x , poly &y ) {
 if ( b.zero() ) {
 x.clear() ; x.a[1] = 1 ; y.clear() ;
 return a ;
 }
 poly ret = extgcd( b , a - ( a / b ) * b , x , y ) ;
 poly t = x ; x = y ; y = t - (a / b) * y ;
 return ret ;
}
bool dopoly( poly a , poly b , poly c ) {
 poly x , y ;
 poly gcd = extgcd( a , b , x , y ) ;
 poly c1 = c / gcd ;
 if ( flag ) return false ;
 ansx = x * c1 ; ansy = y * c1 ;
 return true ;
}
bool solve() { 
 if ( a[0].zero() && b[0].zero() && !c[0].zero() ) return false ;
 if ( a[1].zero() && b[1].zero() && !c[1].zero() ) return false ; 
 if ( a[0].zero() && b[0].zero() && c[0].zero() && a[1].zero() && b[1].zero() && c[1].zero() ) return true ;
 if ( a[0].zero() && b[0].zero() && c[0].zero() )
 return dopoly( a[1] , b[1] , c[1] ) ;
 else if ( a[1].zero() && b[1].zero() && c[1].zero() )
 return dopoly( a[0] , b[0] , c[0] ) ; 
 poly D = a[0]*b[1] - a[1]*b[0] ;
 if ( !D.zero() ) {
 	//ansx = c[0] * a[1] - c[1] * a[0];
 ansy = ( c[0]*a[1] - c[1]*a[0] ) / ( a[1]*b[0]-a[0]*b[1]) ;
 if ( flag ) return false ;
 ansx = ( c[0]*b[1] - c[1]*b[0] ) / ( a[1]*b[0]-a[0]*b[1]) ;
 if ( flag ) return false ;
 }
 else {
 if ( !(c[0]*a[1] - c[1]*a[0]).zero() ) return false ;
 if ( !(c[0]*b[1] - c[1]*b[0]).zero() ) return false ;
 bool bj = false ;
 if ( a[0].zero() ) {
 bj = true ;
 ansy = c[0] / b[0] ;
 if (flag ) return false ;
 }
 if ( b[0].zero() ) {
 bj = true ;
 ansx = c[0] / a[0] ;
 if ( flag ) return false ;
 } 
 if ( a[1].zero() ) {
 bj = true ;
 ansx = c[1] / b[1] ;
 if ( flag ) return false ;
 } 
 if ( b[1].zero() ) {
 bj = true ;
 ansx = c[1] / a[1] ;
 if ( flag ) return false ;
 }
 if ( !bj )
 return dopoly(a[0],b[0],c[0]) ;
 }
 return true ;
}
int main(){
	//freopen("D.in","r",stdin);
 while ( a[0].readin() ) {
 b[0].readin() ; c[0].readin() ;
 a[1].readin() ; b[1].readin() ; c[1].readin() ;
 if ( !solve() ) 
 puts("No solution") ;
 else {
 ansx.show() ;
 ansy.show() ;
 }
 puts("") ;
 }
}
