
#include<cstdio>
#include<iostream>

using namespace std;



int f[1010][2];
int ans[7][2];
int n,m;
int main()
{
 int T;
 scanf("%d",&T);
 while (T--)
 {
 int now=0;
 scanf("%d%d",&n,&m);
 for (int i=0;i<=n;i++) f[i][now]=0;
 for (int i=0;i<m;i++)
 {
 now=1-now;
 for (int i=0;i<=n;i++) f[i][now]=f[i][1-now];
 int x;
 scanf("%d",&x);
 int K=0;
 f[x][now]++;
 for (int j=x+1;j<=n&& K<1;j++)
 if (f[j][now]>=2)
 {
 f[j][now]-=2;
 f[j+1][now]++;
 K++;
 }
 if (f[x][now]>=2)
 {
 f[x][now]-=2;
 f[x+1][now]++;
 }
 K=0;
 for (int j=0;j<=n;j++)
 {
 if (f[j][now]!=f[j][1-now])
 {
 ans[K][0]=j;
 ans[K][1]=f[j][now];
 K++;
 }
 }
 printf("%d",K);
 for (int j=0;j<K;j++)
 {
 printf(" %d %d",ans[j][0],ans[j][1]);
 }
 printf("\n");
 }
 if (T>0) printf("\n");
 }
}
/*
7
7
1 2 3 4 5 1 5
*/
