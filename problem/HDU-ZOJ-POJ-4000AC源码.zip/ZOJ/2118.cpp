#include <stdio.h>
#include <queue>
#include <set>
#include <algorithm>

using namespace std;

int dp[250003];

class cmp
{
 public:
 bool operator()(const int& a,const int& b)
 {
 if (dp[a]!=dp[b]) return dp[a]<dp[b];
 else return a<b;
 }
};

set<int, cmp> s[50003];
set<int, cmp>::iterator it;
int min1[2000003],cd[250003],ind[250003];
char str[250003],str1[10];

void init(int node,int b,int e)
{
 if (b==e)
 {
 ind[b]=node;
 if (b==cd[0]) min1[node]=0;
 else min1[node]=1e9;
 return ;
 }
 init(2*node,b,(b+e)/2);
 init(2*node+1,(b+e)/2+1,e);
 min1[node]=min(min1[2*node],min1[2*node+1]);
}

int query(int node,int b,int e,int i,int j)
{
 if (b>j||e<i) return 1e9;
 if (b>=i&&e<=j) return min1[node];
 return min(query(2*node,b,(b+e)/2,i,j),query(2*node+1,(b+e)/2+1,e,i,j));
}

int main()
{
 int test,n,m,k,i,mn1,max1,j,p;
 scanf("%d",&test);
 while (test--)
 {
 scanf("%d%d%d",&n,&m,&k);
 for (i=1;i<=n;i++)
 {
 scanf("%s",str1);
 str[i]=str1[0];
 }
 if (str[1]=='C') str[0]='D';
 else str[0]='C';
 cd[0]=0;
 mn1=cd[0];
 for (i=1;i<=n;i++)
 {
 if (str[i]=='C') cd[i]=cd[i-1]+1;
 else cd[i]=cd[i-1]-1;
 if (cd[i]<mn1) mn1=cd[i];
 }
 max1=0;
 if (mn1<0)
 {
 for (i=0;i<=n;i++) cd[i]-=mn1;
 }
 for (i=0;i<=n;i++)
 {
 if (cd[i]>max1) max1=cd[i];
 }
 deque<int> dq;
 dq.push_front(0);
 dp[0]=0;
 s[cd[0]].insert(0);
 init(1,0,max1);
 for (i=1;i<=n;i++)
 {
 if (str[i]==str[i-1])
 {
 if (dq.front()<i-m) dq.pop_front();
 }
 else
 {
 while (!dq.empty()&&dq.front()<i-1) dq.pop_front();
 }
 p=dp[dq.front()];
 //printf("%d",p);
 if (i-m-1>=0)
 {
 it=s[cd[i-m-1]].find(i-m-1);
 s[cd[i-m-1]].erase(it);
 j=ind[cd[i-m-1]];
 if (s[cd[i-m-1]].size()==0) min1[j]=1e9;
 else min1[j]=dp[*s[cd[i-m-1]].begin()];
 j>>=1;
 while (j)
 {
 min1[j]=min(min1[2*j],min1[2*j+1]);
 j>>=1;
 }
 }
 //printf(" %d\n",query(1,0,max1,max(0,cd[i]-k),min(max1,cd[i]+k)));
 p=min(p,query(1,0,max1,max(0,cd[i]-k),min(max1,cd[i]+k)));
 dp[i]=p+1;
 while (!dq.empty()&&(dp[dq.back()]>dp[i])) dq.pop_back();
 dq.push_back(i);
 s[cd[i]].insert(i);
 j=ind[cd[i]];
 while (j&&dp[i]<min1[j])
 {
 min1[j]=dp[i];
 j>>=1;
 }
 //printf("%d\n",dp[i]);
 }
 printf("%d\n",dp[n]);
 for (i=0;i<=max1;i++) s[i].clear();
 }
 return 0;
}
