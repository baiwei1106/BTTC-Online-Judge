#include<stdio.h>
int m,n,t,l,i,j,k,minx,p,temp,time,rank,pos;
int I[2000],A[2000],L[2000],O[2000],T[2000],Z[2000],V[2000],C[2000],e[50][50],r[50][50],select[2000],expect[2000],real[2000],solve[2000],penalty[2000];
int ans[2000],id[2000];
int max(int i,int j)
{
 if (i>j) return i;
 else
 return j;
}
int main(void)
{
 while (scanf("%d%d%d%d",&m,&n,&t,&l)!=EOF)
 {
 for (i=1;i<=m;i++)
 scanf("%d%d%d%d",&I[i],&A[i],&L[i],&O[i]);
 for (i=1;i<=t;i++)
 scanf("%d%d%d%d",&T[i],&Z[i],&V[i],&C[i]);
 for (j=1;j<=t;j++)
 for (i=1;i<=n;i++)
 {
 e[j][i]=I[i]/O[i]+max(A[i]/C[j],5);
 r[j][i]=max(I[i]-T[j],0)+A[i]/(Z[j]+C[j])+L[i]/V[j];
 }
 minx=2000000000;
 for (i=1;i<=n;i++)
 select[i]=i;
 while (true)
 {
 for (i=1;i<=t;i++)
 {
 p=0;
 for (j=1;j<=n;j++)
 {
 if (T[i]+C[i]<=I[select[j]]-O[select[j]]) continue;
 p=p+1;
 expect[p]=e[i][select[j]];
 real[p]=r[i][select[j]];
 }
 for (j=1;j<=p-1;j++)
 for (k=j+1;k<=p;k++)
 if (expect[j]>expect[k] || expect[j]==expect[k] && real[j]>real[k])
 {
 temp=expect[j];expect[j]=expect[k];expect[k]=temp;
 temp=real[j];real[j]=real[k];real[k]=temp;
 }
 time=0;solve[i]=0;penalty[i]=0;
 for (j=1;j<=p;j++)
 {
 time=time+real[j];
 if (time>l) break;
 solve[i]=solve[i]+1;
 penalty[i]=penalty[i]+time;
 }
 }
 for (i=1;i<=t;i++)
 id[i]=i;
 for (i=1;i<=t-1;i++)
 for (j=i+1;j<=t;j++)
 if (solve[i]<solve[j] || solve[i]==solve[j] && penalty[i]>penalty[j])
 {
 temp=id[i];id[i]=id[j];id[j]=temp;
 temp=solve[i];solve[i]=solve[j];solve[j]=temp;
 temp=penalty[i];penalty[i]=penalty[j];penalty[j]=temp;
 }
 for (i=1;i<=t;i++)
 if (id[i]==1) break;
 rank=i;
 while (rank>1 && solve[rank]==solve[rank-1] && penalty[rank]==penalty[rank-1])
 rank--;
 if (rank<minx)
 {
 minx=rank;
 for (i=1;i<=n;i++)
 ans[i]=select[i];
 }
 pos=n;
 while (pos>=1 && select[pos]==pos+m-n) pos--;
 if (pos==0) break;
 select[pos]++;
 for (i=pos+1;i<=n;i++)
 select[i]=select[i-1]+1;
 }
 for (i=1;i<=n-1;i++)
 printf("%d ",ans[i]);
 printf("%d\n",ans[n]);
 }
 return 0;
}
