#include<stdio.h>
int main()
{
	int n,a[15][15],fail;
	while(scanf("%d",&n)&&n)
	{
		int i,j,k,flag[1005]={0},sum;
		fail=0;
		for(i=0;i<n;i++)
		{
			sum=0;
			for(j=0;j<n;j++)
			{
				scanf("%d",&a[i][j]);
				if(flag[a[i][j]]==1)
				{
					fail=1;
				}
				flag[a[i][j]]=1;
				sum+=a[i][j];
			}
		}
		int sum1,sum2,sum3,sum4;
		sum3=sum4=0;
		for(i=0;i<n&&!fail;i++)
		{
			sum1=sum2=0;
			for(j=0;j<n;j++)
			{
				sum1+=a[i][j];
				sum2+=a[j][i];
			}
			if(sum1!=sum)fail=1;
			if(sum2!=sum)fail=1;
			sum3+=a[i][i];
			sum4+=a[i][n-1-i];
		}
		if(sum3!=sum)fail=1;
		if(sum4!=sum)fail=1;
		if(fail)printf("No\n");
		else printf("Yes\n");
	}
	return 0;
}
