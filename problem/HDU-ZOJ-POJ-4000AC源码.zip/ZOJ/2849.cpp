#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<queue>
#include<vector>
#include<iostream>
using namespace std;

const int M = 1000000000;
struct PP{
 int type,day;
}dp[501][501];
struct p{
 int x,y,type,day;
}fr,o,st[501*501];
int cmp1(p A,p B)
{
 return A.type<B.type; 
}
int g[501][501],res[501*501],c[4][2]={1,0,0,1,-1,0,0,-1},m,n;
bool operator<(const p& A,const p& B)
{ 
	return A.day>B.day;
}
priority_queue<p>q;
void bfs()
{
 int i;
 while(!q.empty())
 {
 fr=q.top();
 q.pop();
 for(i=0;i<4;i++)
 {
 o=fr;
 o.x=fr.x+c[i][0];
 o.y=fr.y+c[i][1];
 if(o.x>=0&&o.y>=0&&o.x<m&&o.y<n&&g[o.x][o.y]<0)
 {
 if(o.day<-g[o.x][o.y])o.day=-g[o.x][o.y];
 if(dp[o.x][o.y].day>o.day)
 {
 dp[o.x][o.y].type=o.type;
 dp[o.x][o.y].day=o.day;
 q.push(o); 
 } 
 else if(dp[o.x][o.y].day==o.day&&dp[o.x][o.y].type>o.type)
 {
 dp[o.x][o.y].type=o.type;
 q.push(o); 
 } 
 } 
 }
 } 
}
int main()
{
 int i,j,k;
 while(~scanf("%d%d",&m,&n))
 {
 for(i=0;i<m;i++)
 for(j=0;j<n;j++)
 {
 dp[i][j].day=M; 
 }
 k=0;
 for(i=0;i<m;i++)
 for(j=0;j<n;j++)
 {
 scanf("%d",&g[i][j]);
 if(g[i][j]>0)
 {
 st[k].x=i;
 st[k].y=j;
 st[k].day=1;
 st[k].type=g[i][j];
 dp[i][j].type=g[i][j];
 //printf("k:%d g:%d \n",k,g[i][j]);
 dp[i][j].day=1;
 k++; 
 } 
 }
 while(!q.empty())q.pop(); 
 for(i=0;i<k;i++)
 {
 q.push(st[i]); 
 }
 bfs();
 
 memset(res,0,sizeof(res));
 for(i=0;i<m;i++)
 for(j=0;j<n;j++)
 res[dp[i][j].type]++;
 scanf("%d",&m);
 while(m--)
 {
 scanf("%d",&i);
 printf("%d\n",res[i]); 
 } 
 }
}
