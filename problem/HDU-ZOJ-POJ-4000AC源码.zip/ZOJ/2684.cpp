#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
const int maxn=1000005;
int ll[maxn],cnt,num,ans,a,b,aa,bb;
bool flag,vis[maxn];
struct str
{
 int node,fa,ls,rs;
}edge[maxn];
void creat(int n)
{
 cnt=0;num=n;
 edge[++cnt].fa=2,edge[cnt].ls=-1,edge[cnt].rs=-1,edge[cnt].node=1;
 edge[++cnt].fa=-1,edge[cnt].ls=1,edge[cnt].rs=-1,edge[cnt].node=++num;
 for(int i=1,now=1,tot=0;i<n;i++,tot=0)
 {
 while(tot<ll[i])
 {
 tot++;
 if(edge[now].node-n<=0)now=edge[now].fa;
 else
 {
 if(edge[now].ls==-1)
 {
 edge[++cnt].fa=now,edge[cnt].ls=-1,edge[cnt].rs=-1;
 edge[now].ls=cnt;
 if(tot==ll[i])edge[cnt].node=i+1;
 else edge[cnt].node=++num;
 now=cnt;
 }
 else if(edge[now].rs==-1)
 {
 edge[++cnt].fa=now,edge[cnt].ls=-1,edge[cnt].rs=-1;
 edge[now].rs=cnt;
 if(tot==ll[i])edge[cnt].node=i+1;
 else edge[cnt].node=++num;
 now=cnt;
 }
 else
 {
 if(edge[now].fa==-1)
 {
 edge[++cnt].fa=-1,edge[cnt].ls=now;
 edge[cnt].rs=-1,edge[cnt].node=++num;
 edge[now].fa=cnt;
 now=cnt;
 }
 else now=edge[now].fa;
 }
 }
 }
 }
 for(int i=1;i<=cnt;i++)
 {
 if(edge[i].node==a)aa=i;
 else if(edge[i].node==b)bb=i;
 }
}
void out(int root)
{
 cout<<edge[root].node<<" "<<edge[edge[root].fa].node<<" "<<edge[edge[root].ls].node<<" "<<edge[edge[root].rs].node<<endl;
 if(edge[root].ls!=-1)out(edge[root].ls);
 if(edge[root].rs!=-1)out(edge[root].rs );
}
void dfs(int root,int dep,int tar)
{
 if(flag)return;
 if(root==tar){flag=true;ans=dep;return;}
 if(!vis[edge[root].fa]&&edge[root].fa!=-1)
 vis[edge[root].fa]=true,dfs(edge[root].fa,dep+1,tar);
 if(!vis[edge[root].ls]&&edge[root].ls!=-1)
 vis[edge[root].ls]=true,dfs(edge[root].ls,dep+1,tar);
 if(!vis[edge[root].rs]&&edge[root].rs!=-1)
 vis[edge[root].rs]=true,dfs(edge[root].rs,dep+1,tar);
}
int main()
{
 int cas,n;
 cin>>cas;
 while(cas--)
 {
 cin>>n;
 for(int i=1;i<n;i++)cin>>ll[i];
 cin>>a>>b;
 creat(n);
 memset(vis,0,sizeof(vis));
 flag=false;
 dfs(aa,0,bb);
 cout<<ans<<endl;
 }
 return 0;
}
