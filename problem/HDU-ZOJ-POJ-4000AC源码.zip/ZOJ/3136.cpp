#include<stdio.h>

int a[30],b[30];
int M,n;

int main()
{
 int tst,i,j;
 scanf("%d",&tst);
 while(tst--)
 {
 scanf("%d",&n);
 int mx1=0;
 for(i=0;i<n;i++)
 {
 scanf("%d%d",&a[i],&b[i]);

 }
 scanf("%d",&M);
 for(i=0;i<n;i++)
 {
 if(a[i]*M+b[i]>mx1) mx1=a[i]*M+b[i];
 }
 int ans=0;
 int x;
 for(i=1;i<=mx1;i++)
 {
 bool pl=true;
 int c1=M;
 int c2=0;

 for(j=0;j<n;j++)
 {
 if((i-b[j])%a[j]==0&&i>=b[j])
 {
 x=(i-b[j])/a[j];
 }
 else pl=false;
 c2+=x;
 if(!pl) break;


 }
 if(c1==c2&&pl)
 {
 ans=i;
 break;
 }

 }
 printf("%d\n",ans);

 }
 return 0;
}
