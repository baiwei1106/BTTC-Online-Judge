#include <iostream>
#include <queue>
#include <stack>
#include <cstring>

using namespace std;

#define min mmin
typedef long long LL;

queue <int> que;
stack <int> min;
stack <int> min10;
stack <int> hour;

void omin(int node);
void omin10(int node);
void ohour(int node);

void omin(int node)
{
 if (min.size() == 9)
 {
 while (!min.empty())
 {
 int node = min.top();
 min.pop();
 que.push(node);
 }
 omin10(node);
 }
 else
 {
 min.push(node);
 }
}

void omin10(int node)
{
 if (min10.size() == 5)
 {
 while (!min10.empty())
 {
 int node = min10.top();
 min10.pop();
 que.push(node);
 }
 ohour(node);
 }
 else
 {
 min10.push(node);
 }
}
void ohour(int node)
{
 if (hour.size() == 23)
 {
 while (!hour.empty())
 {
 int node = hour.top();
 hour.pop();
 que.push(node);
 }
 que.push(node);
 }
 else
 {
 hour.push(node);
 }
}

LL gcd(LL a, LL b)
{
 if (b == 0)
 {
 return a;
 }
 else
 {
 return gcd(b, a%b);
 }
}

LL lcm(LL a, LL b)
{
 return a*b / gcd(a, b);
}

int main()
{
 int n;
 while (cin >> n)
 {
 if (n == 0)
 {
 break;
 }
 while (!que.empty())
 {
 que.pop();
 }
 while (!min.empty())
 {
 min.pop();
 }
 while (!hour.empty())
 {
 hour.pop();
 }
 while (!min10.empty())
 {
 min10.pop();
 }
 for (int i = 1; i <= n; i++)
 {
 que.push(i);
 }
 for (int i = 0; i < 1440; i++)
 {
 int node = que.front();
 que.pop();
 omin(node);
 }
 int array[405];
 for (int i = 1; i <= n; i++)
 {
 int node = que.front();
 que.pop();
 array[node] = i;
 }
 LL ans = 1;
 for (int i = 1; i <= n; i++)
 {
 int x = i;
 LL j;
 for (j = 1; ; j++)
 {
 x = array[x];
 if (x == i)
 {
 break;
 }
 }
 ans = lcm(ans, j);
 }
 cout << ans << endl;
 }
 return 0;
}
