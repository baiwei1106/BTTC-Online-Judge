#include<cstdio>
#define LL long long
const int MAX=100000+1;
LL shai[MAX],top;
void init(){
	LL x=3;
	while(top<MAX){
		if(x%3==0||x%5==0){
			top++;
			shai[top]=x;
		}
		x++;
	}
}
int main(){
	init();
	int N;
	while(~scanf("%d",&N)){
		printf("%lld\n",shai[N]);
	}
	return 0;
}
