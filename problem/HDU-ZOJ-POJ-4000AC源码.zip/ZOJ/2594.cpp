#include<iostream>
#include<cstring>
#include<string>
using namespace std;

string a[800];
bool p[160005];
int d[160005],map[160005][5],T,m,n,tmp,tmp1,que[160000],head,tail,now,F;

int main()
{
	ios::sync_with_stdio(false);
	cin >> T ;
	while ( T-- )
	{
		cin >> n >> m ;
		cin.get();
		memset(p,false,sizeof(p));
		memset(d,0,sizeof(d));
		memset(map,0,sizeof(map));
		for ( int i = 2*m-1 ; i >= 1 ; --i )
			getline(cin,a[i]);
		for ( int i = 1 ; i <= m ; ++i )
		{
			for ( int j = 1 ; j <= n ; ++j )
			{
				if ( a[2*i-1][2*j-1] == '-' && j < n ) 
				{
					 tmp = (i-1)*n+j;
					 ++map[tmp][0];
					 tmp1 = map[tmp][0];
					 map[tmp][tmp1] = tmp+1 ;
					 ++map[tmp+1][0];
					 tmp1 = map[tmp+1][0];
					 map[tmp+1][tmp1] = tmp ; 
				}
				if ( a[2*i][2*j-1-1] == '|' && i < m ) 
				{
					tmp = (i-1)*n+j;
					++map[tmp][0];
					tmp1 = map[tmp][0];
					map[tmp][tmp1] = tmp+n ;
					++map[tmp+n][0];
					tmp1 = map[tmp+n][0];
					map[tmp+n][tmp1] = tmp ; 
				}
			}		
		}
 		que[0] = m*n ;
		d[m*n] = 0 ;		
		p[m*n] = true;
		head = 0 ;
		tail = 0 ;
		while ( head <= tail )
		{
			now = que[head];
			for ( int i = 1 ; i <= map[now][0] ; ++i )
			{
				if ( !p[map[now][i]] ) 
				{
					d[map[now][i]] = d[now]+1;
					p[map[now][i]] = true ;
					++tail;
					que[tail] = map[now][i];
					if ( que[tail] == 1 ) break;
				}
			}
			++head;
			if ( que[tail] == 1 ) break;
		}
		now = 1 ;
		if ( d[now+1]+1 == d[now] ) 
		{
			cout << "E" << endl;
			now = now+1;
			F = 2 ;
		}
		else
		{
			cout << "N" << endl;
			now = now+n;
			F = 1;
		}
		for ( int i = 2 ; i <= d[1] ; ++i )
		for ( int k = 1 ; k <= map[now][0] ; ++k )
		{
			if ( d[map[now][k]]+1 == d[now] ) 
			{
				if ( now+1 == map[now][k] ) 	
				{
					if ( F == 1 ) cout << "R" ;
					if ( F == 2 ) cout << "F" ;
					if ( F == 3 ) cout << "L" ;
					F = 2 ;
					now = map[now][k] ;
				}
				else if ( now-1 == map[now][k] )
				{
					if ( F == 1 ) cout << "L" ;
					if ( F == 3 ) cout << "R" ;
					if ( F == 4 ) cout << "F" ;
					F = 4 ;
					now = map[now][k] ;
				}
				else if ( now+n == map[now][k] )
				{
					if ( F == 1 ) cout << "F" ;
					if ( F == 2 ) cout << "L" ;
					if ( F == 4 ) cout << "R" ; 
					F = 1 ;
					now = map[now][k] ;
				}
				else if ( now-n == map[now][k] )
				{
					if ( F == 2 ) cout << "R" ;
					if ( F == 3 ) cout << "F" ;
					if ( F == 4 ) cout << "L" ;
					F = 3 ;
					now = map[now][k] ;
				}
				break;
			}
		}
		cout << endl;
		if ( T ) cout << endl;
	}
	return 0;
}