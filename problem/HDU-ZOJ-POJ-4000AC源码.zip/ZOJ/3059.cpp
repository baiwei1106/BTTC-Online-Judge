/*
 * File:
 * Author: xiaotian @ hnu
 * Created on 2010��11��2��, ����9:26
 * ���⣺
 */

#include<stdio.h>
#include<iostream>
#include<string.h>
#include<map>
#include<math.h>
#include<set>
#include<queue>
#include<vector>
#include<algorithm>
#define N 101
#define inf 0x3ffffff
using namespace std;
int g[N][N][7][7];
int n, m;
char mp[N][N];

struct node {
 int x, y, st;

 node(int xx = 0, int yy = 0, int aa = 0) : x(xx), y(yy), st(aa) {
 }

 bool operator==(const node & r)const {
 return r.x == x && r.y == y && r.st == st;
 }
};
node s, t;
int dx[4] = {0, 1, 0, -1};
int dy[4] = {1, 0, -1, 0};
int trans[4][6] = {5, 6, 3, 4, 2, 1,
 3, 4, 2, 1, 5, 6,
 6, 5, 3, 4, 1, 2,
 4, 3, 1, 2, 5, 6};

inline int ok(int x, int y) {
 return x >= 0 && y >= 0 && x < n && y < m && mp[x][y] != '#';
}

int change(int st,int k) {
 int tmp[6];
 int sta[6];
 for(int i=5;i>=0;st/=10,i--)
 sta[i]=st%10;
 for (int i = 0; i < 6; i++)
 tmp[i] = sta[trans[k][i] - 1];
 int ans=0;
 for(int i=0;i<6;i++)
 ans=ans*10+tmp[i];
 return ans;
}

int bfs() {
 queue<node>q;
 for (int i = 0; i <= n; i++)
 for (int j = 0; j <= m; j++)
 for (int a = 0; a < 7; a++)
 for (int b = 0; b < 7; b++)
 g[i][j][a][b] = inf;
 int a = s.st / 100000, b = (s.st / 100) % 10;
 g[s.x][s.y][a][b] = 0;
 q.push(s);
 while (!q.empty()) {
 node p = q.front();
 q.pop();
 //if(p.x==t.x && p.y==t.y)
 //printf("%d %d %d %d %d\n",p.x,p.y,p.a,p.b,g[p.x][p.y][p.a][p.b]);
 a = p.st / 100000;
 b = (p.st / 100) % 10;
 if (p == t) return g[p.x][p.y][a][b];
 for (int i = 0; i < 4; i++) {
 int x = p.x + dx[i], y = p.y + dy[i];
 if (ok(x, y)) {
 int tmp=change(p.st,i);
 int c = tmp/100000, d = (tmp/100)%10;
 if (g[p.x][p.y][a][b] + 1 < g[x][y][c][d]) {
 g[x][y][c][d] = g[p.x][p.y][a][b] + 1;
 q.push(node(x, y, tmp));
 }
 }
 }
 }
 return -1;
}

int main() {
 //freopen("newfile", "r", stdin);
 while (scanf("%d%d\n", &n, &m) != EOF) {
 for (int i = 0; i < n; i++)
 gets(mp[i]);
 scanf("%d %d %d %d", &s.x, &s.y, &t.x, &t.y);
 s.st = 0;
 int k;
 for (int i = 0; i < 6; s.st = s.st * 10 + k, i++)
 scanf("%d", &k);
 t.st = 0;
 for (int i = 0; i < 6; t.st = t.st * 10 + k, i++)
 scanf("%d", &k);
 printf("%d\n", bfs());
 }
}