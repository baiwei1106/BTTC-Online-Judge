#include<stdio.h>
#include<math.h>
int main(){
	int y,n,i,j;
	while(scanf("%d",&y),y){
		n=(y-1960)/10;
		double t=4.0;
		for(i=1;i<=n;i++)
		t*=2;
		double sum=0;
		i=0;
		while(t>sum){
			i++;
			sum+=log10(i)/log10(2);
		}
		printf("%d\n",i-1);
	}
	return 0;
}
		
			