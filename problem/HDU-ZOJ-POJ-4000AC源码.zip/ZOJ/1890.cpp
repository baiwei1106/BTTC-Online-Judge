#include <stdio.h>
#include <stdlib.h>

int main()
{
	int h;
	int m;
	int s;
	int h1=0;
	int m1=0;
	int s1=0;
	double a=0;
	int speed;
	char c;
	float sum=0;
	while(scanf("%d:%d:%d%c",&h,&m,&s,&c)!=EOF)
	{
		if(c==' ')
		{
			scanf("%d",&speed);
			sum+=((h*3600+m*60+s)-(h1*3600+m1*60+s1))*a/1000;
			a=speed/3.6;
			h1=h;
			m1=m;
			s1=s;
		}
		else
		{
			printf("%02d:%02d:%02d ",h,m,s);
			sum+=((h*3600+m*60+s)-(h1*3600+m1*60+s1))*a/1000;
			printf("%.2f km\n",sum);
			h1=h;
			m1=m;
			s1=s;
		}
	}
	return 0;
}