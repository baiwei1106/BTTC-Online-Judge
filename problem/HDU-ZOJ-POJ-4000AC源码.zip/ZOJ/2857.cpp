#include <iostream>
#include <vector>
#include <cstdio>
using namespace std;
int main()
{
 vector<int> r;
 vector<int> g;
 vector<int> b;
 int n,m;
 int rr,gg,bb;
 int w=0;
 while(cin>>n>>m)
 {
 r.clear();
 g.clear();
 b.clear();
 w++;
 if(n==0&&m==0)
 break;
 for(int i=0; i<n*m; i++)
 {
 cin>>rr;
 r.push_back(rr);
 }
 for(int j=0; j<n*m; j++)
 {
 cin>>gg;
 g.push_back(gg);
 }
 for(int k=0; k<n*m; k++)
 {
 cin>>bb;
 b.push_back(bb);
 }
 printf("Case %d:\n",w);
 for(int p=0; p<n*m; p++)
 {
 printf("%d",(r[p]+g[p]+b[p])/3);
 if((p+1)%m==0)
 cout<<endl;
 else
 cout<<",";
 }
 }
 return 0;
}
