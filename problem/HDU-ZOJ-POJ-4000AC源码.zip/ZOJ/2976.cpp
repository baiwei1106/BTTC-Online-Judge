/*
 * Author: xioumu
 * Created Time: 2013/5/23 17:16:16
 * File Name: i.cpp
 * solve: i.cpp
 */
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
#include<set>
#include<iostream>
#include<vector>
#include<queue>

using namespace std;
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clr(x) memset(x,0,sizeof(x))
#define clrs( x , y ) memset(x,y,sizeof(x))
#define out(x) printf(#x" %d\n", x)
#define sqr(x) ((x) * (x))
typedef long long lint;

const int maxint = -1u>>1;
const double eps = 1e-8;
const int maxn = 100 + 10;

int sgn(const double &x) { return (x > eps) - (x < -eps); }

double xx[maxn], yy[maxn], zz[maxn], ll[maxn];
int n;

double gao(double ox, double oy) {
 double ma = 0;
 rep (i, n) {
 double dis;
 double x, y, z, l;
 x = xx[i] - ox;
 y = yy[i] - oy;
 z = zz[i];
 l = ll[i];
 dis = y * y + x * x + z * z;
 double c = z / sqrt(dis);
 double res = l / (dis) * c;
 //if (sgn(ox) == 0 && sgn(oy) == 0)
 //printf("%d : %f %f %f\n", i, dis, c, res);
 ma += res;
 }
 //printf("%f\n", ma);
 return ma;
}
int main() {
 int T;
 scanf("%d", &T);
 while (T--) {
 scanf("%d", &n);
 double ma = 0;
 rep (i, n)
 scanf("%lf%lf%lf%lf", &xx[i], &yy[i], &zz[i], &ll[i]);
 repf (i, -100, 100)
 repf (j, -100, 100) {
 double tmp = gao(i, j);
 ma = max(tmp, ma);
 }
 printf("%.2f\n", ma);
 }
 return 0;
}
