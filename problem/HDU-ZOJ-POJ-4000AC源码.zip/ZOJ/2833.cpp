#include<stdio.h>
#include<string.h>
int father[100001];
int num[100001];

int find(int x)
{
	if(x==father[x])
		return x;
	x=find(father[x]);
	return x;
}
int main()
{
	int n,m,i,t=1;
	char operation;
	while(scanf("%d%d",&n,&m)!=EOF)
	{ 
		if(t!=1)
			printf("\n");
		printf("Case %d:\n",t++);
		memset(num,-1,sizeof(num));
		int x,y;
		for(i=1;i<=n;i++)
		{
			father[i]=i;
			//num[i]=1;
		}
		for(i=0;i<m;i++)
		{
			scanf("%c",&operation);
			scanf("%c",&operation);
			if(operation=='Q')
			{
				scanf("%d",&x);
				printf("%d\n",-num[find(x)]);
			}
			else
			{
				scanf("%d%d",&x,&y);
				y=find(y);
				x=find(x);
				if(x!=y)
				{
					if(x<y)
					{
					father[x]=y;
					num[y]+=num[x];
					}
					else
					{
					father[y]=x;
					num[x]+=num[y];
					}

				}
			}
		}
	}
	return 0;
}
