#include<stdio.h>
void fun(char c,int &spaceTemp,int &trailings,int &tabTemp,int &tabs);

int main()
{
 int spaceTemp,trailings,tabTemp,tabs;
 int N; scanf("%d",&N);
 getchar();
 char c1,c2,c3;
 while(N--)
 {
 tabTemp=spaceTemp=trailings=tabs=0;
 
 while(1)
 {
 c1=getchar();
 if(c1 != '#')
 {
 while(c1 != '\n')
 {
 fun(c1,spaceTemp,trailings,tabTemp,tabs);
 c1=getchar();
 }
 trailings += (spaceTemp + 4*tabTemp);
 tabs += tabTemp;
 tabTemp=spaceTemp=0;
 }
 
 else 
 {
 c2=getchar();
 if(c2 == '#') 
 {
 c3=getchar();
 if(c3 == '\n')
 break;
 
 else
 {
 while(c3 != '\n')
 {
 fun(c3,spaceTemp,trailings,tabTemp,tabs);
 c3=getchar();
 }
 trailings += (spaceTemp + 4*tabTemp);
 tabs += tabTemp;
 tabTemp=spaceTemp=0;
 }
 } 
 } 
 }
 printf("%d tab(s) replaced\n",tabs);
 printf("%d trailing space(s) removed\n",trailings);
 }
 return 0;
}
//�Զ���ķ�'\n'�ַ����� 
void fun(char c,int &spaceTemp,int &trailings,int &tabTemp,int &tabs)
{
 if(c == ' ')
 ++spaceTemp;
 else if(c == '\t')
 ++tabTemp;
 else
 {
 spaceTemp=0;
 tabs += tabTemp;
 tabTemp=0;
 }
}
