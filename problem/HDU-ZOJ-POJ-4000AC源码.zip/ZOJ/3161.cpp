#include <stdio.h>
#include <cstring>
#include <algorithm>
using namespace std;

int n,m;
bool a[510];
int f[510];

int main()
{
	while(scanf("%d%d",&n,&m)!=EOF)
	{
		memset(a, 0, sizeof(a));
		for (int i=0; i<m;i++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			if (x>y) swap(x,y);
			if (y!=x+1) continue;
			a[x]=1;
		}
		int ans=n;
		for (int i=0; i<n; i++)
		if (a[i])
		{
			int j=i;
			while(j<n&&a[j]) j++;
			ans-=(j-i+1-(j-i+3)/3);
			i=j;
		}
		printf("%d\n",ans);
	}
	return 0;
}