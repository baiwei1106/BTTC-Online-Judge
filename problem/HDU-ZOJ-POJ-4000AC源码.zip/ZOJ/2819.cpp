#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

double a[600], b[600], c[600], a1[60], b1[60], c1[60], x, y, z, t, f[60];
int n, m;

int main()
{
 while(scanf("%d", &n)&&n)
 {
 for(int i= 0;i < n;i++)
 {
 scanf("%lf%lf%lf", &a[i], &b[i], &c[i]);
 }
 scanf("%d", &m);
 for(int i = 0;i < m;i++)
 {
 scanf("%lf%lf%lf%lf", &a1[i], &b1[i], &c1[i], &f[i]);
 }
 int sum = 0;
 for(int i = 0;i < n;i++)
 {
 int tag = 0;
 x = sqrt(a[i]*a[i] + b[i]*b[i] + c[i]*c[i]);
 for(int j = 0;j < m;j++)
 {
 if(!tag)
 {
 y = sqrt(a1[j]*a1[j] + b1[j]*b1[j] + c1[j]*c1[j]);
 z = sqrt((a[i]-a1[j])*(a[i]-a1[j]) + (b[i]-b1[j])*(b[i]-b1[j]) + (c[i]-c1[j])*(c[i]-c1[j]));
 t = (x*x+y*y-z*z)/2/x/y;
 if(f[j]-acos(t) > 1e-9)
 {
 tag = 1;
 sum ++;
 }
 }
 }
 }
 printf("%d\n", sum);
 }
 return 0;
}
