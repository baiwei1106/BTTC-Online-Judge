#include<cstdio>
#include<string>
#define maxsize 2000
using namespace std;
struct hp
{
 int len;
 int s[maxsize+1];
};
void input(hp &a,string str)
{
 int i;
 while(str[0]=='0' && str.size()!=1)
 str.erase(0,1);
 a.len=(int)str.size();
 for(i=1;i<=a.len;++i)
 a.s[i]=str[a.len-i]-48;
 for (i=a.len+1;i<=maxsize;++i)
 a.s[i]=0;
}
void print(const hp &y)
{
 int i;
 for(i=y.len;i>=1;i--)
 printf("%d",y.s[i]);
 printf("\n");
}
void plus1(const hp &a,const hp &b,hp &c) 
{
 int i,len;
 for(i=1;i<=maxsize;i++) c.s[i]=0;
 if(a.len>b.len) len=a.len;
 else len=b.len;
 for(i=1;i<=len;i++)
 {
 c.s[i]+=a.s[i]+b.s[i];
 if(c.s[i]>=10)
 {
 c.s[i]-=10;
 c.s[i+1]++;
 }
 }
 if(c.s[len+1]>0) len++;
 c.len=len;
}
void subtract(const hp &a,const hp &b,hp &c) 
{
 int i,len;
 for(i=1;i<=maxsize;i++) c.s[i]=0;
 if(a.len>b.len) len=a.len;
 else len=b.len;
 for(i=1;i<=len;i++)
 {
 c.s[i]+=a.s[i]-b.s[i];
 if(c.s[i]<0)
 {
 c.s[i]+=10;
 c.s[i+1]--;
 }
 }
 while(len>1&&c.s[len]==0) len--;
 c.len=len;
}
void multiply(const hp &a,int b,hp &c) 
{
 int i,len;
 for(i=1;i<=maxsize;i++) c.s[i]=0;
 len=a.len;
 for(i=1;i<=len;i++)
 {
 c.s[i]+=a.s[i]*b;
 c.s[i+1]+=c.s[i]/10;
 c.s[i]%=10;
 }
 len++;
 while(c.s[len]>=10)
 {
 c.s[len+1]+=c.s[len]/10;
 c.s[len]%=10;
 len++;
 }
 while(len>1&&c.s[len]==0) len--;
 c.len=len;
}
void multiplyh(const hp &a,const hp &b,hp &c) 
{
 int i,j,len;
 for(i=1;i<=maxsize;i++) c.s[i]=0;
 for(i=1;i<=a.len;i++)
 for(j=1;j<=b.len;j++)
 {
 c.s[i+j-1]+=a.s[i]*b.s[j];
 c.s[i+j]+=c.s[i+j-1]/10;
 c.s[i+j-1]%=10;
 }
 len=a.len+b.len+1;
 while(len>1&&c.s[len]==0) len--;
 c.len=len;
}
int main()
{
 int t,i,j,len,max;
 char str[2000];
 hp a,b,c,d;
 string s,sa,sb;
 scanf("%d",&t);
 while(t--)
 {
 scanf("%s",&str);
 s=str;
 len=s.size();
 for(i=0;i<len;i++)
 {
 if(s[i]>'9'||s[i]<'0') break;
 }
 sa=s.substr(0,i);
 sb=s.substr(i+1,len-1-i);
 input(a,sa);
 input(b,sb);
 max=0;
 switch(s[i])
 {
 case '+':
 {
 plus1(a,b,c);
 if(a.len>max) max=a.len;
 if(b.len+1>max) max=b.len+1;
 if(c.len>max) max=c.len;
 for(i=a.len;i<max;i++) printf(" ");
 print(a);
 for(i=b.len+1;i<max;i++) printf(" ");
 printf("+");print(b);
 for(i=(b.len+1>c.len?b.len+1:c.len);i<max;i++) printf(" ");
 for(i=0;i<(b.len+1>c.len?b.len+1:c.len);i++) printf("-");
 printf("\n");
 for(i=c.len;i<max;i++) printf(" ");
 print(c);printf("\n");
 break;
 }
 case '-':
 {
 subtract(a,b,c);
 if(a.len>max) max=a.len;
 if(b.len+1>max) max=b.len+1;
 if(c.len>max) max=c.len;
 for(i=a.len;i<max;i++) printf(" ");
 print(a);
 for(i=b.len+1;i<max;i++) printf(" ");
 printf("-");print(b);
 for(i=(b.len+1>c.len?b.len+1:c.len);i<max;i++) printf(" ");
 for(i=0;i<(b.len+1>c.len?b.len+1:c.len);i++) printf("-");
 printf("\n");
 for(i=c.len;i<max;i++) printf(" ");
 print(c);printf("\n");
 break;
 }
 case '*':
 {
 multiplyh(a,b,c);
 if(a.len>max) max=a.len;
 if(b.len+1>max) max=b.len+1;
 if(c.len>max) max=c.len;
 for(i=a.len;i<max;i++) printf(" ");
 print(a);
 for(i=b.len+1;i<max;i++) printf(" ");
 printf("*");print(b);
 if(b.len==1)
 {
 for(i=(b.len+1>c.len?b.len+1:c.len);i<max;i++) printf(" ");
 for(i=0;i<max;i++) printf("-");
 printf("\n");
 print(c);printf("\n");break;
 }
 else
 {
 multiply(a,b.s[1],d);
 for(i=(d.len>b.len+1?d.len:b.len+1);i<max;i++) printf(" ");
 for(i=0;i<(d.len>b.len+1?d.len:b.len+1);i++) printf("-"); 
 printf("\n"); 
 for(i=1;i<=b.len;i++)
 {
 multiply(a,b.s[i],d);
 for(j=0;j<max-d.len-i+1;j++) printf(" ");
 print(d);
 }
 for(i=(b.len+d.len-1>c.len?b.len+d.len-1:c.len);i<max;i++) printf(" ");
 for(i=0;i<(b.len+d.len-1>c.len?b.len+d.len-1:c.len);i++) printf("-"); 
 printf("\n");
 for(i=c.len;i<max;i++) printf(" ");
 print(c);printf("\n");break; 
 } 
 }
 } 
 } 
 return 0;
} 