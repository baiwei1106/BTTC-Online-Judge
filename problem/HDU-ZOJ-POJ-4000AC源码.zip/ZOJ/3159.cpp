#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;

int n;
double vx,vy,t;

struct str{
 double x,y;
 double x1,y1,x2,y2;
};

str st[10];

double ans;
int a[10];

void dfs()
{
 int i,j;
 double temp = 0;
 double mx1,mx2,my1,my2;
 mx1 = my1 = 1e100;
 mx2 = my2 = -1e100;
 for (i = 0;i < n;i++)
 {
 j = a[i];
 st[j].x1 = st[j].x - temp * vx;
 st[j].y1 = st[j].y - temp * vy;
 st[j].x2 = st[j].x + temp * vx;
 st[j].y2 = st[j].y + temp * vy;
 if (st[j].x2 < mx1)
 mx1 = st[j].x2;
 if (st[j].y2 < my1)
 my1 = st[j].y2;
 if (st[j].x1 > mx2)
 mx2 = st[j].x1;
 if (st[j].y1 > my2)
 my2 = st[j].y1;
 temp += t;
 }
 double t1,t2;
 t1 = (mx2 - mx1) / (vx * 2);
 t2 = (my2 - my1) / (vy * 2);
 mx1 = my1 = 1e100;
 mx2 = my2 = -1e100;
 for (i = 1;i < n;i++)
 {
 j = a[i];
 if (st[j].x2 < mx1)
 mx1 = st[j].x2;
 if (st[j].y2 < my1)
 my1 = st[j].y2;
 if (st[j].x1 > mx2)
 mx2 = st[j].x1;
 if (st[j].y1 > my2)
 my2 = st[j].y1;
 temp += t;
 }
 if (st[a[0]].x >= mx2 && st[a[0]].x <= mx1)
 t1 -= min(st[a[0]].x - mx2, mx1 - st[a[0]].x) / vx;
 if (st[a[0]].y >= my2 && st[a[0]].y <= my1)
 t2 -= min(st[a[0]].y - my2, my1 - st[a[0]].y) / vy;
 temp = max(t1,t2);
 temp += t * (n - 1);
 if (temp < ans)
 ans = temp;
}

int main()
{
 int i,j,k;
 while (scanf("%d%lf%lf%lf", &n, &vx, &vy, &t) != EOF)
 {
 for (i = 0;i < n;i++)
 scanf("%lf%lf", &st[i].x, &st[i].y);
 for (i = 0;i < n;i++)
 a[i] = i;
 ans = 1e100;
 dfs();
 while (next_permutation(a,a + n))
 {
 dfs();
 }
 printf("%.8lf\n", ans);
 }
 return 0;
}
