#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;

struct node
{
 int x,y;
 bool f;
};

const int maxn=2*200005;

node a[maxn];
node ans[maxn];
int n,m;

bool cmp(node a,node b)
{
 if (a.x==b.x && a.y==b.y) return a.f;
 if( a.y == b.y )
 return a.x < b.x;
 return a.y > b.y;
}

bool cmpp(node p,node q)
{
 if (p.x==q.x)
 return p.y<q.y;
 else return p.x<q.x;
}

int main()
{
 int i;
 while (scanf("%d%d",&n,&m)!=EOF)
 {
 for (i=1;i<=n;i++)
 {
 scanf("%d%d",&a[i].x,&a[i].y);
 a[i].f=false;
 }

 for (i=n+1;i<=n+m;i++)
 {
 scanf("%d%d",&a[i].x,&a[i].y);
 a[i].f=true;
 }

 sort(a+1,a+n+m+1,cmp);
 int t=0;
 int Min=1000000005;
 for (i=1;i<=n+m;i++)
 {
 if (a[i].f)
 {
 if (a[i].x<Min)
 Min=a[i].x;
 }
 else
 {
 if (a[i].x < Min)
 {
 t++;
 ans[t].x=a[i].x;
 ans[t].y=a[i].y;
 }
 }
 }
 sort(ans+1,ans+t+1,cmpp);
 printf("%d\n",t);
 for (i=1;i<=t;i++)
 printf("%d %d\n",ans[i].x,ans[i].y);
 }
 return 0;
}
