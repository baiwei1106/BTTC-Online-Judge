#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;

int main()
{
	int t;
	scanf("%d",&t);
	while (t--)
	{
		int n;
		scanf("%d",&n);
		if (n==1) 
		{
			puts("7");
			continue;
		}
		else if (n==2) 
		{
			puts("27");
			continue;
		}
		else if (n>=3 && n<=10) 
		{
			puts("70");
			continue;
		}
		else if (n==11) 
		{
			puts("270");
			continue;
		}
		else if (n>11 && n<=100) 
		{
			puts("700");
			continue;
		}
		else if (n==101) 
		{
			puts("2700");
			continue;
		}
		else if (n>101 && n<=1000) 
		{
			puts("7000");
			continue;
		}
		else if (n==1001 || n==1002) 
		{
			puts("26999");
			continue;
		}
		else if (n>1002 && n<=10000) 
		{
			puts("70000");
			continue;
		}
		else if (n==10001) 
		{
			puts("270000");
			continue;
		}
		else if (n>10001 && n<=100000) 
		{
			puts("700000");
			continue;
		}
		else if (n==100001) 
		{
			puts("1699999");
			continue;
		}
		else if (n>100001 && n<=1000000) 
		{
			puts("7000000");
			continue;
		}
		else if (n==1000001) 
		{
			puts("27000000");
			continue;
		}
		else if (n>1000001 && n<=10000000) 
		{
			puts("70000000");
			continue;
		}
		else if (n==10000001) 
		{
			puts("270000000");
			continue;
		}
		else if (n>10000001 && n<=100000000) 
		{
			puts("700000000");
			continue;
		}
	}
}