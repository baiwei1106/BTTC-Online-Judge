#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

#define N 100
int ct;
int dp[N][N],pa[N][N],p[N];
void print_ans(int i,int j)
{
    if(i==j)
    {
        printf("A%d",i);
        return;
    }
    printf("(");
    print_ans(i,pa[i][j]);
    printf(" x ");
    print_ans(pa[i][j]+1,j);
    printf(")");
}

int main(void)
{
    int cas=1,n,i,j,k;
    while(scanf("%d",&n)&&n)
    {
        memset(dp,0,sizeof(dp));
        memset(pa,0,sizeof(pa));
        for(i=0; i<n; i++)
            scanf("%d%d",&p[i],&p[i+1]);
        for(k=1; k<=n; k++)
            for(i=1; i+k<=n; i++)
            {
                dp[i][i+k]=0x0f0f0f0f;
                for(j=i; j<i+k; j++)
                    if(dp[i][i+k]>dp[i][j]+dp[j+1][i+k]+p[i-1]*p[j]*p[i+k])
                        pa[i][i+k]=j,dp[i][i+k]=dp[i][j]+dp[j+1][i+k]+p[i-1]*p[j]*p[i+k];
            }
        printf("Case %d: ",cas++);
        print_ans(1,n);
        puts("");
    }
    return 0;
}