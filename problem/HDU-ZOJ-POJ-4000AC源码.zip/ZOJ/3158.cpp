#include <iostream>
#include <cmath>
#include <cstdio>

using namespace std;

int n, m, least, firstcut[10], a[10][10], dif;

void dfs(int k)
{
 if(k >= m) {
 int l = 0, r = 0;
 for(int i = 0; i < m; i++) {
 for(int j = 0;j <= firstcut[i]; j++){
 l += a[i][j];
 }
 }
 for(int i = 0; i < m; i++) {
 for(int j = firstcut[i] + 1; j < n; j++) {
 r += a[i][j];
 }
 }
 least = min(least, int(abs(double(l-r))));
 return ;
 }
 for(int i = 0; i <= n - 2; i++) {
 firstcut[k] = i;
 dfs(k + 1);
 }
}

int main()
{
 //freopen("data.in", "rb", stdin);
 while(scanf("%d%d", &m, &n) != EOF) {
 least = 10000000;
 for(int i = 0;i < m; i++) {
 for(int j = 0; j < n; j++) {
 scanf("%d", &a[i][j]);
 }
 }
 scanf("%d", &dif);
 for(int i = 0; i <= n - 2; i++) {
 firstcut[0] = i;
 dfs(1);
 }
 if(dif < least) {
 printf("You'd better buy another one!\n");
 }
 else {
 printf("%d\n",least);
 }
 }
 return 0;
}

