#include<cstdio>
#include<cstring>
#include<iostream>
#include<queue>
using namespace std;

int sx, sy, ex, ey;
int dx[4] = {0,1,0,-1};
int dy[4] = {-1,0,1,0};
struct nod{
	int cnt, dir, x, y;
}u, temp;
int vis[500][500][4];
char er[501][501];
//��0��1��2��3
queue<nod> q;
int n, m;

nod gao(nod a){
	if(a.dir == 0){
		while(a.x > 0 && er[a.x-1][a.y] != '#') a.x --;
	}else if(a.dir == 1){
		while(a.x < n-1 && er[a.x+1][a.y] != '#') a.x ++;
	}else if(a.dir == 2){
		while(a.y > 0 && er[a.x][a.y-1] != '#') a.y --;
	}else if(a.dir == 3){
		while(a.y < m-1 && er[a.x][a.y+1] != '#') a.y ++;
	}
	return a;
}	
//����0����1����2����3
nod solve(nod a, int kind){
	if(kind == 0){
		if(a.dir == 0) a.dir = 3;
		else if(a.dir == 3) a.dir = 1;
		else if(a.dir == 1) a.dir = 2;
		else a.dir = 0;
		return gao(a);
	}else if(kind == 1){
		if(a.dir == 0) a.dir = 2;
		else if(a.dir == 2) a.dir = 1;
		else if(a.dir == 1) a.dir = 3;
		else a.dir = 0;
		return gao(a);
	}else if(kind == 2){
		if(a.dir == 1){
			if(a.y > 0 && er[a.x][a.y-1] != '#') {
				a.y -= 1;
				return gao(a);
			}
		}else if(a.dir == 0){
			if(a.y < m-1 && er[a.x][a.y+1] != '#'){
				a.y += 1;
				return gao(a);
			}
		}else if(a.dir == 2){
			if(a.x > 0 && er[a.x-1][a.y] != '#'){
				a.x -= 1;
				return gao(a);
			}
		}else if(a.dir == 3){
			if(a.x < n-1 && er[a.x+1][a.y] != '#'){
				a.x += 1;
				return gao(a);
			}
		}
	}else {
		if(a.dir == 1){
			if(a.y < m-1 && er[a.x][a.y+1] != '#'){
				a.y += 1;
				return gao(a);
			}
		}else if(a.dir == 0){
			if(a.y > 0 && er[a.x][a.y-1] != '#') {
				a.y -= 1;
				return gao(a);
			}
		}else if(a.dir == 2){
			if(a.x < n-1 && er[a.x+1][a.y] != '#'){
				a.x += 1;
				return gao(a);
			}
		}else if(a.dir == 3){
			if(a.x > 0 && er[a.x-1][a.y] != '#'){
				a.x -= 1;
				return gao(a);
			}
		}
	}
	return a;
}

int bfs(){
	while(!q.empty()) q.pop();
	memset(vis, 0, sizeof(vis));
	temp.x = sx;
	temp.y = sy;
	temp.cnt = 0;
	temp.dir = 1;
	temp = gao(temp);
	vis[temp.x][temp.y][temp.dir] = 1;
	q.push(temp);
	while(!q.empty()){
		u = q.front();
		q.pop();
		if(er[u.x][u.y] == 'E') return u.cnt;
		u.cnt ++;
		for(int i = 0; i < 4; i ++){
			temp = solve(u, i);
			if(vis[temp.x][temp.y][temp.dir]) continue;
		//	printf("temp.x = %d, temp.y = %d, temp.cnt = %d, temp.dir = %d\n", temp.x, temp.y, temp.cnt, temp.dir);
			vis[temp.x][temp.y][temp.dir] = 1;
			q.push(temp);
		}
	//	cout << endl;
	}
	return -1;
}	

int main(){
	while(scanf("%d%d", &n, &m) != EOF){
		int i, j;
		getchar();
		for(i = 0; i < n; i ++){
			gets(er[i]);
			for(j = 0; j < m; j ++){
				if(er[i][j] == '|'){
					sx = i;
					sy = j;
				}if(er[i][j] == 'E'){
					ex = i;
					ey = j;
				}
			}
		}
		int k = bfs();
		if(k != -1)
		printf("%d\n", k);
		else printf("Can not escape!\n");
	}
	return 0;
}	