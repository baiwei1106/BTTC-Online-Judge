#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<math.h>
using namespace std;

double h,H,D;
double f(double x)
{
 return h*(D+x)/H-x+(H*x)/(D+x);
}
double BS()
{
 double l=0,r=D*h/(H-h),mid1,mid2;
 int tim=60;

 while(tim--)
 {
	mid1=l+(r-l)/3;
	mid2=r-(r-l)/3;

	if(f(mid1)>f(mid2))
	 r=mid2;
	else
	 l=mid1;
 }
 return f(l);
}
int main()
{
 int t;
 scanf("%d",&t);
 while(t--)
 {
	scanf("%lf%lf%lf",&H,&h,&D);
	double ans=D*h/H;
	double tt=BS();
	ans=max(ans,tt);
	printf("%.3lf\n",ans);
 }
}