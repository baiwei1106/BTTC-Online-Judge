#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
struct win{
	int x1,y1,x2,y2;
}cnt[11];
bool isin(int x,int y,win a){
	if(x>=a.x1&&x<=a.x2&&y>=a.y1&&y<=a.y2)
		return true;
	return false;
}
int main(){
	int i,a,b,c,d,x,y;
	for(int n,m;cin>>n&&n;){
		for(i=0;i<n;i++){
			cin>>a>>b>>c>>d;
			if(a>c) swap(a,c);
			if(b>d) swap(b,d);
			cnt[i].x1=a;cnt[i].y1=b;cnt[i].x2=c;cnt[i].y2=d;
		}
		cin>>m;
		for(;m;m--){
			cin>>x>>y;
			bool flag=false;
			for(i=n-1;i>=0&&!flag;i--){
				if(isin(x,y,cnt[i])){
					cout<<i<<endl;
					flag=true;
				}
			}
			if(!flag) cout<<-1<<endl;
		}
	}
}