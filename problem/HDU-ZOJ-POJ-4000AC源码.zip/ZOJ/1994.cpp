#include<iostream>
using namespace std;
#include<cstdio>
#include<cstdlib>
#include<cstring>

const int inf=0x7fffffff;
namespace Dinic{
	const int maxn=250*250*10,maxm=250*250*10;
	int s,t,stop,maxflow;
	int head[maxn],head2[maxn],next[maxm*2],to[maxm*2],f[maxm*2],op=1;
	int way[maxn],dis[maxn],que[maxn];
	
	void init(){
		op=1;stop=0;
		memset(head,0,sizeof(head));
		}
	void build(int a,int b,int c,int&no){
		next[++op]=head[a];head[a]=op;to[op]=b;f[op]=c;
		next[++op]=head[b];head[b]=op;to[op]=a;f[op]=0;
		no=op;
		}
	bool bfs(){
		int start,tail;
		que[start=tail=0]=t;
		memset(dis,0,sizeof(dis));
		dis[t]=inf;
		while(start<=tail){
			int p=que[start++];
			for(int pos=head[p];pos;pos=next[pos])
				if(f[pos^1] && !dis[to[pos]]){
					dis[to[pos]]=dis[p]-1;
					que[++tail]=to[pos];
					}
			}
		memcpy(head2,head,sizeof(head));
		return dis[s];
		}
	bool find(int s,int top){
		if(s==t){
			int minflow=inf;
			for(int pos=1;pos<top;pos++)
				if(f[way[pos]]<minflow){
					minflow=f[way[pos]];
					stop=pos;
					}
			maxflow+=minflow;
			for(int pos=1;pos<top;pos++){
				f[way[pos]]-=minflow;
				f[way[pos]^1]+=minflow;
				}
			return 1;
			}
		for(int&pos=head2[s];pos;pos=next[pos])
			if(f[pos] && dis[to[pos]]==dis[s]+1){
				way[top]=pos;
				if(find(to[pos],top+1) && top!=stop)return 1;
				}
		return 0;
		}
	int findmaxflow(){
		maxflow=0;
		while(bfs())find(s,1);
		return maxflow;
		}
	}
const int maxn=250,maxm=30;
int n,m,low[maxn][maxm],top[maxn][maxm],sum1[maxn],sum2[maxm],op,kase;
int ans[maxn][maxm],no[maxn][maxm][2],s,t,ss,tt;
int to[Dinic::maxn],sum,tem;

void init(){
	Dinic::init();
	memset(to,0,sizeof(to));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			low[i][j]=0;
			top[i][j]=inf;
			}
	for(int i=1;i<=n;i++)
		scanf("%d",&sum1[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&sum2[i]);
	
	scanf("%d",&kase);
	int x1,y1,x2,y2,x;
	char c;
	while(kase--){
		scanf("%d%d%s%d",&x1,&y1,&c,&x);
		//printf("%d %d %c %d\n",x1,y1,c,x);
		if(x1)x2=x1;
		 else{
			x1=1;x2=n;
			}
		if(y1)y2=y1;
		 else{
			y1=1;y2=m;
			}
		for(int i=x1;i<=x2;i++)
			for(int j=y1;j<=y2;j++){
				switch(c){
					case '>':low[i][j]=max(low[i][j],x+1);break;
					case '<':top[i][j]=min(top[i][j],x-1);break;
					case '=':low[i][j]=max(low[i][j],x),top[i][j]=min(top[i][j],x);break;
					}
				}
		}
	}
void solve(){
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(low[i][j]>top[i][j]){
			printf("IMPOSSIBLE\n");
			return;
			}
	
	op=sum=0;
	s=++op;t=++op;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			for(int k=0;k<2;k++)
				no[i][j][k]=++op;
	for(int i=1;i<=n;i++)
		no[i][0][0]=++op;
	for(int j=1;j<=m;j++)
		no[0][j][0]=++op;
	ss=++op;tt=++op;
	
	for(int i=1;i<=n;i++){
		to[s]-=sum1[i];
		to[no[i][0][0]]+=sum1[i];
		}
	for(int j=1;j<=m;j++){
		to[t]+=sum2[j];
		to[no[0][j][0]]-=sum2[j];
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			to[no[i][j][1]]+=low[i][j];
			to[no[i][j][0]]-=low[i][j];
			Dinic::build(no[i][j][0],no[i][j][1],top[i][j]-low[i][j],ans[i][j]);
			}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			Dinic::build(no[i][0][0],no[i][j][0],inf,tem);
			Dinic::build(no[i][j][1],no[0][j][0],inf,tem);
			}
	Dinic::build(t,s,inf,tem);
	
	for(int i=1;i<ss;i++)
		if(to[i]!=0){
			if(to[i]>0)sum+=to[i];
			if(to[i]>0)Dinic::build(ss,i,to[i],tem);
			 else Dinic::build(i,tt,-to[i],tem);
			}
	//cout<<op<<endl;
	Dinic::s=ss;Dinic::t=tt;
	int x=Dinic::findmaxflow();
	//cout<<x<<' '<<sum<<endl;
	if(x!=sum){
		printf("IMPOSSIBLE\n");
		return;
		}else{
		for(int i=1;i<=n;i++){
			for(int j=1;j<m;j++)
				printf("%d ",low[i][j]+Dinic::f[ans[i][j]]);
			printf("%d\n",low[i][m]+Dinic::f[ans[i][m]]);
			}
		}
	}

int main()
{
 
 int T;
 scanf("%d",&T);
 bool first=1;
 
 while(T--){
	if(first)first=0;
	 else printf("\n");
 	init();
 	solve();
 	}
 
 return 0;
}
