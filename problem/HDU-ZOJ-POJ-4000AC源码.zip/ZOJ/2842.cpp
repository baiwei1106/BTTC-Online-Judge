#include<cstdio>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<string>
using namespace std;
char a[27];
int main()
{
	int n,i,j,k,q,t1,t2,s[100],sum[100];
	char b[26];
	while(scanf("%d",&n),n){t1=0;
	 memset(sum,0,sizeof(sum));	
	 getchar();
 for(i=0;i<n;i++)
	 { scanf("%c",&a[i]);//printf("%c\n",a[i]);
 }
 for(i=0;i<26;i++)
 { b[i]='A'+i;//printf("%c\n",b[i]);
 }
 for(i=0;i<n;i++)
 { q=0; t2=0; memset(s,0,sizeof(s)); s[0]=1;
 for(j=0;j<26;j++){//printf("%d q=%d\n%c %c\n",a[i]-65,q,a[i],b[j]);
 if(b[j]==a[i])break;
 if(b[j]>=65&&b[j]<=90)
 q++;
 }
 for(k=i+1;k<n;k++)
 {
 for(int u=0;u<=t2;u++)
 s[u]=s[u]*(26-k);
 for(int u=0;u<=t2;u++)
 {
 if(s[u]>=10000){if(u+1>t2)t2=u+1;s[u+1]=s[u+1]+s[u]/10000;s[u]-=(s[u]/10000)*10000;}
 }
 }
 for(int v=0;v<=t2;v++)
 {
 sum[v]+=s[v]*q;
 }
 for(int v=0;v<=t2;v++)
 { //printf("V= %d %d\n",v,sum[v]);
 if(sum[v]>=10000){if(v+1>t2)t2=v+1;sum[v+1]+=sum[v]/10000;sum[v]-=(sum[v]/10000)*10000;if(v+1>t1)t1=v+1;}
 //printf("%d %d\n",s[v],sum[v]);
 }

 b[a[i]-65]='#';
 }//printf("t1=%d\n",t1);
 printf("%d",sum[t1]);
 for(int y=t1-1;y>=0;y--)
 {
 printf("%d%d%d%d",sum[y]/1000,sum[y]%1000/100,sum[y]%100/10,sum[y]%10);
 }
 printf("\n");
 }
}
 /*3
SDE
26
ABCDEFGHIJKLMNOPQRSTUVWXYZ
26
ZYXWVUTSRQPONMLKJIHGFEDCBA
*/
