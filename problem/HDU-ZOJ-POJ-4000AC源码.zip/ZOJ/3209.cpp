#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cassert>
#include <iostream>
#include <sstream>
#include <fstream>
#include <map>
#include <set>
#include <vector>
#include <queue>
#include <algorithm>
#include <iomanip>
using namespace std;
#define max(x,y) ((x)>(y)?(x):(y))
#define min(x,y) ((x)<(y)?(x):(y))
#define abs(x) ((x)>=0?(x):-(x))
#define i64 long long
#define u32 unsigned int
#define u64 unsigned long long
#define clr(x,y) memset(x,y,sizeof(x))
#define PI acos(-1.0)
#define sqr(x) ((x)*(x))
#define inf 0x3f3f3f3f
#define maxnode 50005
#define maxn 5005
struct DLX
{
 int n , sz; // �������ڵ�����
 int S[maxn]; // ���нڵ�����
 int row[maxnode],col[maxnode]; // ���ڵ����б��
 int L[maxnode],R[maxnode],U[maxnode],D[maxnode]; // ʮ������

 int ansd,ans[maxn]; // ��

 void init(int n )
 {
 this->n = n ;
 for(int i = 0 ; i <= n; i++ )
 {
 U[i] = i ;
 D[i] = i ;
 L[i] = i - 1;
 R[i] = i + 1;
 }
 R[n] = 0 ;
 L[0] = n;
 sz = n + 1 ;
 memset(S,0,sizeof(S));
 }
 void addRow(int r,vector<int> c1)
 {
 int first = sz;
 for(int i = 0 ; i < c1.size(); i++ ){
 int c = c1[i];
 L[sz] = sz - 1 ; R[sz] = sz + 1 ; D[sz] = c ; U[sz] = U[c];
 D[U[c]] = sz; U[c] = sz;
 row[sz] = r; col[sz] = c;
 S[c] ++ ; sz ++ ;
 }
 R[sz - 1] = first ; L[first] = sz - 1;
 }
 // ˳������A��������s�������Ԫ��
 #define FOR(i,A,s) for(int i = A[s]; i != s ; i = A[i])

 void remove(int c){
 L[R[c]] = L[c];
 R[L[c]] = R[c];
 FOR(i,D,c)
 FOR(j,R,i) {U[D[j]] = U[j];D[U[j]] = D[j];--S[col[j]];}
 }
 void restore(int c){
 FOR(i,U,c)
 FOR(j,L,i) {++S[col[j]];U[D[j]] = j;D[U[j]] = j; }
 L[R[c]] = c;
 R[L[c]] = c;
 }
 bool fla;
 void dfs(int d){
 if(R[0] == 0 ){
 fla = true ;
 ansd = min(ansd , d);
 return ;
 }
 // ��S��С����c
 int c = R[0] ;
 FOR(i,R,0) if(S[i] < S[c]) c = i;

 remove(c);
 FOR(i,D,c){
 // ans[d] = row[i];
 FOR(j,R,i) remove(col[j]);
 dfs(d + 1);
 FOR(j,L,i) restore(col[j]);
 }
 restore(c);

 }
 bool solve()
 {
 fla = false;
 dfs(0);
 if(fla == false) return false;
 else return true;
 }
};

DLX solver;
int n,m;
int encode(int x,int y)
{
 int res ;
 res = ( x - 1 ) * m + y ;
 return res;
}
int main()
{
 int cas;
 scanf("%d",&cas);
 int p;
 int x1,x2,y1,y2;
 vector<int> c1;
 while(cas -- )
 {
 scanf("%d%d%d",&n,&m,&p);
 solver.init(n * m);
 for(int i = 1 ; i <= p ; i++ )
 {
 scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
 c1.clear();
 for(int x = x1 + 1 ; x<= x2; x ++ )
 {
 for(int y = y1 + 1 ;y <= y2; y ++ )
 {
 //printf("%d %d %d\n",x,y,encode(x,y));
 c1.push_back(encode(x,y));
 }
 }
 solver.addRow(i,c1);
 }
 solver.ansd = inf ;
 bool fff = solver.solve();
 if(fff)
 printf("%d\n",solver.ansd);
 else printf("-1\n");
 }
	return 0;
}
