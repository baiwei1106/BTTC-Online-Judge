#pragma warning(disable:4786)
#include<stdio.h>
#include<string.h>
#include<string>
#include<map>
#include <set>
#include<ctype.h>
#include<algorithm>
#include<map>
#include<stack>
#include<queue>
#include<iostream>
using namespace std;
#include <math.h>


int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,m;
		scanf("%d%d",&n,&m);
		stack<int> h[3];
	//	a = n,b = 0,c = 0;
		int i;int x,y;
		for(i=n;i>=1;i--)
		{
			h[0].push(i);
		}
		int ans = 0;
		for(i=1;i<=m;i++)
		{
			scanf("%d%d",&x,&y);
		/*
				if(x==y)
						{
							ans = -1*i;
							break;
						}*/
			
			x--,y--;
			if(h[x].empty())
			{
				ans = -1*i;
				break;
			}
			int tmp1 = h[x].top();
			h[x].pop();
			if(!h[y].empty())
			{
				int tmp2 = h[y].top();
				if(tmp1>tmp2)
				{
					ans = -1*i;
					break;
				}
				h[y].push(tmp1);
				if(h[y].size()==n&&y==2)
				{
					ans = i;
					break;
				}
			}
			else
			{
				h[y].push(tmp1);
				if(h[y].size()==n&&y==2)
				{
					ans = i;
					break;
				}
			}
		}
		i++;
		for(;i<=m;i++)
		{
			scanf("%d%d",&x,&y);
		}
		printf("%d\n",ans);
	}
	return 0;
}