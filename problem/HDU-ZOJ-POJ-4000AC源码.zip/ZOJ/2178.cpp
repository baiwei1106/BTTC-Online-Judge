
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<iostream>
using namespace std;
int n;
int d[20010];
int arr[20010];
int finder(int u)
{
 if(arr[u]!=u)
	 {
		 int num=finder(arr[u]);
		 d[u]+=d[arr[u]];
		 return arr[u]=num;
	 }
	 else
		 return u;
}
int main()
{
	int T;
	scanf("%d",&T);
	int u,v;
	while(T--)
	{
 scanf("%d",&n);
		getchar();
		for(int i=1;i<=n;i++) 
		{
			arr[i]=i;
			d[i]=0;
		}
		char str;
		while(scanf("%c",&str)!=EOF)
		{
		 if(str=='O') break;
		 if(str=='E')
		 {
		 scanf("%d",&u); finder(u); printf("%d\n",d[u]);
		 getchar();
		 }
		 else
		 {
		 scanf("%d%d",&u,&v);
			 arr[u]=v;//��ʼ�϶�arr[u]=u;
			 d[u]=abs(u-v)%1000;
		 getchar();
		 }
		}
	}
 return 0;
}