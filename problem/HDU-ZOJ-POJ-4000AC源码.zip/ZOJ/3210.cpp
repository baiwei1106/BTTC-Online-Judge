#include<cstdio>
#define maxn 1<<7
bool Stack(int *p,int *q,int n)
{
 for(int i=0,j=n-1; i<n; i++,j--)
 {
 if(p[i]!=q[j]) return 0;
 }
 return 1;
}
bool Queue(int *p,int *q,int n)
{
 for(int i=0; i<n; i++)
 {
 if(p[i]!=q[i]) return 0;
 }
 return 1;
}
int main()
{
 for(int N; scanf("%d",&N)==1;)
 {
 while(N--)
 {
 int n,p[maxn],q[maxn];
 scanf("%d",&n);
 for(int i=0; i<n; i++) scanf("%d",&p[i]);
 for(int i=0; i<n; i++) scanf("%d",&q[i]);
 bool S=Stack(p,q,n),Q=Queue(p,q,n);
 if(S&&!Q) printf("stack\n");
 else if(!S&&Q) printf("queue\n");
 else if(S&&Q) printf("both\n");
 else printf("neither\n");
 }
 }
 return 0;
}