#include<cstdio>
#include<queue>
#include<iostream>
using namespace std;

struct node
{
 int Q_num,Period,time;//time��ϵͳ���е��ĵ�ǰʱ��
 bool operator<(const node a)const{
	 return a.time<time||(a.time==time&&a.Q_num<Q_num);
 }
};

priority_queue<node>a;
int main()
{
 char str[30];
	while(scanf("%s",str)&&str[0]!='#')
	{
	 node b;
		 cin>>b.Q_num>>b.Period;
		 b.time=b.Period;
		 a.push(b);
	}
	int k;
	cin>>k;
	while(k--)
	{
		node c=a.top();
		a.pop();
		cout<<c.Q_num<<endl;
		c.time+=c.Period;
		a.push(c);
	}
 return 0;
}