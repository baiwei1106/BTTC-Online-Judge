#include <cstdio>
#include <algorithm>

using namespace std;

int aa[110];
int bb[3000];
const int INF = 1 << 30;

int main()
{
 int cn, cns;

 //freopen("input.txt", "r", stdin);

 scanf("%d", &cns);
 for (cn = 0; cn < cns; cn++) {
 int n, m;
 scanf("%d%d", &n, &m);
 int ans = 0;
 for (int i = 0; i < n; i++) {
 int cc = 0;
 for (int j = 0; j < m; j++) {
 scanf("%d", &aa[j]);
 if (aa[j] != -1) {
 cc++;
 bb[aa[j]] = j;
 } else {
 aa[j] = INF;
 }
 }
 sort(aa, aa + m);
 int base = 0;
 for (int j = 0; j < m; j++) {
 if (aa[j] == INF) {
 break;
 }
 int posi = (bb[aa[j]] + base) % m;
 if (posi < m - posi) {
 ans += posi * 5;
 base = (base - posi + m) % m;
 } else {
 ans += (m - posi) * 5;
 base = (base + m - posi) % m;
 }
 }
 ans = ans + cc * i * 20;
 }
 printf("%d\n", ans);
 }
 return 0;
}
