#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;

long long int n,a[1010],ans=-1,tot;

int main()
{
	int i,j,k,tmp;
	while (cin>>n)
	{
		ans=-1;
		for (i=1; i<=n; i++)
		 cin>>a[i];
		sort(a+1,a+n+1);
		for (i=1; i<=n; i++)
		{
			for (j=i+1; j<=n; j++)
			{
				tot=2;
				tmp=a[j]-a[i]+a[j];
				for (k=j+1; k<=n; k++)
				{
					if (a[k]>tmp) break;
					if (a[k]==tmp)
					{
						tot++;
						tmp=a[k]+a[j]-a[i];
					}
				}
				ans=max(ans,tot);
			}
		}
		cout<<ans<<endl;
	}
	//system ("pause");
	return 0;	
}