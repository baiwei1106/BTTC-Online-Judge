#include <cstdio>
#include <cstring>
using namespace std;
#define MAXN 51
int SG[MAXN];
bool vis[MAXN];
void Init()
{
 for(int i=2;i<MAXN;++i){
 memset(vis,0,sizeof(vis));
 for(int j=1;j<i;++j)
 vis[SG[j-1]^SG[i-j-1]]=true;
 for(int j=0;j<MAXN;++j)
 if(!vis[j]){
 SG[i]=j; break;
 }
 }
}
void Solve()
{
 int a,i,n,res;
 while(scanf("%d",&n)!=EOF){
 for(res=0,i=1;i<=n;++i){
 scanf("%d",&a);
 res^=SG[a];
 }
 printf("%s\n",res?"Yes":"No");
 }
}
int main()
{
 Init();
 Solve();
 return 0;
}
