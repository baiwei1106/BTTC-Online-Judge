#include<iostream>
#include<cstring>
#include<cstdio>
#include<map>
#include<stdlib.h>
using namespace std;
map<string,int> fx;
struct node
{
	char name[30];
	int youxiandu;
	node *next;
} *h;
void tianjia(char e[30],int youxian)
{
	node *p,*q;
	p=(node*)malloc(sizeof(node));
	q=h;
	while(q->next!=NULL&&q->next->youxiandu>youxian)
	q=q->next;
	p->next=q->next;
	strcpy(p->name,e);
	p->youxiandu=youxian;
	q->next=p;
}
void shanchu(char e[30])
{
	node *p,*q;
	p=q=h;
	while(strcmp(e,q->name)!=0)
	{
		p=q;
		q=q->next;
	}
	p->next=q->next;
	free(q);
}
void quchu()
{
	node *p;
	if(h->next==NULL)
	printf("<empty>\n");
	else
	{
		p=h->next;
		h->next=p->next;
		printf("%s\n",p->name);
		free(p);
	}
}
int main ()
{
	char ss[30],pp;
	int n,m,i,j,a,b,p,q,s,f,N,K;
	scanf("%d",&N);
	for(K=0;K<N;K++)
	{	h=(node *)malloc(sizeof(node));
		h->next=NULL;
		scanf("%d%*c",&n);
		for(i=0;i<n;i++)
			{scanf("%s%d%*c",ss,&p);fx[ss]=p;}
		scanf("%d%*c",&m);
		for(int S=0;S<m;S++)
		{
			scanf("%c%*c",&pp);
			if(pp=='a')
			{
				scanf("%s%*c",ss);
				tianjia(ss,fx[ss]);
			}
			if(pp=='g')
			{
				quchu();
			}
			if(pp=='d')
			{
				scanf("%s%*c",ss);
				shanchu(ss);
			}
		}
	}
}