#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;

const double eps = 1e-8;

inline int sgn(double a){ return (a > eps) - (a < -eps); }

struct point {
 double x, y;
 point(double _x = 0, double _y = 0): x(_x), y(_y) {
 }
 void input() {
 scanf("%lf%lf", &x, &y);
 }
 double len() const {
 return sqrt(x * x + y * y);
 }
 point trunc(double l) const {
 double r = l / len();
 return point(x * r, y * r);
 }
 point rotate_left() const {
 return point(-y, x);
 }
 point rotate_right() const {
 return point(y, -x);
 }
}p[100000];

point operator+(const point& p1, const point& p2) {
 return point(p1.x + p2.x, p1.y + p2.y);
}

point operator-(const point& p1, const point& p2) {
 return point(p1.x - p2.x, p1.y - p2.y);
}

double operator^(const point& p1, const point& p2) {
 return p1.x * p2.x + p1.y * p2.y;
}

double operator*(const point& p1, const point& p2) {
 return p1.x * p2.y - p1.y * p2.x;
}

struct circle {
 point c;
 double r;
 circle() {
 }
 circle(const point& _c, double _r): c(_c), r(_r) {
 }
 void input() {
 c.input();
 scanf("%lf", &r);
 }
}cir[105],c[105];
double dist(point a,point b)
{
 return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
bool get_intersection(const circle& cir1, const circle& cir2, point& c1, point& c2) {
 double d = (cir1.c - cir2.c).len();
 if (sgn(d - (cir1.r + cir2.r)) > 0 || sgn(d - fabs(cir1.r - cir2.r)) < 0)
 return false;
 double p = (d + cir1.r + cir2.r) / 2.0;
 double h = sqrt(fabs(p * (p - d) * (p - cir1.r) * (p - cir2.r))) * 2.0 / d;
 point pp = cir1.c + (cir2.c - cir1.c).trunc(sqrt(fabs(cir1.r * cir1.r - h * h)));
 c1 = pp + (cir2.c - cir1.c).rotate_right().trunc(h);
 c2 = pp - (cir2.c - cir1.c).rotate_right().trunc(h);
 return true;
}
int main()
{
 int n,s,i,j;
 double r;
 while(scanf("%lf %d",&r,&n)!=EOF)
 {
 for(i=1;i<=n;i++)
 scanf("%lf %lf %lf",&cir[i].c.x,&cir[i].c.y,&cir[i].r);
 int t=0,ret=0;
 for(i=1;i<=n;i++)
 {
 if(sgn(cir[i].r-r)>0)continue;
 c[t].c.x=cir[i].c.x;
 c[t].c.y=cir[i].c.y;
 c[t].r=r-cir[i].r;
 p[t]=c[t].c;
 t++;
 }
 point a,b;
 ret=s=t;
 for(i=0;i<s;i++)
 for(j=i+1;j<s;j++)
 {
 bool k=get_intersection(c[i],c[j],a,b);
 if(k)
 { 
 p[ret++]=a;
 p[ret++]=b;
 }
 } 
 int ans=0,m;
 for(i=0;i<ret;i++)
 {
 m=0;
 for(j=0;j<s;j++)
 {
 if(sgn(dist(p[i],c[j].c)-(c[j].r))<=0)
 m++;
 }
 if(m>ans)ans=m;
 }
 printf("%d\n",ans);
 }
 return 0;
}



