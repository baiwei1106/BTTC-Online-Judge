/*
 * Author: Eyelids
 * Created Time: 2013/7/30 13:12:50
 * File Name: e.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )
int n, m, a0, a1, now, I0, I1;
lint f[2][1 << 9][1 << 9];

bool Have(int sta, int i) {
 return (sta & (1 << i)) != 0 ? 1 : 0; 
}
int Add(int sta, int i) {
 return sta | (1 << i);
}

void Dfs(int cur0, int cur1, int i, int nxt, lint val) { 
 //cout <<i<<" "<<cur0<<" "<<cur1<<" "<<nxt<<" "<<val<<endl;
 if (i == m) {
 a0 = cur1;
 a1 = nxt;
 
 f[I1][a0][a1] += val;
 return; 
 }
 
 if (Have(cur0, i)) {
 Dfs(cur0, cur1, i + 1, nxt, val);
 return;
 }
 
 if (Have(cur0, i) == 0)
 Dfs(cur0, Add(cur1, i), i + 1, Add(nxt, i), val);
 
 if (i + 2 < m)
 if (Have(cur0, i) == 0 && Have(cur0, i + 1) == 0 && Have(cur0, i + 2) == 0) 
 Dfs(cur0, cur1, i + 3, nxt, val);
 
}

int main() {
 while (scanf("%d%d", &m, &n) == 2) {
 if (n == 0 && m == 0) break;
 memset(f, 0, sizeof(f));
 f[0][0][0] = 1;
 
 
 for (int i = 0; i < n; i ++) {
 I0 = i % 2;
 I1 = (i + 1) % 2;
 
 for (int sta0 = 0; sta0 < (1 << m); sta0 ++)
 for (int sta1 = 0; sta1 < (1 << m); sta1 ++) {
 if (f[I0][sta0][sta1] == 0) continue;
 
 //cout <<i<<" "<<sta0<<" "<<sta1<<" "<<f[i][sta0][sta1]<<endl;
 Dfs(sta0, sta1, 0, 0, f[I0][sta0][sta1]);
 
 f[I0][sta0][sta1] = 0;
 } 
 } 
 
 printf("%lld\n", f[n % 2][0][0]);
 }
 
 return 0;
}






















