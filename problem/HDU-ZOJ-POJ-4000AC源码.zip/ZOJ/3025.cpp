#include <cstdio>
#include <cstring>

using namespace std;

char str[110];
char sta[110];
int top;
int stanum[110];
int stop;
int num[128];
int res1[3][3] = {
 0, 0, 0,
 0, 1, 1,
 0, 1, 2.
};
int res2[3][3] = {
 0, 1, 2,
 1, 1, 2,
 2, 2, 2,
};
int res[3] = {2, 1, 0};

bool solve(int p, int q, int r)
{
 num['P'] = p;
 num['Q'] = q;
 num['R'] = r;
 int len = strlen(str);
 top = 0;
 stop = 0;
 for (int i = 0; i < len; ) {
 if ((str[i] >= '0' && str[i] <= '9')
 || (str[i] >= 'A' && str[i] <= 'Z')) {
 if (str[i] >= '0' && str[i] <= '9') {
 stanum[stop++] = str[i] - '0';
 } else {
 stanum[stop++] = num[str[i]];
 }
 while (top > 0 && sta[top - 1] == '-') {
 stanum[stop - 1] = res[stanum[stop - 1]];
 top--;
 }
 i++;
 } else {
 if (str[i] == ')') {
 char opt = sta[top - 1];
 int ans;
 int b = stanum[--stop];
 int a = stanum[--stop];
 if (opt == '*') {
 ans = res1[a][b];
 } else {
 ans = res2[a][b];
 }
 stanum[stop++] = ans;
 top -= 2;
 while (top > 0 && sta[top - 1] == '-') {
 stanum[stop - 1] = res[stanum[stop - 1]];
 top--;
 }

 } else {
 sta[top++] = str[i];
 }
 i++;
 }
 }
 return stanum[0] == 2;
}

int main()
{
 //freopen("input.txt", "r", stdin);
 while (scanf("%s", str) == 1) {
 if (str[0] == '.')
 break;
 int p, q, r;
 int cc = 0;
 for (p = 0; p <= 2; p++) {
 for (q = 0; q <= 2; q++) {
 for (r = 0; r <= 2; r++) {
 if (solve(p, q, r))
 cc++;
 }
 }
 }
 printf("%d\n", cc);
 }
 return 0;
}
