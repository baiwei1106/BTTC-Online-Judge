#include <stdio.h>
#include <math.h>
int n;

void solve()
{
	double ans=0;
	if (n<=100)
		for(int i=1;i<=n;i++) ans+=1.0/i;
	else 
		ans=log(n)+0.57721566490153286060+1.0/2/n-1.0/12/n/n+1.0/120/n/n/n/n;
	printf("%.8f\n",ans);
}

int main()
{
	while(scanf("%d",&n)!=EOF)
	{
		solve();
	}
}