#include <cstdio>
#include <cstring>
int maze[12][12];
bool tab[12][12];
int n,m;
typedef struct
{
 int x,y;
}point;
typedef struct
{
 int front;
	int rear;
	point data[100];
}queue;
queue q;
void enque(int x,int y)
{
	point e;
	e.x=x,e.y=y;
 q.data[q.rear++]=e;
	tab[x][y]=false;
}
int deque()
{
 return q.front++;
}
int fun(int x,int y)
{ 
		if(x+1<n&&tab[x+1][y])
		{ 
		 if(maze[x][y]+maze[x+1][y])
		 enque(x+1,y);
		 else return 0;
		}
	 if(y+1<m&&tab[x][y+1])
		{ 
		 if(maze[x][y]+maze[x][y+1])
		 enque(x,y+1);
		 else return 0;
		}return 1;
}
int main()
{
 int i,j,anw,flag,pre;
	 while(scanf("%d%d",&n,&m)!=EOF&&(m||n))
	 {
		anw=0;
		for(i=0;i<n;i++)
		 for(j=0;j<m;j++)
		 {
			 scanf("%d",&maze[i][j]);
			 anw+=maze[i][j];
		 }
	 if(anw==n*m)
		{
		 printf("No\n");
			 continue;
		}
	 q.front=q.rear=0;
	 memset(tab,true,sizeof(tab));
	 tab[0][0]=false;
	 enque(0,0);
		flag=0;
 while(q.rear!=q.front)
		{
	 pre=deque();
			if(fun(q.data[pre].x,q.data[pre].y)==0)
			{flag=1;break;}
		}
		if(flag) printf("No\n");
		else printf("Yes\n");
	 }return 0;
}
