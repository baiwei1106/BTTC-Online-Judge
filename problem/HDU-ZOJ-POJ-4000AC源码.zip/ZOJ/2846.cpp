#include"iostream"
#include"cstdio"
#include"cstring"
#include"cmath"
#include"cstdlib"
#include"algorithm"
#include"queue"
using namespace std;

#define LL int
LL ans,anscost;
const int maxn=20200;
const int maxm=10033*100*2;
const LL inf=99999999999999999;
struct edge
{
	short u,v;
	LL cap,flow,cost;
	int next;
}et[maxm];
int S,T,tot; 
int eh[maxn];
void add(int u,int v,LL c,LL f,LL cost)
{
	edge E={u,v,c,f,cost,eh[u]};
	et[tot]=E;	eh[u]=tot++;
}
void addedge(int u,int v,LL c,LL cost)
{
	add(u,v,c,0,cost),add(v,u,0,0,0);
}


int p[maxn];
LL low[maxn],dis[maxn];
bool vit[maxn];
bool spfa()
{
	queue<int > q;
	memset(vit,0,sizeof(vit));
	memset(p,-1,sizeof(p));
	fill(dis,dis+maxn,inf);
	vit[S]=1;
	dis[S]=0;
	low[S]=inf;
	q.push(S);
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		vit[u]=0;
		int i;
		for(i=eh[u];i!=-1;i=et[i].next)
		{
		//	cout<<"paa"<<endl;
			int v=et[i].v;
			LL cap=et[i].cap,flow=et[i].flow,cost=et[i].cost;
			if(cap-flow>0&&dis[u]+cost<dis[v])
			{
				dis[v]=dis[u]+cost;
				p[v]=i;
				low[v]=low[u] < (cap-flow) ? low[u]:(cap-flow);
				if(!vit[v])
				{
					vit[v]=1;
					q.push(v);
				}
			}
		}
	}
	return dis[T]!=inf;

}

void costflow()
{
	ans=0;anscost=0;
	while(spfa())
	{
		int x=p[T];
		ans+=low[T];
		anscost+=low[T]*dis[T];
		while(x!=-1)
		{
			et[x].flow+=low[T];
			et[x^1].flow-=low[T];
			et[x^1].cost=-et[x].cost;
			x=p[et[x].u];
		}
	}
}
void init()
{
	tot=0;
	memset(eh,-1,sizeof(eh));
}

int map[103][103];
int mat[103][103];
int main()
{
	int m,n;
	while(~scanf("%d%d",&n,&m))
	{
		init();
		if(n==0&&m==0)
			break;
		int i,j,k;
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				scanf("%d",&map[i][j]);
		for(i=1;i<=m;i++)
			for(j=1;j<=n;j++)
				scanf("%d",&mat[i][j]);
		S=0;
		int W=n*2*m+1;
	 T=n*2*m+2;
		int Z=n*2*m+3;
		addedge(S,Z,1,0);
		for(i=1;i<=n;i++)
			addedge(Z,i,1,map[1][i]);
		for(i=1;i<=m;i++)
			for(j=1;j<=n;j++)
			{
				int a=(2*i-1-1)*n+j;
				int b=(2*i-1)*n+j;
				addedge(a,b,1,-mat[i][j]);
			}
		for(i=1;i<m;i++)
			for(j=1;j<=n;j++)
				for(k=1;k<=n;k++)
				{
					int a=(2*i-1)*n+j;
					int b=(2*(i+1)-1-1)*n+k;
					addedge(a,b,1,map[j][k]);
				}
		for(i=1;i<=n;i++)
		{
			int a=(2*m-1)*n+i;
			addedge(a,W,1,0);
		}
		addedge(W,T,1,0);
		costflow();
		printf("%d\n",-anscost);
	}
	return 0;
}


