#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<list>
#define EPS 1e-9
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define oo 123456789
typedef long long LL;
const double PI = acos(-1.0);
using namespace std;
/*******************************************************/
#define MAXN 210
char mp[MAXN][MAXN];
int flag[MAXN][MAXN];
bool vis[MAXN][MAXN];
int n, m;
bool yes;
int sx, sy, ex, ey;
void dfs(int x, int y) {
	if (x >= n || y >= m) {
		return;
	}
	if (flag[x][y] == 0 || vis[x][y] || yes) {
		return;
	}
	vis[x][y] = true;
	if (x == ex && y == ey) {
		yes = true;
		return;
	}
	dfs(x + 1, y);
	dfs(x, y + 1);
}
bool check(int a, int b) {
	int i, j;
	int x, y;
	int nx, ny;
	x = y = 0;
	while (x < n && y < m) {
		x += a - 1;
		y += b - 1;
	}
	nx = x - (a - 1);
	ny = y - (b - 1);
	if (!(n - 1 >= nx && n - 1 <= x && m - 1 >= ny && m - 1 <= y)) {
		return false;
	}
	ex = n - 1 - nx;
	ey = m - 1 - ny;
	if (ex == 0 && ey == 0) {
		ex = a - 1;
		ey = b - 1;
	}
	for (i = 0; i < a; i++) {
		for (j = 0; j < b; j++) {
			if (mp[i][j] == '.') {
				flag[i][j] = 1;
			} else {
				flag[i][j] = 0;
			}
		}
	}
	x = a - 1;
	y = b - 1;
	while (x < n && y < m) {
		nx = x + a - 1;
		ny = y + b - 1;
		for (i = x; i <= nx; i++) {
			for (j = y; j <= ny; j++) {
				if (mp[i][j] != '.') {
					flag[i - x][j - y] = 0;
				}
			}
		}
//		printf("%d %d -> %d %d\n", x, y, nx, ny);
		x = nx;
		y = ny;
	}
//	printf("row: %d , col: %d , ( %d , %d )\n", a, b, ex, ey);
//	for (i = 0; i < a; i++) {
//		for (j = 0; j < b; j++) {
//			printf("%d", flag[i][j]);
//		}
//		puts("");
//	}
	yes = false;
	memset(vis, false, sizeof(vis));
	sx = sy = 0;
	dfs(sx, sy);
	if (yes) {
		yes = false;
		memset(vis, false, sizeof(vis));
		sx = ex;
		sy = ey;
		ex = a - 1;
		ey = b - 1;
		dfs(sx, sy);
		return yes;
	}
	return false;
}
int main() {
	int i, j;
	int ans;
	while (~scanf("%d%d", &m, &n)) {
		memset(mp, '.', sizeof(mp));
		for (i = 0; i < n; i++) {
			for (j = 0; j < m; j++) {
				scanf(" %c", &mp[i][j]);
			}
		}
		ans = oo;
		for (i = 1; i <= n; i++) {
			for (j = 1; j <= m; j++) {
				if (i == 1 || j == 1) {
					continue;
				}
				if (i - 1 + j - 1 < ans && check(i, j)) {
//					printf("yes : %d %d\n", i, j);
					ans = i - 1 + j - 1;
				}
			}
		}
		if (ans == oo) {
			ans = -1;
		}
		printf("%d\n", ans);
	}
	return 0;
}
/*
 5 5
 .....
 .....
 .....
 ....X
 ...X.
 */
