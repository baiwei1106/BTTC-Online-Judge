#include <string.h>
#include <iostream>
#include <stdio.h>
using namespace std ;
#define N 310
#define INF 1<<29
struct Tree{
 int v ;
 int x[2], y[2] ;
 int xmid(){ return (x[0] + x[1]) >> 1; }
 int ymid(){ return (y[0] + y[1]) >> 1; }
}t[N*N*5] ;
int n, m, q ;
int f[N][N] ;

void push_up(int rt){
 t[rt].v = t[(rt<<2)+1].v ;
 for(int i=2; i<5; i++) t[rt].v = min(t[rt].v, t[(rt<<2)+i].v) ;
}

void build(int x0, int x1, int y0, int y1, int rt){
 t[rt].x[0] = x0, t[rt].x[1] = x1 ;
 t[rt].y[0] = y0, t[rt].y[1] = y1 ;
 if(x0 == x1 && y0 == y1){
 t[rt].v = f[x0][y0] ;
 return ;
 }
 int xmid = t[rt].xmid() ;
 int ymid = t[rt].ymid() ;
 build(x0, xmid, y0, ymid, (rt<<2)+1) ;
 build(x0, xmid, ymid < y1 ? ymid+1 : y1, y1, (rt<<2)+2) ;
 build(xmid < x1 ? xmid+1 : x1, x1, y0, ymid, (rt<<2)+3) ;
 build(xmid < x1 ? xmid+1 : x1, x1, ymid < y1 ? ymid+1 : y1, y1, (rt<<2)+4) ;
 push_up(rt) ;
}

int query(int x0, int x1, int y0, int y1, int rt){
 if(x0 <= t[rt].x[0] && y0 <= t[rt].y[0] && x1 >= t[rt].x[1] && y1 >= t[rt].y[1]) return t[rt].v ;
 if(x0 > t[rt].x[1] || x1 < t[rt].x[0] || y0 > t[rt].y[1] || y1 < t[rt].y[0]) return INF ;
 int ans = INF ;
 for(int i=1; i<=4; i++)
 ans = min(ans, query(x0, x1, y0, y1, (rt<<2)+i)) ;
 return ans ;
}

int main(){
 //freopen("input.txt", "r", stdin) ;
 int T ;
 scanf("%d", &T) ;
 while(T--){
 scanf("%d", &n) ;
 for(int i=1; i<=n; i++)
 for(int j=1; j<=n; j++)
 scanf("%d", &f[i][j]) ;
 build(1, n, 1, n, 0) ;
 scanf("%d", &q) ;
 while(q--){
 int x0, y0, x1, y1 ;
 scanf("%d %d %d %d", &x0, &y0, &x1, &y1) ;
 printf("%d\n", query(x0, x1, y0, y1, 0)) ;
 }
 }
 return 0 ;
}
