#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<string>
using namespace std;
char a[105][100];
int n,m,k;
int f[105],fs;
char c[100];
int pan()
{
	int i;
	for(i=1;i<=m;i++)
	{
		if(!strcmp(a[i],c))
		{
			f[fs]=i;
			fs++;
			return 1;
		}		
	}
	return 0;
}
int fun()
{
	int i,l;
	l=strlen(c);
	if(pan())
		return 1;
	for(i=1;i<l;i++)
	{
		c[i-1]=c[i-1]^c[i];
		c[i]=c[i-1]^c[i];
		c[i-1]=c[i-1]^c[i];
		pan();
		c[i-1]=c[i-1]^c[i];
		c[i]=c[i-1]^c[i];
		c[i-1]=c[i-1]^c[i];
	}
	return 0;
}
bool cmp(int x,int y)
{
	if(strcmp(a[x],a[y])<0)
	return 1;
	else
	return 0;
}
int main()
{	
	int i,t=0;
	while(scanf("%d",&n)!=EOF)
	{
		while(n--)
		{
			if(t==0)
			t=1;
			else
			printf("\n");
			scanf("%d",&m);
			for(i=1;i<=m;i++)
				scanf("%s",a[i]);
			scanf("%d",&k);
			while(k--)
			{
				fs=0;
				scanf("%s",c);
				if(fun())
				{
					printf("%s",a[f[0]]);
				}
				else if(fs!=0)
				{
					sort(f,f+fs,cmp);
					for(i=0;i<fs;i++)
					{
						if(i!=0)
							printf(",");
						printf("%s",a[f[i]]);
					}
				}
				else
				{
					printf("%s",c);
				}
				printf("\n");
			}
		}
	}
}
