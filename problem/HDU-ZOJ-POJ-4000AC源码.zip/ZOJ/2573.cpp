#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;

struct mat
{
	unsigned long long a[51][51],n;
	mat()
	{
		memset(a,0,sizeof(a));
	}
}A,B,C;

int n,m,a,b;
int MAT1[2][55],MAT2[2][55];

mat mult(mat A,mat B)
{
	mat C;
	int n=A.n;
	C.n=n;
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
		{
			C.a[i][j]=0;
			for (int k=0;k<n;k++)
				C.a[i][j]=(C.a[i][j]+A.a[i][k]*B.a[k][j])%2;
		}
	return C;
}

mat power(mat A,int n)
{
	mat ans,bas=A;
	ans.n=A.n;
	for (int i=0;i<A.n;i++)
		for (int j=0;j<A.n;j++)
		{
			if (i==j) ans.a[i][j]=1;
			else ans.a[i][j]=0;
		}
	while (n>0)
	{
		if (n&1) ans=mult(ans,bas);
		bas=mult(bas,bas);
		n>>=1;
	}
	return ans;
}

int main()
{
	while (scanf("%d%d%d%d",&n,&m,&a,&b)>0)
	{
		int tmp=m/(a+b);
		A.n=n;B.n=n;
		for (int i=0;i<n;i++)
			for (int j=0;j<n;j++) scanf("%d",&A.a[j][i]);
		for (int i=0;i<n;i++)
			for (int j=0;j<n;j++) scanf("%d",&B.a[j][i]);
		mat Q1=power(A,a),Q2=power(B,b);
		mat Q3=mult(Q1,Q2);
		mat Q4=power(Q3,tmp);
		mat Q5=power(A,min(m-tmp*(a+b),a)),Q6=power(B,max(m-tmp*(a+b)-a,0));
		mat Q7=mult(Q4,Q5);
		mat Q8=mult(Q7,Q6);
		for (int i=0;i<n;i++)
		{
			char st[10];
			scanf("%s",st);
			if (st[0]=='a') MAT1[0][i]=1;
			else MAT1[0][i]=0;
		}
		memset(MAT2,0,sizeof(MAT2));
		for (int i=0;i<n;i++)
			for (int k=0;k<n;k++)
				MAT2[0][i]=(MAT2[0][i]+MAT1[0][k]*Q8.a[k][i])%2;
		if (MAT2[0][0]==1) printf("alive");
		else printf("dead");
		for (int i=1;i<n;i++)
			if (MAT2[0][i]==1) printf(" alive");
			else printf(" dead");
		puts("");
	}
}