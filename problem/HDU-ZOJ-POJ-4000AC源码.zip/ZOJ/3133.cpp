/*
 * Author: OpenLegend
 * Created Time: 2010-8-21 15:19:59
 * File Name: c.cpp
 */
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
using namespace std;
typedef long long LL;
const LL INF = 1000000007LL*1000000007LL;
struct Pt{
 int x, y;
 Pt(int _x, int _y):
 x(_x), y(_y){}
 Pt(){}
};
vector<Pt> vec;
int n, w, h;
const int maxn = 50005;
LL m1[maxn], mv1[maxn], m2[maxn], mv2[maxn];//, T1[maxn], T2[maxn], Tv1[maxn], Tv2[maxn];
LL cal(){
 memset(m1, -1, sizeof(m1));
 memset(m2, -1, sizeof(m2));
 for(int i = 0; i < (int)vec.size(); i ++){
 //printf("%d %d\n", vec[i].x, vec[i].y);
 m1[vec[i].x] = max(m1[vec[i].x], (LL)vec[i].y);
 m2[vec[i].x] = max(m2[vec[i].x], (LL)h-1-vec[i].y);
 }
 memcpy(mv1, m1, sizeof(m1));
 memcpy(mv2, m2, sizeof(m2));
 
 for(int i = 1; i < w; i ++){
 m1[i] = max(m1[i], m1[i-1]);
 m2[i] = max(m2[i], m2[i-1]);
 }
 for(int i = w-2; i >= 0; i --){
 mv1[i] = max(mv1[i], mv1[i+1]);
 mv2[i] = max(mv2[i], mv2[i+1]);
 }
 
 for(int i = 0; i < w; i ++){
 if(m2[i] == -1) m2[i] = h-1;
 if(mv2[i] == -1) mv2[i] = h-1;
 m1[i] ++; m2[i] ++;
 mv1[i] ++; mv2[i] ++;
 //printf("%I64d %I64d %I64d %I64d\n", m1[i], m2[i], mv1[i], mv2[i]);
 }
 for(int i = 1; i < w; i ++){
 m1[i] += m1[i-1];
 m2[i] += m2[i-1];
 }
 for(int i = w-2; i >= 0; i --){
 mv1[i] += mv1[i+1];
 mv2[i] += mv2[i+1];
 }
 //for(int i = 0; i < w; i ++) printf("%I64d %I64d %I64d %I64d\n", m1[i], m2[i], mv1[i], mv2[i]);
 LL ret = INF;
 for(int i = 0; i < w; i ++){
 LL tmp = h*2;
 if(i != 0) tmp += m1[i-1] + m2[i-1];
 if(i != w-1) tmp += mv1[i+1] + mv2[i+1];
 //printf("i = %d %I64d\n", i, tmp);
 ret = min(ret, tmp);
 }
 return ret - (LL)w*h;
}
int main() {
 int test;
 scanf("%d", &test);
 while(test --){
 scanf("%d%d%d", &w, &h, &n);
 vec.clear();
 for(int i = 0; i < n; i ++){
 int x, y;
 scanf("%d%d", &x, &y);
 if(x != 0 && y != 0) vec.push_back(Pt(x-1, y-1));
 if(x != w && y != h) vec.push_back(Pt(x, y));
 if(x != w && y != 0) vec.push_back(Pt(x, y-1));
 if(x != 0 && y != h) vec.push_back(Pt(x-1, y));
 }
 //sort(vec.begin(), vec.end());
 //vec.erase(unique(vec.begin(), vec.end()), vec.end());
 LL ans = cal();
 swap(w, h);
 for(int i = 0; i < (int)vec.size(); i ++) swap(vec[i].x, vec[i].y);
 ans = min(ans, cal());
 cout << ans << endl;
 }
 return 0;
}

