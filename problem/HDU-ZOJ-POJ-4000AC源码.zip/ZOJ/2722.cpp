#include <iostream>
#include <cmath>
using namespace std;
int main()
{
 double i,n,count;
 while(cin>>n)
 {
 if(n==0)
 break;
 count=0;
 for(i=0;i<32;i++)
 {
 if(pow(2,i)>=n)
 {
 count=i;
 break;
 }
 }
 cout<<count<<endl;
 }
 return 0;
}
