/*
 * Author: xioumu
 * Created Time: 2013/8/1 20:35:51
 * File Name: B.cpp
 * solve: B.cpp
 */
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
#include<set>
#include<iostream>
#include<vector>
#include<queue>

using namespace std;
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clr(x) memset(x,0,sizeof(x))
#define clrs( x , y ) memset(x,y,sizeof(x))
#define out(x) printf(#x" %d\n", x)
#define sqr(x) ((x) * (x))
typedef long long lint;

const int maxint = -1u>>1;
const double eps = 1e-8;

int sgn(const double &x) { return (x > eps) - (x < -eps); }

const int maxn = 1000 + 10;
const int maxm = 20000 + 10;
map<int, int> mp[maxn];
int n, m;

vector<int> e[maxn], g[maxn];
int t[maxm];
queue<int> que;

void add(vector<int> *e, int x, int y) {
 e[x].push_back(y);
}

vector<int> getTop(vector<int> *e) {
 vector<int> res;
 int in[maxn] = {0};
 repf (i, 1, n)
 rep (j, sz(e[i]))
 in[e[i][j]]++;
 repf (i, 1, n)
 if (in[i] == 0) 
 que.push(i);
 
 while (!que.empty()) {
 int k = que.front();
 que.pop();
 res.push_back(k);
 rep (i, sz(e[k])) {
 int j = e[k][i];
 in[j]--;
 if (in[j] == 0) 
 que.push(j);
 }
 }
 return res;
}

vector<int> ans;
int getAns(vector<int> &se, vector<int> &sg) {
 int pos[maxn], v[maxn] = {0}, down[maxn] = {0};
 ans.clear();
 rep (i, sz(sg)) {
 pos[sg[i]] = i;
 }
 rep (i, sz(se)) {
 int k = -1;
 rep (j, sz(se)) {
 if (v[se[j]]) continue;
 if (k == -1 || pos[se[k]] > pos[se[j]])
 k = j;
 } 
 int w = se[k];
 //printf("%d %d\n", w, pos[w]);
 repd (j, k - 1, pos[w]) {
 if (mp[se[j]].count(w)) {
 int h = mp[se[j]][w];
 //printf("%d\n", t[h]);
 if (t[h]) return false; 
 else ans.push_back(h);
 } 
 swap(se[j], se[j + 1]);
 } 
 v[w] = 1;
 }
 return true;
}
int main() {
 while (scanf("%d%d", &n, &m) == 2) {
 clr(t);
 repf (i, 1, n) {
 e[i].clear();
 g[i].clear();
 mp[i].clear();
 }
 repf (i, 1, m) {
 int x, y, ty;
 scanf("%d%d%d", &x, &y, &ty);
 if (mp[x][y] != 0) {
 t[mp[x][y]] = 1;
 t[i] = 1;
 }
 mp[x][y] = i;
 add(e, x, y);
 if (ty == 0)
 add(g, x, y);
 else add(g, y, x);
 }
 vector<int> se = getTop(e);
 vector<int> sg = getTop(g);
 //rep (i, sz(se)) 
 //printf("%d ", se[i]);
 //puts("");
 //rep (i, sz(sg))
 //printf("%d ", sg[i]);
 //puts("");
 //puts("test");
 if (!getAns(se, sg))
 printf("-1\n");
 else {
 printf("%d\n", sz(ans));
 rep (i, sz(ans)) {
 if (i) printf(" ");
 printf("%d", ans[i]);
 }
 if (sz(ans)) puts("");
 }
 printf("\n");
 }
 return 0;
}
