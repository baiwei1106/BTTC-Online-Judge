#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <list>
#include <stack>
#include <bitset>
#include <numeric>
#include <functional>
using namespace std;
//typedef __int64 ll;
//typedef unsigned long long ull;
//const ll Inf = ~(1ll << 63);
const int inf = 0x7fffffff;
const int N = 105;
const int mod = 1000000007;
const double PI = acos(-1.0);
const double eps = 1e-8;
#define CC(a,b) memset(a,b,sizeof(a))
template<class Z>inline bool checkmax(Z &a,Z b){if(a < b || a == -1) {a = b; return true;} return false;}
template<class Z>inline bool checkmin(Z &a,Z b){if(a > b || a == -1) {a = b; return true;} return false;}
template<class Z>inline Z ABS(Z a) {return a > 0 ? a : -a;}
int cas = 0; void printcas() {printf("Case #%d: ", ++cas);}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
bool hash[N][N];
int ans[N * N];
int n;
int idx;


void DFS(int cur) {
	for(int i = 0; i < n; i++) {
		if(i != cur && !hash[cur][i]) {
			hash[cur][i] = hash[i][cur] = 1;
			DFS(i);
		}
	}
	ans[idx ++] = cur;
}

int main() {
	while(~scanf("%d", &n)) {
		CC(hash, 0);
		idx = 0;
		DFS(0);
		cout << idx - 1 << endl;
		for(int i = 1; i < idx - 1; i++)	
			cout << ans[i] << " ";
		cout << ans[idx - 1] << endl;
	}
	return 0;
}