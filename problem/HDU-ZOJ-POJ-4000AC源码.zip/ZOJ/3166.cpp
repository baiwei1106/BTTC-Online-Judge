/*
 * Author: xioumu
 * Created Time: 2012-4-2 17:00:54
 * File Name: i.cpp
 * solve: i.cpp
 */
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
#define inf 1e-8
#define MAXN 107
#define MAXNUM (int64)100000000000007
typedef long long int64;
int64 map[MAXN][MAXN],map2[MAXN][MAXN];
int64 n,m,mm,a[MAXN];
int main(){
 int64 i,j,k,r,w;
 while(scanf("%lld %lld",&n,&m) != EOF){
 memset(a,0,sizeof(a));
 for(i=1; i<=n ;i++)
 for(j=1;j<=n;j++){
 map[i][j] = map2[i][j] = MAXNUM;
 //if(i == j) map[i][j] = map2[i][j] = 0;
 }
 for(i=1; i<=m; i++)
 scanf("%lld",&a[i]);
 scanf("%d",&mm);
 for(i=1;i<=mm;i++){
 scanf("%lld %lld %lld",&k,&r,&w);
 map[k][r] = min(map[k][r], w);
 }
 //
 for(k=1; k<=n; k++)
 for(i=1; i<=n; i++)
 for(j=1; j<=n; j++)
 if(map[i][j] > map[i][k] + map[k][j]){
 map[i][j] = map[i][k] + map[k][j];
 }
 //printf("=====\n");
 if(m != 0) sort(a+1, a + m + 1);
 int64 ans1=MAXNUM,ans2 = -1;
 for(i=1; i<=m; i++){
 r = 0;
 if(map[ a[i] ][ a[i] ] < ans1){ 
 ans1 = map[ a[i] ][ a[i] ];
 ans2 = a[i];
 }
 }
 if(ans2 == -1) printf("I will nerver go to that city!\n");
 else printf("%lld\n",ans2);
 } 
 return 0;
}
