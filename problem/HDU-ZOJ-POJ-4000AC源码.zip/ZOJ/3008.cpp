#include <cstring>
#include <cstdio>
#include <algorithm>
#include <iostream>
#include <cstdlib>
#define MAXN 10010
using namespace std;

long long isprime[MAXN];
long long prime[5000];
long long pn;
long long n, m;
long long p[5000], a[5000];
long long ans, k;

void DFS(long long i, long long c)
{
 long long j;
 if (c > n || c <= 0)
 return;
 if (i >= k)
 {
 ans++;
 return;
 }
 for(j = 0; j <= a[i]; j++)
 {
 if(j)
 c *= p[i];
 DFS(i + 1, c);
 }
}

int main()
{
 long long i, t;
 while(scanf("%lld%lld",&n,&m)!=EOF)
 {
 ans = k = 0;
 t = n;
 for (i = 2; i * i <= t; i++)
 if (t%i == 0)
 {
 p[k] = i;
 a[k] = 1;
 t /= i;
 while (t%i == 0)
 {
 a[k]++;
 t /= i;
 }
 a[k] *= m;
 k++;
 }
 if(t > 1)
 {
 p[k] = t;
 a[k] = m;
 k++;
 }
 //for (int i = 0; i < k; i++)
			//cout << "p[" << i << "]=" << a[i] << " a[" << i << "]=" << b[i] << endl;
 
 DFS(0,1);
 printf("%lld\n",ans);
 }
 return 0;
}