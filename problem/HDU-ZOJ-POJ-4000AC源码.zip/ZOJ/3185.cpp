#include<stdio.h>
#include<string.h>
#include<string>
#include<set>
#include<vector>
#include<iostream>

using namespace std;

string a,op,b;
char ans[2000];
char tmps[20];

multiset<string> myset;

int main()
{
	while(1){
		myset.clear();
		cin >> a;
		if(a == ".")
			break;
		cin >> op >> b;
		if(op[0] == '+'){
			if(a.length() == 2){
				cout << b << endl;
				continue;
			}else if(b.length() == 2){
				cout << a << endl;
				continue;
			}
			int p = 0;
			for(int i = 0;i < a.length() - 1;++i)
				ans[p++] = a[i];
			p = a.length() - 1;
			ans[p++] = ',';
			for(int i = 1;i < b.length() - 1;++i)
				ans[p++] = b[i];
			ans[p++] = ']';
			ans[p] = '\0';
			cout << ans << endl;
		}else{
			string t = "";
			for(int i = 1;i < b.length();++i){
				if(b[i] == ',' || b[i] == ']'){
					myset.insert(t);
					t = "";
				}else{
					sprintf(tmps,"%c",b[i]);
					t = t + string(tmps);
				}
			}
			t = "";
			int p = 0;
			string ansstr = "[";
			for(int i = 1;i < a.length();++i){
				if(a[i] == ',' || a[i] == ']'){
					if(myset.find(t) == myset.end()){
						if(ansstr[ansstr.length() - 1] != '[')
							ansstr += ",";
						ansstr += t;
					}else
						myset.erase(myset.find(t));
					t = "";
				}else{
					sprintf(tmps,"%c",a[i]);
					t = t + string(tmps);
				}
			}
			ansstr += "]";
			cout << ansstr << endl;
		}
	}
	return 0;
}