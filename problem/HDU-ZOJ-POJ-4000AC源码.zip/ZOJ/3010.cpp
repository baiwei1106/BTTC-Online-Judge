#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<string>
using namespace std;
int s[15];
double cost[15];
double ans;
int n,m;
void dfs(int depth, int state, double t){
 if(t<ans)
 return;
 if(depth==n){
 if(state+1==(1<<n))
 ans=t;
 return;
 }
 dfs(depth+1,state,t);
 dfs(depth+1,state^s[depth],t*cost[depth]);
}
int main(){
	while(scanf("%d%d",&n,&m)!=EOF){
		if(n==0 && m==0)break;
		ans=-1;
		for(int i=0;i<n;i++){
			int k;
			scanf("%d",&k);
			s[i]=(1<<i);
 while(k--){
 	int p;
 scanf("%d",&p);
 s[i]=s[i]|(1<<(--p));
 }
 int t;
			scanf("%d",&t);
			cost[i]=1-1.0*t/100;
		}
		dfs(0,0,m);
 if(ans>0)
 printf("%.2lf\n",ans);
 else
 printf("-1\n");
	}
	return 0;
}