#include <cstdio>
#include <cstring>
#include <algorithm>
#define eps 1e-6
using namespace std;
int ABS(int x){
 if(x >= 0) return x;
 else return -x;
}
struct node{
 int h,m;
 double ang;
 bool operator < (const node&t)const{
 if(ang - t.ang>eps||t.ang-ang > eps) return ang < t.ang;
 else return h*60+m<t.h*60+m;
 }
}p[10];

int main(){

 // freopen("1.txt","r",stdin);

 int T,a,b;
 scanf("%d",&T);
 while(T--){
 for(int i = 0; i < 5; i++)
 scanf("%d:%d",&p[i].h,&p[i].m);
 for(int i = 0; i < 5; i++){
 double am = p[i].m*6;
 double ah = (p[i].h%12)*30+p[i].m*0.5;
 p[i].ang = ABS(ah-am);
 //printf("%d %d#\n",ah,am);
 if(p[i].ang > 180) p[i].ang = 360-p[i].ang;
 }
 sort(p,p+5);
 // for(int i = 0; i < 5; i++)
 // printf("%d:%d %d*\n",p[i].h,p[i].m,p[i].ang);

 printf("%02d:%02d\n",p[2].h,p[2].m);
 }
 return 0;
}
