#include<stdio.h>

const int go[4][2]={-1, 0, 0, 1, 1, 0, 0, -1};
int treasurex[2000];
int treasurey[2000];
int dp[2000][4];

int indata()
{
 int n;
 scanf("%d",&n);
 char str[20];
 int x=0,y=0,dir=0;
 int resu=0;
 for (int i=1; i<=n; i++)
 {
 scanf("%s",str);
 if (str[0]=='F')
 {
 x+=go[dir][0];
 y+=go[dir][1];
 }
 if (str[0]=='T')
 {
 scanf("%s",str);
 if (str[0]=='R')
 dir=(dir+1)%4;
 else
 dir=(dir+3)%4;
 }
 if (str[0]=='S')
 {
 resu++;
 treasurex[resu]=x+go[dir][0];
 treasurey[resu]=y+go[dir][1];
 }
 }
 return resu;
}

int calstep(int x1, int y1, int x2, int y2)
{
 if (x1==x2&&y1==y2)
 return 0;
 if (x1==x2||y1==y2)
 return 1;
 return 2;
}

int main()
{
 // freopen("input.txt","r",stdin);
 int CAS, CAS1;
 scanf("%d", &CAS1);
 for (CAS=1; CAS<=CAS1; CAS++)
 {
 int sp=indata();
 for (int i=0; i<4; i++)
 {
 treasurex[0]=0;
 treasurey[0]=0;
 dp[0][0]=0;
 }
 for (int i=1; i<=sp; i++)
 for (int j=0; j<4; j++)
 {
 int cntx=treasurex[i]-go[j][0];
 int cnty=treasurey[i]-go[j][1];

 int prex=treasurex[i-1]-go[0][0];
 int prey=treasurey[i-1]-go[0][1];
 if (i==1)
 {
 prex=0;
 prey=0;
 }
 dp[i][j]=dp[i-1][0]+calstep(cntx, cnty, prex, prey);

 for (int k=1; k<4; k++)
 {
 prex=treasurex[i-1]-go[k][0];
 prey=treasurey[i-1]-go[k][1];
 if (i==1)
 {
 prex=0;
 prey=0;
 }

 int temp=calstep(cntx, cnty, prex, prey);
 if (dp[i][j]>dp[i-1][k]+temp)
 dp[i][j]=dp[i-1][k]+temp;
 }
 }
 int resu=dp[sp][0];
 for (int i=1; i<4; i++)
 if (resu>dp[sp][i])
 resu=dp[sp][i];
 if (CAS!=1)
 printf("\n");
 printf("Case %d:\n%d\n",CAS,resu+sp);
 }
 return 0;
}
