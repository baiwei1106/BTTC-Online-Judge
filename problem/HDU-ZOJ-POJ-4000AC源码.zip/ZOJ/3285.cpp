#include<iostream>
#include<cstdio>
#include<cstring>
#include<map>
#include<algorithm>
using namespace std;
struct Point{
	int x,y;
	bool friend operator<(Point a,Point b){
		if(a.x!=b.x)return a.x<b.x;
		return a.y<b.y;
	}
	Point(){}
	Point(int xx,int yy){
		x=xx;y=yy;
	}
};
map<Point,int>mp;
struct Unit{
	int l,r,x,y,id;
	bool friend operator<(Unit a,Unit b){
		return a.x>b.x;
	}
};
Unit ut[1005];
int N,W,C,D;
double val[1005];
int f_max(int x,int y){
	return x>y?x:y;
}
void get_data(){
	int i;
	mp.clear();
	for(i=0;i<N;i++){
		scanf("%d%d",&ut[i].x,&ut[i].y);
		ut[i].l=ut[i].r=-1;
	}
	sort(ut,ut+N);
	for(i=0;i<N;i++){
		mp[Point(ut[i].x,ut[i].y)]=i;
	}
	Point t;
	memset(val,0,sizeof(val));
	int fg;
	for(i=0;i<N;i++){
		fg=0;
		t.x=ut[i].x-1;t.y=ut[i].y-1;
		if(mp.find(t)!=mp.end())ut[i].l=mp[t],fg++;
		t.x=ut[i].x-1;t.y=ut[i].y+1;
		if(mp.find(t)!=mp.end())ut[i].r=mp[t],fg++;
		if(fg==1){
			if(ut[i].l!=-1)val[ut[i].l]+=val[i]+W;
			if(ut[i].r!=-1)val[ut[i].r]+=val[i]+W;
		}else if(fg==2){
			val[ut[i].l]+=(val[i]+W)*1.0/2;
			val[ut[i].r]+=(val[i]+W)*1.0/2;
		}
	//	printf("id %d: %d %d\n",i,ut[i].l,ut[i].r);
	}
	sort(val,val+N);
	int tt,cnt=0;
	if(val[N-1]>C)tt=0;
	else{
		tt=(C-val[N-1])/D;
		while(tt*D<=C-val[N-1])tt++;
	}
	for(i=N-1;i>=0;i--){
	//	printf("%lf %d\n",val[i],tt);
		if(val[i]>f_max(0,C-D*tt))cnt++;
	}
	if(!cnt)printf("-1\n");
	else printf("%d %d\n",tt,cnt);
}
int main(){
	while(scanf("%d%d%d%d",&N,&W,&C,&D)!=EOF){
		get_data();
	//	run();
	}
	return 0;
}