#include<stdio.h>
#include<string.h>
int t,o,s,c,n,m,i,x,min,a1,a2;
int a[50000],b[50000],q[50000],w[50000];
void qsort(int l,int r)
{
	int ii,jj,tt,bb;
	ii=l;jj=r;
	bb=a[(ii+jj)/2];
	do
	{
		while(a[ii]<bb)ii++;
		while(a[jj]>bb)jj--;
		if(ii<=jj)
		{
			tt=a[ii];a[ii]=a[jj];a[jj]=tt;
			tt=b[ii];b[ii]=b[jj];b[jj]=tt;
			ii++;jj--;
		}
	}
	while (ii<=jj);
	if(ii<r)qsort(ii,r);
	if(jj>l)qsort(l,jj);	
}
void qsort1(int l,int r)
{
	int ii,jj,tt,bb;
	ii=l;jj=r;
	bb=q[(ii+jj)/2];
	do
	{
		while(q[ii]<bb)ii++;
		while(q[jj]>bb)jj--;
		if(ii<=jj)
		{
			tt=q[ii];q[ii]=q[jj];q[jj]=tt;
			ii++;jj--;
		}
	}
	while (ii<=jj);
	if(ii<r)qsort1(ii,r);
	if(jj>l)qsort1(l,jj);	
}
void qsort2(int l,int r)
{
	int ii,jj,tt,bb;
	ii=l;jj=r;
	bb=w[(ii+jj)/2];
	do
	{
		while(w[ii]<bb)ii++;
		while(w[jj]>bb)jj--;
		if(ii<=jj)
		{
			tt=w[ii];w[ii]=w[jj];w[jj]=tt;
			ii++;jj--;
		}
	}
	while (ii<=jj);
	if(ii<r)qsort2(ii,r);
	if(jj>l)qsort2(l,jj);	
}
int main()
{
	scanf("%d",&t);
	for(o=1;o<=t;o++)
	{
		scanf("%d%d",&s,&c);
		if(s==1)
		{
			scanf("%d%d",&n,&m);
			printf("%d\n",n-m);
		}
		else{
		for(i=1;i<=s;i++)
		{
			scanf("%d",&x);
			a[i]=x;b[i]=0;
			q[i]=x;
		}
		for(i=1;i<=s;i++)
		{
			scanf("%d",&x);
			a[i+s]=x;b[i+s]=1;
			w[i]=x;
		}
		qsort(1,2*s);min=-1;
		for(i=2;i<=2*s;i++)b[i]=b[i-1]+b[i];
		for(i=1;i<2*s;i++)
		if(min<a[i+1]-a[i])
		{
			a1=i-b[i];a2=s-b[i];
			if(a1>a2)
			if(c>=a2*2+(a1-a2-1)*(a1-a2))min=a[i+1]-a[i];
			if(a2>a1)
			if(c>=a1*2+(a2-a1-1)*(a2-a1))min=a[i+1]-a[i];
			if(a1==a2)
			if(c>=a1*2)min=a[i+1]-a[i];
		}
		if(min>=0)printf("%d\n",min);
		if(min<0)
		{
			qsort1(1,s);
			qsort2(1,s);
			min=-999999999;
			if(min<q[c/2+1]-w[s-c/2-1])min=q[c/2+1]-w[s-c/2-1];
			if(min<q[c/2+2]-w[s-c/2])min=q[c/2+2]-w[s-c/2];
			printf("%d\n",min);		
		}
		}
	}
}