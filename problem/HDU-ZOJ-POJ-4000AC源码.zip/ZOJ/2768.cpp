#include <iostream>
#include <string.h>
#include <stdio.h>
#include <math.h>
#define maxn 12
#define maxm 10000
#define eps 1e-8
using namespace std;

double matrix[maxn][maxn];
double k[maxn];
int c[maxn];
int n, tot;
double res[maxn];
char restr[maxn];
char str[maxm];
int ori[2][5];
int use[5];

void init()
{
	int i, j;
	gets(str);
	gets(str);
	//cout<<str<<endl;
	for (i = 0; i < 2; i++)
		for (j = 0; j < 5; j++)
			scanf("%d", &ori[i][j]);
}

void GenMap()
{
	int i, j;
	memset (matrix, 0, sizeof matrix);
	memset (k, 0, sizeof k);
	for (i = 0; i < 5; i++)
		for (j = 0; j < 5; j++)
			matrix[i][i + j] = str[j];
	for(i= 5; i < 10; i++)
		for (j = 0; j < 5; j++)
			matrix[i][i - 5 + j] = str[j + 5];
	for (i = 0; i < 5; i++)
		k[i] = ori[0][i];
	for (i = 5; i < 10; i++)
		k[i] = ori[1][i - 5];
		
	for (i = 0; i < 10; i++)
		matrix[i][9] = 23;	
		
		/*
	for (i = 0; i < 10; i++)
	{
		for (j = 0; j < 10; j++)
			printf("%3.0f ", matrix[i][j]);
		cout<<endl;
	}
	*/
}

bool gauss(double A[maxn][maxn], double B[maxn], int n)
{
	int i, j, k;
	double t;
	for (k = 0; k < n; k++)
	{
		double maxp;
		int row;
		maxp = 0;
		for (i = k; i < n; i++)
			if (fabs(A[i][k]) > fabs(maxp))
				maxp = A[row = i][k];
		if (fabs(maxp) < 1e-10) return 0;
		if (row != k)
		{
			for (j = k; j < n; j++)
			{
				t = A[k][j]; A[k][j] = A[row][j]; A[row][j] = t;
			}
			t = B[k]; B[k] = B[row]; B[row] = t;
		}
		for (j = k + 1; j < n; j++)
		{
			A[k][j] /= maxp;
			for (i = k + 1; i < n; i++) A[i][j] -= A[i][k] * A[k][j];
		}
		B[k] /= maxp;
		for (i = k + 1; i < n; i++)
			B[i] -= B[k] * A[i][k];
	}
	for (i = n - 1; i >= 0; i--)
	{
		for (j = i + 1; j < n; j++)
			B[i] -= A[i][j] * B[j];
	}
	return 1;
}

void Solve()
{
	int i, j, t, tmp;
	GenMap();
	gauss(matrix, k, 9);
	/*
	for (i = 0; i < 10; i++)
		printf("%.2f ", k[i]);
	cout<<endl;
	*/
	scanf("%d", &n);
	for (t = 0, tot = 0; t < n; t++)
	{
		for (i = 0; i < 5; i++)
			scanf("%d", &use[i]);
		memset (matrix, 0, sizeof matrix);
		for (i = 0; i < 5; i++)
			for (j = 0; j < 5; j++)
				matrix[i][j] = k[i + j];
		for (i = 0; i < 5; i++)
			res[i] = use[i];
		gauss(matrix, res, 5);
		for (i = 0; i < 5; i++)
		{
			tmp = (int) (res[i] + eps);
			restr[tot++] = tmp;
		}
	}
	for (i = 0; i < tot; i++)
		cout<<restr[i];
	cout<<endl;
}

int main()
{
	int t, i;
	scanf("%d", &t);
	for (i = 1; i <= t; i++)
	{
		init();
		Solve();
	}
	return 0;
}