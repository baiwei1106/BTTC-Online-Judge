#include <stdio.h>
#include <string.h>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

int a[1000];
int main()
{
 int i,j,n,T,s,x,y,z,ans;
 scanf("%d",&T);
 while(T--)
 {
 scanf("%d%d",&x,&y);
 if (x<y || (x+y)%2!=0)
 {
 printf("impossible\n");
 }
 else
 {
 printf("%d %d\n",(x+y)/2,(x-y)/2);
 }
 }
 return 0;
}
