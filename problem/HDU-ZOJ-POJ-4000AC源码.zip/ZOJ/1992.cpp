#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cctype>
#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <stack>
using namespace std;

typedef long long LL;
typedef pair<int,int> PII;
typedef vector<int> VI;

#define PB push_back
#define MP make_pair
#define clr(a,b) (memset(a,b,sizeof(a)))
#define rep(i,a) for(int i=0; i<(int)a.size(); i++)

const int INF = 0x3f3f3f3f;
const double eps = 1E-8;

const int NV = 210,NE = 1010;
int head[NV], e, d[NV], vd[NV], cur[NV], pre[NV];
struct E{
	int u, v, w, next;
}edge[NE<<1];

void addedge(int u, int v, int w){
	edge[e].u = u, edge[e].v = v, edge[e].w = w, edge[e].next = head[u], head[u] = e++;
	edge[e].u = v, edge[e].v = u, edge[e].w = 0, edge[e].next = head[v], head[v] = e++;
}

int sap(int s, int t, int n){
	if(s == t)	return 0;
	int ret = 0, u = s, i, mini;
	clr(d, 0), clr(vd, 0);
	vd[0] = n, cur[s] = head[s], pre[s] = -1;

	while(d[s] < n)
	{
		if(u == t)
		{
			for(mini = INF, i=pre[u]; ~i; i=pre[edge[i].u ])
				mini = min(mini, edge[i].w);
			for(i=pre[u]; ~i; i=pre[edge[i].u ])
				edge[i].w -= mini, edge[i^1].w += mini;
			ret += mini, u = s;
		}

		for(i=cur[u]; ~i; i=edge[i].next)
			if(edge[i].w > 0 && d[u] == d[edge[i].v ] + 1)
			{
				cur[u] = i;
				pre[u = edge[i].v ] = i;
				break;
			}

		if(i == -1)
		{
			if(--vd[d[u] ] == 0 )	break;
			vd[++d[u] ]++;
			cur[u] = head[u];
			if(u != s)	u = edge[pre[u] ].u;
		}
	}
	return ret;
}

int T, n, m;
int x[NE],y[NE],c[NE];
int in[NV], out[NV], v[NV];

int main()
{
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d%d",&n,&m);
		clr(in, 0), clr(out, 0);
		for(int i=1; i<=m; i++)
		{
			scanf("%d%d%d",&x[i],&y[i],&c[i]);
			out[x[i] ]++, in[y[i] ]++;
		}

		int tot = 0;
		bool ok = true;
		for(int i=1; i<=n; i++)
		{
			v[i] = abs(in[i] - out[i]);
			if(v[i] % 2 == 1)	ok = false;
			if(out[i] > in[i]) tot += (out[i] - in[i])/2;
		}

		if(ok == false)
		{
			puts("impossible");
			continue;
		}

		clr(head, -1), e = 0;
		for(int i=1; i<=m; i++)
			if(c[i] == 0)
				addedge(x[i], y[i], 1);
		for(int i=1; i<=n; i++)
		{
			if(in[i] > out[i])	addedge(i, n+2, (in[i] - out[i])/2);
			if(in[i] < out[i])	addedge(n+1, i, (out[i] - in[i])/2);
		}
		int ans = sap(n+1, n+2, n+2);
		if(ans == tot)	puts("possible");
		else	puts("impossible");
	}
	return 0;
}
