#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

const double EPS = 1E-9, Pi = atan(1.0) * 4.0;

struct Point
{
	double x, y;
	Point(double _x = 0, double _y = 0): x(_x), y(_y) {}

	friend double DIS (const Point& a, const Point& b)
	{
		return pow(a.x-b.x, 2.0) + pow(a.y-b.y, 2.0);
	}
};

int main()
{
	double a, W, x, y, D, A;
	while (~scanf("%lf%lf%lf%lf%lf%lf", &a, &W, &x, &y, &D, &A))
	{
		A = A * Pi / 180;
		double aa = DIS(Point(x, y), Point(-a, 0)), bb = DIS(Point(x, y), Point(a, 0)), cc = DIS(Point(a, 0), Point(-a, 0));
		double cita = (aa + bb - cc) / (2 * sqrt(aa*bb));
		cita = (acos(cita) - A) * 0.5;
		if (cita < 0)
		{
			puts("0");
			continue;
		}
		double dd = tan(cita) * D * 2.0;
		int n = dd / W;
		if (!(fabs(dd / W - n) < EPS))
			n++;
		printf("%d\n", n);
	}
	return 0;
}