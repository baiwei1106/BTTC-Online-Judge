#include<stdio.h>
int main()
{
	char s[]="`1234567890-=QWERTYUIOP[]\\ASDFGHJKL;'ZXCVBNM,./";
	char ch;
	while((ch=getchar())!=EOF)
	{
		if(ch==' '||ch=='\n')
			putchar(ch);
		else
		{
			int i=0;
			while(s[i+1]!=ch)i++;
			putchar(s[i]);
		}
	}
	return 0;
}
