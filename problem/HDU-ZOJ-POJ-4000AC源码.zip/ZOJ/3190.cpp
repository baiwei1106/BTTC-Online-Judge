#include<stdio.h>
#include<algorithm>
#include<string.h>
#include<queue>
#include<vector>
using namespace std;
struct Node {
	int next[2], v, fail;
	int sfc;
} _node[51000 + 11000];
int ec;
vector<int> safe_set;
void add_word(char *str, int k) {
	int p = 0;
	for (int i = 0; str[i]; i++) {
		if (_node[p].next[str[i] - '0'] != -1) {
			p = _node[p].next[str[i] - '0'];
		} else {
			_node[p].next[str[i] - '0'] = ec;
			p = ec++;
		}
	}
	_node[p].v = k;
	if (k) {
		_node[p].sfc = safe_set.size();
		safe_set.push_back(p);
	}
}
void get_fail() {
	queue<int> qu;
	qu.push(0);
	while (!qu.empty()) {
		int p = qu.front();
		qu.pop();
		for (int i = 0; i < 2; i++) {
			if (_node[p].next[i] != -1) {
				qu.push(_node[p].next[i]);
				int cur = _node[p].fail;
				while (cur != -1 && _node[cur].next[i] == -1) {
					cur = _node[cur].fail;
				}
				if (cur == -1) {
					_node[_node[p].next[i]].fail = 0;
				} else {
					_node[_node[p].next[i]].fail = _node[cur].next[i];
				}
//			} else {
//				int cur = _node[p].fail;
//				while (cur != -1 && _node[cur].next[i] == -1) {
//					cur = _node[cur].fail;
//				}
//				if (cur == -1) {
//					_node[p].next[i] = 0;
//				} else {
//					_node[p].next[i] = _node[cur].next[i];
//				}
			}
		}
	}
}
int vi[51000 + 11000];
int dist[10][10];

void bfs(int st) {
	queue<int> qu;
	int tmp_st = safe_set[st];
	qu.push(tmp_st);
	memset(vi, -1, sizeof(vi));
	vi[tmp_st] = 0;
	while (!qu.empty()) {
		int p = qu.front();
		qu.pop();
		for (int i = 0; i < 2; i++) {
			int cur = p;
			//���Ӷ� ���˸�����
			while (cur != -1 && _node[cur].next[i] == -1) {
				cur = _node[cur].fail;
			}
			if (cur == -1) {
				int to_cur = 0;
				if (_node[to_cur].v == 0)
					continue;
				if (vi[to_cur] == -1) {
					vi[to_cur] = vi[p] + 1;
					qu.push(to_cur);
				}
			} else {
				int to_cur = _node[cur].next[i];
				if (_node[to_cur].v == 0)
					continue;
				if (vi[to_cur] == -1) {
					vi[to_cur] = vi[p] + 1;
					qu.push(to_cur);
				}
			}
		}
	}
	for (int i = 0; i < ec; i++) {
		if (_node[i].sfc != -1) {
			dist[st][_node[i].sfc] = vi[i];
		}
	}
}
int dp[11][1 << 11];
char str[51000];
char n_str[11][1100];
#define INF 0x3f3f3f3f
int main() {
	int n, m;
	while (scanf(" %d %d", &n, &m) == 2 && (n | m)) {
		memset(_node, -1, sizeof(_node));
		safe_set.clear();
		ec = 1;
		vector<int> dd;
		dd.clear();
		for (int i = 0; i < n; i++) {
			scanf(" %s", n_str[i]);
		}
		for (int i = 0; i < n; i++) {
			bool is_sub = false;
			for (int j = 0; j < n; j++) {
				if (i == j)
					continue;
				if (strstr(n_str[j], n_str[i])) {
					is_sub = true;
					break;
				}
			}
			if (!is_sub) {
				add_word(n_str[i], 1);
				dd.push_back(strlen(n_str[i]));
			}
		}
		n = dd.size();
		for (int i = 0; i < m; i++) {
			scanf(" %s", str);
			add_word(str, 0);
		}
		get_fail();

		memset(dist, 0x3f, sizeof(dist));
		for (int i = 0; i < n; i++) {
			bfs(i);
		}
		memset(dp, 0x3f, sizeof(dp));
		for (int i = 0; i < n; i++) {
			dp[i][1 << i] = dd[i];
		}

		for (int sta = 1; sta < (1 << n); sta++) {
			for (int j = 0; j < n; j++) {
				if (dp[j][sta] == INF)
					continue;
				for (int k = 0; k < n; k++) {
					dp[k][sta | (1 << k)] = min(dp[k][sta | (1 << k)],
							dp[j][sta] + dist[j][k]);
				}
			}
		}
		int ans = INF;
		for (int i = 0; i < n; i++) {
			ans = min(ans, dp[i][(1 << n) - 1]);
		}
		printf("%d\n", ans);
	}
	return 0;
}
