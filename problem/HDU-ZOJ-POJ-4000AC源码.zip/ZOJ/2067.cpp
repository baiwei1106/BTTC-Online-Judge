#include <iostream>
#include <string.h>
using namespace std;
char r[101][101];
int h[101][101];

int main()
{
	int i,j,k,n,min,sum;
	while(cin>>n)
	{
		for(i=0;i<n;i++)
			cin>>r[i];
		memset(h,0,sizeof(h));
		sum=0;
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				if(r[i][j]=='.')
				{
					if(i==0)	h[i][j]=1;
					else h[i][j]=h[i-1][j]+1;
				}
				min=10000000;
				for(k=j;k>=0;k--)
				{
					if(r[i][k]=='#')
						break;
					else if(min>h[i][k])
						min=h[i][k];
					sum+=min;
				}
			}
		}
		cout<<sum<<endl;
	}
	return 0;
}