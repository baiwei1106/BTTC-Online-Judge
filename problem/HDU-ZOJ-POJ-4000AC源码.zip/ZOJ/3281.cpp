#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include <queue>
#include <iostream>
#include <sstream>
using namespace std;

const int INF = 1000000;
const int maxn = 5000 + 5;

int n, m, p;
map<string, int> id;
vector<string> v[maxn];
char s0[300000], s1[53];
vector<int> e0[maxn], el[maxn], er[maxn];
vector<pair<int, int> > e[maxn];
int dist1[maxn], dist2[maxn], dep[maxn];
bool used[maxn];

void dfs(const vector<int> *el, int n, int dad, int deep, int a, int b) {
 dep[n] = deep;
 e[n].clear();
 if (dad >= 0) {
 e[n].push_back(make_pair(dad, a));
 }
 for (int i = 0; i < (int)e0[n].size(); ++i) {
 int x = e0[n][i];
 e[n].push_back(make_pair(x, b));
 dfs(el, x, n, deep + 1, a, b);
 }
 for (int i = 0; i < (int)el[n].size(); ++i) {
 e[n].push_back(make_pair(el[n][i], 2));
 }
}
void spfa(int *dist) {
 memset(used, 0, sizeof(used));
 for (int i = 0; i < m; ++i) {
 dist[i] = INF;
 }
 queue<int> que;
 que.push(0);
 used[0] = true;
 dist[0] = 0;
 while (!que.empty()) {
 int x = que.front();
 que.pop();
 used[x] = false;
 for (int i = 0; i < (int)e[x].size(); ++i) {
 int c = e[x][i].first;
 if (dist[c] > dist[x] + e[x][i].second) {
 dist[c] = dist[x] + e[x][i].second;
 if (!used[c]) {
 used[c] = true;
 que.push(c);
 }
 }
 }
 }
}
int main()
{
 while (scanf("%d%d", &n, &p) == 2) {
 id.clear();
 n *= p;
 scanf("%d", &m);
 for (int i = 0; i < m; ++i) {
 e0[i].clear();
 el[i].clear();
 v[i].clear();
 er[i].clear();
 
 scanf("%s", s0);
 id[string(s0)] = i;
 gets(s0);
 int len = 0;
 for (int j = 0; s0[j]; ++j) {
 if (s0[j] == ' ') {
 if (len == 0) continue;
 s1[len] = 0;
 v[i].push_back(string(s1));
 len = 0;
 } else {
 s1[len++] = s0[j];
 }
 }
 if (len > 0) {
 s1[len] = 0;
 v[i].push_back(string(s1));
 }
 }
// printf("-\n");
 for (int i = 0; i < m; ++i) {
 for (int j = 0; j < (int)v[i].size(); ++j) {
 if (id.find(v[i][j]) != id.end()) {
 e0[i].push_back(id[v[i][j]]);
 } else {
 sscanf(v[i][j].c_str() + 5, "%s", s0);
 if (id.find(string(s0)) == id.end()) while (1);
 el[i].push_back(id[string(s0)]);
 er[id[string(s0)]].push_back(i);
 }
 }
 }
 dfs(el, 0, -1, 0, 1, 2);
 spfa(dist1);
 dfs(er, 0, -1, 0, 2, 1);
 spfa(dist2);
 int ans = 0;
 for (int i = 0; i < m; ++i) {
 if (dist1[i] + dist2[i] <= n) {
 ans = max(ans, dep[i]);
 }
 }
 printf("%d\n", ans);
 }
 return 0;
}
