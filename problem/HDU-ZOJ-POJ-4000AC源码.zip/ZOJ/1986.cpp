#include <iostream>
#include <fstream>
#include <cstdlib>
#include <algorithm>
#include <cstring>
#include <climits>




using namespace std;

int P;
int array[50000];
int dp[50000];
int len;



int DP()
{

 dp[1]=array[0];
 len=1;

 for(int i=1;i<P;i++)
 {
 //printf("%d : ",i);
 if(array[i]>dp[len])
 {
 dp[++len]=array[i];
 }
 else
 {
 int lo=1,hi=len;
 int mid;

 while(lo<hi)
 {
 mid=(lo+hi)/2;
 if(dp[mid]>=array[i])
 {
 hi=mid-1;
 }
 else
 {
 lo=mid+1;
 }
 }
 mid=(lo+hi)/2;
 while(dp[mid]<=array[i] && mid<len)
 mid++;
 //printf("%d %d\n",mid,len);
 dp[mid]=array[i];

 }


 }


 return len;



}




int main()
{
 //freopen("input.txt","r",stdin);

 int n_case;
 scanf("%d",&n_case);


 while(n_case--)
 {
 scanf("%d",&P);
 for(int i=0;i<P;i++)
 {
 scanf("%d",&array[i]);
 }
 int res=DP();
 printf("%d\n",res);
 }













 return 0;
}
