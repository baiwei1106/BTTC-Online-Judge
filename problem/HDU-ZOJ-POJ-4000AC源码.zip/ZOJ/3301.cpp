#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
struct g
{
	int x,id;
}s[10100];
bool cmp(g a,g b)
{
	return a.x<b.x;
}
int main()
{
	int i,j,k,n,ri=0;
	while(scanf("%d",&n)!=EOF)
	{
		ri++;
		if(ri!=1)
			printf("\n");
		for(i=0;i<n;i++)
		{
			scanf("%d",&s[i].x);
			s[i].id=i;
		}
		sort(s,s+n,cmp);
		for(i=0;i<n/2;i++)
		{
			printf("%d %d\n",s[i*2].id+1,s[i*2+1].id+1);
		}
		}
}
