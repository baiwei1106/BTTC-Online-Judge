#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std ;

#define MAXNODE 50050
#define vi vector<int>
#define vvi vector< vi >
#define imax 1023456789

vvi costs ; //ok
int heights[ MAXNODE + 10 ] ; //ok
int P[ MAXNODE + 10 ] ;
int cost[ MAXNODE + 10 ] ;
int parent[ MAXNODE + 10 ] ;
vvi edges ; //ok
int mxHeight = 0 ; //ok
int nr ;


int getParent( int x , int y ) {
 while( P[ x ] != P[ y ] ) {
 if( heights[ x ] > heights[ y ] ) {
 x = P[ x ] ;
 }
 else {
 y = P[ y ] ;
 }
 }

 while( x != y ) {
 if( heights[ x ] > heights[ y ] ) {
 x = parent[ x ] ;
 }

 else {
 y = parent[ y ] ;
 }
 }

 return x ;
}

void depth( int cur , int height , int curCost ) {
 heights[ cur ] = height ;
 cost[ cur ] = curCost ;
 mxHeight = max( height , mxHeight ) ;

 for( int i = 0 ; i < edges[ cur ].size() ; i ++ ) {
 int nxt = edges[ cur ][ i ] ;

 if( heights[ nxt ] == -1 ) {
 parent[ nxt ] = cur ;
 int nxtCost = curCost + costs[ cur ][ i ] ;
 depth( nxt , height + 1 , nxtCost ) ;
 }
 }
}

void dfs( int cur ) {
 //cerr << cur << endl ;
 if( heights[ cur ] < nr ) {
 P[ cur ] = 0 ;
 }

 else if( ( heights[ cur ] % nr == 0 ) ) {
 P[ cur ] = parent[ cur ] ;
 }

 else {
 P[ cur ] = P[ parent[ cur ] ] ;
 }

 for( int i = 0 ; i < edges[ cur ].size() ; i ++ ) {
 int nxt = edges[ cur ][ i ] ;
 if( P[ nxt ] != -1 ) continue ;
 dfs( nxt ) ;
 }
}

int solve( int x , int y , int z ) {

 int ret = imax ;

 vector<int> v ;
 v.push_back( x ) ;
 v.push_back( y ) ;
 v.push_back( z ) ;

 sort( v.begin() , v.end() ) ;

 do {
 int pa = getParent( v[ 0 ] , v[ 1 ] ) ;
 int curTot = 0 ;
 curTot = cost[ v[ 0 ] ] - cost[ pa ] ;
 curTot += cost[ v[ 1 ] ] - cost[ pa ] ;

 int pb = getParent( pa , v[ 2 ] ) ;
 curTot += cost[ pa ] - cost[ pb ] ;
 curTot += cost[ v[ 2 ] ] - cost[ pb ];
// cerr << pa << " " << pb << endl ;
 ret = min( ret , curTot ) ;

 }while( next_permutation( v.begin() , v.end() ));
 /*
 vector<pair<int,int> > vp ;
 pair<int,int> p ;
 p.first = heights[ x ] ;
 p.second = x ;
 vp.push_back( p ) ;
 p.first = heights[ y ] ;
 p.second = y ;
 vp.push_back( p ) ;
 p.first = heights[ z ] ;
 p.second = z ;
 vp.push_back( p ) ;

 sort( vp.begin() , vp.end() ) ;

 int pa = getParent( vp[ 2 ].second , vp[ 1 ].second ) ;

 if( pa == vp[ 2 ].second ) {
 ret += cost[ vp[ 2 ].second ] - cost[ vp[ 1 ] ].second ;
 }

 else if ( pa == vp[ 1 ].second ) {
 ret += cost[ vp[ 1 ].second ] - cost[ vp[ 2 ].second ] ;
 }

 else {

 }

 */

 return ret ;
}

int main() {

 int N ;
 int cnt = 0 ;
 while( cin >> N ) {
 cnt ++ ;
 int u , v , c;
 edges = vvi ( N ) ;
 costs = vvi ( N ) ;
 memset( heights , -1 , sizeof( heights ) ) ;
 memset( P , -1 , sizeof( P ) ) ;
 mxHeight = 0 ;

 for( int i = 0 ; i < ( N - 1 ) ; i ++ ) {
 scanf("%d %d %d",&u,&v,&c) ;
 //parent[ v ] = u ;
 edges[ u ].push_back( v ) ;
 edges[ v ].push_back( u ) ;
 costs[ u ].push_back( c ) ;
 costs[ v ].push_back( c ) ;
 }
 //cerr << "here" << endl ;
 parent[ 0 ] = 0 ;
 depth( 0 , 0 , 0 ) ;
 //cerr << "h2" << endl ;
 int lim = sqrt( mxHeight ) ;
 nr = lim + 1 ;
 //cerr << nr << endl ;
 dfs( 0 ) ;
 // cerr << "h3" << endl ;
 int Q ;

 cin >> Q ;

 //int u , v , w ;
 int x , y , z ;

 if( cnt != 1 ) {
 cout << "\n" ;
 }
 for( int i = 0 ; i < Q ; i ++ ) {
 scanf("%d %d %d",&x,&y,&z) ;
 int res = solve( x , y , z ) ;
 cout << res << "\n" ;
 }
 }

 return 0 ;
}
