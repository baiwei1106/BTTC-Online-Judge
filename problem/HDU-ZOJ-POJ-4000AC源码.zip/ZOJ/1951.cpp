#include <stdio.h>
#include <math.h>

int prime(int x)
{
 int i;
 for(i=1;i<=sqrt(double(x));i++)
 { if(i!=1)
 {
 if(x%i==0)
 return 0;
 }
 
 }
 return 1;
}
int main()
{
 int n,i,s;
 while(scanf("%d",&n)!=EOF&&n)
 { 
 for(i=3;i<=n/2;i+=2)
 {
 if(prime(i))
 {
 s=n-i;
 if(prime(s))
 { printf("%d = %d + %d\n",n,i,n-i);
 break;
 }
 
 }
 }
 if(i>n/2)
 printf("Goldbach's conjecture is wrong."); 

 }
return 0;
} 
