#include <stdio.h>
#include <string.h>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

int a[1000];
int main()
{
 int i,j,n,T,s,x,y,z,ans;
 while(1)
 {
 scanf("%d",&n);
 if (n==-1) break;
 z=0;
 ans=0;
 for (i=0;i<n;i++)
 {
 scanf("%d%d",&x,&y);
 ans+=x*(y-z);
 z=y;
 }
 printf("%d miles\n",ans);
 }
 return 0;
}
