#include <iostream>
#include <cstring>
#include <cstdio>
#include <string>
#include <vector>
#include <cassert>
#include <map>
using namespace std;
const int Maxn = 300;
char str[Maxn];
vector<string> vec;
string to[Maxn];
bool same(int i, int j)
{
	if (islower(str[i]) && islower(str[j])) return true;
	return i == j;
}
map<string, int>mp;
int num;
int getNum(string str)
{
	if (str[0] == '+') return -1;
	else if (str[0] == '-') return -2;
	else if (str[0] == '*') return -3;
	else if (str[0] == '/') return -4;
	else if(str[0] == '(') return -5;
	else if (str[0] == ')') return -6;
	if (mp.find(str) != mp.end()) return mp[str];
	to[num] = str;
	return mp[str] = num++;
}
int rank(int x)
{
	switch(x)
	{
		case -1: 
		case -2: return 0;
		case -3:
		case -4 : return 1;
		default : return 2;
	}
}
int seq[Maxn], size;
int data[Maxn];
int tot;
void dfs(int &s)
{
	int op[Maxn], tot2 = 0;
	for (; s < size; ++s)
	{
		if (seq[s] == -5) 
		{
			s++;
			dfs(s);
			assert(seq[s] == -6);
		}
		else if(seq[s] >= 0) data[tot++] = seq[s];
		else if(seq[s] == -6) 
		{
			while (tot2) data[tot++] = op[--tot2];
			return;
		}
		else if(seq[s] < 0)
		{
			while (tot2)
			{
				if (op[tot2 - 1] <= -3) data[tot++] = op[--tot2];
				else
				{
					if (seq[s] > -3) data[tot++] = op[--tot2];
					else break;
				}
			}
			op[tot2++] = seq[s];
		}
	}
	while (tot2) data[tot++] = op[--tot2];
		
}
void init()
{
	tot = 0;
	int s = 0;
	int le = 0;
	int tmp2 = 0;
	for (int i = 0; i < size; assert(le >= 0),++i)
		if (seq[i] == -5)le++;
		else if(seq[i] == -6) le--;
		else if (seq[i] < 0) tmp2--;
		else tmp2++;
	assert(tmp2 == 1);
	//	cout << seq[i] <<" "; cout << endl;
	dfs(s);
	//assert(s == size);
	int tmp = 0;
	for (int i = 0; i < tot; ++i)
		if (data[i] >=0) tmp++;
		else tmp--;
	assert(tmp <= 1);
	//for (int i = 0; i < tot; ++i)
	//	cout << data[i] <<" ";
	//	cout << endl;
}
void add(vector<int> &ret, vector<int> &tmp)
{
	for (int i = 0; i < tmp.size(); ++i)
		ret.push_back(tmp[i]);
}
void out(vector<int> &ret)
{
	for (int i = 0; i < ret.size(); ++i)
		cout << ret[i] << " ";
	cout << endl;
}
pair<vector<int>, int> DFS(int &tot)
{
	vector<int> ret;
	//cout << data[tot] << endl;
	if (data[tot] >= 0) 
	{
		ret.push_back(data[tot]);
		--tot;
		return make_pair(ret, -5);
	}
	else
	{
		int o = data[tot--];
		pair<vector<int>, int> rig = DFS(tot);
		pair<vector<int>, int> lef = DFS(tot);
		
		//cout <<"--left" << endl;
		//out(lef.first);
		//cout <<"rigth :" << endl;
		//out(rig.first);
		if(rank(lef.second) < rank(o))
		{
			ret.push_back(-5);
			add(ret, lef.first);
			ret.push_back(-6);
		}
		else add(ret, lef.first);
		ret.push_back(o);
		if (rank(rig.second) < rank(o) || (rank(rig.second) == rank(o) && o % 2 == 0))
		{
			ret.push_back(-5);
			add(ret, rig.first);
			ret.push_back(-6);
		}
		else add(ret, rig.first);
		return make_pair(ret, o);
	}
}

int main()
{
	int T;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%s", str);
		mp.clear(); size = 0; num = 0;
		for (int i = 0, j = 0; str[i]; i = j)
		{
			string ret = "";
			for (; str[j] && same(i, j); ++j)
				ret += str[j];
			seq[size++] = getNum(ret);
		}
		init();
		tot--;
		vector<int> ans = DFS(tot).first;
		//assert(tot == -1);
		for (int i = 0; i < ans.size(); ++i)
		{
			int c = ans[i];
			if (c >= 0) printf("%s", to[c].c_str());
			else 
			{
				switch(c)
				{
					case -1: printf("+"); break;
					case -2 : printf("-"); break;
					case -3: printf("*"); break;
					case -4: printf("/"); break;
					case -5: printf("("); break;
					case -6: printf(")"); break;
				}
			}
		}
		puts("");
	}
	return 0;
}