#include<iostream>
#include<string>
using namespace std;

string decimalAdd(string a,string b)//
{
 if(a.length()<b.length())
  swap(a,b);
 int flag=0;
 string sum="";//此题中无需考虑小数相加会超过1；
 for(int i=a.length()-1;i>b.length()-1;i--)
 {
  sum=a[i]+sum;
 }
 for(int j=b.length()-1,k=b.length()-1;j>a.find('.',1)&&k>b.find('.',1);j--,k--)
 {
  if(a[j]+b[k]-96+flag>9)
  {   
   sum=char(a[j]+b[k]-48+flag-10)+sum;
   flag=1;
  }
  else
  {
   sum=char(a[j]+b[k]-48+flag)+sum;   
   flag=0;
  }
 }
 if(flag==0)
  return "0."+sum;
 return "1."+sum;
}

string decimalDivide(string a)// chuyi 8
{
 int flag=0;
 if(a.find('.',1)!=-1)
 {
  a.erase(0,2);
  flag=1;
 }
 int rest=a[0]-48,i=0;
 string result="";
 while(1)
 {
  result=result+char(rest/8+48);
  rest=(rest%8)*10;i++;
  if(i<=a.length()-1)
   rest+=a[i]-48;
  if(rest==0&&result.length()>a.length())
   break;
 }
 if(flag==0)
 {
  result.erase(0,1);
  return "0."+result;
 }
 return "0."+result;
}

string divide(char a,int flag)
{
 string result=" ",temp="0.0";
 result[0]=a;
 int rest=(a-48)*10;
 for(int i=0;i<flag;i++)
 {
  result=decimalDivide(result);
 }
 return result;
}

int main()
{
 string octal="",a;
 while(cin>>octal&&!cin.eof())
 {
  string result="0.0";
  for(int i=octal.find('.',1)+1;i<octal.length();i++)//flag=i-octal.find('.',1)
  {
   result=decimalAdd(divide(octal[i],i-octal.find('.',1)),result);
  }
 cout<<octal<<" [8] = "<<result<<" [10]"<<endl;
 }
 return 0;
}