#include<cstdio>
#include<cstring>
const int maxn=161;
double dp[maxn][maxn][maxn];
int n;
void work(int k)
{
		dp[1][2][k+1]+=0.5*dp[1][1][k];
		dp[2][1][k+1]+=0.5*dp[1][1][k];

		dp[1][n-1][k+1]+=0.5*dp[1][n][k];
		dp[2][n][k+1]+=0.5*dp[1][n][k];

		dp[n-1][1][k+1]+=0.5*dp[n][1][k];
		dp[n][2][k+1]+=0.5*dp[n][1][k];

		dp[n-1][n][k+1]+=0.5*dp[n][n][k];
		dp[n][n-1][k+1]+=0.5*dp[n][n][k];
		for(int i=2;i<n;i++)
		{			
			dp[1][i-1][k+1]+=dp[1][i][k]/3.0;
			dp[1][i+1][k+1]+=dp[1][i][k]/3.0;
			dp[2][i][k+1]+=dp[1][i][k]/3.0;

			dp[n][i-1][k+1]+=dp[n][i][k]/3.0;
			dp[n][i+1][k+1]+=dp[n][i][k]/3.0;
			dp[n-1][i][k+1]+=dp[n][i][k]/3.0;
			if(!(i==(n+1)/2&&k==1))
			{
				dp[i-1][1][k+1]+=dp[i][1][k]/3.0;
				dp[i+1][1][k+1]+=dp[i][1][k]/3.0;
				dp[i][2][k+1]+=dp[i][1][k]/3.0;
			}
			dp[i-1][n][k+1]+=dp[i][n][k]/3.0;
			dp[i+1][n][k+1]+=dp[i][n][k]/3.0;
			dp[i][n-1][k+1]+=dp[i][n][k]/3.0;
		}
}				
int main()
{
	while(~scanf("%d",&n))
	{
		memset(dp,0,sizeof(dp));
		dp[(n+1)/2][(n+1)/2][0]=1;
		for(int k=0;k<n;k++)
		{
			work(k);
			for(int i=2;i<n;i++)
				for(int j=2;j<n;j++)
				{
					if(i==(n+1)/2&&j==k)continue;
					dp[i][j+1][k+1]+=0.25*dp[i][j][k];
					dp[i][j-1][k+1]+=0.25*dp[i][j][k];
					dp[i+1][j][k+1]+=0.25*dp[i][j][k];
					dp[i-1][j][k+1]+=0.25*dp[i][j][k];
				}					
		}
		double ans=0;
		for(int i=1;i<=n;i++)
			ans+=dp[(n+1)/2][i][i];
		printf("%0.4lf\n",ans);
	}
	return 0;
}
