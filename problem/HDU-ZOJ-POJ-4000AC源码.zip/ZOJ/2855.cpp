#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <stack>
#include <queue>
#include <algorithm>
#include <cmath>
#include <map>
#include <set>
using namespace std;
const long double eps = 1e-100;
const long double Pi = acos(-1.0);

int main()
{
 long double a,b;
 int n;
 while(cin >> a >> b >> n)
 {
 long double x = a*Pi/180+eps;
 long double y = log(tan(Pi/4 + Pi*b/360))+eps;
 long double maxx = 180*Pi/180+eps, maxy = log(tan(Pi/4 + Pi*85/360))+eps;
 long double ox = eps,oy = eps;
 cout << 't';
 for(int i = 0 ; i < n ; i++)
 {
 //cout << x <<":" << y <<endl;
 //cout << maxx << "," << maxy <<endl;
 if(x-ox > eps && y-oy > eps)
 {
 cout << 'r';
 ox += maxx/2.0;
 oy += maxy/2.0;
 }
 else if(x-ox > eps && y-oy < -eps)
 {
 cout << 's';
 ox += maxx/2.0;
 oy -= maxy/2.0;
 }
 else if(x-ox < -eps && y-oy > eps)
 {
 cout << 'q';
 ox -= maxx/2.0;
 oy += maxy/2.0;
 }
 else if(x-ox < -eps && y-oy < -eps)
 {
 cout << 't';
 ox -= maxx/2.0;
 oy -= maxy/2.0;
 }
 maxx /= 2.0;
 maxy /= 2.0;
 }
 cout <<endl;
 }
	return 0;
}
