#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<algorithm>
#include<iostream>
#include<string>
#include<cmath>
#include<queue>
#include<vector>
#include<stack>
#include<map>
using namespace std;
double a[90][90],b[90][90],P[50];
bool cmp(double a,double b)
{
 return a>b;
}
int main()
{
 int i,j,T=0;
 while(cin>>P[1])
 {
 for(i=2;i<=11;i++)
 scanf("%lf",&P[i]);
 sort(P+1,P+12,cmp);
 int ok1=0,ok2=0;
 for(i=1;i<=11;i++)
 {
 if(P[i]!=100) ok1=1;
 if(P[i]!=0) ok2=1;
 P[i]/=100.0;
 //cout<<P[i]<<' ';
 }//cout<<endl;
 scanf("%lf",&P[0]);
 if(P[0]!=100) ok1=1;
 if(P[0]!=0)ok2=1;
 if(!ok1 || !ok2)
 {
 printf("0.0000\n");
 continue;
 }
 P[0]/=100.0;
 a[0][0]=b[0][0]=1.0;
 for(i=1;i<=5;i++)
 {
 a[i][0]=a[i-1][0]*(1.0-P[i]);//cout<<a[i][0]<<' ';
 for(j=1;j<i;j++)
 {
 a[i][j]=a[i-1][j-1]*P[i]+a[i-1][j]*(1.0-P[i]);//cout<<a[i][j]<<' ';
 }
 a[i][i]=a[i-1][j-1]*P[i];//cout<<a[i][i]<<endl;
 }
 for(i=1;i<=5;i++)
 {
 b[i][0]=b[i-1][0]*(1-P[0]);
 for(j=1;j<i;j++)
 {
 b[i][j]=b[i-1][j-1]*P[0]+b[i-1][j]*(1-P[0]);
 }
 b[i][i]=b[i-1][j-1]*P[0];
 }
 /*
 for(i=0;i<=5;i++)
 printf("%lf ",a[5][i]);cout<<endl;
 for(i=0;i<=5;i++)
 printf("%lf ",b[5][i]);cout<<endl;
 //*/
 double Win=0.0,lose=0.0,left=0;
 for(i=0;i<=5;i++)
 for(j=0;j<=5;j++)
 {
 if(i>j)
 Win+=a[5][i]*b[5][j];
 else if(i<j)
 lose+=a[5][i]*b[5][j];
 else left+=a[5][i]*b[5][j];
 }
 int cnt=5,A=5;
 double Win1=Win,lose1=lose;
 while(left>1e-9 && A<=15)
 {
 cnt++;
 A++;
 if(cnt==12) cnt=1;
 Win+=left*P[cnt]*(1-P[0]);
 lose+=left*P[0]*(1-P[cnt]);
 left=left*(P[cnt]*P[0]+(1-P[cnt])*(1-P[0]));
 }
 //cout<<Win<<' '<<Win1<<' '<<lose<<' '<<lose1<<' '<<left<<endl;
 if(left<1e-9)
 printf("%.4lf\n",Win*100.0);
 else printf("%.4lf\n",Win*100.0+(Win-Win1)/(Win-Win1+lose-lose1)*left*100.0);
 }
}
