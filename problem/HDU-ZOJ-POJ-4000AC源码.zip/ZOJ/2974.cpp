/*
 * Author: xioumu
 * Created Time: 2013/5/23 20:31:45
 * File Name: j.cpp
 * solve: j.cpp
 */
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
#include<set>
#include<iostream>
#include<vector>
#include<queue>

using namespace std;
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clr(x) memset(x,0,sizeof(x))
#define clrs( x , y ) memset(x,y,sizeof(x))
#define out(x) printf(#x" %d\n", x)
#define sqr(x) ((x) * (x))
typedef long long lint;

const int maxint = -1u>>1;
const double eps = 1e-8;
const int maxa = 20 + 10;

int sgn(const double &x) { return (x > eps) - (x < -eps); }

struct matrix {
 double ar[maxa][maxa];
 int n, m;
 matrix(int _n = 0, int _m = 0) {
 n = _n, m = _m;
 memset(ar, 0, sizeof(ar));
 }
 void clear() {
 clr(ar);
 }
 void set_one() {
 rep (i, n)
 rep (j, m)
 ar[i][j] = 0;
 rep (i, min(n, m)) {
 ar[i][i] = 1.0;
 }
 }
 void output() const {
 printf("%d %d\n", n, m);
 rep (i, n) {
 rep (j, m)
 printf("%.2f ", ar[i][j]);
 printf("\n");
 }
 }
};

matrix operator * (const matrix &a, const matrix &b) {
 matrix c;
 if (a.m != b.n) printf("a.m != b.n\n");
 c.clear();
 c.n = a.n;
 c.m = b.m;
 rep (i, a.n)
 rep (j, b.m)
 rep (k, a.m) {
 c.ar[i][j] += a.ar[i][k] * b.ar[k][j];
 //printf("%d %d: %f\n", i, j, a.ar[i][k] * b.ar[k][j]);
 }
 //a.output();
 //b.output();
 //c.output();
 //printf("===========\n");
 return c;
}

matrix s, change;
int n;

void init() {
 scanf("%d", &n);
 s.clear();
 s.n = n;
 s.m = 1;
 rep (i, n) {
 double tmp;
 scanf("%lf", &tmp);
 s.ar[i][0] = tmp;
 }
 change.clear();
 change.n = change.m = n;
 rep (i, n) {
 int k;
 scanf("%d", &k);
 rep (j, k) {
 int tmp;
 scanf("%d", &tmp);
 tmp--;
 change.ar[tmp][i] = 1.0 / k;
 }
 if (k == 0)
 change.ar[i][i] = 1.0;
 }
 //change.output();
}

void gao() {
 int m;
 matrix res;
 res = matrix(n, n);
 res.set_one();
 //res.output();
 scanf("%d", &m);
 while (m != 0) {
 if (m & 1) {
 res = res * change;
 }
 change = change * change;
 m >>= 1;
 }
 //s.output();
 //res.output();
 s = res * s;
 //s.output();
 rep (i, n) {
 if (i != 0) printf(" ");
 printf("%.2f", s.ar[i][0]);
 }
 printf("\n");
}

int main() {
 int T;
 scanf("%d", &T);
 while (T--) {
 init();
 gao();
 }
 return 0;
}
