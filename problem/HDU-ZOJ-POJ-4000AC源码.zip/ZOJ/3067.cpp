#include <cstdlib> 
#include <cctype> 
#include <cstring> 
#include <cstdio> 
#include <cmath> 
#include <algorithm> 
#include <vector> 
#include <string> 
#include <iostream> 
#include <sstream> 
#include <map> 
#include <set> 
#include <queue> 
#include <stack> 
#include <fstream> 
#include <numeric> 
#include <iomanip> 
#include <bitset> 
#include <list> 
#include <stdexcept> 
#include <functional> 
#include <utility> 
#include <ctime>
using namespace std;
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MEM(a,b) memset((a),(b),sizeof(a))
const int N = 1<<10;
int a[N];
int main()
{
	//freopen("input.txt","r",stdin);
	
	int n;
	while(cin >> n)
	{
		if(n == 0) break;
		int ans = 0;
		int cnt = 0;
		for(int i = 0; i < n; i++)
		{
			cin >> a[i];
			ans ^= a[i];
		}
		if(!ans)
		{
			cout << 0 << endl;
		}
		else
		{
			for(int i = 0; i < n; i++)
			{
				if((ans^a[i]) <= a[i])
				{
					cnt++;
				}
			}
			cout << cnt << endl;
		}
	}



	return 0;
}