#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include <queue>
using namespace std;
#define SZ(v) ((int)(v).size())
#define REP(i, n) for (int i = 0; i < (n); ++i) 
const int maxint = -1u>>1;
const int maxn = 50 + 4;
const double eps = 1e-9;
int sgn(double x) {
 return (x > eps) - (x < -eps);
}

int n[3];
char a[3][maxn];
char s[maxn];

double calc(int n, char *a) {
 double x = 0;
 int i = 1;
 while (i <= n && a[i] == a[1]) {
 if (a[i] == 'W') x += 1;
 else x -= 1;
 ++i;
 }
 int k = 2;
 while (i <= n) {
 if (a[i] == 'W') x += 1.0 / k;
 else x -= 1.0 / k;
 ++i;
 k <<= 1;
 }
 return x;
}
double calc() {
 for (int i = 0; i < 3; ++i) scanf("%d", &n[i]);
 for (int i = 0; i < 3; ++i) {
 for (int j = 1; j <= n[i]; ++j) {
 scanf("%s", s);
 a[i][j] = s[0];
 }
 }
 double sum = 0;
 for (int i = 0; i < 3; ++i) {
 sum += calc(n[i], a[i]);
 }
 return sum;
}
int main() {
 int t;
 scanf("%d", &t);
 while (t--) {
 scanf("\n");
 gets(s);
 printf("%s: ", s);
 double c1 = calc();
 double c2 = calc();
 if (sgn(c1 - c2) >= 0) printf("Yes\n");
 else printf("No\n");
 }
 return 0;
}
