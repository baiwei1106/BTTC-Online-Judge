#include <cstring>
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <bitset>
using namespace std;

const int N = 505;
const int M = 500 * 500;
const int INF = 1 << 29;
int map[256];
int n, m, s, t, a, b;
int ans[500], key[500];
char name[500][50];

void init() {
	for (int i = 0; i < 26; i++)
		map[i + 'A'] = i;
}

struct Edge {
	Edge* next, * pair;
	int v, cap, flow;

	void init(int v, int w, Edge* e1, Edge* e2) {
		this->v = v, this->cap = w, next = e1, pair = e2, flow = 0;
	}
};

struct Trie {
	int ch[100000][26];
	int val[100000];
	int sz;
	int id;
	
	void init() {
		sz = 1;
		id = 1;
		memset(ch[0], 0, sizeof(ch[0]));	
	}

	int find(char* s) {
		int u = 0;
		for (int i = 0; s[i]; i++) {
			int c = map[s[i]];
			if (s[i] < 'A' || s[i] > 'Z') while(1);
			if (!ch[u][c]) {
				memset(ch[sz], 0, sizeof(ch[sz]));
				val[sz] = 0;
				ch[u][c] = sz++;	
			}
			u = ch[u][c];
		}
		if (val[u] == 0)
			val[u] = id++;
		return val[u];
	}
}T;

struct Dinic {
	Edge E[M], * head[N], * used[N];
	int que[N], lev[N];
	int tot, maxFlow;

	void init() {
		for (int i = 0; i < n; i++) {
			head[i] = 0;
		}
		tot = 0;
	}

	void add(int u, int v, int w) {
		E[tot].init(v, w, head[u], &E[tot + 1]);
		head[u] = &E[tot++];
		E[tot].init(u, 0, head[v], &E[tot - 1]);
		head[v] = &E[tot++];
	}

	bool bfs() {
		for (int i = 0; i < n; lev[i++] = -1);
		int st = 0, ed = 0;
		que[ed++] = s;
		lev[s] = 0;
		while (st < ed) {
			int u = que[st++];
			for (Edge* e = head[u]; e; e = e->next) {
				int v = e->v;
				if (lev[v] == -1 && e->cap > e->flow) {
					lev[v] = lev[u] + 1;
					que[ed++] = v;
				}
			}
		}
		return lev[t] != -1;
	}

	int dfs(int u, int f) {
		if (u == t) return f;
		for (Edge* & e = used[u]; e; e = e->next) {
			int v = e->v;
			if (lev[v] == lev[u] + 1 && e->cap > e->flow) {
				int tmp = dfs(v, min(f, e->cap - e->flow));
				if (tmp > 0) {
					e->flow += tmp;
					e->pair->flow -= tmp;
					return tmp;
				}
			}
		}
		return 0;
	}

	void run() {
		maxFlow = 0;
		while (bfs()) {
			for (int i = 0; i < n; used[i] = head[i++]);
			for (int f = 0; f = dfs(s, INF); maxFlow += f);
		}
	}

	void solve() {
		int cnt = 0;
		for (int i = a + 1; i <= a + b; i++)
			if (lev[i] != -1)
				ans[cnt++] = i;
		printf("%d\n", cnt);
		for (int i = 0; i < cnt; i++)
			puts(name[ans[i]]);
		cnt = 0;
		for (int i = 1; i <= a; i++)
			if (lev[i] != -1)
				ans[cnt++] = i;
		printf("%d\n", cnt);
		for (int i = 0; i < cnt; i++)
			puts(name[ans[i]]);
	}

}G;

char str[50];
int cost[N];

int main() {
	int test, w, c, d, sum;
	scanf("%d", &test);
	init();
	while (test--) {
		scanf("%d", &a);
		T.init();
		for (int i = 1; i <= a; i++) {
			scanf("%s%d", name[i], &cost[i]);
			T.find(name[i]);
		}
		scanf("%d", &b);
		n = a + b + 2;
		s = 0, t = n - 1;
		G.init();
		sum = 0;
		for (int i = 1; i <= a; i++) {
			G.add(i, t, cost[i]);
		}
		for (int i = a + 1; i <= b + a; i++) {
			scanf("%s%d%d", name[i], &c, &d);
			T.find(name[i]);
			G.add(s, i, c);
			sum += c;
			for (int j = 0; j < d; j++) {
				scanf("%s", str);
				G.add(i, T.find(str), INF);	
			}
		}
		G.run();
		printf("%d\n", sum - G.maxFlow);
		G.solve();
		if (test) puts("");
	}
	return 0;
}