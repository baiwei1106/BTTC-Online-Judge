#include<iostream>
using namespace std;
int main()
{
 int t;cin>>t;
 while(t--)
 {
 int n;cin>>n;
 int st=n,en=n;long long ans=0;
 for(int i=1;i<=22000&&i<=n;i++)
 {
 st=n/i;ans+=(en-st)*(i-1);en=st;
 }
 for(int i=1;i<=en;i++)ans+=(int)n/i;
 ans=ans-n;
 cout<<ans<<endl;
 }
 return 0;
}
