#include<iostream>
#include<cstdio>
#include<memory.h>

using namespace std;

#define Clear(f, nr) memset(f, nr, sizeof(f))
const int SIZE =9;
const int INF = 1 << 30;

int G[SIZE][SIZE];
bool vis[SIZE][SIZE];
bool flag;
int move[5][2] = {{-1, 0}, {-1, 1}, {0, 1}, {1, 1}, {1, 0}};
int sum, m;
int up[SIZE];

bool Judge(int x, int y)
{
 if(x >= 0 && x < 8 && y >= 0 && y < 8 && !vis[x][y])
 return 1;
 return 0;
}

void dfs(int x, int y)
{
 if(flag || sum > m) return ;
 if(up[y] < m - sum) return ; //����
 //cout << x << ", " << y << endl;
 if(x == 7 && y == 7) {
 if(sum == m) flag = 1;
 //cout << sum << endl;
 return ;
 }
 for(int i = 0; i < 5; i ++) {
 int row = x + move[i][0];
 int col = y + move[i][1];
 if(Judge(row, col)) {
 vis[row][col] = 1;
 sum += G[row][col];
 dfs(row, col);
 sum -= G[row][col];
 vis[row][col] = 0;
 }
 }
}

int main()
{
 int T;
 scanf("%d", &T);
 while(T --) {
 scanf("%d", &m);
 Clear(up, 0);
 for(int i = 0; i < 8; i ++)
 for(int j = 0; j < 8; j ++) {
 scanf("%d", &G[i][j]);
 up[j] += G[i][j];
 }
 for(int j = 6; j >= 0; j --)
 up[j] += up[j + 1];
 flag = 0;
 Clear(vis, 0);
 sum = G[0][0];
 vis[0][0] = 1;
 dfs(0, 0);
 puts(flag ? "Yes" : "No");
 }
}
