#include<stdio.h>
#include<algorithm>
using namespace std;
struct node
{
 double time;
}p[10009];
int main()
{
 int n,i,j,v,st;
 while(scanf("%d",&n)!=EOF)
 {
 if(n==0) break;
 for(i=0,j=0;i<n;i++)
 {
 scanf("%d%d",&v,&st);
 if(st>=0)
 {
 // p[j].v=v,p[j].st=st;
 p[j].time=st+(4.5*3600)/v;
 j++;
 }
 }
 for(i=1;i<j;i++)
 {
 if(p[i].time<p[0].time) swap(p[i],p[0]);
 }
 if(p[0].time-(int)p[0].time==0)
 printf("%.0lf\n",p[0].time);
 else printf("%.0lf\n",p[0].time+1);
 }
}
