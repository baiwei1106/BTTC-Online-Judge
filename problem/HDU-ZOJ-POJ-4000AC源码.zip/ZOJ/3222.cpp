#include <stdio.h>
#include <string.h>
#include <algorithm>

#define clr(a,b) memset(a,b,sizeof(a))
using namespace std;
const int N = 310;
const int inf = 0x3f3f3f3f;
const int d = 100;

int n, m, h, w;
int mp[N][N], an[N][N];

int cal(int x, int y)
{
 int ans = -inf, t;
 for (int i=d+1; i<=n+d+h; i++)
 {
 for (int j=d+1; j<=m+d+w; j++)
 {
 t = mp[i][j]+mp[i-x][j-y]-mp[i-x][j]-mp[i][j-y];
 if (ans < t) ans = t;
 }
 }
 return ans;
}

int main()
{
 //freopen("D:/a.txt", "r", stdin);
 while (~scanf("%d%d%d%d", &n,&m,&h,&w))
 {
 clr(mp, 0); clr(an, 0);
 for (int i=101; i<=n+100; i++)
 for (int j=101; j<=m+100; j++)
 scanf("%d", &mp[i][j]), mp[i][j]+=mp[i-1][j]+mp[i][j-1]-mp[i-1][j-1];
 for (int i=1+d; i<=n+d; i++)
 for (int j=m+1+d; j<=m+w+d; j++)
 mp[i][j]+=mp[i-1][j]+mp[i][j-1]-mp[i-1][j-1];
 for (int i=n+d+1; i<=n+h+d; i++)
 for (int j=d+1; j<=m+w+d; j++)
 mp[i][j]+=mp[i-1][j]+mp[i][j-1]-mp[i-1][j-1];
 int ans = -inf;
 for (int i=1; i<w; i++)
 an[h][i] = cal(h, i);
 for (int i=1; i<h; i++)
 an[i][w] = cal(i, w);
 for (int i=1; i<w; i++)
 ans = max(ans, an[h][i]+an[h][w-i]);
 for (int i=1; i<h; i++)
 ans = max(ans, an[i][w]+an[h-i][w]);
 printf("%d\n", ans);
 }
 return 0;
}
