#include <iostream>
#include <cstdio>
#include <string>
#include <string.h>
#include <cstdlib>
using namespace std;

string a, b;
int ans;
bool pos[1000];

inline void judge(){
	int i, j;
	int la = a.size();
	int lb = b.size();
	// cout << la << " " << lb << endl;
	for (i=0;i<la;i++){
		bool exist = true;
		for (j=0;j<lb;j++)
			if (a[i+j] != b[j]){
				exist = false;
				break;
			}

		if (exist && !pos[i]){
			ans ++;
			pos[i] = true;
		}		
	}
}

int main(){

	while (cin >> a >> b){
		memset(pos, 0, sizeof(pos));
		ans = 0;
		int p = 0;
		int len = b.size();
		int i;
		for (p=0; p < len; p++){
			judge();
			string t;
			t = b.substr(1, len - 1);
			// cout << "t: " << t << endl;
			t += b[0];
			b = t;
			// cout << b << endl;
		}

		cout << ans << endl;
	}
	return 0;
}