#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
#define N 50005
int t,n;
vector< vector<int> > V(N); 

int ar[N];
int ans[N];
struct Node
{
 int low,mapp;
 int val,id;
 bool operator < (const Node& nde) const
 {
 return val>nde.val;
 }
}node[N];

void dfs(int u)
{
 node[u].low = t;
 
 for(int i=0;i<V[u].size();i++)
 dfs(V[u][i]);
	 				
 

 node[u].mapp = t++;
 
 	 
}
int lowbit(int x)
{
 return x&(-x); 	
}

void add(int x)
{
 for(int i=x;i<=n;ar[i]++,i+=lowbit(i)); 	 
}
int sum(int x)
{
 int s = 0;
 for(int i=x;i>0;s+=ar[i],i-=lowbit(i));
 return s; 	
}

int main()
{
 int x;
 while(scanf("%d",&n)!=EOF)
 {
 
	 memset(ar,0,sizeof(ar));
	 for(int i=0;i<n;i++)
		 V[i].clear();
	 node[0].id = 0;
 for(int i=1;i<n;i++)
 {
	 
 scanf("%d",&x);
 V[x].push_back(i);
		 node[i].id = i;
 }

 t = 1;
 	 dfs(0);
 	 
 	 for(int i=0;i<n;i++)
		 scanf("%d",&node[i].val);
	 sort(node,node+n);
	 for(int i=0,j=0;i<n;)
	 {
		 
	 while(j<n&&node[j].val==node[i].val)
		 {
			ans[node[j].id] = sum(node[j].mapp)-sum(node[j].low-1);
			j++;
		 }
		 while(i<j)
		 {
		 add(node[i].mapp);
			i++;
		 }
	 }
	 printf("%d",ans[0]);
	 for(int i=1;i<n;i++)
		 printf(" %d",ans[i]);
	 puts("");

	 							 
 }
 	 
}
