#include <cstdio>
#include <cstring>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>

using namespace std;

const int N = 100 ;

char s[N] ;

int main(){
 while (~scanf("%s",s)){
 int n = strlen(s) ;
 if (count(s,s+n,'Z')!=1){
 printf("Wrong Answer\n");
 continue ;
 }
 if (count(s,s+n,'J')!=1){
 printf("Wrong Answer\n");
 continue ;
 }
 int pz , pj , flag = 0 ;
 for (int i = 0 ; i < n ; i++){
 if (s[i]=='Z') pz = i ;
 if (s[i]=='J') pj = i ;
 if (s[i]!='Z' && s[i]!='J' && s[i]!='O') flag=1 ;
 }
 if (pz>pj || flag){
 printf("Wrong Answer\n");
 continue ;
 }
 int a = 0 , b = 0 , c = 0 ;
 a = pz ;
 b = pj - pz - 1 ;
 c = n - pj - 1 ;
 if (b > 0 && a + b == c)
 printf("Accepted\n");
 else
 printf("Wrong Answer\n");
 }
 return 0 ;
}
