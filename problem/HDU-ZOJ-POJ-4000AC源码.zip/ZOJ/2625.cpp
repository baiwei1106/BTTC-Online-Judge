#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
using namespace std;

int num[128][256];

void add(int a,int b,int c)
{
	int n;
	int bit=0;
	int i;
	for(i=0;i<=200;i++)
	{
 	n=num[a][i]*a+num[b][i]*b+bit;
 num[c][i]=n%10;
 	bit=n/10;
	}
}

int main() 
{
	int i,j,m;
	memset(num,0,sizeof(num));
	num[1][0]=0;
	num[2][0]=1;
	num[3][0]=3;
	for(i=4;i<=100;i++)
 	add(i-1,i-2,i);
	while(cin >> m)
	{
 	if(m==0||m==1)
 		cout << "0" ;
 	for(i=200;i>=0;i--)
 		if(num[m][i]!=0)break;
 	for(j=i;j>=0;j--)
 		 cout << num[m][j];
 	cout << endl;
	}
	return 0;
}

