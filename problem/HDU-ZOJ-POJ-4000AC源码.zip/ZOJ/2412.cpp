#include<cstdio>
#include<cstring>

int fa[55*55],N,M;
int find(int x) {return fa[x]==-1? x:fa[x]=find(fa[x]);}
char map[55][55];

void init()
{
 memset(fa,-1,sizeof(fa));
}

void read()
{
 for(int i=0;i<N;++i) scanf("%s",map[i]);
}
int s[11][4]={{1,0,1,0},{1,0,0,1},{0,1,1,0},{0,1,0,1},{1,1,0,0},{0,0,1,1},{1,0,1,1},{1,1,1,0},
 {0,1,1,1},{1,1,0,1},{1,1,1,1}};

void Union(int a,int b)
{
	int p=find(a),q=find(b);
	if(p!=q) fa[q]=p;
}

int work()
{
	int ans=0;
	
	for(int i=0;i<N;++i)
		for(int j=0;j<M;++j)
		{
			if(j>0 && s[map[i][j]-'A'][2]+s[map[i][j-1]-'A'][3]==2) Union(i*M+j,i*M+j-1);
			if(i>0 && s[map[i][j]-'A'][0]+s[map[i-1][j]-'A'][1]==2) Union(i*M+j,(i-1)*M+j);
		}
	
	for(int i=0;i<N;++i)
		for(int j=0;j<M;++j) 
		{
			find(i*M+j);
			if(fa[i*M+j]==-1) ++ans;
		}
	
	return ans;
}

int main()
{
 while(~scanf("%d%d",&N,&M) && N+M!=-2)
 {
 init();
 read();
 printf("%d\n",work());
 }
	return 0;
}
