#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;
#define N 55
#define EPS 1e-7

const double PI = acos(-1.0);

int sgn(double a)
{
 return (a > EPS) - (a < -EPS);
}

struct Po
{
 double x, y;
 Po(double a = 0, double b = 0)
 {
 x = a;
 y = b;
 }
 Po operator +(const Po & a) const
 {
 return Po(x + a.x, y + a.y);
 }
 Po operator -(const Po & a) const
 {
 return Po(x - a.x, y - a.y);
 }
 Po vect(double a) const // return a vector of length a
 {
 a /= sqrt(x * x + y * y);
 return Po(x * a, y * a);
 }
 Po left() const // rotate 90 degrees
 {
 return Po(-y, x);
 }
};

struct Seg
{
 Po s,e;
 Seg(){}
 Seg(Po a,Po b){s=a;e=b;}
};

struct Line
{
 double a,b,c;
 Line(double x=1,double y=-1,double z=0){a=x;b=y;c=z;}
 Line(Po p1,Po p2)
 {
 int sig=1;
 a=p2.y-p1.y;
 if(a<0) {a=-a;sig=-1;}
 b=sig*(p1.x-p2.x);
 c=sig*(p1.y*p2.x-p1.x*p2.y);
 }
};

double xm(Po a,Po b,Po c) // (ab)X(ac)
{
 return (b.x-a.x)*(c.y-a.y)-(c.x-a.x)*(b.y-a.y);
}

double dm(Po a,Po b,Po c) // (ab)*(ac)
{
 return (b.x-a.x)*(c.x-a.x)+(b.y-a.y)*(c.y-a.y);
}

double dis(Po a,Po b)
{
 return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}

// angle sort
bool posy(Po &a)
{
 if(a.y>0||(a.y==0&&a.x>0))
 return 1;
 return 0;
}



bool Linecross(Line l1,Line l2,Po &p)
{
 double d=l1.a*l2.b-l2.a*l1.b;
 if(fabs(d)<EPS) // ���ཻ���غ�
 return false;
 p.x=(l2.c*l1.b-l1.c*l2.b)/d;
 p.y=(l2.a*l1.c-l1.a*l2.c)/d;
 return true;
}


//p1 X p2 > 0 return intersec-points'number
int cli(Po cp,double r, Po l1,Po l2,Po& p1,Po& p2)
{
 Po p=cp+(l2-l1).left(),rp;
 p.x+=l1.y-l2.y;
 p.y+=l2.x-l1.x;
 Linecross(Line(p,cp),Line(l1,l2),rp);
 double d=dis(rp,cp);
 if(sgn(d-r)>0) return 0;
 double t;
 if(sgn(d-r)==0) t=0;
 else t=sqrt(r*r-d*d);
 p1=rp-(rp-cp).left().vect(t);
 p2=rp+(rp-cp).left().vect(t);
 return 2;
}

bool inrec(Po a,Po b,Po p)
{
 if(sgn(p.x-a.x)>0&&sgn(b.x-p.x)>0&&sgn(p.y-a.y)>0&&sgn(b.y-p.y)>0)
 return true;
 return false;
}

double midang(double a,double b)
{
 if(b<a)
 b+=2*PI;
 double md=(a+b)/2;
 if(md>PI) md-=2*PI;
 return md;
}

struct FK
{
 double a;
 int dt;
 FK(double b=0,int d=0)
 {
 a=b;
 dt=d;
 }
};

int fkcmp(FK a,FK b)
{
 if(sgn(b.a-a.a)>0)
 return 1;
 if(sgn(b.a-a.a)==0)
 return a.dt>b.dt;
 return 0;
}

int main()
{
 double r;
 int n;
 while(scanf("%lf%d",&r,&n)==2)
 {
 double x1[N],x2[N],y1[N],y2[N];
 for(int i=0;i<n;i++)
 {
 scanf("%lf%lf%lf%lf",&x1[i],&y1[i],&x2[i],&y2[i]);
 }
 int ok=0;
 for(int i=0;i<n;i++)
 {
 if(x1[i]-EPS<=-r&&x2[i]>=r-EPS&&y1[i]-EPS<=-r&&y2[i]>=r-EPS)
 {
 printf("%.3lf\n",2*r*PI);
 ok=1;
 break;
 }
 }
 if(ok) continue;
 vector<FK> vec;
 for(int i=0;i<n;i++)
 {
 vector<double> tmp;
 Po p1,p2;
 if(cli(Po(0,0),r,Po(x1[i],y1[i]),Po(x2[i],y1[i]),p1,p2)==2)
 {
 if(dm(p1,Po(x1[i],y1[i]),Po(x2[i],y1[i]))<EPS)
 tmp.push_back(atan2(p1.y,p1.x));
 if(dm(p2,Po(x1[i],y1[i]),Po(x2[i],y1[i]))<EPS)
 tmp.push_back(atan2(p2.y,p2.x));
 }
 if(cli(Po(0,0),r,Po(x1[i],y2[i]),Po(x2[i],y2[i]),p1,p2)==2)
 {
 if(dm(p1,Po(x1[i],y2[i]),Po(x2[i],y2[i]))<EPS)
 tmp.push_back(atan2(p1.y,p1.x));
 if(dm(p2,Po(x1[i],y2[i]),Po(x2[i],y2[i]))<EPS)
 tmp.push_back(atan2(p2.y,p2.x));
 }
 if(cli(Po(0,0),r,Po(x1[i],y1[i]),Po(x1[i],y2[i]),p1,p2)==2)
 {
 if(dm(p1,Po(x1[i],y1[i]),Po(x1[i],y2[i]))<EPS)
 tmp.push_back(atan2(p1.y,p1.x));
 if(dm(p2,Po(x1[i],y1[i]),Po(x1[i],y2[i]))<EPS)
 tmp.push_back(atan2(p2.y,p2.x));
 }
 if(cli(Po(0,0),r,Po(x2[i],y1[i]),Po(x2[i],y2[i]),p1,p2)==2)
 {
 if(dm(p1,Po(x2[i],y1[i]),Po(x2[i],y2[i]))<EPS)
 tmp.push_back(atan2(p1.y,p1.x));
 if(dm(p2,Po(x2[i],y1[i]),Po(x2[i],y2[i]))<EPS)
 tmp.push_back(atan2(p2.y,p2.x));
 }
 int sz=tmp.size();
 sort(tmp.begin(),tmp.end());
 for(int j=0;j<sz;j++)
 {

 double ma=midang(tmp[j],tmp[(j+1)%sz]);
 Po pp(r*cos(ma),r*sin(ma));
 //printf("%lf %lf\n",pp.x,pp.y);
 if(inrec(Po(x1[i],y1[i]),Po(x2[i],y2[i]),pp))
 {
 vec.push_back(FK(tmp[j],1));
 vec.push_back(FK(tmp[(j+1)%sz],-1));
 if(tmp[(j+1)%sz]<tmp[j])
 {
 vec.push_back(FK(PI,-1));
 vec.push_back(FK(-PI,1));
 }

 }
 }
 //puts("**********************");
 }
 sort(vec.begin(),vec.end(),fkcmp);
 double ans=0;
 int cnt=0;
 for(int i=0;i<vec.size();i++)
 {
 // printf("%lf\n",vec[i].a);
 if(cnt)
 ans+=vec[i].a-vec[i-1].a;
 cnt+=vec[i].dt;
 }
 printf("%.3lf\n",ans*r);
 }
 return 0;
}

