#include<stdio.h>
const unsigned long long inf=(1<<63)-1+(1<<63);
typedef unsigned long long ll;
int n,m;
ll a[20];
ll ans;
ll gcd(ll a,ll b)
{
 if(a<b) a=a^b,b=a^b,a=a^b;
 if(!b) return a;
 while(b)
 {
 ll t=a;
 a=b;
 b=t%b;
 }
 return a;
}
ll lcm(ll a,ll b)
{
 ll tmp=a/gcd(a,b);
 if(tmp>(inf/b))
 return inf;
 return tmp*b;
}
void dfs(ll flag,int x,ll num,ll b)
{
 if(flag&1)
 ans+=b/num;
 else
 ans-=b/num;
 for(int i=x+1;i<=n;i++)
 {
 dfs(flag+1,i,lcm(num,a[i]),b);
 }
 return;

}
ll solve(ll l,ll r)
{
 int i;
 ll result=0;
 ans=0;
 for(i=1;i<=n;i++)
 dfs(1,i,a[i],l);
 result+=ans;
 ans=0;
 for(i=1;i<=n;i++)
 dfs(1,i,a[i],r);
 result=ans-result;
 for(i=1;i<=n;i++)
 {
 a[i]=lcm(a[i],a[n+1]);
 }
 ans=0;
 for(i=1;i<=n;i++)
 dfs(1,i,a[i],l);
 result+=ans;
 ans=0;
 for(i=1;i<=n;i++)
 dfs(1,i,a[i],r);
 result-=ans;

 return result;
}
int main()
{
 int i;
 ll l,r;
 scanf("%d %d %llu %llu",&n,&m,&l,&r);
 while(!(n==0 && m==0 && l==0 && r==0))
 {
 for(i=1;i<=n;i++)
 {
 scanf("%llu",&a[i]);
 }
 a[n+1]=1;
 ll tmp;
 for(i=1;i<=m;i++)
 {
 scanf("%llu",&tmp);
 a[n+1]=lcm(a[n+1],tmp);
 }
 ll result=solve(l-1,r);
 printf("%llu\n",result);
 scanf("%d %d %llu %llu",&n,&m,&l,&r);
 }
 return 0;
}
