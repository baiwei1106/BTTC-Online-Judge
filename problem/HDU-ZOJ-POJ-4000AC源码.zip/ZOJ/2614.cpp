#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>
#include <string>
#include <cmath>
#define Mod (1000000009LL)
#define eps (1e-10)
#define Maxn 50
#define Pi (acos(-1.0))
using namespace std;
double T[Maxn],S[Maxn],C[Maxn],R[Maxn];
double a,b,h,tmp;
double x,ans;
int N;
double t;
int n;
long long D,H,B,L;
double d,l,b1;
double m;
double x1,x2,y;
double f(double x)
{
 return sqrt(1.0+4.0*m*m*x*x);
}
double Romberg(double a,double b)
{
 h=b-a;
 tmp=(f(a)+f(b))*h/2.0;
 T[0]=tmp;
 //printf("%.2lf %.2f\n",T[0],h);
 for(int i=0;i<N+3;i++)
 {
 tmp=0;
 x=a+h/2.0;
 while(x<b-eps)
 {
 tmp+=f(x);
 x+=h;
 }
 // printf("%.3f %.3f\n",T[i],h,tmp);
 T[i+1]=(T[i]+h*tmp)/2.0;
 h/=2.0;
 }
 for(int i=0;i<N+2;i++)
 S[i]=(4.0*T[i+1]-T[i])/3.0;
 //����������������˹��ת��
 for(int i=0;i<N+1;i++)
 C[i]=(16.0*S[i+1]-S[i])/15.0;
 //���п���˹���������ת��
 for(int i=0;i<N;i++)
 R[i]=(64.0*C[i+1]-C[i])/63.0;
 return R[N-1];
}
int main()
{
 N=10;
 int T1;
 scanf("%d",&T1);
 int cas=0;
 while(T1--)
 {
 scanf("%lld%lld%lld%lld",&D,&H,&B,&L);
 n=B/D;
 if(B%D) n++;
 d=(double)(D)/(double)(n);
 l=(double)(L)/(double)(n);
 b1=(double)(B)/(double)(n);
 b1/=2.0;
 //m=0;x1=Romberg(-b1,b1);
 //m=(double)(H)/(b1*b1);
 //x2=Romberg(-b1,b1);
 //if(x2<l-eps) while(1);
 for(x1=0.0,x2=(double)(H)/(b1*b1);x1<x2-eps;)
 {
 m=(x1+x2)/2.0;
 y=Romberg(-b1,b1);
 if(y>l) x2=m;
 else x1=m;
 }
 //printf("%d\n",n);
 ans=H-x1*b1*b1;
 printf("Case %d:\n",++cas);
 printf("%.2f\n",ans);
 if(T1) printf("\n");
 }
	return 0;
}
