#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

const int MAXN=1010;
struct Line
{
	int left,right;
};

Line line[MAXN];
int n,d,m,p,k,v,t1,t2;

bool cmp(Line a,Line b)
{
	if(a.left!=b.left) return a.left<b.left;
	return a.right<b.right;
}

int cal(int num,int time)
{
	int i,j;
	int shang=0;
	for(i=num;i<n;++i)
	{
		if(time<line[i].left-v*t1)
			time=line[i].left-v*t1;
		if(time+t1*v<=line[i].right)
		{
			shang+=d;
			time+=t1*v;
		}
	}
	return shang;
}

int main()
{
	int i,j,k;
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int i,j;
		int maxx=0;
		scanf("%d%d%d%d%d%d%d%d",&n,&d,&m,&p,&k,&v,&t1,&t2);
		for(i=0;i<n;++i) scanf("%d%d",&line[i].left,&line[i].right);
		sort(line,line+n,cmp);
		int time=k;
		int sum=0;
		for(i=0;i<n;++i)
		{
			maxx=max(maxx,sum+cal(i,time+t2*v)+m*p/(time+t2*v)/(time+t2*v));
			if(time<line[i].left-v*t1)
				time=line[i].left-v*t1;
			if(time+t1*v<=line[i].right)
			{
				sum+=d;
				time+=t1*v;
			}
		}
		maxx=max(maxx,sum+m*p/(time+t2*v)/(time+t2*v+k));
		cout<<maxx<<endl;
	}
}
