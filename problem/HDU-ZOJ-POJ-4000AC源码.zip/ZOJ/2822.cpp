//����:1.���ܱ�֤���ظ�,����13 3 ������3+5 + 5����
#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <queue>
#include <map>
#include <algorithm>
#include <memory.h>
#include <cmath>
#include <cstdlib>

using namespace std;
bool prime[1300];
int f[300][1300][15],
 p[300],n,l,K,len;
int main()
{
 //freopen("i.txt","r",stdin);
 memset(prime,0,sizeof(prime));
 l=1;
 for(int i=2;i<1300;i++) prime[i]=1;

 for(int i=2;i<1300;i++){
 if(prime[i]){
 p[l++]=i;
 for(int j=i+1;j<1300;j++){
 if(j%i==0)
 prime[j]=0;
 }
 }
 }

 while(cin>>n>>K){
 if(!n&&!K)
 break;
 memset(f,0,sizeof(f));
 for(int i=1;i<l;i++) {
 if(p[i]>n){
 len=i-1;
 break;
 }
 //cout<<p[i]<<endl;
 }

 for(int i=0;i<=len;i++)
 f[i][0][0]=1;

 for(int i=1;i<=len;i++){
 for(int j=2;j<=n;j++){
 for(int k=1;k<=K;k++){
 f[i][j][k]=f[i-1][j][k];
 if(j-p[i]>=0){
 f[i][j][k]+=f[i-1][j-p[i]][k-1];
// if(i==3&&j==8&&k==2){
// cout<<f[i-1][j][k]<<" "<<f[i][j-p[i]][k-1]<<endl;
// cout<<i<<" "<<j-p[i]<<" "<<k-1<<endl;
// }
 }
 //cout<<f[5][2][1]<<endl;
 //if(i==3&&j==13&&k==3){

 }
 }
 }
 //cout<<p[3]<<endl;
 cout<<f[len][n][K]<<endl;
 }

 return 0;
}
