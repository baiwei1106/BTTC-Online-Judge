#include <cstdio>

long long f[11][301][2][2], ans[301];

void solve() {
	f[0][0][0][0] = 1;
	for(int i = 0; i < 10; ++i) {
		for(int j = 0; j <= 300; ++j) {
			for(int a = 0; a < 2; ++a) {
				for(int b = 0; b < 2; ++b) {
					long long p = f[i][j][a][b];
					if(p) {
						f[i + 1][j + 10 + (a + b) * 10][1][a] += p;
						for(int c = 0; c < 10; ++c) {
							f[i + 1][j + 10 + (a + b) * c + a * (10 - c)][0][1] += p;
						}
						for(int c = 0; c < 10; ++c) {
							for(int d = 0; d < 10 - c; ++d) {
								f[i + 1][j + c + d + (a + b) * c + a * d][0][0] += p;
							}
						}
					}
				}
			}
		}
	}
	for(int i = 0; i <= 300; ++i) {
		for(int a = 0; a < 2; ++a) {
			for(int b = 0; b < 2; ++b) {
				if(f[10][i][a][b] == 0) {
					continue;
				}
				long long p = f[10][i][a][b];
				if(a == 0) {
					if(b == 0) {
						ans[i] += p;
					} else {
						for(int k = 0; k <= 10; ++k) {
							ans[i + k * b] += p;
						}
					}
				} else {
//					for(int c = 0; c <= 10; ++c) {
//						for(int d = 0; d <= 10; ++d) {
//							ans[i + (a + b) * c + a * d] += p;
//						}
//					}
					for(int c = 0; c <= 10; ++c) {
						ans[i + (a + b) * 10 + c * a] += p;
					}
					for(int c = 0; c < 10; ++c) {
						for(int d = 0; d <= 10 - c; ++d) {
							ans[i + (a + b) * c + a * d] += p;
						}
					}
				}
			}
		}
	}
}

int main() {
	solve();
//	for(int i = 0; i <= 300; ++i) {
//		printf("%lld\n", ans[i]);
//	}
//	puts("");
	
	int n;
	while(scanf("%d", &n) != EOF) {
		printf("%lld\n", ans[n]);
	}
}