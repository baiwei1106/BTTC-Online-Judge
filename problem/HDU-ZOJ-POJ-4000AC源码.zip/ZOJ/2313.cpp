#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <algorithm> 
using namespace std;

void jianyi(char s[],int len){
	if(s[len-1]>'0')s[len-1]--;
	else {
		s[len-1]='9';
		jianyi(s,len-1);
	}
}

void chuer(char s[],int len,char shang[]){
	shang[0] = (s[0]-48)/2+48;
	int yu;
	if(s[0]%2 == 0)yu = 0;
	else yu = 1;
	
	for(int i=1;i<len;i++){
		shang[i] = (yu*10+s[i]-48)/2+48;
		if(s[i]%2 == 0)yu = 0;
		else yu = 1;
	}
	
	shang[len] = 0;
}

void quling(char s[],int len){
	if(s[0] == '0'){
		if(len == 1)return;
		for(int i=1;i<=len;i++)s[i-1] = s[i];
		quling(s,len-1);
	}
}

int main(){
	int n;
	scanf("%d",&n);{
		while(n--){
			char s[2100],shang[2100];
			scanf("%s",s);
			int len = strlen(s);
			if(s[len-1]%2 == 1){
				jianyi(s,len);
				chuer(s,len,shang);
			}
			else{
				chuer(s,len,shang);
				jianyi(shang,len);
				if(shang[len-1]%2 == 0){
					jianyi(shang,len);
				}
			}
			quling(shang,len);
			printf("%s\n",shang);
			if(n>0)printf("\n");
		}
	}
}
