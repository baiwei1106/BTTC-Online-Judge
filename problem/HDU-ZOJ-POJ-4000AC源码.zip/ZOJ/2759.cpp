#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{
 int n,a[100],b[100],i,j,k,l,m;
 while(scanf("%d",&n)!=EOF)
 {
 for(i=j=0,k=3,l=1;n>0;)
 {
 m=n%k;
 if(m>0&&m<=l) b[j++]=l;
 else if(m>l&&m<=(l<<1)) a[i++]=l;
 n-=l;
 l=k;
 k*=3;
 }
 if(i==0) printf("-1\n");
 else
 {
 printf("%d",a[0]);
 for(k=1;k<i;k++) printf(" %d",a[k]);
 printf("\n");
 }
 if(j==0) printf("-1\n");
 else
 {
 printf("%d",b[0]);
 for(k=1;k<j;k++) printf(" %d",b[k]);
 printf("\n");
 }
 printf("\n");
 }
}
