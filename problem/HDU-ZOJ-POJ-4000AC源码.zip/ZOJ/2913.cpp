#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <queue>
#define rep(i,n) for(int i=0;i<n;i++)
#define F first
#define S second
#define mp make_pair
#define LL long long
#define pb push_back
#define inf 0x3fffffff
using namespace std;

int T;
int n,m;
vector <int> p[10005];
vector <int> pas;
int dis[10005],vis[10005],ma[10005];

queue <int> q;
void bfs(int st)
{
 while(!q.empty())q.pop();
 memset(vis,0,sizeof(vis));
 rep(i,10005)dis[i]=inf;
 dis[st] = 0;
 vis[st] = 1;
 q.push(st);
 while(!q.empty())
 {
 int st = q.front();
 q.pop();
 for(int i=0;i<p[st].size();i++)
 {
 int en = p[st][i];
 if(!vis[en])
 {
 dis[en] = dis[st] + 1;
 vis[en] = 1;
 q.push(en);
 }
 }
 }
}
int main()
{
 scanf("%d",&T);
 while(T--)
 {
 scanf("%d%d",&n,&m);
 rep(i,10005)p[i].clear();
 int st,en,num;
 rep(i,n)
 {
 scanf("%d%d",&st,&num);
 rep(j,num)
 {
 scanf("%d",&en);
 p[st].pb(en);
 }
 }
 pas.clear();
 rep(i,m)
 {
 scanf("%d",&num);
 rep(j,num)
 {
 scanf("%d",&st);
 pas.pb(st);
 }
 }
 rep(i,10005)ma[i] = 0;
 rep(i,pas.size())
 {
 bfs(pas[i]);
 rep(j,10005)
 ma[j] = max(ma[j],dis[j]);
 }
 int ret = inf , id = -1;
 rep(i,10005)
 {
 if(ma[i]<ret)
 {
 ret = ma[i];
 id = i;
 }
 }
 printf("%d %d\n",ret+1,id);
 }
}



