#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
#include<queue>
#include<vector>
#include<stdlib.h>
#define ll long long
using namespace std;
ll c[32][32],ans,l,n,m;
int main()
{
	c[0][0]=1;
	for (int i=1;i<=32;i++) c[i][i]=c[i][0]=1;
	for (int i=2;i<=32;i++)
		for (int j=1;j<=i;j++)
		c[i][j]=c[i-1][j]+c[i-1][j-1];
	for (int i=0;i<=32;i++)
		for (int j=1;j<=i;j++)
			c[i][j]+=c[i][j-1];
	while (~scanf("%lld%lld%lld",&n,&l,&m))
	{
		ans=0;
		while (n)
		{
			ans*=2;
			if (l>n-1) l=n-1;
			if (m>c[n-1][l]) 
			{
				m-=c[n-1][l];
				l--;
				ans++;
			}
			n--;
		}
		printf("%lld\n",ans);
	}
}