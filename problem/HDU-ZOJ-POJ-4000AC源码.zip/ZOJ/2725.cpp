#include <cstdlib> 
#include <cctype> 
#include <cstring> 
#include <cstdio> 
#include <cmath> 
#include <algorithm> 
#include <vector> 
#include <string> 
#include <iostream> 
#include <sstream> 
#include <map> 
#include <set> 
#include <queue> 
#include <stack> 
#include <fstream> 
#include <numeric> 
#include <iomanip> 
#include <bitset> 
#include <list> 
#include <stdexcept> 
#include <functional> 
#include <utility> 
#include <ctime>
using namespace std;
ifstream fin("aa.txt");
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MEM(a,b) memset((a),(b),sizeof(a))
#define BLANK(a) for(int i = 0; i < (a); i ++) printf(" ")
const int N = 1000000;
int a[N];

void init()
{
	MEM(a,0);
	for(int i = 1; i < N; i++)
	{
		if(a[i]) continue;
		for(int j = 1; j <= i; j*=10)
		{
			int t = i/j%10;
			t = 9-t;
			for(int k = 1; k <= t; k++)
			{
				a[i+k*j] = 1;
			}
		}
		int n = i;
		for(int j = 10; n*j < N; j*=10)
		{
			for(int k = 0; k < j/10; k++)
			{
				a[n*j+k] = 1;
			}
		}
	}
}
		

int main()
{
	char c[10];
	init();
	while(scanf("%s",c)!=EOF)
	{
		if(c[0] == '0') 
		{
			puts("Yes");
			continue;
		}
		int n;
		sscanf(c,"%d",&n);
		if(a[n]) puts("Yes");
		else puts("No");
	}
		
	
	
 return 0;
}