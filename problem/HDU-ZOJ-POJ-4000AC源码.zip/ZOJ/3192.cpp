#include<iostream>
#include<cstdio>
#include<string.h>
#include<cmath>
#include<algorithm>
using namespace std;

const int MAXN=10100;
struct node{
	int l,p;
}fra[MAXN];

bool cmp(node x,node y)
{
	if (x.p<y.p) return true;
	else return false;
}

int main()
{
	int n,i,ans,pre,now;
	scanf("%d",&n);
	while (n>0)
	{
		for (i=0;i<n;i++)	scanf("%d%d",&fra[i].l,&fra[i].p);
		sort(fra,fra+n,cmp);
		ans=1; pre=0; now=fra[0].p;
		for (i=1;i<n;i++)
		{
			if (now<=fra[i].p)
			{
				ans++; pre=now;
				if (now+fra[i].l<fra[i].p) now=fra[i].p;
				else now+=fra[i].l;
				continue;
			}
			if (pre+fra[i].l<now)
			{
				if (pre+fra[i].l<fra[i].p) now=fra[i].p;
				else now=pre+fra[i].l;
			}
		}
		printf("%d\n",ans);
		scanf("%d",&n);
	}
	return 0;
}
