#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;

int n, cd[22];
char ch[3];
int singer[22], pai[22];
int ts[2200000], used[1100000];
struct Tlst{
	int st, t;
}lst[1100000];

int get(char ch[]){
	if (strlen(ch)==2) return 7;
	if (ch[0]>='3' && ch[0]<='9') return ch[0]-'3';
	if (ch[0]=='J') return 8;
	if (ch[0]=='Q') return 9;
	if (ch[0]=='K') return 10;
	if (ch[0]=='A') return 11;
	if (ch[0]=='2') return 12;
	if (ch[0]=='L') return 13;
	if (ch[0]=='F') return 14;
	return -1;
}

bool init(){
	if (scanf("%d", &n) == EOF) return false;
	for (int i=0; i<n; i++) {
		scanf("%s", ch);
		cd[i] = get(ch);
	}
	return true;
}

void singstr(int val, int len, int pos, int st){
	if (len>=5) ts[++ts[0]] = st;
	for (int i=pos+1; i<n; i++){
		if (cd[i]>val+1||cd[i]>=12) return;
		if (cd[i]==val) continue;
		singstr(cd[i], len+1, i, st|(1<<i));
	}
}

void pairstr(int val, int len, int pos, int st){
	if (len>=3) ts[++ts[0]] = st;
	for (int i=pos+2; i<n; i++){
		if (cd[i]>val+1||cd[i]>=12) return;
		if (cd[i]!=cd[i-1]) continue;
		if (cd[i]==val) continue;
		pairstr(cd[i], len+1, i, st|((1<<i)+(1<<(i-1))));
	}
}

void withsing(int len, int st, int pos){
	if (len == 0){ 
		ts[++ts[0]] = st;
		return;
	}
	for (int i=pos; i<=singer[0]; i++){
		if (st&singer[i]) continue;
		withsing(len-1, st|singer[i], i+1);
	}
}

void withpair(int len, int st, int pos){
	if (len == 0){
		ts[++ts[0]] = st;
		return;
	}
	for (int i=pos; i<=pai[0]; i++){
		if (st&pai[i]) continue;
		withpair(len-1, st|pai[i], i+1);
	}
}

void tripstr(int val, int len, int pos, int st){
	ts[++ts[0]] = st;
	withsing(len, st, 1);
	withpair(len, st, 1);
	for (int i=pos+3; i<n; i++){
		if (cd[i]>val+1||cd[i]>=12) return;
		if (cd[i]!=cd[i-1]||cd[i]!=cd[i-2]) continue;
		if (cd[i]==val) continue;
		tripstr(cd[i], len+1, i, st|((1<<i)+(1<<(i-1))+(1<<(i-2))));
	}
}

bool cmp(int a, int b){return a>b;}

int solve(){
	if (n<=1) return n;
	sort(cd, cd+n);
	singer[0]=pai[0]=ts[0]=0;
	for (int i=0; i<n; i++) singer[++singer[0]] = (1<<i), singstr(cd[i], 1, i, (1<<i)), ts[++ts[0]] = singer[singer[0]];
	for (int i=1; i<n; i++) if (cd[i]==cd[i-1]) 
		pai[++pai[0]] = (1<<i) + (1<<(i-1)), pairstr(cd[i], 1, i, (1<<i)+(1<<(i-1))), ts[++ts[0]] = pai[pai[0]];
	for (int i=2; i<n; i++) if (cd[i]==cd[i-1] && cd[i]==cd[i-2])
		tripstr(cd[i], 1, i, (1<<i)+(1<<(i-1))+(1<<(i-2)));
	for (int i=3; i<n; i++) if (cd[i]==cd[i-1] && cd[i]==cd[i-2] && cd[i]==cd[i-3]){
		int st = (1<<i) + (1<<(i-1)) + (1<<(i-2)) + (1<<(i-3));
		ts[++ts[0]] = st;
		withsing(2, st, 1);
		withpair(2, st, 1);
	}
	if (cd[n-1]==14 && cd[n-2]== 13) ts[++ts[0]] = (1<<(n-1)) + (1<<(n-2));
	sort(ts+1, ts+ts[0]+1, cmp);
	memset(used, 0, sizeof used); used[0]=true;
	lst[0].st=0, lst[0].t=0;
	int head=0, tail=1;
	while (head<tail){
		int h=lst[head].st, ht=lst[head].t;
		for (int i=1; i<=ts[0]; i++) if ((h&ts[i])==0){
			int tst = (h|ts[i]);
			if (used[tst]) continue;
			if (tst == (1<<n)-1) return ht + 1;
			lst[tail].st = tst;
			lst[tail].t = ht + 1;
			used[tst] = true;
			tail++;
		}
		head++;
	}
//	cout<<"impossible"<<endl;
//	return -1;
}

int main(){
	while (init()) 
		printf("%d\n", solve());
	return 0;
}
