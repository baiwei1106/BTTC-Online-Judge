#include<stdio.h>
#include<iostream>
#include<vector>
#include<cstring>
#include<algorithm>
using namespace std;
int tian[1005];
int front1,rear1;
int king[1005];
int front2,rear2;
int N;
int solve()
{
 int rt=0;
 front1=front2=1;
 rear1=rear2=N;
 while(front1<=rear1)
 {
 if(tian[front1]>king[front2]) //���µ������µ���
 {
 rt+=200;
 front1++;
 front2++;
 continue;
 }
 if(tian[rear1]>king[rear2]) //���ϵ������ϵ���
 {
 rt+=200;
 rear1--;
 rear2--;
 continue;
 }
 if(tian[front1]<=king[front2] && tian[rear1]<=king[rear2]) //���µ������ϵ���
 {
 if(tian[front1]<king[rear2]) rt-=200;
 front1++;
 rear2--;
 continue;
 }
 }
 return rt;
}
int main()
{
 while(scanf("%d",&N)==1 && N)
 {
 for(int i=1;i<=N;i++)
 scanf("%d",&tian[i]);
 for(int i=1;i<=N;i++)
 scanf("%d",&king[i]);
 sort(tian,tian+N+1);
 sort(king,king+N+1);
 printf("%d\n",solve());
 }
 return 0;
}
