#include <iostream>
#include <stdio.h>
#include <string.h>
using namespace std;
#define N 20000
struct note
{
 int v,next;
}edge[N*4];

int head[N],kk;
int num[N],num2[N];
bool has[N];
void init()
{
 kk = 1;
 memset(num,0,sizeof(num));
 memset(num2,0,sizeof(num2));
 memset(head,-1,sizeof(head));
 memset(has,0,sizeof(has));
}

void add(int fa,int son)
{
 edge[kk].v = son;
 edge[kk].next = head[fa];
 head[fa] = kk++;
}

int main()
{
 int t;
 cin >> t;
 while(t--)
 {
 int n,m;
 cin >> n >> m;
 init();
 for(int i = 1;i <= n;i++ )has[i] = 1;
 for(int i = 0;i < m;i++)
 {

 int tt;
 cin >> tt;
 has[tt] = 0;
 int cc;
 cin >> cc;
 int ttt;
 while(cc--)
 {
 cin >> ttt;
 add(tt,ttt);
 }
 }
 while(true)
 {
 bool b = 0;
 memset(num,0,sizeof(num));
 for(int i = 1;i <= n;i++)
 {
 if(has[i] == 1) continue;
 else for(int j = head[i];j != -1;j = edge[j].next)
 {
 num[edge[j].v]++;
 if(has[edge[j].v] == 1)
 {
 has[i] = 1;
 // cout << i << " a ";
 b = 1;
 }
 }
 }

 for(int i = 1;i <= n;i++)
 {
 if(has[i] != 1 && num[i] == 0)
 {
 has[i] = 1;
 //cout << i << " b ";
 b = 1;
 }
 }
 if(!b) break;
 }
 int ans = n;
 for(int i = 1;i <= n;i++) ans -= has[i];
 cout << ans << "\n";
 }
 return 0;
}
