#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<numeric>
#include<cstdio>
#include<cmath>
using namespace std;
const int maxn = 21111;
int f[maxn],n,a[111];
inline int lowbit(int x)
{
	return x&(-x);
}
inline int cal(int n,int m)
{
	return f[n]-f[m]-f[n-m];
}
void init()
{
	int i,t,k=0;
	f[0]=0;
	for(i=1;i<=11111;++i)
	{
		k=0;
		t=i;
		while((t+1)&1)
			++k,t>>=1;
		f[i]=f[i-1]+k;
	}
}
void go(int n,int s,int &x,int &y)
{
	if(a[n-1]<2)
	{
		x=-1;
		y=0;
		return;
	}
	x=n+1;
	int t=cal(s,n);
	int b,c=0,cnt=0;
	for(int i=0;i<n;++i)
	{
		b=a[i];
		if(b)
		{
			while((b+1)&1)
				++c,b>>=1;
		}
	}
	y=c-t;
}
void gao(int n,int s,int &x,int &y)
{
	int c=s-a[0]+1;
	x=c;
	int cnt=count(a,a+n,a[0]);
	int t=cal(s,c-1);
	int k=0;
	while(cnt&&((cnt+1)&1))
		k++,cnt>>=1;
	y=k-t;
}
int main()
{
	init();
	int i,j;
	int x,y;
	while(~scanf("%d",&n))
	{
		int s=0;
		for(i=0;i<n;++i)
		{
			scanf("%d",a+i);
			s+=a[i];
		}
		sort(a,a+n);
		go(n,s,x,y);
		printf("%d\n%d\n",x,y);
		gao(n,s,x,y);
		printf("%d\n%d\n",x,y);
	}
	return 0;
}