#include <stdio.h>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

int N, M, K;
int p[5001];
long long sum[5001];

int find(int x)
{
 if(p[x] == -1) return x;
 int f = find(p[x]);
 sum[x] = sum[x] + sum[p[x]];
 p[x] = f;
 return f;
}

int main()
{
 while(~scanf("%d%d%d", &N, &M, &K))
 {
 for(int i = 0; i <= N; ++i) 
 {
 sum[i] = 0;
 //p[i] = i;
 }
 memset(p, -1, sizeof(p));
 for(int i = 1; i <= M; ++i)
 {
 int a, b;
 long long w;
 scanf("%d%d%lld", &a, &b, &w);
 --a;
 int fa = find(a);
 int fb = find(b);
 if(fa < fb)
 {
 p[fb] = fa;
 sum[fb] = sum[a] + w - sum[b];
 }
 if(fa > fb)
 {
 p[fa] = fb;
 sum[fa] = sum[b] - w - sum[a];
 }
 }
 for(int i = 1; i <= K; ++i)
 {
 int a, b;
 scanf("%d%d", &a, &b);
 --a;
 int fa = find(a), fb = find(b);
 if(fa != fb) puts("UNKNOWN");
 else printf("%lld\n", sum[b] - sum[a]);
 }
 puts("");
 }
 return 0;
}
