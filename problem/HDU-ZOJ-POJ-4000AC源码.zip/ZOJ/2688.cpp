#include<cstdio>
#include<iostream>
using namespace std;

const int X=1<<5;
const double inf=1e20;
double dp[X],a[10],b[X];
int main(){
 int i,j,k,n;
 double sum,as;
 while(scanf("%d",&n),n){
 as=-inf;
 for(i=0;i<X;i++)
 dp[i]=-inf;
 for(i=0;i<n;i++){
 for(j=0;j<5;j++)
 scanf("%lf",&a[j]);
 for(k=0;k<X;k++){
 sum=0;
 for(j=0;j<5;j++)
 if(k>>j&1)
 sum+=a[j];
 else
 sum-=a[j];
 j=k^X-1;
 as=max(as,dp[j]+sum);
 b[k]=sum;
 }
 for(k=0;k<X;k++){
 // printf("%.2lf ",b[k]);
 dp[k]=max(dp[k],b[k]);
 }
 }
 printf("%.2lf\n",as);
 }
 return 0;


}
