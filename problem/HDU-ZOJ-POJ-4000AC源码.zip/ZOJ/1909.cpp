#include <iostream>
#include <cstdio>
#include <string.h>
#include <algorithm>
using namespace std;
struct stick
{
 int len;
 int num;
}s[25];
int m,ave;

bool cmp( stick a,stick b )
{
	return a.len>b.len;
}

bool dfs( int rest,int sum,int index )
{
 int i;
 if( sum==ave ) return true;
 for( i=index;i<m;i++ )
 {
 if( s[i].num!=0 && s[i].len<=rest )
 {
 s[i].num--;
 if( rest==s[i].len )
 {
 if( dfs( ave,sum-rest,0 ) )
 return true;
 }
 else if( dfs( rest-s[i].len,sum-s[i].len,i ) )
 return true;
 s[i].num++;
 if( rest==ave ) return false;
 }
 }
 return false;
}

int main()
{
 int n,i,j,k,t,maxi,sum;
 scanf( "%d",&n );
 while( n-- )
 {
 scanf( "%d",&m );
		sum=0; k=0; maxi=-1;
 for( i=0;i<m;i++ )
 {
 scanf( "%d",&t );
 sum+=t ;
 for( j=0;j<k;j++ )
 {
 if( s[j].len==t )
 {
 s[j].num++;
 break;
 }
 }
 if( j==k )
 {
 s[k].len=t;
 s[k].num=1;
 k++;
 if( maxi<t ) maxi=t;
 }
 }
 m=k;
 ave=sum/4;
 if( sum%4!=0 || maxi>ave )
 printf( "no\n" );
 else
 {
 sort( s,s+m,cmp );
 if( dfs( ave,sum,0 ) ) printf( "yes\n" );
 else printf( "no\n" );
 }
 }
 return 0;
}
