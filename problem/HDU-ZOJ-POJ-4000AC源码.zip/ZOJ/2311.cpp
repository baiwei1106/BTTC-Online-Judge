#include<stdio.h>
#include<map>
#include<string.h>
#include<string>
#include<iostream>
#include<algorithm>
using namespace std;
map<string,int>se;
map<string,int>::iterator it;

void Insert()
{
	se.clear();
 se["negative"] = -1;
 se["zero"] = 0;
 se["one"] = 1;
 se["two"] = 2;
 se["three"] = 3;
 se["four"] = 4;
 se["five"] = 5;
 se["six"] = 6;
 se["seven"] = 7;
 se["eight"] = 8;
 se["nine"] = 9;
 se["ten"] = 10;
 se["eleven"] = 11;
 se["twelve"] = 12;
 se["thirteen"] = 13;
 se["fourteen"] = 14;
 se["fifteen"] = 15;
 se["sixteen"] = 16;
 se["seventeen"] = 17;
 se["eighteen"] = 18;
 se["nineteen"] = 19;
 se["twenty"] = 20;
 se["thirty"] = 30;
 se["forty"] = 40;
 se["fifty"] = 50;
 se["sixty"] = 60;
 se["seventy"] = 70;
 se["eighty"] = 80;
 se["ninety"] = 90;
 se["hundred"] = 100;
 se["thousand"] = 1000;
 se["million"] = 1000000;

}

int main()
{
	int tt,i,j,a[3],sum;
	char s[1000],str[100];
	Insert();
	while(gets(s))
	{
		if(strlen(s)==0)break; 
		memset(a,0,sizeof(a));
		int flag=1;
		j=sum=0;
		int len=strlen(s);
		s[len++]=' ';
		s[len]='\0';
		for(i=0;i<len;i++)
		{
			if(s[i]!=' ') str[j++]=s[i];
 else
 {
			 str[j]=0; 
 tt=se[str];
 j=0; 
 if(tt==-1)flag=-1;
 else if(tt==1000000)
		 {
				 a[0]=sum;
		 sum=0;
		 }
		 else if(tt==1000)
		 {
		 	a[1]=sum;
					sum=0;		 	
				}
				else if(tt==100)
					sum*=100;
				else sum+=tt;
		 }		 
	 }
		 printf("%d\n",flag*(a[0]*1000000+a[1]*1000+sum));
	}
	return 0;
} 