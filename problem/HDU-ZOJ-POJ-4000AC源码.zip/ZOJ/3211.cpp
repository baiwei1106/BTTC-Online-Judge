#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<map>
#include<string>
using namespace std;

struct NN
{
 int a,b;
}nn[2100];

int cmp(NN a,NN b)
{
 return a.b<b.b;
}
int dp[300][300];

int main()
{
 int t,n,m,i,j,k;
 int ans=0;

 scanf("%d",&t);
 while(t--)
 {
	ans=0;
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
	 scanf("%d",&nn[i].a);
	for(i=1;i<=n;i++)
	 scanf("%d",&nn[i].b);
	sort(nn+1,nn+1+n,cmp);

	memset(dp,0,sizeof(dp));
	for(i=1;i<=n;i++)
	{
	 for(j=1;j<=m;j++)
		dp[i][j]=max(dp[i-1][j],dp[i-1][j-1]+nn[i].a+nn[i].b*(j-1));
	}
	printf("%d\n",dp[n][m]);
 }
}