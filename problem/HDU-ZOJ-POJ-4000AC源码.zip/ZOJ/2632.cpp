#include <iostream>
#include <string.h>
#include <algorithm>
#include <cstdio>
using namespace std;

int n , x , y , ans , L , R;

int get_len( int L , int R ){ return( ( L/4+R/4 )*4 ); }

void work1()
{
				if ( L >= 4 || R >= 4 ) ans = 4;
				if ( L >= 3 && R >= 2 ) ans = max( ans , get_len( L-3 , R+2 ) );
				if ( R >= 3 && L >= 2 ) ans = max( ans , get_len( L+2 , R-3 ) ); 
}

void work2() 
{
				if ( L >=2 && R >= 2 ) ans = 4;
				if ( L >= 1 ) ans = max( ans , get_len( L-1 , R ) );
				if ( R >= 1 ) ans = max( ans , get_len( L , R-1 ) );
}

int main()
{
				while ( 1 )
				{
							scanf( "%d" , &n );
							if ( n == 0 ) break;
							scanf( "%d %d" , &x , &y );
							L = x; R = n-x;
							ans = 0;
							if ( y != 1 ) work2();
							else 		 work1();
							if ( ans == 0 ) printf( "wuwuwu\n" );
							else		 printf( "%d.00\n" , ans );
				}	
}
