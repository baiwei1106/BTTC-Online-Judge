#include <stdio.h>
#include <string.h>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

int a[1005];
int dp[1005];

int main()
{
 int i,j,n,T,s,x,y,z,ans,up;
 scanf("%d",&T);
 while(T--)
 {
 scanf("%d",&n);
 for (i=0;i<n;i++)
 {
 scanf("%d",&a[i]);
 }
 for (i=0;i<n;i++)
 {
 ans=0;
 for (j=0;j<i;j++)
 {
 if (a[i]>a[j]) ans=max(dp[j],ans);
 }
 dp[i]=ans+1;
 }
 ans=0;
 for (i=0;i<n;i++)
 {
 ans=max(ans,dp[i]);
 }
 printf("%d\n",ans);
 if (T>0) printf("\n");
 }
 return 0;
}
