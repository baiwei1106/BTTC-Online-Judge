#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#define maxn 1006
using namespace std;

char s1[maxn],s2[maxn];
struct bignum
{
 int len;
 int s[maxn];
};

void print(bignum x)
{
 for (int i = x.len; i >= 1; i--)
 {
 printf("%d", x.s[i]);
 }
 cout << endl;
}
bignum change(char *str)
{
 bignum x;
 x.len = strlen(str);
 for(int i = 1; i <= x.len; i++)
 {
 x.s[i] = str[ x.len - i ] - '0';
 }
//// for (int i = 1; i <= x.len; i++) cout << x.s[i];
//// cout << endl;
 return x;
}
bool small(bignum x ,bignum y)
{
 if(x.len < y.len) return true;
 if(x.len > y.len) return false;
 int i = x.len;
 while((x.s[i] == y.s[i]) && (i > 1))
 {
 i--;
 }
 if(x.s[i] <= y.s[i]) return true;
 else return false;
}
bignum sub(bignum a ,bignum b)
{
 bignum c;
 for (int i = 1, j = 0; i <= a.len; i++)
 {
 c.s[i] = a.s[i] - j;
 //cout << c.s[i] << endl;
 if (i <= b.len) c.s[i] -= b.s[i];
 if (c.s[i] < 0)
 {
 j = 1, c.s[i] += 10;
 }
 else j = 0;
 }
// for (int i = 1; i <= c.len; i++) cout << c << endl;
// cout << endl;
 c.len = a.len;
 while(c.len > 1 && c.s[ c.len ] == 0) c.len--;
 return c;
}
bignum mul(bignum a)
{
 int cnt = 0;bignum c;

 c.len = a.len;
 for(int i = 1; i <= a.len; i++)
 {
 c.s[i] = ( a.s[i] * 2 + cnt) % 10;
 cnt = ( a.s[i] * 2 + cnt) / 10;
 }
 // for (int i = 1; i <= c.len; i++) cout << c << endl;
// cout << endl;
 if( cnt > 0 )
 {
 c.s[++c.len] = cnt;
 }
 return c;
}

bignum div(bignum a)
{
 int cnt = 0;
 bignum c;
 c.len = a.len;
 for(int i = a.len; i >= 1; i--)
 {
 if( ( cnt * 10 + a.s[i] ) >= 2)
 {
 c.s[i] = ( cnt * 10 + a.s[i] ) / 2;
 cnt = ( cnt * 10 + a.s[i] ) % 2;
 }
 else
 {
 c.s[i] = 0;
 cnt = cnt * 10 + a.s[i];
 }
 }
 while( c.s[c.len] == 0 )c.len--;
 return c;
}

bignum gcd( bignum a, bignum b )
{
 int num = 0;
 while(a.len && b.len)
 {
 if(a.s[1] % 2)
 {
 if(b.s[1] % 2)
 {
 if(small(a,b)) b = sub ( b, a );
 else a = sub(a,b);
 }
 else b = div(b);
 }
 else
 {
 if(b.s[1] % 2) a = div(a);
 else
 {
 a = div(a);
 b = div(b);
 num++;
 }
 }
 if(b.len==1 && b.s[1]==0) break;
 if(a.len==1 && a.s[1]==0) break;
 }
 if(a.len)
 {
 while(num--) a = mul(a);
//// for (int i = 1; i <= a.len; i++)cout << a.s[i];
//// cout << endl;
 return a;

 }
 else
 {
 while(num--) b = mul(b);
//// for (int i = 1; i <= b.len; i++)cout << b.s[i];
//// cout << endl;
 return b;
 }
}



int main()
{
 //freopen("in.in","r",stdin);
 bool flag = false;
 while(~scanf("%s%s",s1,s2))
 {
 //cout << s1 <<endl;
 if(!flag) flag = true;
 else puts("");
 bignum a = change(s1);
 bignum b = change(s2);
 bignum c = gcd(a,b);
 print(c);
 }
 return 0;
}
