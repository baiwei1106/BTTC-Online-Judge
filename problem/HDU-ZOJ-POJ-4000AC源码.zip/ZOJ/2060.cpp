#include <stdio.h>
#include <string.h>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

int a[1005];
int ans[1000005];

int main()
{
 int i,j,n,T,s,x,y,z,up;
 ans[0]=7%3;
 ans[1]=11%3;
 for (i=2;i<1000002;i++)
 {
 ans[i]=(ans[i-1]+ans[i-2])%3;
 }
 while(scanf("%d",&n)!=EOF)
 {
 if (ans[n]==0) printf("yes\n");
 else printf("no\n");
 }
 return 0;
}
