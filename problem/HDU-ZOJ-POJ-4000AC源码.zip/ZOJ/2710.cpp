#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
struct point
{
 int x,y,need,choice;
 double h1,h2;
};

struct tmp
{
 int num;
 double cost;
};

point p[250];
tmp t[250];
double cmp(tmp a,tmp b)
{
 if(a.cost==b.cost)
 {
 return a.num<b.num;
 }
 else
 {
 return a.cost<b.cost;
 }

}
int main()
{
 int n;
 int c;
 int x1,y1,x2,y2;
 int x3,y3,x4,y4;
 double k1,k2,b1,b2;
 int temp1,temp2,xl1,xl2,cnt1,cnt2;
 while(cin>>n>>c)
 {
 cin>>x1>>y1>>x2>>y2;
 cin>>x3>>y3>>x4>>y4;
 temp1=temp2=0;
 cnt1=cnt2=0;
 if(x1==x2)
 {
 xl1=x1;
 temp1=1;
 }
 else
 {
 k1=(y2-y1)*1.0/(x2-x1);
 b1=y1*1.0-k1*x1;
 }
 if(x3==x4)
 {
 xl2=x3;
 temp2=1;
 }
 else
 {
 k2=(y4-y3)*1.0/(x4-x3);
 b2=y3*1.0-k2*x3;
 }
 for(int i=1; i<=n; i++)
 {
 cin>>p[i].x>>p[i].y>>p[i].need;
 if(temp1)
 {
 p[i].h1=fabs(xl1-p[i].x);
 }
 else
 {
 p[i].h1=fabs(k1*p[i].x-p[i].y+b1)/(sqrt(k1*k1+1));

 }
 if(temp2)
 {
 p[i].h2=fabs(xl2-p[i].x);
 }
 else
 {
 p[i].h2=fabs(k2*p[i].x-p[i].y+b2)/(sqrt(k2*k2+1));
 }
 if(p[i].h1<p[i].h2)
 {
 p[i].choice=1;
 cnt1++;
 }
 else
 {
 p[i].choice=2;
 cnt2++;
 }
 }
 if(abs(cnt1-cnt2)>c)
 {
 for(int i=1; i<=n; i++)
 {
 t[i].num=i;
 t[i].cost=fabs(p[i].h1-p[i].h2)*p[i].need;
 }
 sort(t+1,t+n+1,cmp);
 if(cnt1>cnt2)
 {
 for(int i=1; i<=n; i++)
 {
 if(p[t[i].num].choice==1)
 {
 p[t[i].num].choice=2;
 cnt1--;
 cnt2++;
 if(cnt1-cnt2<=c)
 {
 break;
 }
 }
 }
 }
 else if(cnt1<cnt2)
 {
 for(int i=1; i<=n; i++)
 {
 if(p[t[i].num].choice==2)
 {
 p[t[i].num].choice=1;
 cnt2--;
 cnt1++;
 if(cnt2-cnt1<=c)
 {
 break;
 }
 }
 }
 }
 }

 for(int i=1; i<n; i++)
 {
 cout<<p[i].choice<<" ";
 }
 cout<<p[n].choice<<endl<<endl;

 }
 return 0;
}
