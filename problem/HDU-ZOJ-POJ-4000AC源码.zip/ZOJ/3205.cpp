//============================================================================
// Name : D.cpp
// Author : 
// Version :
// Copyright : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<stdio.h>
using namespace std;
#define pmod 1000000007
#define LL long long
LL a[105][105],s[105],c[105],d[105],e[105];
LL ext_gcd(LL a,LL b,LL &x,LL &y)
{
	LL t,d;
	if(b==0){x=1;y=0;return a;}
	d=ext_gcd(b,a%b,x,y);
	t=x;
	x=y;
	y=t-a/b*y;
	return d;
}
LL Invmod(LL a)
{
	LL x,y;
	LL n=pmod;
	if(ext_gcd(a,n,x,y)!=1) return -1;
	return (x%n+n)%n;
}
int main() {
	int t,n,m,q;
	LL r,v,p;
	int i,j;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&m);
		for(i=0;i<n;++i)
		{
			for(j=0;j<=m;++j)
				scanf("%lld",&a[i][j]);
		}
		scanf("%d",&q);
		while(q--)
		{
			for(i=1;i<=m;++i)
				scanf("%lld",&c[i]);
			for(i=0;i<n;++i)
			{
				e[i]=0;
				d[i]=a[i][0];
				s[i]=a[i][0];

				for(j=1;j<=m;++j)
				{
					if(c[j]==0&&a[i][j]!=0)
						e[i]++;
					v=c[j];
					r=a[i][j];
					p=1;
					while(r)
					{
						if(r&1)
						{
							s[i]*=v;
							s[i]%=pmod;
							if(c[j])
							{
								d[i]*=v;
								d[i]%=pmod;
							}
						}
						v*=v;
						v%=pmod;
						r>>=1;
					}
				}
		//		printf("%lld\n",s[i]);
			}
			for(j=1;j<=m;++j)
			{

				v=0;
				for(i=0;i<n;++i)
				{
					if(c[j]==0)
					{
						if(a[i][j]==1&&e[i]==1)
						{
							v+=d[i];
							v%=pmod;
						}
					}
					else if(a[i][j])
					{
						p=1;
						p=(s[i]*a[i][j])%pmod;
				//		p/=c[j];
						p=(p*Invmod(c[j]))%pmod;
						v+=p;
						v%=pmod;
					}
		//			printf("%lld\n",p);
				}
				if(j!=1)
					printf(" ");
				printf("%lld",v);
			}
			printf("\n");
		}
		if(t)
			printf("\n");
	}
	return 0;
}
