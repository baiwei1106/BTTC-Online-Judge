#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <cstring>
using namespace std;
#define M 1000000
#define maxx 2000
#define N 1009
int a[20];
int check (int m) {
	int cn = 0;
	while (m) {
		if(a[m%10]) return 0;
		m /= 10;
		cn ++;
	}
	return cn;
}
int main () {
	int n, m;
	while (scanf ("%d", &n) != EOF) {
		memset (a, 0, sizeof(a));
		int u, v;
		for (int i = 1; i <= n; ++i) {
			scanf ("%d", &u);
			a[u] = 1;
		}
		scanf ("%d%d", &u, &v);
		int ans = abs(u - v);
		for (int i = 1; i <= M+M;++i) {
			int cn = check(i);
			if(cn) {
				ans = min(cn + 1 + abs(v - i), ans);
			}
		}
		printf("%d\n", ans);
	}
}