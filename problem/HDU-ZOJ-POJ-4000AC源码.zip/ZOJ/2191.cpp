#include <iostream>
using namespace std;	
int main()
{
	double f0,f1,f2,a,b,c,x,y,z;
	while(cin>>f0>>f1>>f2)
	{
		c=f0;
		a=((f2-f0)-(f1-f0)*2)/2;
		b=f1-a-c;
		x=9*a+3*b+c;
		y=16*a+4*b+c;
		z=25*a+5*b+c;
		cout<<x<<' '<<y<<' '<<z<<endl;
	}
	return 0;
}