#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cctype>

#include<cmath>
#include<iostream>
#include<fstream>

#include<string>
#include<utility>
#include<vector>
#include<queue>
#include<map>
#include<algorithm>
#include<set>
#include<sstream>
#include<stack>
#define ii long long int
#define pi 2*acos(0.0)
#define eps 1e-7
#define mem(x,y) memset(x,y,sizeof(x))
#define all(x) x.begin(), x.end()
#define pb push_back
#define sz(a) a.size()

using namespace std;

int a[40],n1,n,SUM;
vector <int> v1,v2;

void call1(int i)
{
 if (i>n1) { v1.pb(SUM); return; }
 call1(i+1);
 SUM+= a[i];
 call1(i+1);
 SUM-= a[i];
}

void call2(int i)
{
 if (i>n) { v2.pb(SUM); return; }
 call2(i+1);
 SUM+= a[i];
 call2(i+1);
 SUM-= a[i];
}

int main()
{
 /*
 vector <int> v;
 v.pb(10);v.pb(10);v.pb(15);v.pb(18);
 vector <int> :: iterator it;
 it= lower_bound(all(v),35);
 if (*(it)!=v[0]) cout<<">> "<<*(it-1)<<endl;
 */
 //freopen("in.txt","r",stdin);
 int t;
 scanf("%d",&t);
 while (t--)
 {
 v1.clear(); v2.clear();
 int sum= 0,mid;
 cin >> n;
 for (int i=1; i<=n; ++i) cin >>a[i],sum+= a[i];
 mid= sum/2;
 n1= n/2;
 SUM= 0;
 call1(1);
 int sz= sz(v1);
 //cout<<n1<<endl;
 //cout<<"sum: "<<sum<<endl;
 //cout<<"mid: "<<mid<<endl<<endl;
 //for (int i=0; i<sz; ++i) cout<<v1[i]<<" ";
 //puts("\n=====");
 SUM= 0;
 call2(n1+1);

 sort(all(v2));
 //for (int i=0; i<sz(v2); ++i) cout<<v2[i]<<" ";
 //puts("\n=====");

 vector <int> :: iterator it;
 int MIN= sum;
 for (int i=0; i<sz; ++i)
 {
 int my= mid-v1[i],t1;
 it= lower_bound(all(v2),my);

 if (*(it)<=v2[sz(v2)-1])
 {
 //cout<<v1[i]<<" er jonno "<<*it<<endl;
 t1= v1[i]+ *it;
 MIN= min(MIN,abs(sum-2*t1));
 //cout<<abs(sum-t1)<<endl;
 }
 if (*(it)!=v2[0])
 {
 //cout<<v1[i]<<" er jonno abar "<<*(it-1)<<endl;
 t1= v1[i]+ *(it-1);
 MIN= min(MIN,abs(sum-2*t1));
 //cout<<abs(sum-t1)<<endl;
 }
 }
 cout<<MIN<<endl;
 }
 return 0;
}
