#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
#define D 1234567
#define ll long long
int N,C,num[55],tnum[55];
char tB[100005];
int B[100005];
int L,lr;
void pre(){
	int i;
	L=strlen(tB);
	for(i=0;i<L;i++)B[i]=tB[L-1-i]-'0';
}
int f_pow(int x,int n){
	int r=1;
	while(n--)r=(r*x)%C;
	return r;
}
int fp[105][11];
void get_fp(){
	int i,j;
	memset(fp,0,sizeof(fp));
	for(i=1;i<C;i++){
		fp[i][0]=1;
		for(j=1;j<=10;j++){
			fp[i][j]=(fp[i][j-1]*i)%C;
		}
	}
}
int f_pow(int x){
	int r=1,i;
	x%=C;
	for(i=0;i<L;i++){
		r=(r*fp[x][B[i]])%C;
		x=fp[x][10];
	}
	return r;
}
ll cnt[55][105];
void run(){
	get_fp();
	int i,j;
	for(i=0;i<N;i++)tnum[i]=f_pow(num[i]);
	memset(cnt,0,sizeof(cnt));
	cnt[0][tnum[0]]=1;
	for(i=1;i<N;i++){
		for(j=0;j<C;j++){
			if(!cnt[i-1][j])continue;
			cnt[i][(j*tnum[i])%C]+=cnt[i-1][j];
		}
		for(j=0;j<C;j++)cnt[i][j]+=cnt[i-1][j];
		cnt[i][tnum[i]]++;
	}
	ll res=0;
	for(j=0;j<C;j++){
		res+=cnt[N-1][j]*j;
		res%=D;
	}
	printf("%lld\n",res);
}
int main(){
	while(scanf("%d%s%d",&N,tB,&C)!=EOF){
		int i;
		for(i=0;i<N;i++)scanf("%d",&num[i]);
		pre();
		run();
	}
	return 0;
}