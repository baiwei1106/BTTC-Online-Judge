#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <iostream>

using namespace std;

int s, n;
int in[505][2];
int group[505];

struct edge{
 int u, v;
 double cost;
}edge[260000];

int e;

double dis(int a, int b)
{
 double dx = in[a][0] - in[b][0];
 double dy = in[a][1] - in[b][1];
 return sqrt(dx * dx + dy * dy);
}

void setup()
{
 e = 0;
 for(int i = 0; i < n; i++ )
 {
 for(int j = i + 1; j < n; j++ )
 {
 edge[e].u = i;
 edge[e].v = j;
 edge[e++].cost = dis(i, j); 
 }
 group[i] = i;
 }
}

int cmp(struct edge A, struct edge B)
{
 return A.cost < B.cost;
}

int getGroup(int x)
{
 if(group[x] == x)
 {
 return x;
 }
 else
 {
 int gg = getGroup(group[x]);
 return group[x] = gg;
 }
}

double kruskal()
{
 double maxTransmit = 0.0;
 sort(edge, edge + e, cmp);
 int numEdge = n - max(1, s);
 
 for(int i = 0; i < e && numEdge; i++ )
 {
 int gu = getGroup(edge[i].u);
 int gv = getGroup(edge[i].v);
 if(gu != gv)
 {
 numEdge--;
 group[gu] = gv;
 maxTransmit = max(maxTransmit, edge[i].cost); 
 }
 }
 return maxTransmit;
}

int main()
{
 int numTest;
 
 scanf("%d", &numTest);
 
 while(numTest--)
 {
 scanf("%d %d", &s, &n);
 
 for(int i = 0; i < n; i++ )
 {
 scanf("%d %d", &in[i][0], &in[i][1]);
 }
 
 setup();
 printf("%.2lf\n", kruskal());
 }
}
 
 
