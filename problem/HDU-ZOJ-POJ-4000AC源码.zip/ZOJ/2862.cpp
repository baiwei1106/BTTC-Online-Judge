#include<iostream>
#include<cstring>
#include<cstdio>
#include<string>
#include<queue>
#include<map>
#include<algorithm>
using namespace std;

#define M 100000
map<string, int> mp;
map<int, string> mmp;
int cnt;
char str[1000], s1[1000], s2[1000];
int vv[M<<1], nxt[M<<1], h[M], e, n;
void add( int u, int v )
{
	vv[e] = v, nxt[e] = h[u]; h[u] = e++;
	vv[e] = u, nxt[e] = h[v]; h[v] = e++;
}
int vis[M], pre[M];

void dfs( int u, int fa )
{
	if( vis[u] ) pre[u] = u;
	else pre[u] = pre[fa];
	for( int i = h[u]; i+1; i = nxt[i] ) if( vv[i] - fa ){
		dfs( vv[i], u );
	}
}
int main()
{
	int cas = 0, n, u, v, m;
	while( scanf( "%s", str ) == 1 ){
		mp.clear(); cnt = 0;
		mmp.clear();
		scanf( "%d", &n );
		memset( h, -1, sizeof(h) ); e = 0;
		mp[str] = ++cnt;
		mmp[cnt] = str;
		for( int i = 0; i < n; ++i ){
			scanf( "%s%s", s1, s2 );
			if( !mp.count( s1 ) ) mp[s1] = ++cnt, mmp[cnt] = s1;
			if( !mp.count( s2 ) ) mp[s2] = ++cnt, mmp[cnt] = s2;
			add( mp[s1], mp[s2] );
		}
		scanf( "%d", &m );
		for( int i = 1; i <= cnt; ++i ) vis[i] = 0;
		for( int i = 0; i < m; ++i ){
			scanf( "%s", s1 );
			vis[mp[s1]] = 1;
		}
		pre[0] = pre[1] = 0;
		dfs( 1, 1 );
		scanf( "%d", &m );
		if( cas ) puts( "" );
		printf( "Function %d\n", ++cas );
		for( int i = 0; i < m; ++i ){
			scanf( "%s", s1 );
			u = mp[s1];
			v = pre[u];
			if( v ) cout<<mmp[v]<<endl;
			else puts( "Exception" );
		}
	}
}
/*

struct Node
{
	int id, val, L, R;
}nde[M];

bool cmp( Node a, Node b )
{
	return a.val > b.val;
}

int deep;
void dfs( int u, int fa )
{
	nde[u].L = ++deep;
	for( int i = h[u]; i+1; i = nxt[i] ) if( fa - vv[i] )
		dfs( vv[i], u );
	nde[u].R = deep;
}

int ans[M], sum[M];
queue<int> q;

void add( int i )
{
	while( i <= n ){
		sum[i] += 1;
		i += i&-i;
	}
}

int query( int i )
{
	int ans = 0;
	while( i ){
		ans += sum[i];
		i -= i&-i;
	}
	return ans;
}
int main()
{
	int v;
	while( scanf( "%d", &n ) == 1 ){
		memset( h, -1, sizeof(h) ); e = 0;
		for( int i = 1; i < n; ++i ){
			scanf( "%d", &v );
			add( i, v );
		}
		for( int i = 0; i < n; ++i ){
			scanf( "%d", &nde[i].val );
			nde[i].id = i;
		}
		deep = 0;
		dfs( 0, 0 );
		sort( nde, nde+n, cmp );
		memset( sum, 0, sizeof(sum) );
		int j = 0;
		for( int i = 0; i < n; ){
			while( j < n && nde[j].val == nde[i].val ){
				ans[nde[j].id] = query( nde[j].R ) - query( nde[j].L - 1 );
				++j;
			}
			while( i < j ){
				add( nde[i].L );
				++i;
			}
		}
		printf( "%d", ans[0] );
		for( int i = 1; i < n; ++i ) printf( " %d", ans[i] );
		puts( "" );
	}
}
*/
/*
#define N 305
#define inf (1<<31)-1
int arr[N][N];
int crr[N][N];
int row[N][N];
int col[N][N];
inline int lowbit(int x)
{
 return x&(-x);
}
int main()
{
 int T,n,m;
 int x1,y1,x2,y2;
 scanf("%d",&T);
 while(T--)
 {
	 
		scanf("%d",&n);
		for( int i = 1; i <= n; ++i )
			for( int j = 1; j <= n; ++j ) 
			{
				crr[i][j] = inf;
				row[i][j] = inf;
				col[i][j] = inf;
			}
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
			{
				scanf("%d",&arr[i][j]);
				for(int jj=j;jj<=n;jj+=lowbit(jj))
					row[i][j] = min(arr[i][j],row[i][j]);
				for(int ii=i;ii<=n;ii+=lowbit(ii))
				 col[i][j] = min(arr[i][j],col[i][j]);
				for(int ii=i;ii<=n;ii+=lowbit(ii))
					for(int jj=j;jj<=n;jj+=lowbit(jj))
						crr[ii][jj] = min(crr[ii][jj],arr[i][j]);
			}
		scanf("%d",&m);
		while(m--)
		{
		 scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
		 int ans = inf;
		 int temp = y2;
 while(x2>=x1)
		 {
			 temp = y2;
		 while(y2>=y1)
				{
				 ans = min(ans,arr[x2][y2]);
 for(y2=y2-1;y2>=y1&&y2-lowbit(y2)+1>=y1;y2-=lowbit(y2))
					 ans = min(ans,row[x2][y2]);
				}
				y2 = temp;
 for(x2=x2-1;x2>=x1&&x2-lowbit(x2)+1>=x1;x2-=lowbit(x2))
				{
				 while(y2>=y1)
				 {
						//ans = min(ans,arr[x2][y2]);
						//for(y2=y2-1;y2>=y1&&y2-lowbit(y2)+1>=y1;y2-=lowbit(y2))
							ans = min(ans,col[x2][y2]);
						y2 = temp;
 for(y2=y2-1;y2>=y1&&y2-lowbit(y2)+1>=y1;y2-=lowbit(y2))				 
					 ans = min(ans,crr[x2][y2]);
				 }
				}
				
			 
		 }
		 printf("%d\n",ans);
		}
 }
}
*/
/*int pp,base,x,y,a[10000],b[10000],n,l,la,lb,ans;
int main()
{
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		ans=0;
		scanf("%d%d%d%d",&pp,&base,&x,&y);
		if (base==2) ans=x^y;
		else
		{
			l=la=lb=0;
			while (x)
			{
				a[++la]=x%base;
				x/=base;
			}
			while (y)
			{
				b[++lb]=y%base;
				y/=base;
			}
			l=max(la,lb);
			for (int i=1;i<=l;i++)
				a[i]=(a[i]+b[i])%base;
			for (int i=l;i>=1;i--)
				ans=ans*base+a[i];
		}
		printf("%d %d\n",pp,ans);
	}
}

const int e[8]={-1,-1,-1,0,1,1,1,0};
const int r[8]={-1,0,1,1,1,0,-1,-1};
int map[16][16],lx[300],ly[300],near[300][9],l[300],ad,t;
int vis[300],ok;
bool inmap(int x,int y)
{
	return x<16&&x&&y&&y<16;
}
void output()
{
	for (int i=1;i<=15;i++)
		for (int j=1;j<=15;j++)
		{
			if (map[i][j]%2)
				printf("%d",vis[map[i][j]]);
			else
				printf("%d",map[i][j]);
			if (j<15) printf(" ");
			else printf("\n");
		}
}
void dfs(int u,int deep)
{
	output();
	int x,y,i,v;
	if (deep>=2*ad)
	{
		output();
		ok=1;
		return;
	}
	for (int j=1;j<=l[u];j++)
	{
		i=near[u][j];
		x=lx[u]+e[i];
		y=ly[u]+r[i];
		if (!inmap(x,y)) continue;
		v=map[x][y];
		if (!vis[v])
		{
			vis[v]=deep;
			dfs(v,deep+2);
			if (ok) return;
			vis[v]=0;
		}
	}
}
int main()
{
	int n,x,y;
	scanf("%d",&n);
	for (int pp=1;pp<=n;pp++)
	{
		memset(l,0,sizeof(l));
		ok=0;
		printf("Round #%d:",pp);
		ad=0;
		for (int i=1;i<=15;i++)
		for (int j=1;j<=15;j++)
		{
			scanf("%d",&map[i][j]);
			if (map[i][j]) cout<<map[i][j]<<endl;
			if (map[i][j]==1)
			{
				map[i][j]+=ad*2;
				ad++;
			}
		}
	for (int i=1;i<=15;i++)
		for (int j=1;j<=15;j++)
			if (map[i][j]&&(map[i][j]%2==0))
			{
				t=map[i][j]/2;
				lx[t]=i;
				ly[t]=j;
				for (int ii=0;ii<8;ii++)
				{
					x=i+e[ii];
					y=j+r[ii];
					if (!inmap(x,y)) continue;
					if (map[x][y]%2)
						near[t][++l[t]]=ii;
				}
			}
	int u=1;
	u++;
	dfs(1,1);
	}
}
*/