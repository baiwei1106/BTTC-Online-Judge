#include"stdio.h"
#include"string.h"
int n,m,in[27],out[27],vi[27],s[27];
char a[1001];
int find(int b)
{
	return b==s[b]?b:find(s[b]);
}
void lianjie(int b,int c)
{
	if(find(b)!=find(c))
		s[find(b)]=find(c);
}
int main()
{
	int i;
	scanf("%d",&n);
	while(n--)
	{
		memset(in,0,sizeof(in));
		memset(out,0,sizeof(out));
		memset(vi,0,sizeof(vi));
		for(i=0;i<27;i++)
 s[i]=i;
		scanf("%d",&m);
		for(i=0;i<m;i++)
		{
 scanf("%s",a);
			 int t=strlen(a);
 out[a[0]-'a']++;
			 in[a[t-1]-'a']++;
			 vi[a[0]-'a']=1;
			 vi[a[t-1]-'a']=1;
			 lianjie(a[0]-'a',a[t-1]-'a');
		}
		int sum=0;
		for(i=0;i<26;i++)
			if(vi[i]&&s[i]==i)
 sum++;
			if(sum>1)
			{
				printf("The door cannot be opened.\n");
				continue;
			}
			int j=0,st[27];
			for(i=0;i<26;i++)
			{
 if(vi[i]&&out[i]!=in[i])
 st[j++]=i;
			}
			if(j==0)
			{
				printf("Ordering is possible.\n");
				continue;
			}
			if(j==2&&(out[st[0]]-in[st[0]]==1&&in[st[1]]-out[st[1]]==1||out[st[1]]-in[st[1]]==1&&in[st[0]]-out[st[0]]==1))
			{
	 printf("Ordering is possible.\n");
					continue;
			}
 	printf("The door cannot be opened.\n");
	}
	return 0;
}