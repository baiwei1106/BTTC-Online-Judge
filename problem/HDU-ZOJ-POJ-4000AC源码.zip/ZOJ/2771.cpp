#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
using namespace std;
const int base = 10000, cap = 30;
struct xnum { 
 int len, data[cap]; 
 xnum() : len(0) {} 
 xnum(const xnum& v) : len(v.len) { memcpy(data, v.data, len * sizeof *data); } 
 xnum(int v) : len(0) { for (; v > 0; v /= base) data[len++] = v % base; } 
 xnum& operator=(const xnum& v) { len = v.len; memcpy(data, v.data, len * sizeof *data); return *this; } 
 int& operator[](int index) { return data[index]; } 
 int operator[](int index) const { return data[index]; } 
}; 
xnum operator+(const xnum& a, const xnum& b) { 
 xnum r; int i, c = 0; 
 for (i = 0; i < a.len || i < b.len || c > 0; i++) { 
 if (i < a.len) c += a[i]; 
 if (i < b.len) c += b[i]; 
 r[i] = c % base; 
 c /= base; 
 } 
 r.len = i; 
 return r; 
} 
ostream& operator<<(ostream& out, const xnum& v) {
 out << (v.len == 0 ? 0 : v[v.len - 1]); 
 for (int i = v.len - 2; i >= 0; i--) for (int j = base / 10; j > 0; j /= 10) out << v[i] / j % 10; 
 return out; 
}
xnum f[3][4][70][200];
int n;
void display()
{
 while (cin>>n) {
 for (int v=1;v<=3*(n+1);v++)
 for (int i=0;i<=n;i++)
 for (int j=1;j<=3;j++)
 for (int k=1;k<=2;k++) f[k][j][i][v]=xnum(0);
 f[1][1][n][1]=xnum(1);
 for (int v=1;v<=3*(n+1);v++)
 for (int i=n;i>=0;i--)
 for (int j=1;j<=3;j++)
 for (int k=1;k<=2;k++) {
 if (j==1) {
 if (k==1) f[k][j][i][v]=f[k][j][i][v]+f[2][j][i+1][v-1];
 if (k==2) f[k][j][i][v]=f[k][j][i][v]+f[1][j][i+1][v-1]+f[2][2][i][v-1];
 }
 if (j==2) {
 if (k==1) f[k][j][i][v]=f[k][j][i][v]+f[2][j][i+1][v-1]+f[k][1][i][v-1];
 if (k==2) f[k][j][i][v]=f[k][j][i][v]+f[1][j][i+1][v-1]+f[k][3][i][v-1];
 }
 if (j==3) {
 if (k==1) f[k][j][i][v]=f[k][j][i][v]+f[2][j][i+1][v-1]+f[k][2][i][v-1];
 if (k==2) f[k][j][i][v]=f[k][j][i][v]+f[1][j][i+1][v-1];
 }
 }
 xnum ans;
 ans=xnum(0);
 for (int i=1;i<=3*(n+1);i++)
 ans=ans+f[2][1][0][i]+f[1][3][0][i];
 cout<<ans<<endl;
 }
}
int main()
{
 //freopen("h.in","r",stdin);
 display();
 return 0;
}
