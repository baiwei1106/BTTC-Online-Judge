#include <iostream>
#include <cstdio>
#include <cstring>
#define lng long long
using namespace std;

int n, k;
lng dp[100][10][10];

int main()
{
 //freopen("in", "r", stdin);
 while(~scanf("%d %d", &n, &k))
 {
 for(int i = 0; i <= n; ++i) for(int j = 0; j <= k; ++j) for(int q = 0; q <= k; ++q) dp[i][j][q] = 0;
 dp[0][0][0] = 1;
 for(int i = 1; i <= n; ++i)
 {
 for(int j = 0; j <= k; ++j)
 {
 for(int q = 0; q <= k; ++q)
 {
 if(j + q <= k)
 {
 //cout << i << " " << max(0, j - 1) << " " << q + 1 << "\n";
 //cout << i << " " << j + 1 << " " << max(0, q - 1) << "\n";
 dp[i][max(0, j - 1)][q + 1] += dp[i - 1][j][q];
 dp[i][j + 1][max(0, q - 1)] += dp[i - 1][j][q];
 }
 }
 }
 }
 lng res = 0;
 for(int i = 0; i <= k; ++i)
 for(int j = 0; j <= k; ++j)
 if(i + j <= k) res += dp[n][i][j];
 printf("%lld\n", res);
 }
 return 0;
}
