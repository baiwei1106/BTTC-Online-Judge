#include<stdio.h>
#include<string.h>

int is[20][20];
int ans[20][20];

int main()
{
 int t,n,m,i,j,k;

 scanf("%d",&t);
 while(t--)
 {
	scanf("%d%d%d",&n,&m,&k);
	memset(is,0,sizeof(is));
	for(i=1;i<n;i++)
	{
	 if(!k)
		break;
	 for(j=1;j<m-1;j++)
	 {
		is[i][j]=1;
		k--;
		if(!k)
		 break;
	 }
	}
	memset(ans,0,sizeof(ans));
	for(i=1;i<n;i++)
	{
	 for(j=1;j<m;j++)
	 {
		if(i>1)
		 ans[i][j]=ans[i-1][j]-ans[i-1][j-1]-ans[i-1][j+1]-ans[i-2][j];
		else
		 ans[i][j]=0;
		if(!is[i-1][j])
		{
		 if(ans[i][j])
			ans[i][j]=0;
		 else
			ans[i][j]=1;
		}
	 }
	}
	for(i=0;i<n;i++)
	{
	 printf("%d",ans[i][0]);
	 for(j=1;j<m;j++)
		printf(" %d",ans[i][j]);
	 puts("");
	}
 }
}