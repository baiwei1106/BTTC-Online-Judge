#include<iostream>
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<vector>
using namespace std;
const double eps=1e-8;
int dblcmp(double x)
{
 if(x<-eps) return -1;
 return x>eps?1:0;
}
struct Point
{
 double x,y;
 Point(){}
 Point(double a,double b)
 {
 x=a,y=b;
 }
 Point operator - (Point b)
 {
 return Point(x-b.x,y-b.y);
 }
};
double cross(Point a,Point b)
{
 return a.x*b.y-b.x*a.y;
}
int segment_intersect(Point a,Point b,Point c,Point d)
{
 if(cross(b-a,c-a)*cross(b-a,d-a)<0&&
 cross(d-c,a-c)*cross(d-c,b-c)<0)
 return 1;
 else
 return 0;
}
Point p[200005];
vector<int>v;
vector<int>::iterator it;
int n;
int a[1005],b[1005],ta,tb;
int main()
{
 while(cin>>n&&n)
 {
 ta=0,tb=0;
 int i,j,k;
 for(i=0;i<2*n;i+=2)
 {
 scanf("%lf%lf%lf%lf",&p[i].x,&p[i].y,&p[i+1].x,&p[i+1].y);
 }
 a[ta++]=0;
 for(i=1;i<n;i++)
 {
 for(j=0;j<ta;j++)
 if(!segment_intersect(p[i*2],p[i*2+1],
 p[a[j]*2],p[a[j]*2+1]))
 b[tb++]=a[j];
 b[tb++]=i;
 for(ta=0;ta<tb;ta++)
 a[ta]=b[ta];
 tb=0;
 }
 printf("Top sticks: %d",a[0]+1);
 for(i=1;i<ta;i++)
 printf(", %d",a[i]+1);
 printf(".\n");
 }
 return 0;
}