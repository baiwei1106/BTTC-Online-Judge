#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;
const int Max = 2000;
struct po
{
 int j, f;
 bool operator < (const po &q) const
 {
 return (double)j/f > (double)q.j/q.f;
 }
}p[Max];
int main()
{
 int n, m;
 while(cin>>n>>m, n != -1 || m != -1)
 {
 double ans = 0;
 for(int i = 0; i < m; ++i)
 {
 cin>>p[i].j>>p[i].f;
 if(p[i].f==0)
 {
 ans += p[i].j;
 --i;
 --m;
 }
 }
 sort(p, p + m);
 for(int i = 0; i < m; ++i)
 {
 if(n >= p[i].f)
 ans += p[i].j;
 else
 {
 ans += ((double)n/p[i].f) * p[i].j;
 break;
 }
 n -= p[i].f;
 }
 printf("%.3lf\n", ans);
 }
}
