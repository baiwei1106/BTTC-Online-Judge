#include<iostream>
#include<cstdio>
#include<vector>
#include<string>
#include<queue>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
#define N 10002
#define ll long long
#define pi acos(-1.0)

int main()
{
	double k,h,a,b;
	while(scanf("%lf",&k)!=EOF)
	{
		scanf("%lf%lf%lf",&h,&a,&b);
		double angle = 90-2*k;
		angle = angle*pi/180;
		double tx = cos(angle);
		double ty = sin(angle);
		if(a>h) { tx = -tx;ty = -ty; a = a-h; }
		else a = h-a;
		double x = a*tx;
		double y = h+a*ty;
		double ans = sqrt(y*y+(x-b)*(x-b));
		printf("%.2lf\n",ans);
	}
}
//int a[N],b[N];
//int dp[N][N];
//
//int main()
//{
//	
//	int n,m;
//	while(scanf("%d%d",&n,&m)!=EOF)
//	{
//		for(int i=1;i<=n;i++) scanf("%d",a+i);
//		for(int i=1;i<=m;i++) scanf("%d",b+i);
//		memset(dp,0,sizeof(dp));
//		for(int i=1;i<=n;i++)
//			for(int j=1;j<=m;j++)
//				if(a[i]==b[j]) dp[i][j] = dp[i-1][j-1]+1;
//				else dp[i][j] = max(dp[i-1][j],dp[i][j-1]);
//		printf("%d\n",dp[n][m]);
//	}
//}