#include <cstdio>
#define LL unsigned long long
LL a[70];
LL re;

int find(LL num)
{
	LL i=1;
	while(!(num>=a[i] && num<a[i+1]))
	{
		i++;
	}
	return i;
}

int main()
{
	LL i,num,times;
	bool b;
	a[1]=2;
	for(i=2;i<=63;i++)
		a[i]=a[i-1]*2;
	while(scanf("%llu%llu",&num,&times)!=EOF)
	{
		b=true;
		if(num==1)	printf("1\n",num);
		else
		{
			if(times>300)	times=300;
			for(i=0;i<times;i++)
			{
				if(num==1)	{ b=false; printf("1\n",num);	break;}
				re=find(num);
				num=2*(num-a[re])+1;
			}
			if(b)	printf("%llu\n",num);
		}
	}
	return 0;
}
