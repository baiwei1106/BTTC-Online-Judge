#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <queue>
#include <vector>

using namespace std;

const int MAXN=1010;
const int MAXM=MAXN*MAXN;

struct Node
{
 int to,next,w;
}e[MAXM*2];
int n,m,q,start,end,size,box[MAXN];
int dis[2][MAXN];
bool flag[MAXN];

void add(int from,int to,int w)
{
 e[size].to=to;
 e[size].w=w;
 e[size].next=box[from];
 box[from]=size++;
}
void init()
{
 memset(box,-1,sizeof(box)),size=0;
 for(int i=0,a,b,c;i<m;++i)
 {
 scanf("%d%d%d",&a,&b,&c);
 add(a,b,c),add(b,a,c);
 }
}
void spfa(int s,int k)
{
 queue<int> Q;
 memset(dis[k],20,sizeof(dis[k]));
 memset(flag,false,sizeof(flag));
 dis[k][s]=0,Q.push(s);
 while(!Q.empty())
 {
 int x=Q.front();Q.pop();flag[x]=false;
 for(int i=box[x];~i;i=e[i].next)
 if(dis[k][e[i].to]-dis[k][x]>e[i].w)
 {
 dis[k][e[i].to]=dis[k][x]+e[i].w;
 if(!flag[e[i].to])flag[e[i].to]=true,Q.push(e[i].to);
 }
 }
}
void solve()
{
 spfa(start,0);
 spfa(end,1);
 vector<int> nst[MAXN];
 for(int i=1;i<=n;++i)
 for(int j=box[i];~j;j=e[j].next)
 if(dis[1][e[j].to]+dis[0][i]+e[j].w==dis[0][end]) nst[i].push_back(e[j].to);
 scanf("%d",&q);
 for(int i=0,a;i<q;++i)
 {
 scanf("%d",&a);
 if(dis[0][end]<=a)
 {
 puts("1");
 continue;
 }
 int ans=0;
 for(int i=1;i<=n;++i)
 {
 if(dis[0][i] == a && nst[i].size()>0) ans++;
 else if(dis[0][i]<a)
 {
 for(int j=0;j<(int)nst[i].size();++j)
 if(dis[0][nst[i][j]]>a)
 ans++;
 }
 }
 printf("%d\n",ans);
 }
}
int main()
{
// freopen("in.txt","r",stdin);
 int cas=0;
 while(scanf("%d%d%d%d",&n,&m,&start,&end)!=EOF)
 {
 if(cas++)puts("");
 init();
 solve();
 }
 return 0;
}
