#include<cstdio>
#include<vector>
#include<cstring>
#include<algorithm>
using namespace std;
#define CLR(v) memset(v,0,sizeof(v));
const int maxn = 1010;
int val[maxn];
vector<int> edge[maxn];
int more[maxn],dp[maxn],sum[maxn];
void get_sum(int u,int f)
{
	sum[u]=val[u];
	int sz=edge[u].size();
	for(int i=0;i<sz;i++)
	{
		int v=edge[u][i];
		if(v==f) continue; 
		get_sum(v,u);
		sum[u]+=sum[v];
	}
}
void get_more(int u,int f)
{
	more[u]=0;
	int sz=edge[u].size();
	int s=0;
	for(int i=0;i<sz;i++)
	{
		int v=edge[u][i];
		if(v==f) continue;
		get_more(v,u);
	}
	for(int i=0;i<sz;i++) s+=more[edge[u][i]];
	for(int i=0;i<sz;i++)
	{
		int v=edge[u][i];
		more[u]=max(more[u],sum[v]+s-more[v]);
	}
}
bool vis[maxn];
void dfs(int u,int f)
{
	dp[u]=val[u];
	int sz=edge[u].size();
	if(sz==1)	dp[u]=max(dp[u],sum[edge[u][0]]+val[u]);
	
	int s=0;
	for(int i=0;i<sz;i++)
	{
		int v=edge[u][i];
		if(v==f) continue;
		dfs(v,u);
	}
	for(int i=0;i<sz;i++)	s+=more[edge[u][i]];
	for(int i=0;i<sz;i++)
	{
		for(int j=i+1;j<sz;j++)
		{
			int son1=edge[u][i];
			int son2=edge[u][j];
			dp[u]=max(dp[u],dp[son1]+sum[son2]+s-more[son1]-more[son2]+val[u]);
			dp[u]=max(dp[u],dp[son2]+sum[son1]+s-more[son1]-more[son2]+val[u]);
		}
	}
}
bool root[maxn];
int main()
{
	int n;
	while(scanf("%d",&n),n)
	{
		for(int i=0;i<n;i++) scanf("%d",&val[i]),edge[i].clear();
		memset(root,false,sizeof(root));
		for(int i=0,j;i<n;i++)
		{
			scanf("%d",&j);
		 if(j==-1) root[i]=true;
			if(j!=-1) edge[j].push_back(i);
		}
		CLR(dp);CLR(more);CLR(sum);
		int ans=0;
		for(int i=0;i<n-1;i++)
		{
			if(root[i])
			{
				get_sum(i,-1);
				ans+=sum[i];
			}
		}
		get_sum(n-1,-1);
		get_more(n-1,-1);
		dfs(n-1,-1);
		printf("%d\n",ans+dp[n-1]);
	}
	return 0;
}