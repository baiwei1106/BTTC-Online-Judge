#include<map>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

const int MAXN = 50010;

struct Node{
 int mark;
 int x;
 int y; 
};
Node node[MAXN];
Node edge[MAXN];

int n , m , q;
int val[MAXN];
int father[MAXN];
int ans[MAXN];
map<int , int>mp;

void init(){
 mp.clear();
 for(int i = 0 ; i < n ; i++)
 father[i] = i;
}

int find(int x){
 if(father[x] != x)
 father[x] = find(father[x]); 
 return father[x];
}

void Union(int x , int y){
 int fx = find(x); 
 int fy = find(y); 
 if(fx != fy){
 if(val[fx] > val[fy])
 father[fy] = fx;
 else if(val[fx] < val[fy])
 father[fx] = fy;
 else{
 if(fx < fy) 
 father[fy] = fx;
 else
 father[fx] = fy;
 }
 }
}

void solve(){
 for(int i = 0 ; i < m ; i++){
 if(mp[edge[i].x*MAXN+edge[i].y])
 continue;
 Union(edge[i].x , edge[i].y);
 }
 int pos = 0;
 for(int i = q-1 ; i >= 0 ; i--){
 if(node[i].mark == 0){
 int fx = find(node[i].x); 
 if(val[fx] > val[node[i].x])
 ans[pos++] = fx;
 else
 ans[pos++] = -1;
 }
 else
 Union(node[i].x , node[i].y);
 }
 for(int i = pos-1 ; i >= 0 ; i--)
 printf("%d\n" , ans[i]);
}

int main(){
 int x , y;
 char str[10];
 bool first = true; 
 while(scanf("%d" , &n) != EOF){
 if(first)
 first = false;
 else
 puts("");
 for(int i = 0 ; i < n ; i++) 
 scanf("%d" , &val[i]);
 init();
 scanf("%d" , &m); 
 for(int i = 0 ; i < m ; i++){
 scanf("%d%d" , &edge[i].x , &edge[i].y);
 if(edge[i].x > edge[i].y)
 swap(edge[i].x , edge[i].y);
 }
 scanf("%d" , &q); 
 for(int i = 0 ; i < q ; i++){
 scanf("%s" , str); 
 if(str[0] == 'q'){
 scanf("%d" , &node[i].x);
 node[i].mark = 0;
 }
 else{
 scanf("%d%d" , &node[i].x , &node[i].y);
 if(node[i].x > node[i].y)
 swap(node[i].x , node[i].y);
 node[i].mark = 1;
 mp[node[i].x*MAXN+node[i].y] = 1;
 }
 }
 solve();
 }
 return 0;
}

