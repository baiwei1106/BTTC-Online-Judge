#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std;
#define N 10000
int main()
{
 int T;
 scanf("%d", &T);
 getchar();
 for(int g = 1; g <= T; g++)
 {
 char a[N];
 gets(a);
 int len = strlen(a);
 int i=0, u=0, p=0;
 double I, U, P;
 for(int j = 0; j < len; j++)
 {
 if(a[j]=='U'&&a[j+1]=='=')
 {
 U = atof(&a[j+2]);
 u=1;
 int k = j;
 while(a[k]!='V')
 {
 k++;
 }
 if(a[k-1]=='m')
 U /= 1000.0;
 if(a[k-1]=='k')
 U *= 1000.0;
 if(a[k-1]=='M')
 U *= 1000000.0;
 }
 if(a[j]=='I'&&a[j+1]=='=')
 {
 I = atof(&a[j+2]);
 i = 1;
 int k = j;
 while(a[k]!='A')
 {
 k++;
 }
 if(a[k-1]=='m')
 I /= 1000.0;
 if(a[k-1]=='k')
 I *= 1000.0;
 if(a[k-1]=='M')
 I *= 1000000.0;
 }
 if(a[j]=='P'&&a[j+1]=='=')
 {
 P = atof(&a[j+2]);
 p = 1;
 int k = j;
 while(a[k]!='W')
 {
 k++;
 }
 if(a[k-1]=='m')
 P /= 1000.0;
 if(a[k-1]=='k')
 P *= 1000.0;
 if(a[k-1]=='M')
 P *= 1000000.0;
 }
 }
 if(i&&u)
 {
 printf("Problem #%d\n", g);
 printf("P=%.2fW\n\n", I*U);
 }
 if(i&&p)
 {
 printf("Problem #%d\n", g);
 printf("U=%.2fV\n\n", P/I);
 }
 if(u&&p)
 {
 printf("Problem #%d\n", g);
 printf("I=%.2fA\n\n", P/U);
 }

 }
 return 0;
}


