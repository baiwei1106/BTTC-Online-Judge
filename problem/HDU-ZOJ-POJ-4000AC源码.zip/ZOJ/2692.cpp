#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include <queue>
using namespace std;
#define SZ(v) ((int)(v).size())
#define REP(i, n) for (int i = 0; i < (n); ++i) 
const int maxint = -1u>>1;
const int maxn = 100 + 10;

char s[maxn], b[7], ansb[7];
int ans, rec[10];
bool used[10];
int dp[maxn][6], a[6];

void work() {
 for (int i = 0; i < 6; ++i) {
 b[i] = rec[a[i]] + '0';
 }
 b[6] = 0;
 for (int i = 0; i < 6; ++i) dp[0][i] = 0;
 int n = strlen(s + 1);
 for (int i = 1; i <= n; ++i) {
 for (int j = 0; j < 6; ++j) {
 dp[i][j] = dp[i - 1][j] + 1;
 for (int k = 0; k < 6; ++k) {
 if (k == j || k == 5 - j) continue;
 dp[i][j] = min(dp[i][j], dp[i - 1][k] + (s[i] != b[j]));
 //printf("%c %c\n", s[i], b[j]);
 }
 }
 }
 int res = n;
 for (int i = 0; i < 6; ++i) res = min(res, dp[n][i]);
 //printf("res: %d, ans: %d\n", res, ans);
 sort(b, b + 6);
 if (ans > res || ans == res && strcmp(ansb, b) > 0) {
 ans = res;
 strcpy(ansb, b);
 //printf("%d, %s\n", ans, ansb);
 }
}
int main() {
 int ca = 0;
 while (scanf("%s", s + 1) == 1) {
 memset(used, 0, sizeof(used));
 used[0] = true;
 for (int i = 1; s[i]; ++i) {
 used[s[i] - '0'] = true;
 }
 int n = 0;
 for (int i = 0; i < 10; ++i) {
 if (used[i]) rec[n++] = i;
 }
 ans = strlen(s + 1) + 1;
 for (a[0] = 0; a[0] < n; ++a[0]) {
 for (a[1] = 0; a[1] < n; ++a[1]) {
 for (a[2] = 0; a[2] < n; ++a[2]) {
 for (a[3] = 0; a[3] <= a[2]; ++a[3]) {
 for (a[4] = 0; a[4] <= a[1]; ++a[4]) {
 for (a[5] = 0; a[5] <= a[0]; ++a[5]) {
 work();
 //goto OUT;
 }
 }
 }
 }
 }
 }
OUT:;
 printf("Dice %d: discrepancy is %d, digits used:", ++ca, ans);
 for (int i = 0; i < 6; ++i) {
 printf(" %c", ansb[i]);
 }
 printf("\n");
 }
 return 0;
}
