#include <stdio.h>
#include <iostream>
#include <string.h>
#include <math.h>
#include <map>
#include <string>
#include <algorithm>
using namespace std;

map <string,int> mp;
string name;
string hash[1000];
int sc[1000],num[1000],pal[1000],r[1000],mc[1000];
bool cmp(int x,int y)
{
    if (sc[x]!=sc[y]) return sc[x]<sc[y];
    double num1,num2;
    num1=(double)sc[x]/(double)num[x];
    num2=(double)sc[y]/(double)num[y];
    if (fabs(num1-num2)>1e-8)
        return num1<num2;
    return hash[x]<hash[y];
}
int main()
{
    int t;
    scanf("%d",&t);
    for (int ii=1;ii<=t;ii++)
    {
        memset(sc,0,sizeof(sc));
        memset(num,0,sizeof(num));
        mp.clear();
        int h;
        scanf("%d",&h);
        for (int i=0;i<h;i++)
            scanf("%d",&pal[i]);
        printf("Tournament %d\n",ii);
        int id=0;
        while (cin >> name&&name!="EndOfTournament")
        {
            if (name=="ShowRank")
            {
                puts("Place  Name        Score  Holes");
                for (int i=0;i<id;i++)
                    r[i]=i;
                sort(r,r+id,cmp);
                for (int j=0;j<id;j++)
                {
                    int now=0;
                    if (j!=0&&sc[r[j]]==sc[r[j-1]])
                        mc[r[j]]=mc[r[j-1]];
                    else mc[r[j]]=j+1;
                    printf("%5d  %s",mc[r[j]],hash[r[j]].c_str());
                    int delta=12-hash[r[j]].size();
                    for (int k=0;k<delta;k++)
                        printf(" ");
                    if (sc[r[j]]<=0)
                        printf("%5d  ",sc[r[j]]);
                    else
                    {
                        int cntt=0;
                        int num=sc[r[j]];
                        while (num!=0)
                        {
                            cntt++;
                            num/=10;
                        }
                        for (int k=0;k<5-cntt-1;k++)
                            printf(" ");
                        printf("+%d  ",sc[r[j]]);
                    }
                    if (num[r[j]]==h)
                        printf("%5c\n",'F');
                    else
                        printf("%5d\n",num[r[j]]);
                }
                printf("\n");
                continue;
            }
            int temp;
            scanf("%d",&temp);
            if (mp.find(name)==mp.end())
            {
                mp.insert(pair<string,int>(name,id));
                hash[id]=name;
                num[id]=0;
                sc[id]+=temp-pal[num[id]];
                num[id]++;
                id++;
            }
            else
            {
                int now=mp[name];
                sc[now]+=temp-pal[num[now]];
                num[now]++;
            }
        }
    }
    return 0;
}
