#include <stdio.h>
#include <string.h>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

int a[1000];
int main()
{
 int i,j,n,T,s;
 scanf("%d",&T);
 while(T--)
 {
 scanf("%d",&n);
 s=0;
 for (i=0;i<n;i++)
 {
 scanf("%d",&a[i]);
 s+=a[i];
 }
 printf("%d\n",s-n+1);
 }
 return 0;
}
