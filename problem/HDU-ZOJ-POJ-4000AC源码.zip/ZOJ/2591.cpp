/*
 * Author: chlxyd
 * Created Time: 2013/7/22 15:49:34
 * File Name: E.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )

const int maxn = 2000 + 10;
const int maxy = 200 + 10;
const int inity = 1869;
const int endy = 2005 - 1869;

char name[maxn][110];
int year[maxn], ty[maxn]; 
vector<int> id[maxy], cid[maxy][10];
vector<int> path;
int cost[maxy][10];
int n;

int two(int x) {
 return 1 << x;
}

bool have(int bit, int w) {
 w--;
 return (bit & two(w)) != 0;
}

void readName(char *c) {
 int cnt = 0;
 char ch[107];
 strcpy(c, "\"");
 scanf(" \"%[^\"]\"", ch);
 strcat(c, ch);
 strcat(c, "\"");
}

void init() {
 scanf("%d", &n);
 rep (i, endy) {
 id[i].clear();
 repf (j, 1, 5)
 cid[i][j].clear();
 }
 memset(cost, 0, sizeof(cost));
 memset(name, 0, sizeof(name));
 rep (i, n) {
 readName(name[i]);
 //puts(name[i]);
 scanf("%d%d", &year[i], &ty[i]);
 year[i] -= inity;
 id[year[i]].push_back(i); 
 cost[year[i]][ty[i]]++;
 cid[year[i]][ty[i]].push_back(i);
 }
}

int f[maxy][7][7], pj[maxy][7][7], pk[maxy][7][7], pbit[maxy][7][7];
int ans, ansi, ansj, ansk, ansbit;

int getcost(int y, int nt, int needt, int bit, int &h) {
 int tn = 0, it = 0, et = 1;
 h = 0;
 if (bit == 0) {
 if (nt == needt) return 0;
 else return 1;
 }
 if (!have(bit, nt) || !have(bit, needt))
 return -1;
 repf (i, 1, 5)
 if (have(bit, i)) {
 tn++;
 if (i == nt) it = 1;
 if (i == needt) et = 0;
 h += cost[y][i];
 }
 if (needt == nt && tn - it + et != 0)
 tn++;
 return tn - it + et;
}

void gao() {
 ans = 0;
 memset(f, -1, sizeof(f));
 repf (i, 1, 5)
 f[0][i][5] = 0;
 rep (i, endy) {
 repf (j, 1, 5) 
 repf (k, 0, 5) {
 repf (r, 1, 5) {
 if (f[i][j][k] == -1) break;
 rep (bit, two(5)) {
 int h;
 int c = getcost(i + 1, j, r, bit, h); 
 if (c != -1 && c <= k) { 
 if (f[i + 1][r][k - c] < f[i][j][k] + h){
 f[i + 1][r][k - c] = f[i][j][k] + h;
 pj[i + 1][r][k - c] = j;
 pk[i + 1][r][k - c] = k;
 pbit[i + 1][r][k - c] = bit;
 }
 if (ans < f[i][j][k] + h) {
 ans = f[i][j][k] + h;
 ansi = i;
 ansj = j;
 ansk = k;
 ansbit = bit;
 }
 }
 }
 }
 } 
 }
 int h;
 //printf("%d %d\n", getcost(1891 - inity, 2, 3, 6, h), f[1891 - inity][2][4]);
 //printf("%d\n", h);
}

void mostPath(int w, int nt, int remaink, int needt, int bit) {
 if (!have(bit, nt) || (!have(bit, needt) && needt != 0)) return;
 vector<int> a;
 int v[10] = {0};
 a.push_back(nt);
 v[nt] = 1;
 if (needt != 0 && needt != nt) {
 a.push_back(needt);
 v[needt] = 1;
 }
 if (remaink != 0 && needt == nt)
 remaink--;
 rep (i, remaink) {
 int ma = -1;
 repf (j, 1, 5) {
 if (v[j] == 0 && have(bit, j)) {
 if (ma == -1 || cost[w][ma] < cost[w][j])
 ma = j;
 }
 }
 if (ma == -1) break;
 a.push_back(ma);
 v[ma] = 1;
 }
 rep (i, sz(a)) {
 if (a[i] == needt) {
 swap(a[i], a[sz(a) - 1]);
 break;
 }
 }
 
 rep (i, sz(a)) {
 rep (j, sz(cid[w][a[i]])) {
 path.push_back(cid[w][a[i]][j]);
 //int h = cid[w][a[i]][j];
 //printf("%s %d\n", name[h], year[h] + inity);
 }
 }
}

void dfs(int ii, int jj, int kk) {
 //printf("%d %d %d %d %d\n", ii + inity, jj, kk, pbit[ii][jj][kk], f[ii][jj][kk]);
 if (ii == 0) return;
 int j = pj[ii][jj][kk];
 int k = pk[ii][jj][kk];
 dfs(ii - 1, j, k);
 mostPath(ii, j, k - kk, jj, pbit[ii][jj][kk]);
}

void putans() {
 //printf("%d\n", ans);
 path.clear();
 dfs(ansi, ansj, ansk);
 mostPath(ansi + 1, ansj, ansk, 0, ansbit);
 //reverse(path.begin(), path.end());
 printf("%d\n", sz(path));
 rep (i, sz(path)) {
 printf("%s\n", name[path[i]], year[path[i]] + inity, ty[path[i]]);
 }
} 

int main(){
 int T;
 scanf("%d", &T);
 rep (ca, T) {
 if (ca != 0) printf("\n");
 init();
 gao();
 putans();
 }
 return 0;
}
