#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

#define CY 100100

int br[CY], n, s;

int main() {
	int k;
	int cas;
	scanf("%d", &cas);
	while (cas--) {
		scanf("%d%d", &n, &s);
		br[0] = 0;
		for (int i = 1; i <= n; ++i) {
			scanf("%d", &br[i]);
			br[i] += br[i - 1];
		}
		int ans = n + 1, l = 0, r = 1;
		for (;;) {
			while (br[r] - br[l] < s && r <= n) ++r;
			while (br[r] - br[l] >= s && r > l) {
				ans = min(r - l, ans);
				++l;
			} 
			if (r >= n) break;
		}
		printf("%d\n", ans == n + 1 ? 0 : ans);
	}
	return 0;
}