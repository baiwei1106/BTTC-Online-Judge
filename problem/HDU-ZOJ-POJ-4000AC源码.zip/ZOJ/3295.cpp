#include<cstdio>
#include<cmath>
int num[1025];
int two[20];
int main()
{
	int n , k , i, j;
	two[0] = 1;
	for(i = 1; i <= 10; i++)
	two[i] = two[i-1] * 2;
	while(scanf("%d%d",&n,&k)!=EOF)
	{
		for(i = 1; i <= two[n]; i++) 
		{
			scanf("%d",&num[i]);
		}
		int more = 0, less = 0;
 for(i = 1; i <= two[n]; i++)
		{
			if(num[i] > num[k+1]) more ++;
			if(num[i] < num[k+1]) less ++;
		}
		int ans = log2(less+1);
 int ans1=(more==0?ans:0);
		printf("%d %d\n",ans1,ans);
	}
	return 0;
}