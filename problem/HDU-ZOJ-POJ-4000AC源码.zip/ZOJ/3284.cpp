#include<stdio.h>
#include<string.h>
int a[110][110];
int r,c;

void add(int x,int y,int v)
{
 int i,j;
 for(i=x;i<=r;i+=i&-i)
 for(j=y;j<=c;j+=j&-j) a[i][j]+=v;
}
int sum(int x,int y)
{
 int ans=0,i,j;
 for(i=x;i>0;i-=i&-i)
 for(j=y;j>0;j-=j&-j) ans+=a[i][j];
 return ans;
}
void add(int x1,int y1,int x2,int y2,int v)
{
 x2++,y2++;
 add(x1,y1, v);add(x2,y2, v);
 add(x2,y1,-v);add(x1,y2,-v);
}
int main()
{
 // freopen("/home/wxf/in","r",stdin);
 int cas=1;
 while(scanf("%d%d",&r,&c)!=EOF)
 {
 int p,k,q,x1,x2,y1,y2;
 memset(a,0,sizeof(a));
 for(int i=1;i<=r;i++)
 for(int j=1;j<=c;j++) scanf("%d",&k),add(i,j,i,j,k);
 scanf("%d",&q);
 printf("Case %d\n",cas++);
 while(q--)
 {
 scanf("%d",&p);
 if(p==0)
 {
 scanf("%d%d%d%d%d",&x1,&y1,&x2,&y2,&k);
 add(x1,y1,x1,c,k);
 add(x1+1,1,x2-1,c,k);
 add(x2,1,x2,y2,k);
 }
 if(p==1)
 {
 scanf("%d%d%d%d%d",&x1,&y1,&x2,&y2,&k);
 add(x1,y1,r,y1,k);
 add(1,y1+1,r,y2-1,k);
 add(1,y2,x2,y2,k);
 }
 if(p==2)
 {
 scanf("%d%d",&x1,&y1);
 printf("%d\n",sum(x1,y1));
 }
 }
 }
 return 0;
}
