#include<string.h>
#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
long long a[2][100],n,t,m;
void dfs(int d,int nn){

 if(d==m){
 a[0][nn]++;
 return;
 }
 if(d+1<=m)
 dfs(d+1,(nn<<1));
 if(d+2<=m)
 dfs(d+2,(nn<<2)|3);
}
void dfs1(int d,int nn,int mm){
 if(d==m){
 a[t][nn]+=a[(t+1)%2][mm];
 return ;
 }
 if(d+1<=m){
 dfs1(d+1,(nn<<1)|1,mm<<1);
 dfs1(d+1,(nn<<1),(mm<<1)|1);
 }
 if(d+2<=m){
 dfs1(d+2,(nn<<2)|3,(mm<<2)|3);
 }
}
int main(){
 long long i,j;
 while(cin>>n){
 if(n==-1)break;
 for(i=0;i<(1<<3);i++)
 a[0][i]=a[1][i]=0;
 m=3;
 if(n<m)
 n^=m,m^=n,n^=m;
 dfs(0,0);
 for(i=2;i<=n;i++)
 {
 t=(i+1)%2;
 dfs1(0,0,0);
 memset(a[(t+1)%2],0,sizeof(a[(t+1)%2]));
 }
 cout<<a[(n+1)%2][(1<<m)-1]<<endl;
 }
 return 0;
}