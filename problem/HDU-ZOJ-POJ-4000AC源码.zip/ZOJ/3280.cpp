#include<iostream>
#include<cstdio>
using namespace std;
int b[8],n,k;
struct Point
{
 int x[8];
 void input()
 {
 for(int i=0;i<k;i++) scanf("%d",x+i);
 }
 int cal(int mask)
 {
 int res=x[k-1]*b[k-1];
 for(int i=0;i<k-1;i++)
 {
 if((mask>>i)&1) res+=x[i]*b[i];
 else res-=x[i]*b[i];
 }
 return res;
 }
};

Point ps[100010];

int main()
{
 while(scanf("%d%d",&n,&k)!=EOF)
 {
 for(int i=0;i<n;i++) ps[i].input();
 for(int i=0;i<k;i++) scanf("%d",b+i);
 int ans=-1,lim=1<<k-1;
 for(int mask=0;mask<lim;mask++)
 {
 int maxx=-0x3f3f3f3f,minn=0x3f3f3f3f;
 for(int i=0;i<n;i++)
 {
 int tmp=ps[i].cal(mask);
 maxx=max(maxx,tmp);
 minn=min(minn,tmp);
 }
 ans=max(ans,maxx-minn);
 }
 cout<<ans<<endl;
 }
 return 0;
}
