#include <math.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string.h>
#include <stack>
#include <vector>
#include <stdlib.h>
#include <map>
#define L(x) (x<<1)
#define R(x) (x<<1|1)
#define PB push_back
#define clr(a,b) memset(a,b,sizeof(a))
#define forto(a,n) for(int i=a; i<=n; ++i)
#define forn(i,n) for(int i=0; i<n; ++i)
#define forin(ix, n) for(int ix=0; ix<n; ++ix)
#define Type long long
using namespace std;
const int N=50100;//����
const int M=500100;//ѯ����

//���1...n
int first[N],nxt[N*2]; int tot;//nxtȡ����������
struct Edge{
 int b;
}e[N*2];//����������
void add(int ca, int cb, int v){
 e[tot].b=cb;
 nxt[tot]=first[ca];
 first[ca]=tot++;

 e[tot].b=ca;
 nxt[tot]=first[cb];
 first[cb]=tot++;
}

int firstq[N], nxtq[2*M]; int totq;//nxtqȡѯ����������
struct Que{
 int id, time, c;//time���ڱ�ǵ�ǰѯ���ǵڼ���ѯ��
}Q[M*2];
void addq(int a, int b, int time, int c){
 Q[totq].id= b; Q[totq].time=time;
 Q[totq].c = c;
 nxtq[totq]=firstq[a];
 firstq[a]=totq++;

 Q[totq].id= a; Q[totq].time=time;
 Q[totq].c = c;
 nxtq[totq]=firstq[b];
 firstq[b]=totq++;
}

int set[N];
int dis[N], ans[M];
int n,m,q;//n������m������qѯ����
void init1(){
 tot=1;
 for(int i=0; i<=n; ++i){
 set[i]=0; dis[i]=0;
 first[i]=0; firstq[i]=0;
 }
 for(int i=0; i<=2*n; i++){
 nxt[i]=0;
 }
}
void init2(){
 totq=1;
 for(int i=0; i<=q; i++){
 ans[i]=0;
 }
 for(int i=0; i<=2*q; i++){
 nxtq[i]=0;
 }
}


int Find_Set(int x){
 return set[x]==x?x:set[x]=Find_Set(set[x]);
}
void LCA(int x,int d){
 set[x]=x;
 dis[x]=d;
 for(int i=first[x]; i; i=nxt[i]){
 if(!set[e[i].b]){
 LCA(e[i].b, d+1);
 set[e[i].b]=x;
 }
 }
 for(int i=firstq[x]; i; i=nxtq[i]){
 if(set[Q[i].id]){ //Q[i].id������Ѿ����ʹ�, ���Ի�ȡLCA
 if(ans[Q[i].time]){
 if(set[Q[i].c]==Q[i].c){
 ans[Q[i].time] = (Q[i].c==Find_Set(Q[i].id) ? 1 : 0);
 }else{
 ans[Q[i].time]=1;
 }
 }else{
 ans[Q[i].time]= (set[Q[i].c]==Q[i].c ? 1 : 0);
 }
 }else{
 ans[Q[i].time] = (set[Q[i].c]==Q[i].c ? 1 : 0); //�ж�Q[i].c�Ƿ���x������
 }
 }
}
void solve(int cs){
 printf("Case %d:\n", cs);
 int x, y, a, c, b;
 init1();
 for(int i=1; i<n; ++i){
 scanf("%d%d",&x,&y);
 x++; y++;
 add(x, y, 1);
 }

 scanf("%d", &q);
 init2();
 forn(i, q){
 scanf("%d%d%d",&a,&b,&c);
 a++; b++; c++;
 addq(a, b, i, c);
 }
 for(int i=1; i<=n; i++){
 if(set[i]==0)
 LCA(i, 0);
 }
 forn(i, q){
 if(ans[i]) puts("Yes");
 else puts("No");
 }
}
int main(){
 int t=0;
 while(scanf("%d", &n)!=EOF && n>0){
 if(t) puts("");
 solve(t+1);
 t++;
 }
 return 0;
}





