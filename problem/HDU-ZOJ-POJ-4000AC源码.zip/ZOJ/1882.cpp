//============================================================================
// Name : L.cpp
// Author : 
// Version :
// Copyright : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

//============================================================================
// Name : V.cpp
// Author :
// Version :
// Copyright : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

//============================================================================
// Name : xiuche.cpp
// Author :
// Version :
// Copyright : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

//============================================================================
// Name : xiuche.cpp
// Author :
// Version :
// Copyright : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <stdio.h>
#include <stdlib.h>
#include<memory.h>
#include<math.h>
#define M 200001
#define maxx 2000
#define Max(a, b) a > b ? a : b
#define Min(a, b) a < b ? a : b
#define inf (1 << 29)
#define Inf 0x7fffffff
struct TPoint {
	double x, y;
} p[110], q[110];
struct T {
	int u, v, val, next, cost;
} e[M];
int th;
int n, m, i, j, t, x, k;
double s, v;
int visit[M], pre[M], dis[M], que[M], g[M], pos[M];
double map[110][110];
double diss(TPoint a, TPoint b) {
	return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}
void add(int u, int v, int val, int cost) {
	e[th].u = u, e[th].v = v, e[th].val = val, e[th].cost = cost;
	e[th].next = g[u], g[u] = th++;
	e[th].u = v, e[th].v = u, e[th].val = 0, e[th].cost = -cost;
	e[th].next = g[v], g[v] = th++;
}
int spfa(int s, int t, int n) {
	int i, v, k;
	for (i = 0; i <= n; i++) {
		pre[i] = -1, visit[i] = 0;
	}
	int head, tail;
	head = tail = 0;
	for (i = 0; i <= n; i++)
		dis[i] = Inf; //����С����ʱ����øĳ�������
	que[tail++] = s, pre[s] = s, dis[s] = 0, visit[s] = 1;
	while (head != tail) {
		int u = que[head++];
		visit[u] = 0;
		for (k = g[u]; k != -1; k = e[k].next) {
			v = e[k].v;
			if (e[k].val > 0 && dis[u] + e[k].cost < dis[v]) //�����ã�����С����ʱ����ĸķ���
			{
				dis[v] = dis[u] + e[k].cost;
				pre[v] = u;
				pos[v] = k;
				if (!visit[v]) {
					visit[v] = 1;
					que[tail++] = v;
				}
			}
		}
	}
	if (pre[t] != -1 && dis[t] < Inf) //����С����ʱ����ĳ�dit[t] < ������
	{
		return 1;
	}
	return 0;
}
int MinCostFlow(int s, int t, int n) {
	if (s == t) {
		//�����������������������и���s��t�Ͳ��ã�����������еĵ���Ϊs��t�͵ÿ���
		//ֱ�ӷ���ĳ��ֵ������spfa��Ķ��л���ѭ����
	}
	int flow = 0, cost = 0;
	while (spfa(s, t, n)) {
		int u, min = inf;
		for (u = t; u != s; u = pre[u]) {
			min = Min(min, e[pos[u]].val);
		}
		flow += min;
		cost += dis[t] * min;
		for (u = t; u != s; u = pre[u]) {
			e[pos[u]].val -= min;
			e[pos[u] ^ 1].val += min;
		}
	}

	//printf("%d\n", flow);
	return flow;
}
int main() {
	while (scanf("%d%d%lf%lf", &n, &m, &s, &v) != EOF) {
		th = 0;
		memset(g, -1, sizeof(g));
		for (i = 1; i <= n; i++) {
			scanf("%lf%lf", &p[i].x, &p[i].y);
		}
		for (i = 1; i <= m; i++) {
			scanf("%lf%lf", &q[i].x, &q[i].y);
		}
		for (i = 1; i <= n; i++)
			for (j = 1; j <= m; j++)
				map[i][j] = diss(p[i], q[j]) / v;
		for (i = 1; i <= n; i++)
			add(0, i, 1, 0);
		for (i = 1; i <= m; i++) {
			add(i + n, n + m + 1, 1, 0);
		}
		for (i = 1; i <= n; i++)
			for (j = 1; j <= m; j++)
				if (map[i][j] <= s)
					add(i, j + n, 1, -1);

		int ans = MinCostFlow(0, n + m + 1, n + m + 2);
		printf("%d\n", n - ans);
	}
	return 0;
}

