#include<iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<map>
#include<queue>
using namespace std;
#define NMAX 1001
string ss[101];
int W,H,w,h,ct;
int ans,dir[8][2]={{-1,-1},{1,-1},{-1,0},{0,1},{0,-1},{1,0},{-1,1},{1,1}},vis[101][101],vis1[101][101];
bool isin(int x,int y){
	if(x<0||x>=H) return false;
	if(y>=ss[x].length ()||y<0) return false;
	return true;
}
void display(int aa[][101]){
	for(int i=0;i<H;i++){
		for(int j=0;j<ss[i].length();j++)
			cout<<aa[i][j]<<" ";
		cout<<endl;
	}
}
void dfs(int x,int y){
	ct++;
	char ch=ss[x][y];
	int t;
	if(x%2==0) t=0;
	else t=2;
	for(int i=t;i<t+6;i++){
		int x1=x+dir[i][0],y1=y+dir[i][1];
		if(isin(x1,y1)){
			if(!vis[x1][y1]&&ss[x1][y1]==ch){
				vis[x1][y1]=1;
				dfs(x1,y1);
			}
		}
	}
}
void dfs1(int x,int y){
	//cout<<ans<<endl;
	ans--;
	int t;
	if(x%2==0) t=0;
	else t=2;
	for(int i=t;i<6+t;i++){
		if(dir[i][0]==-1) continue;
		int x1=x+dir[i][0],y1=y+dir[i][1];
		if(isin(x1,y1)&&vis[x1][y1]==0){
			if(!vis1[x1][y1]){
				vis1[x1][y1]=1;
				dfs1(x1,y1);
			}
		}
	}
}
int main(){
	for(;cin>>H>>W>>h>>w;){
		memset(vis,0,sizeof(vis));
		memset(vis1,0,sizeof(vis1));
		ans=0;
		ct=0;
		for(int i=0;i<H;i++){
			cin>>ss[i];
			for(int j=0;j<ss[i].length ();j++){
				if(ss[i][j]!='E')
					ans++;
				else{
					vis[i][j]=1;
				}
			}
		}
		h--;w--;
		vis[h][w]=1;
		dfs(h,w);
		for(int i=0;i<ss[0].length ();i++){
			if(!vis[0][i]&&!vis1[0][i]){
				vis1[0][i]=1;
				dfs1(0,i);
			}
		}
		if(ct<=2)
			ans=0;
		cout<<ans<<endl;
	}
}