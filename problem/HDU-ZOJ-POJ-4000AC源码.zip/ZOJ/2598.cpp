#include <iostream>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <set>
#include <vector>
#include <cstdlib>
#include <string>
#define M0(a) memset(a, 0, sizeof(a))
#define MXN 100010
#define Inf 0xfffff
using namespace std;
const double eps = 1e-10;
const double pi = 3.1415926535897932; 
char s[1000];
vector <int> num;
int a[10000], len;
string f[10000];


inline void clear(string& a){
 while(a.length()>0 && a[0]=='0')
 a.erase(0, 1);
 if(a == "")
 a = "0";
} 


string stringAddString(string a, string b){
 while(a.length() < b.length()) 
 a = '0' + a;
 while(a.length() > b.length())
 b = '0' + b; 
 a = '0' + a;
 b = '0' + b;
 for(int i=a.length()-1; i>=0; i--){
 a[i] = a[i] + b[i] - '0';
 if(a[i] > '9'){
 a[i] = a[i] - 10;
 a[i-1] += 1;
 }
 } 
 clear(a);
 return a; 
}


void make2(){
 len = 0;
 int x;
 while (num.size()){
 a[++len] = (num[0] & 1);
 x = 0;
 for (int i = num.size() - 1; i >= 0; --i){
 x = x * 10 + num[i];
 num[i] = x / 2;
 x = x % 2;
 }
 int size = num.size();
 if (size && num[size - 1] == 0) num.pop_back();
 } 
}

void solve(){
 if (strlen(s) == 1 && s[0] == '0'){
 puts("1");
 return; 
 }
 num.clear();
 for (int i = strlen(s) - 1; i >= 0; --i)
 num.push_back(s[i] - 48);
 int ans = 0;
 make2();
 for (int i = 0; i <= len + 1; ++i)
 f[i] = "0";
 f[0] = "1";
 /*cout << len << endl;
 for (int i = len; i >= 1; --i)
 cout << a[i];
 cout << endl;*/
 for (int i = 1; i <= len; ++i){
 f[i] = f[i - 1];
 if (a[i] == 0) continue;
 for (int j = 1; j < i; ++j)
 if (a[j] == 0){
 f[i] = stringAddString(f[i], f[j-1]);
 } 
 }
 cout << f[len] << endl;
 
 
}

int main(){
 // freopen("d.in","r", stdin);
 // freopen("d.out","w", stdout);
 // ios::sync_with_stdio(false);
 while (scanf("%s", &s) != EOF){
 if (s[0] == '-') break;
 solve(); 
 }
 // fclose(stdin); fclose(stdout); 
 
}
