#include<cstdio>
#include<cstring>
#include<iostream>
#define SD(x) scanf("%d",&x)
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define FF(i,n) for(int i=0;i<n;i++)
using namespace std;
const int maxn= 100005;
char str[maxn];
int sb_top;

int GCD(int a, int b){
 if (a>b) swap(a,b);
 static int t;
 for(;t=b;b=a%b, a=t);
 return a;
}

int main(){
 int nca;
 SD(nca);
 while(nca--){
 int x, y;
 SD(y); SD(x);
 int k= GCD(x, y);
 y/= k, x/= k;
 int last= 0;
 sb_top= 0;

 FOR(i,1,x){
 double tmp= (double)i/x*y;
 int h= (int)(tmp);
 FOR(sb, last+1, h){
 if (sb%2==1) {
 str[sb_top++]= 'N';
 }
 else str[sb_top++]= 'S';
 }
 if (i%2==1) str[sb_top++]= 'E';
 else str[sb_top++]= 'W';
 last= h;
 }

 sb_top-= 2;
 printf("%d\n", sb_top);
 FF(i,sb_top){
 printf("%c ", str[i]);
 }
 int tmp;
 if (x%2==1){
 if (y%2==1) tmp= 3;
 else tmp= 2;
 }else {
 if (y%2==1) tmp= 4;
 else tmp= 1;
 }
 printf("%d", tmp);
 puts("");

 }

}
