/*
 * Author: xioumu
 * Created Time: 2012-4-5 16:22:08
 * File Name: h.cpp
 * solve: h.cpp
 */
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
#define inf 1e-8
#define MAXN 507
#define MAXNUM 20000007
typedef long long int64;
struct node{
 int ad,ne,lo;
} e[1000007];
int n, m, s, t, nm, en, ans;
int g[MAXN];
void add(int x, int y, int z){
 e[en].ne = g[x];
 e[en].ad = y;
 g[x] = en;
 e[en].lo = z;
 en++;
}
void init(){
 int i,j,k,r,w;
 ans = 0;
 en = 2;
 s = 0; 
 t = n + m + 1;
 memset(g, 0, sizeof(g));
 //printf("%d %d\n",n,m);
 for(i=1; i<=n; i++){
 scanf("%d",&k);
 add(s, i, k);
 add(i, s, 0);
 ans += k;
 }
 for(i=1; i<=m; i++){
 scanf("%d",&k);
 add(i + n, t, k);
 add(t, i + n, 0);
 ans += k;
 }
 for(i=1; i <= nm; i++){
 scanf("%d %d",&r, &w);
 //printf("%d %d\n",r,w);
 add(r, w + n, MAXNUM);
 add(w + n, r, 0);
 }
}
int lv[MAXN],zh[MAXN],zp[MAXN],start[MAXN];
int top, re, fr;
int level(){
 int i,j,k;
 int p;
 memset(lv, - 1, sizeof(lv));
 re = fr = 0;
 zh[re++] = s;
 lv[s] = 0;
 while(re != fr){
 k = zh[fr++];
 for(p = g[k]; p; p = e[p].ne){
 //if(k == 0) printf("%d %d---\n",e[p].lo,e[p].ad);
 if(e[p].lo > 0 && lv[ e[p].ad ] == -1){
 lv[ e[p].ad ] = lv[k] + 1;
 zh[re++] = e[p].ad;
 if(e[p].ad == t) return 1;
 }
 }
 }
 //printf("%d %d---\n",);
 return 0;
}
void dinic(){
 int i,j,k,r,w;
 int p;
 top = 0;
 zh[++top] = s;
 for(i = s; i <= t; i++) start[i] = g[i]; 
 while(top != 0){
 k = zh[top];
 //printf("%d\n",top);
 if(k != t){
 for(; start[k]; start[k] = e[ start[k] ].ne)
 if(lv[ e[ start[k] ].ad ] == lv[k] + 1 && e[ start[k] ].lo > 0) 
 break;
 if( !start[k] ) { top--; lv[k] = -1; }
 else{
 zh[++top] = e[ start[k] ].ad;
 zp[top] = start[k];
 }
 }
 else{
 w = MAXNUM;
 for(i=top; i>=2; i--) w = min(w, e[ zp[i] ].lo);
 for(i=top; i>=2; i--){
 e[ zp[i] ].lo -= w;
 e[ zp[i] ^ 1].lo += w;
 if(!e[ zp[i] ].lo)
 top = i - 1;
 //printf("%d ",zh[i]);
 }
 ans -= w;
 //printf("%d : %d\n",zh[top],w); 
 }
 }
}
int v[MAXN];
void dfs(int w, int h){
 int i,j,k,p;
 v[w] = 1;
 for(p=g[w]; p; p = e[p].ne){
 if(v[j = e[p].ad] == 0 && e[p].lo >= h){
 dfs(j, h);
 }
 }
}

void solve(){
 int i,j,k,nn=0,mm=0;
 while( level() )
 dinic();
 memset(v, 0, sizeof(v));
 dfs(s, 1);
 for(i=1; i<=n; i++)
 if(v[i] == 1){
 nn++;
 }
 for(i=n + 1; i<=n + m; i++)
 if(v[i] == 0)
 mm++;
 printf("%d %d %d",ans, nn, mm);
 k = 0;
 if(nn != 0) printf("\n");
 for(i=1; i<=n; i++)
 if(v[i] == 1){
 if(k == 1) printf(" ");
 printf("%d",i);
 k = 1;
 }
 k = 0;
 if(mm != 0) printf("\n");
 for(i=n + 1; i<=n + m; i++)
 if(v[i] == 0){
 if(k == 1) printf(" ");
 printf("%d",i - n);
 k = 1;
 }
}
int main(){
 int i,j,k,r,w,ok = 0;
 while(scanf("%d %d %d",&n,&m,&nm) != EOF){
 if(ok == 1) printf("\n");
 init();
 solve();
 ok = 1;
 }
 return 0;
}
