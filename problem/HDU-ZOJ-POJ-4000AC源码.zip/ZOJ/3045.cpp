#include<iostream>
#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<string>
#include<sstream>
#include<cmath>
#include<queue>
#include<vector>
#include<map>
typedef long long llong;
using namespace std;
const int N=10003;
int a[N];
bool flag[N];
bool isShuffle(int n,int kind)
{
	for(int i=0;i<n;i++)
	{
		if(i%kind==0)
			memset(flag,false,kind*sizeof(flag[0]));
		if(flag[a[i]])
			return false;
		flag[a[i]]=true;
	}
	return true;
}
char s[100003];
int main()
{
	//freopen("in.txt","r",stdin);
	int n;
	while(scanf("%d",&n)==1)
	{
		getchar();
		map<string,int> mp;
		string str;
		int top=0;
		for(int i=0;i<n;i++)
		{
			getline(cin,str);
			if(mp.find(str)==mp.end())
				mp[str]=top++;
			a[i]=mp[str];
		}
		if(isShuffle(n,top))
			puts("Either");
		else
			puts("Random");
	}
}
