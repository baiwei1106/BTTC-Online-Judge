#include<cstdio>
#include<algorithm>
using namespace std;
struct v{
 int l,r;
 bool operator<(const v&t)const{
 return l<t.l;
 }
 void set(){
 scanf("%d%d",&l,&r);
 }
}a[5009];
int main(){
 int i,j,k,n,m,x,y,T;
 scanf("%d",&T);
 while(T--){
 scanf("%d",&n);
 for(i=1;i<=n;i++)
 a[i].set();
 sort(a+1,a+n+1);
 x=1;y=0;
 int ans=1;
 for(i=1;i<=n;i++){
 if(a[i].l<=x){
 y=max(y,a[i].r);
 if(y>=n)
 break;
 }
 else{
 x=y+1;
 ans++;
 y=max(y,a[i].r);
 if(y>=n)
 break;
 }
 }
 printf("%d\n",ans);
 }
 return 0;
}
