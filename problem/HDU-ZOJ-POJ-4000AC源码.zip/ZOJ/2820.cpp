// I'm the Topcoder
//C
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
//C++
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cctype>
#include <stack>
#include <string>
#include <list>
#include <queue>
#include <map>
#include <vector>
#include <deque>
#include <set>
using namespace std;

//*************************JUDGE**************************
#define LOCAL_HOST
#define ONLINE_JUDGE
#define TIME_OUT_PUT

//**************************CONSTANT***********************
#define INF 0x7F7F7F7F
#define eps 1e-8
#define PI acos( -1. )
#define PI2 asin ( 1. );
typedef long long LL;
//typedef __int64 LL; //codeforces
#define MP make_pair
typedef vector<int> VI;
typedef vector<int> VS;
typedef pair<int , int> PII;
#define pb push_back
#define mp make_pair

//***************************SENTENCE************************
#define FOR(a,b,i) for ( i = a ; i < b ; i++ )
#define FORE(a,b,i) for ( i = a ; i <= b ; i++ )
#define REP(i,n) FOR(0,n,i)
#define CL(a,b) memset ( a , b , sizeof ( a ) )
#define sqr(a,b) sqrt ( (double)(a)*(a) + (b)*(b) )

//****************************FUNCTION************************
template < typename T > double DIS ( T va , T vb ) { return sqr ( va.x - vb.x , va.y - vb.y ); }
template < class T> inline T INT_LEN( T v ) { int len = 1 ; while ( v /= 10 ) ++len; return len; }
template < typename T > inline T square ( T va , T vb ) { return va * va + vb * vb ; }
//end

#define cy 55

struct P{
	double x , y ;
}ar[cy] , tmp[cy] , goal[cy];

int N;

void input ( int n ){
	for ( int i = 0 ; i < n ; i++ ){
		scanf ( "%lf%lf" , &ar[i].x , &ar[i].y );
	}
	ar[n] = ar[0];
	for ( int i = 0 ; i <= n ; i++ ){
		tmp[i] = ar[i];
	}
}

void splay_len ( P &va , P &vb , double &mx ){
	double dis = DIS ( va , vb );
	double p = mx / dis;
	double L1 = ( vb.x - va.x ) * p;
	double L2 = ( vb.y - va.y ) * p;
	va.x -= L1 , va.y -= L2;
	vb.x += L1 , vb.y += L2;
}

double det ( P &va , P &vb , P &vc ){
	return ( vb.x - va.x ) * ( vc.y - va.y ) - ( vc.x - va.x ) * ( vb.y - va.y );
}

P insec ( P st1 , P ed1 , P st2 , P ed2 ){
	double eds = fabs ( det ( st1 , ed1 , ed2 ) );
	double sts = fabs ( det ( st1 , ed1 , st2 ) );
	P dd;
	dd.x = ( eds * st2.x + sts * ed2.x ) / ( eds + sts );
	dd.y = ( eds * st2.y + sts * ed2.y ) / ( eds + sts );
	return dd;
}

void left_plane ( P *arr , P *goal , int &la , int &lb , P va , P vb ){
	double mx = 20000;
	lb = 0;
	splay_len ( va , vb , mx );
	arr[la] = arr[0];
	double n1 , n2;
	for ( int i = 0 ; i < la ; i++ ){
		n1 = det ( va , vb , arr[i] );
		n2 = det ( va , vb , arr[i + 1] );
		if ( n1 >= 0 ) goal[lb++] = arr[i];
		if ( n1 * n2 < 0 ) goal[lb++] = insec ( va , vb , arr[i] , arr[i + 1] );
	}
}

void solve ( int n ){
	int len = n , k = 0;
	for ( int i = 0 ; i < n ; i++ ){
		left_plane ( tmp , goal , len , k , ar[i] , ar[-~i] );
		for ( int j = 0 ; j < k ; j++ ) tmp[j] = goal[j];
		len = k;
	}
	if ( len >= 3 ) puts ( "1" );
	else puts ( "0" );
}

int main (void){
	while ( ~scanf ( "%d" , &N ) && N ){
		input ( N );
		solve ( N );
	}
	return 0;
}