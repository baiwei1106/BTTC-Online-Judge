#include<cstdio>
#include<vector>
using namespace std;
vector<int>s;
const int X=100010;
int a[X],l[X],r[X];
int main(){
 int i,j,k,n;
 long long as;
 while(scanf("%d",&n),n){
 s.clear();
 s.push_back(0);
 a[0]=-1;
 as=0;
 for(i=1;i<=n;i++){
 scanf("%d",&k);
 a[i]=k;
 while(k<=a[s.back()])s.pop_back();
 l[i]=s.back();
 s.push_back(i);
 }
 s.clear();
 s.push_back(n+1);
 a[n+1]=-1;
 for(i=n;i>=1;i--){
 k=a[i];
 while(k<=a[s.back()])s.pop_back();
 r[i]=s.back();
 s.push_back(i);
 }
 for(i=1;i<=n;i++)
 as=max(as,((long long)a[i])*(r[i]-l[i]-1));
 printf("%lld\n",as);
 }
 return 0;


}
