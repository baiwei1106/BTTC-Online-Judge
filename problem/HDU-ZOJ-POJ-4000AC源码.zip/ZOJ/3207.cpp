#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<map>
#include<string>
using namespace std;

char s[100];
string ss;
map<string,int>M;

int main()
{
 int n,i,j,k;

 int cnt=0;
 scanf("%d",&n);
 while(n--)
 {
	scanf("%s",s);
	ss=s;
	M[ss]=++cnt;
 }
 scanf("%d",&n);
 while(n--)
 {
	scanf("%d",&k);
	cnt=0;
	while(k--)
	{
	 scanf("%s",s);
	 ss=s;
	 if(M.count(ss))
		cnt++;
	}
	printf("%d\n",cnt);
 }
}