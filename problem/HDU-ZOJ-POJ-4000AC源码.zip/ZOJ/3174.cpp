#include <iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int num[10000],sum[10000],a[20]={0,31,28,31,30,31,30,31,31,30,31,30,31};
int main()
{
	int i,j,m,n,k,t,x,y,T;
	for(i=1;i<=2009;i++)
	{
		for(j=1;j<=12;j++)
			for(k=1;k<=a[j];k++)
			{
				x=j; y=k;
				if(i%400==0||i%4==0&&i%100!=0)
					if(j==2) y++;
				if(x*x==i%100||x*x==i%1000)
					if(y*y==i%100||y*y==i%1000)
						num[i]++;
			}
		sum[i]=sum[i-1]+num[i];
	}
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d%d",&x,&y);
		if(x>y) swap(x,y);
		printf("%d\n",sum[y]-sum[x-1]);
	}
}
