#include<iostream> 
#include<cstdio> 
#include<cstring> 
#include<cstdlib> 
#include<cmath> 
#include<queue> 
#include<stack> 
#include<vector> 
#include<algorithm> 
#include<iomanip> 
using namespace std;

#define lim 105
#define PI 3.1415926535
#define Pi 3.162
#define Len sizeof(struct node) 

int xx[8]={-1, 0 , 1,-1, 1,-1, 0, 1}; 
int yy[8]={ 1, 1 , 1, 0, 0,-1,-1,-1}; 
int min(int x,int y){return x>y?y:x;} 
int max(int x,int y){return x>y?x:y;}

typedef struct node
{
	int t; 
}node;
int compare(const void*elem1,const void *elem2)
{
	return(strcmp((char*)elem1,(char*)elem2));
}

int main() 
{ 
	double n,i,j,k; 
 while (scanf("%lf", &n) != EOF) 
 { 
 
		 j=pow((double)10,n*log10(n)-(int)(n*log10(n)));
		 while((int)j==0)
			 j*=10;
		 
		 printf("%d\n",(int)j);
 } 
 return 0; 
} 
/* 
5
EDEEE
DISKE
ESEEE
ECEEE
EEEEE
DISC
DISK
DISP
0
*/ 



