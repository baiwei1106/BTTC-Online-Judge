#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>
using namespace std;
const int N=250009;
bool flag[N];
struct answer
{
	int a,b;
	bool operator<(answer t)const
	{
		if(b!=t.b)return b<t.b;
		return a<t.a;
	}
}t;
set<int> ans;
set<int>::iterator i1,i2;
set<answer> ans1;
set<answer>::iterator it;
int n,top;
bool J(int a,int b)
{
	int i,t;
	for(i=2;i<n;i++)
	{
		t=a+i*b;
		if(t>top||!flag[t])break;
	}
	return i==n;
}
int main()
{
	int cas=0,m;
	ans.clear();
	while(scanf("%d%d",&n,&m))
	{
		if(n==0&&m==0)break;
		if(cas)puts("");
		ans.clear();
		printf("Case %d:\n",++cas);
		memset(flag,0,sizeof(flag));
		int a,b,p,q,i,j,tmp;
		for(p=0;p<=m;p++)
		{
			for(q=p;q<=m;q++)
			{
				tmp=p*p*p+q*q*q;
				flag[tmp]=1;
				ans.insert(tmp);
			}
		}
		top=m*m*m*2;
		ans1.clear();
		for(i1=ans.begin();i1!=ans.end();i1++)
		{
			t.a=(*i1);
			for(i2=++i1;i2!=ans.end();i2++)
			{
				t.b=(*i2)-t.a;
				if(J(t.a,t.b))
					ans1.insert(t);
			}i1--;
		}
		if(ans1.empty())
		{
			printf("NONE\n");
			continue;
		}
		for(it=ans1.begin();it!=ans1.end();it++)
		{
			printf("%d %d\n",(*it).a,(*it).b);
		}
	}
	return 0;
}
