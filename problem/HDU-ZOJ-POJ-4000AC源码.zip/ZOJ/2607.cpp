/*
 * Author: chlxyd
 * Created Time: 2013/7/25 15:59:28
 * File Name: D.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-10);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )

int sgn(double x) {
 return (x > eps) - (x < -eps);
}

int p[10];
double ry1, ry2, rx1, rx2;
double ansx1, ansx2, ansy1, ansy2;
double a[10], b[10];


bool ok(int *p) {
 return !(p[0] < p[1] && p[1] < p[2] && p[2] < p[3]);
}

double gao3(double limx, double midx) {
 rx1 = midx;
 rx2 = limx - midx; 
 ry1 = max(b[0] / rx1, b[1] / rx2);
 ry2 = max(b[2] / rx1, b[3] / rx2);
 return ry1 + ry2;
}

double gao2(double limx) {
 double l = 0, r = limx;
 double ry = 1e100, midx, y1, y2, x1, x2;
 rep (ca, 100) {
 double mid1 = l + (r - l) / 3;
 double mid2 = l + (r - l) * 2 / 3; 
 double h1 = gao3(limx, mid1);
 double h2 = gao3(limx, mid2);
 if (h1 <= h2) {
 r = mid2;
 if (ry > h1) {
 ry = h1;
 midx = mid1; 
 }
 }
 else {
 l = mid1;
 if (ry > h2) {
 ry = h2;
 midx = mid2;
 }
 }
 }
 ry = gao3(limx, midx);
 return ry;
}

double gao() {
 double l = 0, r = 1e3;
 double xmid, s = 1e100;
 rep (ca, 100) {
 //printf("%d : %.2f %.2f\n", ca, l, r);
 double mid1 = l + (r - l) / 3;
 double mid2 = l + (r - l) * 2 / 3; 
 double h1 = gao2(mid1);
 double h2 = gao2(mid2);
 //printf("%.2f %.2f : %.11f %.11f\n", mid1, mid2, h1, h2);
 if (h1 * mid1 < h2 * mid2) {
 r = mid2;
 if (s > h1 * mid1) {
 s = h1 * mid1;
 xmid = mid1;
 }
 }
 else {
 l = mid1;
 if (s > h2 * mid2) {
 s = h2 * mid2;
 xmid = mid2;
 }
 }
 }
 gao2(xmid);
 return s;
}
int main(){
 while (scanf("%lf%lf%lf%lf", &a[0], &a[1], &a[2], &a[3]) == 4) {
 double ans = 1e100;
 p[0] = 0, p[1] = 1;
 p[2] = 2, p[3] = 3; 
 //do {
 rep (i, 4)
 b[i] = a[p[i]];
 double h = gao();
 if (sgn(ans - h) > 0) {
 ans = h;
 ansx1 = rx1;
 ansx2 = rx2;
 ansy1 = ry1;
 ansy2 = ry2;
 }
 //next_permutation(p, p + 4);
 //}while(ok(p));
 printf("%.11f\n", ans);
 printf("%.11f %.11f %.11f %.11f\n", ansy1, ansy2, ansx1, ansx2);
 }
 return 0;
}

