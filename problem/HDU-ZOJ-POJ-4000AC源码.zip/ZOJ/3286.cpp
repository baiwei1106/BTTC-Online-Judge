#include<stdio.h>
#include<string.h>
#define N 1000100
using namespace std;
int n;
int sum[N],su[N];
int a[N];
int main()
{
 a[1]=1;
 for(int i=2;i<N;i++)a[i]=2;
 for(int i=2;i<=1000;i++)
 {
 int j=i*i;
 while(j<N)
 {
 if(i*i<=j)
 {
 if(i*i==j)a[j]++;
 else a[j]+=2;
 }
 j+=i;
 }
 }
 memset(sum,0,sizeof(sum));
 sum[1]=0;su[1]=1;
 for(int i=2;i<N;i++)
 {
 sum[i]=su[a[i]];
 su[a[i]]++;
 }
 while(scanf("%d",&n)!=EOF)
 {
 printf("%d\n",sum[n]);
 }
 return 0;
}
