// One funny thing is, this submission helps discovering a g++ bug in some version of g++ 4.7.2 (which is used on Codeforces and Ideone)
// Rinko ��

#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <assert.h>

#ifdef ONLINE_JUDGE
#define DAMNANDREWSTANKEVICHWHYWEMUSTOUTPUTANYPLANORUSEBIGINTEGERFOREVERYTASKYOUWRITETHATSHORRIBLE(x) freopen(x ".in","rt",stdin); freopen(x ".out","wt",stdout);
#else
#define DAMNANDREWSTANKEVICHWHYWEMUSTOUTPUTANYPLANORUSEBIGINTEGERFOREVERYTASKYOUWRITETHATSHORRIBLE(x)
#endif

using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<pii,pii> piiii;

class LPDualSolver
{
private:
	enum
	{
		LP_MIN,
		LP_MAX
	};
	enum
	{
		NON_NEGATIVE,
		NON_POSITIVE,
		ARBITARY,
		EQUAL = ARBITARY
	};
	int ParseInt(char* stream,int& pos,const unsigned int len)
	{
		if(pos >= len) return -1;

		int num = 0;
		int sign = 1;
		if(stream[pos] == '-') { sign = -1; pos++; }
		else if(stream[pos] == '+') pos++;
		if(!(stream[pos] >= '0' && stream[pos] <= '9')) return sign;
		while(stream[pos] >= '0' && stream[pos] <= '9' && pos < len)
		{
			num = num*10 + stream[pos]-'0';
			pos++;
		}
		return num * sign;
	}
	int ParsePolynomial(char* stream,int* poly,int maxSize=111)
	{
		memset(poly,0,sizeof(*poly)*maxSize);
		int len = strlen(stream);
		int pos = 0;
		int elements = 0;
		while(pos != len)
		{
			int coeff = ParseInt(stream,pos,len);
			pos++; // "x"
			int varid = ParseInt(stream,pos,len); varid--;
			if(varid < 0) break;
			assert(varid < maxSize);
			poly[varid] = coeff;
			elements++;
		}
		return elements;
	}
	int PrintPolynomial(int* poly,int size)
	{
		bool has = false;
		for(int i = 0;i < size;i++)
		{
			if(poly[i] == 0) continue;

			if(poly[i] == -1) putchar('-');
			else
			{
				if(has && poly[i] > 0) putchar('+');
				if(poly[i] != 1) printf("%d",poly[i]);
			}
			has = true;
			printf("y%d",i+1);
		}
		if(!has) putchar('0');
		return 0;
	}
public:
	int n,m,direction;
	int objective[111];
	int conditions[111];
	int A[111][111];
	int restrictionType[111];
	int restrictionCoeff[111];
	LPDualSolver() { memset(this,0,sizeof(*this)); }
	int ReadStdin()
	{
		scanf("%d %d",&n,&m);
		char str[2333] = {0};
		scanf("%s",str);
		if(str[1] == 'i') direction = LP_MIN;
		else direction = LP_MAX;

		scanf("%s",str);
		ParsePolynomial(str,objective,n);

		scanf("%*s"); // "with"
		for(int i = 0;i < n;i++)
		{
			scanf("%s",str);
			int ZERO = 0;
			int varid = ParseInt(strstr(str,"x")+1,ZERO,-1)-1;
			if(strstr(str,"=") == NULL)
			{
				conditions[varid] = ARBITARY;
				scanf("%*s"); // Arbitary
			}
			else if(strstr(str,">=")) conditions[varid] = NON_NEGATIVE;
			else if(strstr(str,"<=")) conditions[varid] = NON_POSITIVE;
		}

		scanf("%*s"); // "under"
		for(int i = 0;i < m;i++)
		{
			scanf("%s",str);
			char* equal_sign = strstr(str,"=");
			*equal_sign = 0;
			ParsePolynomial(str,A[i],n);
			*equal_sign = '=';
			int ZERO = 0;
			restrictionCoeff[i] = ParseInt(strstr(str,"=")+1,ZERO,-1);
			if(strstr(str,">=")) restrictionType[i] = NON_NEGATIVE;
			else if(strstr(str,"<=")) restrictionType[i] = NON_POSITIVE;
			else restrictionType[i] = EQUAL;
		}
		return 0;
	}
	int ToDual()
	{
		// Transpose A
		int newA[111][111] = {0};
		for(int i = 0;i < m;i++)
		{
			for(int j = 0;j < n;j++)
			{
				newA[j][i] = A[i][j];
			}
		}
		memcpy(A,newA,sizeof(newA));

		// swap objective and restrictionCoeff
		int tmp[111] = {0};
		memcpy(tmp,objective,sizeof(objective));
		memcpy(objective,restrictionCoeff,sizeof(restrictionCoeff));
		memcpy(restrictionCoeff,tmp,sizeof(tmp));

		// swap conditions and restrictionType
		memcpy(tmp,conditions,sizeof(conditions));
		for(int i = 0;i < m;i++)
		{
			if(restrictionType[i] == EQUAL) conditions[i] = ARBITARY;
			else conditions[i] = restrictionType[i] ^ direction;
		}
		for(int i = 0;i < n;i++)
		{
			if(tmp[i] == ARBITARY) restrictionType[i] = EQUAL;
			else restrictionType[i] = tmp[i] ^ direction ^ 1;
		}

		// Tiro Finale
		direction ^= 1;
		swap(n,m);
		return 0;
	}
	int WriteStdout()
	{
		printf("%d %d\n",n,m);
		printf("%s ", direction ? "max" : "min");
		PrintPolynomial(objective,n); puts("");
		puts("with");
		for(int i = 0;i < n;i++)
		{
			static const char* fuckthatcannotbeanonymous[] = {">=0","<=0"," arbitary"};
			printf("y%d%s\n",i+1,fuckthatcannotbeanonymous[conditions[i]]);
		}
		puts("under");
		for(int i = 0;i < m;i++)
		{
			PrintPolynomial(A[i],n);
			static const char* fuckthatcannotbeanonymous[] = {">=","<=","="};
			printf("%s%d\n",fuckthatcannotbeanonymous[restrictionType[i]],restrictionCoeff[i]);
		}
		return 0;
	}
};

int main(void)
{
	int T = 0;
	scanf("%d",&T);
	while(T--)
	{
		LPDualSolver lpds;
		lpds.ReadStdin();
		lpds.ToDual();
		lpds.WriteStdout();
		if(T) puts("");
	}
	return 0;
}