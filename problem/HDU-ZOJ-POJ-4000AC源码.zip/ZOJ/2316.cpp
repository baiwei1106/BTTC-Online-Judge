#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;

typedef long long ll;
int a[10005], n, m;

int main()
{
 int T;
 scanf("%d", &T);
 for(int kase=1; kase<=T; kase++) {
 memset(a, 0, sizeof(a));
 scanf("%d%d", &n, &m);
 for(int j=0; j<m; j++) {
 int x, y;
 scanf("%d%d", &x, &y);
 a[x] ++;
 a[y] ++;
 }

 ll ans = 2 * m;
 //cout << ans << endl;
 for(int i=1; i<=n; i++) {
 ans += (ll)a[i] * ((ll)a[i] - 1);
 }

 cout << ans << endl;
 if(kase != T) printf("\n");
 }

 return 0;
}