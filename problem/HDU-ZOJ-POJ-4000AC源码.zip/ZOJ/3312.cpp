#include <iostream>
#include <sstream>
#include <map>
#include<algorithm>
#include<ctime>
#include<stdio.h>
#include<cmath>
#include<algorithm>
#include<cstring>
#include <string>
using namespace std;
double ba[9]={0,8,88,888,8888,88888,888888,8888888,88888888};
double eps=1e-9;
map<double ,string>dp[10];
map<int,string>mp;

int main()
{
	for(int i=1;i<9;i++)
		dp[i][ba[i]]=string(i,'8');
	map<double,string>::iterator it,it2;
	for(int z=2;z<9;z++)
		for(int q=1;q<z;q++)
		{
			int i=z-q;
			//cout<<i<<" "<<q<<" "<<z<<endl;
			if(i>q)continue;
			for(it=dp[i].begin();it!=dp[i].end();it++)
				for(it2=dp[q].begin();it2!=dp[q].end();it2++)
				{
					double k1=it->first,k2=it2->first;
					string z,a=it->second,b=it2->second;
					if(a.size()!=i)z='('+a+')';
					else z=a;
					a=z;
					if(b.size()!=q)z='('+b+')';
					else z=b;
					b=z;
				//	cout<<a<<" "<<b<<endl;
					dp[i+q][k1*k2]=a+'*'+b;
					dp[i+q][k1+k2]=a+'+'+b;
					dp[i+q][k1-k2]=a+'-'+b;
					if(fabs(k2)>eps)
						dp[i+q][k1/k2]=a+'/'+b;
				//	cout<<a<<" "<<b<<" sdaf "<<k1<<" "<<k2<<endl;
					swap(a,b);
					swap(k1,k2);
					dp[i+q][k1-k2]=a+'-'+b;
					if(fabs(k2)>eps)
						dp[i+q][k1/k2]=a+'/'+b;
					
				}

		}
		for(it=dp[8].begin();it!=dp[8].end();it++)
		{
			int k;
			if(it->first>0)
				 k=it->first+eps;
			else k=it->first-eps;
			if(it->second.size()>=30)cout<<it->second<<endl;
			if(fabs(k-it->first)<eps)
				mp[k]=it->second;

		}
	int n;
	while(cin>>n)
	{
		if(mp[n].size()) {
			cout<<mp[n]<<endl;
		}
		else puts("Impossible");
	}
}

