#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#define LL long long
using namespace std;

int a[15];
int n;
int gcd(int a,int b){
 return b==0?a:gcd(b,a%b);
}

int lcm(int a,int b){
 return a/gcd(a,b)*b;
}

int f(int x){
 int ans=1,k=0;
 int i;
 for(i=0;i<n;i++){
 if(x&(1<<i)){
 ans=lcm(ans,a[i]);
 k++;
 }
 }
 if(k&1) return ans;
 return -ans;
}

int main(){
 int m;
 while(scanf("%d %d",&n,&m)==2){
 int i,x;
 int ans=0;
 for(i=0;i<n;i++) scanf("%d",&a[i]);
 for(x=1;x<(1<<n);x++){
 ans+=m/f(x);
 }
 printf("%d\n",ans);
 }
 return 0;
}
