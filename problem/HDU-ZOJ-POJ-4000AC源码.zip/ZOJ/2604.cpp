#include <iostream>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <set>
#include <vector>
#include <cstdlib>
#include <string>
#define M0(a) memset(a, 0, sizeof(a))
#define MXN 100010
#define Inf 0xfffff
using namespace std;
int n, m, cas;
string f[55][55];
int a[10000][2];

inline void clear(string& a){
 while(a.length()>0 && a[0]=='0')
 a.erase(0, 1);
 if(a == "")
 a = "0";
} 

string stringAddString(string a, string b){
 while(a.length() < b.length()) 
 a = '0' + a;
 while(a.length() > b.length())
 b = '0' + b; 
 a = '0' + a;
 b = '0' + b;
 for(int i=a.length()-1; i>=0; i--){
 a[i] = a[i] + b[i] - '0';
 if(a[i] > '9'){
 a[i] = a[i] - 10;
 a[i-1] += 1;
 }
 } 
 clear(a);
 return a; 
}

string stringMultString(string a, string b){
 string result = "0";
 if(a.length() < b.length()){
 string buf = a;
 a = b;
 b = buf;
 } 
 for(int i=b.length()-1; i>=0; i--){
 for(int j=0; j<b[i]-'0'; j++){
 result = stringAddString(result, a);
 }
 a = a + '0';
 }
 clear(result);
 return result; 
}

string stringSubString(string a, string b){
 bool aBigger = true;
 while(a.length() < b.length()) 
 a = '0' + a;
 while(a.length() > b.length())
 b = '0' + b; 
 if(a < b) 
 { 
 aBigger = false; 
 string buf = b; 
 b = a; 
 a = buf; 
 } 
 for(int i=a.length()-1; i>=0; i--){
 if(a[i] >= b[i]){
 a[i] = a[i] - (b[i] - '0');
 }else{
 a[i] = a[i] + 10;
 a[i-1] -= 1;
 a[i] = a[i] - (b[i] - '0');
 }
 }
 clear(a);
 if(!aBigger) 
 a = '-' + a;
 return a; 
}

void dp(){
 for (int i = 0; i <= 50; ++i)
 for (int j = 0; j <= 50; ++j)
 f[i][j] = "0\0";
 for (int i = 0; i <= 50; ++i)
 f[0][i] = "1\0";
 for (int i = 1; i <= 50; ++i)
 for (int j = 1; j <= 50; ++j)
 for (int k = 1; k <= i; ++k)
 f[i][j] = stringAddString(f[i][j] , stringMultString(f[i-k][j] , f[k-1][j-1]));
}

int main(){
 // freopen("a.in", "r", stdin);
 // freopen("a.out", "w", stdout);
 cas = 0;
 dp();
 while (scanf("%d%d", &n, &m) != EOF){
 if (n == 0) break;
 a[++cas][0] = n;
 a[cas][1] = m; 
 }
 for (int i = 1; i <= cas; ++i){
 cout << "Case "<< i << ": ";
 n = a[i][0];
 m = a[i][1];
 cout << stringSubString(f[n][m], f[n][m-1]) << endl;
 if (i < cas) cout << endl;
 }
 fclose(stdin); fclose(stdout); 
}