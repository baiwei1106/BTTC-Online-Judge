/*
 * Author: chlxyd
 * Created Time: 2013/7/19 20:21:36
 * File Name: D1.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )
long long f[80];
int main(){
 f[1] = 2;
 f[2] = 20;
 f[3] = 980;
 f[4] = 232848;
 f[5] = 267227532;
 f[6] = 1478619421136;
 f[7] = 39405996318420160;
 bool first = true ;
 int n ;
 while ( scanf("%d" , &n ) == 1 ) {
 if ( !first ) puts("") ;
 first = false ;
 printf("%lld\n" , f[n] ) ;
 }
}
