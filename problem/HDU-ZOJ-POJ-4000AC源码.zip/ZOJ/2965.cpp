#include <iostream>
using namespace std;
int main()
{
 int t;
 cin >> t;
 while(t--)
 {
 int n;
 cin >> n;
 if(n==1)
 cout << "7" << endl;
 else if(n==2)
 cout << "27" << endl;
 else if(n>2&&n<=10)
 cout << "70" << endl;
 else if(n==11)
 cout << "270" << endl;
 else
 cout << "700" << endl;
 }
 return 0;
}