#include<stdio.h>


int main()
{
 int i,j,k;
 int n,m;
 int cntin=0;
 int resu=9999999;
 int count[3000]={0};
 int a[400100];
 int low[3000],high[3000];
 while (scanf("%d%d",&n,&m)==2)
 {
 for (i=1;i<=n;i++)
 scanf("%d",&a[i]);
 for (i=1;i<=m;i++)
 {
 scanf("%d%d",&low[i],&high[i]);
 count[i]=0;
 }
 resu=9999999;
 cntin=0;
 for (i=1;i<=m;i++)
 if (count[i]>=low[i]&&count[i]<=high[i])
 cntin++;
 if (cntin==m)
 resu=0;
 for (i=1,j=1;j<=n;j++)
 {
 count[a[j]]++;
 if (count[a[j]]==low[a[j]])
 cntin++;
 while (i<=j&&(count[a[j]]>high[a[j]]||count[a[i]]>low[a[i]]))
 {
 if (count[a[i]]==low[a[i]])
 cntin--;
 count[a[i]]--;
 i++;
 }
 if (cntin==m)
 {
 if (j-i+1<=resu)
 resu=j-i+1;
 }
 }
 if (resu>n)
 printf("%d\n",-1);
 else
 printf("%d\n",resu);
 }
 return 0;
}
