#include <cstdio>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>

using namespace std;
typedef pair<string, int> psi;
typedef vector<psi> vpsi;

struct Node {
	Node *child[2], *parent;
	string key;
 	int fix;
	Node(string _key, int _fix) {
		child[0] = child[1] = parent = NULL;
		key = _key;
		fix = _fix;
	}
};

struct Cartesian {
	Node *root, *back;
	Cartesian() {
		root = back = NULL;
	}

	void rotate(Node *rt, bool left){
		bool right = !left;
		Node *p = rt->child[right];

		p->parent = rt->parent;
		if (p->child[left]) p->child[left]->parent = rt;
		rt->child[right] = p->child[left];
		rt->parent = p-> child[left];
		p->child[left] = rt;
	}

	void pushBack(Node *x) {
		Node *p = back;

		while (p && p->fix < x->fix) p = p->parent;
//printf("insert at %d\n", p);
		if (p) {
			if (p->child[false]) p->child[false]->parent = x;
			x->child[true] = p->child[false];
			x->parent = p;
			p->child[false] = x;
		} else {
			if (root) root->parent = x;
			x->child[true] = root;
			root = x;
		}
		back = x;
	}

	void print(Node *T) {
		if (!T) return ;
		putchar('(');
		print(T->child[true]);
		printf("%s/%d", T->key.c_str(), T->fix);
		print(T->child[false]);
		putchar(')');
	}
}cart;

void deal(int n) {
	cart = Cartesian();

	char buf[100];
	vpsi tmp;

	while (n--){
		scanf("%s", buf);

		int p = 0, key;

		while (buf[p] != '/') p++;
		buf[p] = 0;
		sscanf(&buf[p + 1], "%d", &key);
		tmp.push_back(make_pair(buf, key));
	}
	sort(tmp.begin(), tmp.end());

	int size = tmp.size();

	for (int i = 0; i < size; i++) {
		Node *temp = new Node(tmp[i].first, tmp[i].second);

//printf("cur %s %d\n", tmp[i].first.c_str(), tmp[i].second);
//puts("pass");
//printf("back %d\n", cart.back);
		cart.pushBack(temp);
//cart.print(cart.root);
//puts("");
	}
	cart.print(cart.root);
	puts("");
}

int main(){
	int n;

//freopen("in", "r", stdin);
	while (~scanf("%d", &n) && n){
		deal(n);
	}

	return 0;
}




















