#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<list>
#define EPS 1e-9
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define oo 123456789
typedef long long LL;
const double PI = acos(-1.0);
using namespace std;
/*******************************************************/
#define MAXN 35
LL dp[MAXN];
int main() {
	dp[1] = 1;
	dp[2] = 2;
	int i;
	int T;
	for (i = 3; i < MAXN; i++) {
		dp[i] = dp[i - 1] + 2 * dp[i - 2] + 1;
	}
	cin >> T;
	while (T--) {
		cin >> i;
		cout << dp[i] << endl;
	}
	return 0;
}
