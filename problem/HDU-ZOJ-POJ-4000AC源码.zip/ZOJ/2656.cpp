/* 
 * File: i.cpp
 * Author: kingwei
 *
 * Created on 2010��10��21��, ����12:48
 */
#define maxn 20020
#include <cstdlib>
#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <iostream>
#include <vector>
#include <queue>

using namespace std;

struct Tdata{ int oil, city; };

struct cmp{
	bool operator()(const Tdata &a,const Tdata &b){
		return a.oil > b.oil;
	}
};

bool used[maxn];
priority_queue<Tdata, vector<Tdata>, cmp> cnt;
int n;
int dis[maxn], oil[maxn];

bool init(){
	if (scanf("%d", &n) == EOF) return false;
	for (int i=0; i<n; i++) {
		scanf("%d%d", &oil[i], &dis[i]);
		dis[i+n] = dis[i], oil[i+n] = oil[i];
	}
	return true;
}

void solve(){
	while (!cnt.empty()) cnt.pop();
	Tdata d; d.oil = d.city = 0;
	cnt.push(d);;
	int now=oil[0];
	memset(used, 0, sizeof used);
	int ret = -1;
	for (int i=1; i<2*n; i++){
		now-=dis[i-1]; //printf("now:%d\n", now);
		while (!cnt.empty()) {
			if (now+cnt.top().oil < 0){
				used[cnt.top().city] = true;
				cnt.pop();
			}
			else break;
		}
		now+=oil[i];
		if (i<n) {
			d.oil = oil[i]-now, d.city = i;
			cnt.push(d);
		}
		else if (!used[i-n]) {
			printf("%d\n", i-n);
			return;
		}
	}
	printf("impossible\n");
}

int main(int argc, char** argv) {
//	freopen("i.in", "r", stdin);
	while (init()) solve();
	return 0;
}

