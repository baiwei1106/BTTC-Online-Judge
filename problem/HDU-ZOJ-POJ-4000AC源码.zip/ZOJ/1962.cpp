#include<iostream>
#include<string>
using namespace std;

string bigIntegerSum(string one,string two)
{
 int flag=0,i,j;
 string sum="";
 if(one.length()<two.length())
 swap(one,two);
 for(i=one.length()-1,j=two.length()-1;i>=0&&j>=0;i--,j--)
 {
 if(one[i]+two[j]-48+flag>'9')
 {
 sum=char(one[i]+two[j]-48+flag-10)+sum;
 flag=1;
 }
 else
 {
 sum=char(one[i]+two[j]-48+flag)+sum;
 flag=0;
 }
 }
 for(;i>=0;i--)
 {
 if(one[i]+flag>'9')
 {
 sum=char(one[i]+flag-10)+sum;
 flag=1;
 }
 else
 {
 sum=char(one[i]+flag)+sum;
 flag=0;
 }
 }
 if(flag==1)
 sum="1"+sum;
 return sum;
}
string flag[5000];

int fibo(string a,string b)
{
 int count=0;
 flag[0]="1";flag[1]="2";
 for(int i=0;;i++)
 {
 if(i>=2)
 flag[i]=bigIntegerSum(flag[i-2],flag[i-1]);
 if((flag[i]>=a&&flag[i].length()==a.length()||flag[i].length()>a.length())&&(flag[i]<=b&&flag[i].length()==b.length()||flag[i].length()<b.length()))
 count++;
 if(flag[i]>b&&flag[i].length()==b.length()||flag[i].length()>b.length())
 break;
 }
 return count;
}

int main()
{
 string a,b;
 while(cin>>a>>b)
 {
 if(a=="0"&&b=="0")
 break;
 cout<<fibo(a,b)<<endl;
 }
 return 0;
}

 