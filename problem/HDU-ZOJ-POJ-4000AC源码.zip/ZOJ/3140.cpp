#include<algorithm>
#include<vector>
#include<iostream>
#include<cstdio>
#define maxn 5050
using namespace std;

int n,m;
int l[maxn];

int main()
{
 // freopen("input.txt","r",stdin);
 int T;
 int i,j;
 scanf("%d",&T);
 while(T--)
 {
 scanf("%d %d",&n,&m);
 for(i=1;i<=n;i++)
 {
 scanf("%d",&l[i]);
 }
 i=1;
 int temp;
 int ans=0;
 sort(l+1,l+1+n);
 while(i<=n)
 {
 temp=1;
 if(i+1<=n&&l[i]+m>=l[i+1])
 {
 temp++;
 i++;
 while(i-1>=1&&i+1<=n&&l[i-1]+m>=l[i+1]&&l[i]+m>=l[i+1])
 {
 temp++;
 i++;
 }
 }
 else
 {
 i++;
 }
 ans=max(temp,ans);
 }
 printf("%d\n",ans);
 }
 return 0;
}
