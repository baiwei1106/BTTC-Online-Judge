#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
#define M 25000
struct edge{
 int x,y,w;
}eg[M];
int fa[M];
int n,m;
bool cmp(edge t1,edge t2)
{
 return t1.w < t2.w;
}
void init()
{
 for(int i = 0;i < M;i ++)
 fa[i] = i;
}
int get(int x)
{
 if(x == fa[x])
 return x;
 else
 return get(fa[x]);
}
void kruscal()
{
 init();
 int maxe=0;
 for(int i = 0;i < m;i ++)
 {
 int xx = get(eg[i].x);
 int yy = get(eg[i].y);
 if(xx != yy)
 {
 if(xx>yy)
 fa[yy] = xx;
 else
 fa[xx] = yy;
 maxe += eg[i].w;
 }
 }
 cout << maxe << endl;
}
int main()
{
 int t;
 scanf("%d",&t);
 while(t--)
 {
 scanf("%d%d",&n,&m);
 for(int i = 0;i < m;i ++)
 {
 scanf("%d%d%d",&eg[i].x,&eg[i].y,&eg[i].w);
 }
 sort(eg,eg+m,cmp);
 kruscal();
 }
 return 0;
}