#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
int num[1000];
int flag[1000];
int main()
{

	
 int cnt=0;
 int n;
 char s[10];
 while(true)
 {
 cnt=0;
	 while(true)
	 {
	 scanf("%d",&n); 	 
 if(n==0)return 0;
		 scanf("%*s%s",s);
		 num[++cnt]=n;
		 if(s[0]=='h')flag[cnt]=1;
		 else if(s[0]=='l')flag[cnt]=-1;
		 else break;
	 }
		bool ans=true;
		for(int i=1;i<cnt&&ans;i++)
		if(num[cnt]>num[i]&&flag[i]==1)ans=false;
		else if(num[cnt]==num[i])ans=false;		
		else if(num[cnt]<num[i]&&flag[i]==-1)ans=false;
		if(ans)printf("Stan may be honest\n");
		else printf("Stan is dishonest\n");
				
	}
 
 
	return 0;
}
