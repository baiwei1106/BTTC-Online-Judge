#include <stdio.h>
#include <cstring>

int n, top, num;
char str[100];

int getval(char str[])
{
	int ans = 0;
	for(int i=1; i<7; ++i) ans = ans * 2 + str[i] - '0';
	ans = ans * (str[0] == '0' ? 1 : -1);
	return ans;
}

int main()
{
	while(scanf("%d", &n), n != -1)
	{
		int ans = 0;
		top = 0;
		for(int i=0; i<n; ++i)
		{
			scanf("%d", &num);
			for(int j=1<<15; j; j>>=1)
			{
				int x = ((j & num) > 0);
				str[top++] = '0' + x;
				if(top == 7)
				{
					int tmp = getval(str);
					ans += tmp;
					top = 0;
				}
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}
