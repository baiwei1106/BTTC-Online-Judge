#include<iostream>
using namespace std;
int f[105];
int findT()
{
 for(int T=1;T<52;T++)
 {
 int flag=1;
 for(int i=1;i<=T;i++) if(f[i]!=f[i+T]) flag=0;
 if(flag){f[0]=f[T]; return T;}
 }
}
void fan(int a,int b,int n)
{
 if(n<=0) {cout<<1<<endl;return;}
 f[1]=(a+b)%7;
 f[2]=(f[1]*a+b)%7;
 for(int i=3;i<105;i++)
 f[i]=(a*f[i-1]+b*f[i-2])%7;
 int T=findT();
 cout<<f[n%T]<<endl;
}
int main()
{
 int a,b,n;
 while(cin>>a>>b>>n&&a+b+n!=0)
 fan(a%7,b%7,n-2);
 return 0;
}
