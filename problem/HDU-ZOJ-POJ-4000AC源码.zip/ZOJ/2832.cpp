#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<string>
#include<set>
using namespace std;
set<string> a;
string b[105];
string c;
set<string>:: iterator cp;
bool cmp(string x,string y)
{
	return x<y;
}
int main()
{
	int n,m,t=0;
	int i,j,cas;
	while(scanf("%d",&n)!=EOF)
	{
		if(t==0)
		t=1;
		else
		printf("\n");
		for(i=0;i<n;i++)
		{
			//scanf("%s%d",&b[i],&m);
			cin>>b[i]>>m;
			for(j=0;j<m;j++)
			{
				//scanf("%s",c);
				cin>>c;
				a.insert(c);
			}
		}
		sort(b,b+n,cmp);
		for(i=0;i<n;i++)
		{
			cp=a.find(b[i]);
			if(cp==a.end())
			//printf("%s\n",b[i]);
			cout<<b[i]<<endl;
		}
		a.clear();
	}
}
