#include<iostream>
#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<queue>
using namespace std;
const int MAX=1000000000;
const int N=1005;
struct node
{
	int x,h;
	bool operator<(const node& a) const{
		return a.h<h;
	}
};
int map[N][N],m[N],n,st,en;
int half(int x,int h)
{
	int l=0,r=m[x]-1,mid;
	while(l<=r)
	{
		mid=(l+r)/2;
		if(map[x][mid]<=h) l=mid+1;
		else r=mid-1;
	}
	if(map[x][mid]<=h) return map[x][mid+1];
	return map[x][mid];
}
int bfs(int st,int sth,int t)
{
	int mark[N];
	priority_queue<node> q;
	memset(mark,-1,sizeof(mark));
	while(!q.empty())
		q.pop();
	mark[st]=sth;
	node top,next;next.h=sth;next.x=st;
	int x,h,h1,h2;
	q.push(next);
	while(!q.empty())
	{
		top=q.top();q.pop();
		h=top.h;x=top.x;//printf("%d %d %d\n",h,x,t);
		if(x>0) h1=half(x-1,h);
		else h1=MAX;
		if(x<n-1) h2=half(x,h);
		else h2=MAX;//printf("%d %d\n",h1,h2);
		if(h1==MAX&&h2==MAX&&x==en) return 1;
		if(h1==MAX&&h2==MAX) continue;
		if(h1<h2)
		{
			if(mark[x-1]==-1||mark[x-1]<h1)
			{
				mark[x-1]=h1;
				next.x=x-1;next.h=h1;
				q.push(next);
			}
		}
		else
		{
			if(mark[x+1]==-1||mark[x+1]<h2)
			{
				mark[x+1]=h2;
				next.x=x+1;next.h=h2;
				q.push(next);
			}
		}
		if(t) continue;
		if(h1<h2)
		{
			if(bfs(x,h1,1)) return 1;
		}
		else
		{
			if(bfs(x,h2,1)) return 1;
		}
	}
	return 0;
}
int main()
{
	int i,j,k;
	while(scanf("%d",&n)!=EOF)
	{
		for(i=0;i<n-1;i++)
		{
			scanf("%d",&m[i]);
			for(j=0;j<m[i];j++)
				scanf("%d",&map[i][j]);
			sort(map[i],map[i]+m[i]);
			map[i][m[i]]=MAX;
		}
		scanf("%d%d",&st,&en);st--;en--;
		if(bfs(st,0,0)) printf("Yes\n");
		else printf("No\n");
	}
 return 0;
}
