#include<iostream>
#include<algorithm>
using namespace std;
int fib[40];
int main()
{
 fib[0]=1,fib[1]=2;
 for(int i=2;i<40;i++) fib[i]=fib[i-1]+fib[i-2];
 int x;
 while(cin>>x)
 {
 if(*lower_bound(fib,fib+40,x)==x)
 {
 cout<<"lose"<<endl;
 continue;
 }
 while(1)
 {
 int id=upper_bound(fib,fib+40,x)-fib-1;
 if(fib[id]==x) break;
 x-=fib[id];
 }
 cout<<x<<endl;
 }
 return 0;
}
