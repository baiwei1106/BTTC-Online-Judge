#include<iostream>

using namespace std;
 int a[1100][1100];
 int gao(int i,int j)
{
if(i<0||j<0) return 0;
 for(int k=i-1;k>=0;k--)
 {
 if(a[k][j]!=0)
 {//a[k][j]=0;
 gao(k,j);
 }

 }
 for(int k=1;k<=a[i][j];k++)
 {
 if(a[i][j-k]!=0)
 {//a[i][j-k]=0;
 gao(i,j-k);
 }

 }
 a[i][j]=0;

 return 0;
}
int main()
{
 int i,j;

 int n,m;
 int sum;

 while(cin>>n>>m)
 {
 for(i=0;i<n;i++)
 {
 for(j=0;j<m;j++)
 {
 cin>>a[i][j];
 }
 }
 sum=0;
 for(i=n-1;i>=0;i--)
 {
 for(j=m-1;j>=0;j--)
 {
 if(a[i][j]!=0)
 {
 gao(i,j);
 sum++;
 }
 }
 }
 cout<<sum<<endl;
 }
}
