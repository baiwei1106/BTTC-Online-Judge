#include<iostream>
#include<string.h>
using namespace std;
int main()
{
 int n,a[3001],b[3001],i,j,k;
 while(cin>>n)
 {
 if(n>0&&n<=3000)
 {
 for(i=1;i<=n;i++)
 {
 cin>>a[i];
 }
 if(n==1)
		 {
 cout<<"Jolly"<<endl;
 } 
		 else
		 {
		 k=0;
		 memset(b,0,sizeof(b));
 for(i=1;i<=n-1;i++)
 {
 if(a[i]-a[i+1]>=0)
				 b[i]=a[i]-a[i+1];
			 if(a[i]-a[i+1]<0)
				 b[i]=a[i+1]-a[i];
 }
		 for(i=1;i<=n-1;i++)
		 {
			for(j=1;j<=n-1;j++)
			{
			if(i==b[j])
			{
				k++;
				break;
			}
			}
		 }
 if(k==n-1)
 {
 cout<<"Jolly"<<endl;
 }
 else
 {
 cout<<"Not jolly"<<endl;
 }
		 }
 }
 }
 return 0;
}
