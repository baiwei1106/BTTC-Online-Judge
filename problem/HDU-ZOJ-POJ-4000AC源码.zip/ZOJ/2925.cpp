#include <stdio.h>

int n,m,mark = 0,sx,sy;
char map[505][505],sd[5];
int qx[250005],qy[250005],p,l;

void print(){
 int i,j;
 
 if(mark)
 printf("\n");
 
 for(i = 1;i <= n;i ++){
 for(j = 1;j <= m;j ++)
 printf("%c",map[i][j]);
 printf("\n");
 }
}

int main(){ 
 int i,j;
 
 while(scanf("%d %d",&n,&m) != EOF){
 for(i = 1;i <= n;i ++){
 scanf("%s",map[i]);
 for(j = m;j > 0;j --)
 map[i][j] = map[i][j - 1];
 } 
 
 scanf("%d %d %s",&sx,&sy,sd);
 
 map[sx][sy] = sd[0];
 qx[0] = sx,qy[0] = sy;
 p = 0,l = 1;
 while(p < l){
 if(map[qx[p]][qy[p]] == 'N'){
 if(qx[p] - 1 > 0 && map[qx[p] - 1][qy[p]] == 'X'){
 map[qx[p] - 1][qy[p]] = 'N';
 qx[l] = qx[p] - 1,qy[l] = qy[p];
 l ++;
 }
 if(qx[p] - 1 > 0 && qy[p] - 1 > 0 && map[qx[p] - 1][qy[p] - 1] == 'X'){
 map[qx[p] - 1][qy[p] - 1] = 'V';
 qx[l] = qx[p] - 1,qy[l] = qy[p] - 1;
 l ++;
 }
 if(qx[p] - 1 > 0 && qy[p] + 1 <= m && map[qx[p] - 1][qy[p] + 1] == 'X'){
 map[qx[p] - 1][qy[p] + 1] = 'Y';
 qx[l] = qx[p] - 1,qy[l] = qy[p] + 1;
 l ++;
 }
 }
 else if(map[qx[p]][qy[p]] == 'Y'){
 if(qx[p] - 1 > 0 && qy[p] + 1 <= m && map[qx[p] - 1][qy[p] + 1] == 'X'){
 map[qx[p] - 1][qy[p] + 1] = 'Y';
 qx[l] = qx[p] - 1,qy[l] = qy[p] + 1;
 l ++;
 }
 if(qx[p] - 1 > 0 && map[qx[p] - 1][qy[p]] == 'X'){
 map[qx[p] - 1][qy[p]] = 'N';
 qx[l] = qx[p] - 1,qy[l] = qy[p];
 l ++;
 }
 if(qy[p] + 1 <= m && map[qx[p]][qy[p] + 1] == 'X'){
 map[qx[p]][qy[p] + 1] = 'E';
 qx[l] = qx[p],qy[l] = qy[p] + 1;
 l ++;
 }
 }
 else if(map[qx[p]][qy[p]] == 'E'){
 if(qy[p] + 1 <= m && map[qx[p]][qy[p] + 1] == 'X'){
 map[qx[p]][qy[p] + 1] = 'E';
 qx[l] = qx[p],qy[l] = qy[p] + 1;
 l ++;
 }
 if(qx[p] - 1 > 0 && qy[p] + 1 <= m && map[qx[p] - 1][qy[p] + 1] == 'X'){
 map[qx[p] - 1][qy[p] + 1] = 'Y';
 qx[l] = qx[p] - 1,qy[l] = qy[p] + 1;
 l ++;
 }
 if(qx[p] + 1 <= n && qy[p] + 1 <= m && map[qx[p] + 1][qy[p] + 1] == 'X'){
 map[qx[p] + 1][qy[p] + 1] = 'Q';
 qx[l] = qx[p] + 1,qy[l] = qy[p] + 1;
 l ++;
 }
 }
 else if(map[qx[p]][qy[p]] == 'Q'){
 if(qx[p] + 1 <= n && qy[p] + 1 <= m && map[qx[p] + 1][qy[p] + 1] == 'X'){
 map[qx[p] + 1][qy[p] + 1] = 'Q';
 qx[l] = qx[p] + 1,qy[l] = qy[p] + 1;
 l ++;
 }
 if(qy[p] + 1 <= m && map[qx[p]][qy[p] + 1] == 'X'){
 map[qx[p]][qy[p] + 1] = 'E';
 qx[l] = qx[p],qy[l] = qy[p] + 1;
 l ++;
 }
 if(qx[p] + 1 <= n && map[qx[p] + 1][qy[p]] == 'X'){
 map[qx[p] + 1][qy[p]] = 'S';
 qx[l] = qx[p] + 1,qy[l] = qy[p];
 l ++;
 }
 }
 else if(map[qx[p]][qy[p]] == 'S'){
 if(qx[p] + 1 <= n && map[qx[p] + 1][qy[p]] == 'X'){
 map[qx[p] + 1][qy[p]] = 'S';
 qx[l] = qx[p] + 1,qy[l] = qy[p];
 l ++;
 }
 if(qx[p] + 1 <= n && qy[p] + 1 <= m && map[qx[p] + 1][qy[p] + 1] == 'X'){
 map[qx[p] + 1][qy[p] + 1] = 'Q';
 qx[l] = qx[p] + 1,qy[l] = qy[p] + 1;
 l ++;
 }
 if(qx[p] + 1 <= n && qy[p] - 1 > 0 && map[qx[p] + 1][qy[p] - 1] == 'X'){
 map[qx[p] + 1][qy[p] - 1] = 'J';
 qx[l] = qx[p] + 1,qy[l] = qy[p] - 1;
 l ++;
 }
 }
 else if(map[qx[p]][qy[p]] == 'J'){
 if(qx[p] + 1 <= n && qy[p] - 1 > 0 && map[qx[p] + 1][qy[p] - 1] == 'X'){
 map[qx[p] + 1][qy[p] - 1] = 'J';
 qx[l] = qx[p] + 1,qy[l] = qy[p] - 1;
 l ++;
 }
 if(qx[p] + 1 <= n && map[qx[p] + 1][qy[p]] == 'X'){
 map[qx[p] + 1][qy[p]] = 'S';
 qx[l] = qx[p] + 1,qy[l] = qy[p];
 l ++;
 }
 if(qy[p] - 1 > 0 && map[qx[p]][qy[p] - 1] == 'X'){
 map[qx[p]][qy[p] - 1] = 'W';
 qx[l] = qx[p],qy[l] = qy[p] - 1;
 l ++;
 }
 }
 else if(map[qx[p]][qy[p]] == 'W'){
 if(qy[p] - 1 > 0 && map[qx[p]][qy[p] - 1] == 'X'){
 map[qx[p]][qy[p] - 1] = 'W';
 qx[l] = qx[p],qy[l] = qy[p] - 1;
 l ++;
 }
 if(qx[p] + 1 <= n && qy[p] - 1 > 0 && map[qx[p] + 1][qy[p] - 1] == 'X'){
 map[qx[p] + 1][qy[p] - 1] = 'J';
 qx[l] = qx[p] + 1,qy[l] = qy[p] - 1;
 l ++;
 }
 if(qx[p] - 1 > 0 && qy[p] - 1 > 0 && map[qx[p] - 1][qy[p] - 1] == 'X'){
 map[qx[p] - 1][qy[p] - 1] = 'V';
 qx[l] = qx[p] - 1,qy[l] = qy[p] - 1;
 l ++;
 }
 }
 else if(map[qx[p]][qy[p]] == 'V'){
 if(qx[p] - 1 > 0 && qy[p] - 1 > 0 && map[qx[p] - 1][qy[p] - 1] == 'X'){
 map[qx[p] - 1][qy[p] - 1] = 'V';
 qx[l] = qx[p] - 1,qy[l] = qy[p] - 1;
 l ++;
 }
 if(qy[p] - 1 > 0 && map[qx[p]][qy[p] - 1] == 'X'){
 map[qx[p]][qy[p] - 1] = 'W';
 qx[l] = qx[p],qy[l] = qy[p] - 1;
 l ++;
 }
 if(qx[p] - 1 > 0 && map[qx[p] - 1][qy[p]] == 'X'){
 map[qx[p] - 1][qy[p]] = 'N';
 qx[l] = qx[p] - 1,qy[l] = qy[p];
 l ++;
 }
 }
 
 p ++;
 }
 
 print();
 if(!mark)
 mark = 1;
 }

 return 0; 
}
