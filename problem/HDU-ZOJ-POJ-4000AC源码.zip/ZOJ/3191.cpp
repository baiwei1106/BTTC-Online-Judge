#include<stdio.h>
#include<string.h>

int main()
{
	int a;
	while(1){
		scanf("%d",&a);
		if(a == -1)
			break;
		a = 360 - a;
		a += 90;
		a %= 360;
		if(a % 30 == 0)
			printf("Exactly %d o'clock\n",a / 30);
		else{
			int l = a / 30;
			int r = l + 1;
			if(r == 12)
				r = 0;
			printf("Between %d o'clock and %d o'clock\n",l,r);
		}
	}
	return 0;
}