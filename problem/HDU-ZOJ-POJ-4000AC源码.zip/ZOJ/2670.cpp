#include<cstdio>

int main()
{
 int n;
 while(scanf("%d", &n) == 1)
 {
 if(n > 100) {
 printf("Impossible\n");
 continue;
 }
 for(int i=0; i<n; i++) {
 for(int j=0; j<n; j++) {
 if(i == j) {
 if(i == n-1) {
 printf("100");
 }
 else {
 printf("0");
 }
 }
 else printf("1");
 if(j == n-1) printf("\n");
 else printf(" ");
 }
 }
 }
 return 0;
}