//============================================================================
// Name : zoj2562.cpp
// Author : 
// Version :
// Copyright : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include<string>
#include<cstdio>
#include<cstring>
#define LL long long
using namespace std;
LL m,n,p,q,i,j,k,l,r,ansfin,ansval,nowfin,nowval,cnt;
LL prime[105];
LL val[105];
bool hash[105];
void init(){
	LL i_i,i_j;
	memset(hash,0,sizeof(hash));
	memset(prime,0,sizeof(prime));
	hash[0]=hash[1]=false;
	cnt=0;
	for (i_i=2;i_i<=100;i_i++)
		if (!hash[i_i]){
			prime[cnt++]=i_i;
			for (i_j=2;i_j*i_i<=100;i_j++)
				hash[i_i*i_j]=true;
		}
}
void dfs(LL xi){
	LL d_tem=1,d_i=1;
	if (nowfin>ansfin || (nowfin==ansfin && nowval<ansval))
		ansfin=nowfin,ansval=nowval;
	for (d_i=1;;d_i++){
		d_tem*=prime[xi];
		if (nowval*d_tem<=n){
			nowval*=d_tem;
			nowfin*=(d_i+1);
			dfs(xi+1);
			nowfin/=(d_i+1);
			nowval/=d_tem;
		}
		else
			break;
	}
}
int main() {
	init();
	while (scanf("%lld",&n)!=EOF){
		ansfin=ansval=-1;
		memset(val,0,sizeof(val));
		nowval=nowfin=1;
		dfs(0);
		printf("%lld\n",ansval);
	}
	return 0;
}
