//#include <cstdio>
//#include <cstring>
//#include <iostream>
//using namespace std;
//
//int score[][5] = {5, -1, -2, -1, -3,
// -1, 5, -3, -2, -4,
// -2, -3, 5, -2, -2,
// -1, -2, -2, 5, -1,
// -3, -4, -2, -1, 0};
//int dp[110][110];
//
//int key(char ch) {
// switch (ch) {
// case 'A':
// return 0;
// case 'G':
// return 1;
// case 'C':
// return 2;
// case 'T':
// return 3;
// default:
// return 4;
// }
//}
//
//int main() {
//	int T;
// scanf("%d", &T);
// while (T--) {
// int len1, len2;
// char s1[110], s2[110];
// memset(dp, 0, sizeof(dp));
// scanf("%d%s%d%s", &len1, s1, &len2, s2);
// 
// for (int i = 0; i < len1; i++) {
// for (int j = 0; j < len2; j++) {
//
// }
// }
// }
//	return 0;
//}



#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

int dp[55][45005], a[105];

int abs(int a) {
 return (a > 0) ? a : -a;
}

int main() {
 int n;
 while (~scanf("%d", &n)) {
 int sum = 0;
 memset(dp, 0, sizeof(dp));
 for (int i = 1; i <= n; i++) {
 scanf("%d", &a[i]);
 sum += a[i];
 }
 dp[0][0] = 1;
 for (int i = 1; i <= n; i++) {
 for (int j = sum; j >= a[i]; j--) {
 for (int k = 1; k <= n / 2; k++) {
 if (dp[k-1][j-a[i]]) {
 dp[k][j] = 1;
 }
 }
 }
 }
 int ans = 0, diff = 1<<29;
 for (int i = 0; i <= sum; i++) {
 if (dp[n/2][i]) {
 if (abs(sum - i - i) < diff) {
 ans = i;
 diff = abs(sum - i - i);
 }
 }
 }
 int k1 = ans, k2 = sum - ans;
 if (k1 > k2) k1 ^= k2 ^= k1 ^= k2;
 printf("%d %d\n", k1, k2);
 }
 return 0;
}