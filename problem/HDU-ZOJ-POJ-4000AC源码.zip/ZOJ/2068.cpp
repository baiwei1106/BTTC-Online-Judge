#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;
#define N 501
int a[N];
int b[N];
int f[N][N];
int n1,n2;

void swap()
{
	int temp[N];
	int i,t;
	t=n1;
	n1=n2;
	n2=t;
	for(i=0;i<n2;i++)
		temp[i]=a[i];
	for(i=0;i<n1;i++)
		a[i]=b[i];
	for(i=0;i<n2;i++)
		b[i]=temp[i];
}

int mini(int a,int b)
{
	return a>b?b:a;
}

int main()
{
	int T,i,j,t;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n1);
		for(i=0;i<n1;i++)
			scanf("%d",&a[i]);
		sort(a,a+n1);
		scanf("%d",&n2);
		for(i=0;i<n2;i++)
			scanf("%d",&b[i]);
		sort(b,b+n2);
		if(n1<n2)	swap();	
		f[0][0]=(a[0]-b[0])*(a[0]-b[0]);
		for(i=1;i<n1;i++)
		{
			if((a[i]-b[0])*(a[i]-b[0])<f[0][i-1])
				f[0][i]=(a[i]-b[0])*(a[i]-b[0]);
			else
				f[0][i]=f[0][i-1];
		}
		for(i=1;i<n2;i++)
		{
			for(j=i;j<n1;j++)
			{
				if(j-1>=i)
					f[i][j]=mini(f[i][j-1],f[i-1][j-1]+(a[j]-b[i])*(a[j]-b[i]));
				else if(j==i)
					f[i][j]=f[i-1][j-1]+(a[j]-b[i])*(a[j]-b[i]);
			}
		}
	/*	for(i=0;i<n2;i++)
		{
			for(j=0;j<n1;j++)
			{
				cout<<f[i][j]<<" ";
			}
			cout<<endl;
		}*/
		printf("%d\n",f[n2-1][n1-1]);
	}
	return 0;
}
