#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>

const double eps = 1e-8;
const double pi = acos(-1.);
const double inf = 1e30;

using namespace std;

int dblcmp( double x )
{
	if( fabs(x) < eps )
		return x;
	return x > 0 ? 1 : -1;
}

struct point
{
	double x, y, mr, r, ang, D;
} p[1000], C;

double ddd( point& a, point& b )
{
	double dx = a.x - b.x;
	double dy = a.y - b.y;
	return sqrt(dx*dx+dy*dy);
}

void adjust( double& x )
{
	while( dblcmp(x-2*pi) >= 0 )	x -= 2*pi;
	while( x < 0 )	x += 2*pi;
}

struct seg
{
	double x;
	int st;
} s[10000];

int cmp( seg a, seg b )
{
	if( fabs(a.x-b.x) > eps )
		return a.x < b.x;
	return a.st > b.st;
}

double dis[300][300];
bool sure[300];

void makeMaxRadius(int n) {
 memset(sure, false, sizeof (sure));
 for (int k = 0; k < n; k++) {
 for (int i = 0; i < n; i++) {
 if (sure[i] == false) {
 p[i].mr = inf;
 }
 }
 for (int i = 0; i < n; i++) {
 for (int j = i + 1; j < n; j++) {
 if (sure[i] && sure[j]) {
 continue;
 } else if (sure[i]) {
 p[j].mr = min(p[j].mr, dis[i][j] - p[i].mr);
 } else if (sure[j]) {
 p[i].mr = min(p[i].mr, dis[i][j] - p[j].mr);
 } else {
 p[i].mr = min(p[i].mr, 0.5 * dis[i][j]);
 p[j].mr = min(p[j].mr, 0.5 * dis[i][j]);
 }
 }
 if (sure[i] == false) {
 p[i].mr = min(p[i].mr, ddd(C, p[i]));
 }
 }
 double minNum = inf;
 int minInd = -1;
 for (int i = 0; i < n; i++) {
 if (sure[i] == false && p[i].mr < minNum) {
 minNum = p[i].mr;
 minInd = i;
 }
 }
 sure[minInd] = true;
 }
}

int main()
{
	int T, n, i, j, k, e, ok;
	double ll, rr, mid, ang, t;
	int a, b;

	C.x = C.y = 0;

	scanf("%d", &T);
	while( T-- )
	{
		ll = rr = 0;
		scanf("%d", &n);
		for( i = 0; i < n; ++i )
		{
			scanf("%d %d", &a, &b);
			p[i].x = a;
			p[i].y = b;
		}
		for( i = 0; i < n; ++i )
			for( j = 0; j < n; ++j )
				dis[i][j] = ddd(p[i], p[j]);
		for( i = 0; i < n; ++i )
		{
			p[i].D = ddd(p[i], C);
			p[i].mr = -1;
			p[i].ang = atan2(p[i].y, p[i].x);
		}

		//makeMaxRadius(n);
		for( k = 0; k < n; ++k )
		{
			double he = 1e20;
			for( i = 0; i < n; ++i )	if( p[i].mr < 0 )
			{
				if( he > p[i].D )
				{
					he = p[i].D;
					e = i;
				}

				for( j = 0; j < n; ++j )	if( i != j )
				{
					t = dis[i][j];
					if( p[j].mr > 0 )
					{
						if( t - p[j].mr < he )
						{
							he = t-p[j].mr;
							e = i;
						}
					}
					else if( t*0.5 < he )
					{
						he = t*0.5;
						e = i;
					}
				}
			}

			p[e].mr = he;
		}

		for( i = 0; i < n; ++i )
			if( p[i].mr > rr )
				rr = p[i].mr;

		rr += 10;
		ok = 0;
		for( int ii = 100; ii > 0; --ii )
		{
			mid = (ll+rr)*0.5;
			for( i = 0; i < n; ++i )
			{
				if( p[i].mr < mid )
					p[i].r = p[i].mr;
				else
					p[i].r = mid;
			}

			e = 0;
			for( i = 0; i < n; ++i )
			{
				t = asin(p[i].r/p[i].D);
				t = fabs(t);
				s[e].x = p[i].ang-t;
				adjust(s[e].x);
				s[e++].st = 1;

				s[e].x = p[i].ang+t;
				adjust(s[e].x);
				s[e++].st = -1;

				if( s[e-2].x > s[e-1].x )
				{
					s[e].x = 0;
					s[e++].st = 1;
					s[e].x = 2*pi;
					s[e++].st = -1;
				}
			}

			sort(s, s+e, cmp);
			t = ang = 0;
			k = 0;
			for( i = 0; i < e; ++i )
			{
				if( !k )
					t = s[i].x;
				k += s[i].st;
				if( !k )
					ang += s[i].x - t;
			}


			if( dblcmp(ang-2*pi) )
				ll = mid;
			else
			{
				ok = 1;
				rr = mid;
			}
		}

		if( !ok )
			printf("-1.0\n");
		else
			printf("%.8lf\n", mid);
	}

	return 0;
}