#include<stdio.h>
#include<string.h>
using namespace std;
struct data
{
 char str[100];
 double db;
}database;
int main()
{
 int ks,kase,i;
 scanf("%d",&kase);
 for (ks=1;ks<=kase;ks++)
 {
 scanf("%lf %s",&database.db,&database.str);


 printf("%d ",ks);
 if (strcmp(database.str,"kg")==0) printf("%.4lf lb",database.db*2.2046000);
 else if (strcmp(database.str,"l")==0) printf("%.4lf g",database.db*0.2642000);
 else if (strcmp(database.str,"lb")==0) printf("%.4lf kg",database.db*0.4536);
 else if (strcmp(database.str,"g")==0) printf("%.4lf l",database.db*3.7854);
 printf("\n");
 }
}
