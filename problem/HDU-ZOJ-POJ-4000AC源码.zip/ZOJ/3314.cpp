#include<stdio.h>
#include<string.h>
const int dirx[]={1,1,1,0,0,-1,-1,-1};
const int diry[]={1,0,-1,1,-1,1,0,-1};
char map[500][500];
int p[500][500],cnt;
bool ans[30];
int n,m;

struct Node
{
	int a,b,c;
}node[30];


void bfs(int x,int y)
{
	int sumx=1,sumy=0;
	int sx[90005],sy[90005];int i=0,j=1;
	sx[0]=x;sy[0]=y;p[x][y]=cnt;
//	pin[0].a=x,pin[0].b=y;
	int min=y;
	while(i<j)
	{
		int k=0;
		for(k=0;k<8;k++)
		{
			if(sx[i]+dirx[k]<n&&sx[i]+dirx[k]>=0&&sy[i]+diry[k]<m&&sy[i]+diry[k]>=0)
			{
				if(map[sx[i]+dirx[k]][sy[i]+diry[k]]=='M'&&p[sx[i]+dirx[k]][sy[i]+diry[k]]==0)
				{
					p[sx[i]+dirx[k]][sy[i]+diry[k]]=cnt;
					sx[j]=sx[i]+dirx[k];sy[j++]=sy[i]+diry[k];
					//pin[j].a=sx[j];pin[j].b=sy[j++];
					if(sx[j-1]==x||sx[j-1]==x+6) sumx++;
					if(sx[j-1]==x+3) sumy++;
				}
			}
		}
		i++;
	}
	//printf("%d %d %d\n",j,sumx,sumy);
	for(i=0;i<26;i++)
	{
		if(j==40&&sumx==12&&sumy==4&&map[x+3][y+4]=='M'){ans[23]=true;break;}
		if(j==node[i].a&&sumx==node[i].b&&sumy==node[i].c) {ans[i]=true;break;}
	}
}

int main()
{
		node[0].a=33;node[0].b=7;node[0].c=9;
		node[1].a=49;node[1].b=22;node[1].c= 11;
node[2].a=34 ;node[2].b=16 ;node[2].c= 2;
node[3].a=42 ;node[3].b=22 ;node[3].c=4;
node[4].a=44 ;node[4].b=24 ;node[4].c=12;
node[5].a=36 ;node[5].b=15 ;node[5].c=13;
node[6].a=38 ;node[6].b=17 ;node[6].c=2;
node[7].a=37 ;node[7].b=8 ;node[7].c=13;
node[8].a=22 ;node[8].b=12 ;node[8].c=2;
node[9].a=27 ;node[9].b=12 ;node[9].c=2;
node[10].a=36 ;node[10].b=11 ;node[10].c=5;
node[11].a=24 ;node[11].b=14 ;node[11].c=2;
node[12].a=42 ;node[12].b=8 ;node[12].c=9;
node[13].a=42 ;node[13].b=11 ;node[13].c=6;
node[14].a=40 ;node[14].b=12 ;node[14].c=4;
node[15].a=38 ;node[15].b=13 ;node[15].c=4;
node[16].a=48 ;node[16].b=14 ;node[16].c=4;
node[17].a=43 ;node[17].b=16 ;node[17].c=4;
node[18].a=43 ;node[18].b=15 ;node[18].c=5;
node[19].a=34 ;node[19].b=14 ;node[19].c=2;
node[20].a=38 ;node[20].b=14 ;node[20].c=4;
node[21].a=40 ;node[21].b=12 ;node[21].c=6;
node[22].a=40 ;node[22].b=10 ;node[22].c=6;
node[23].a=40 ;node[23].b=12 ;node[23].c=4;
node[24].a=28 ;node[24].b=8 ;node[24].c=4;
node[25].a=31 ;node[25].b=21 ;node[25].c=2;
//freopen("ans.text","w",stdout);
 while(scanf("%d%d",&n,&m)!=EOF)
 {
 int i,j,k;
			cnt=0;
 memset(p,0,sizeof(p));
 memset(ans,0,sizeof(ans));
 for(i=0;i<n;i++)
 scanf("%s",map[i]);
			for(i=0;i<n;i++)
				for(j=0;j<m;j++)
				{
					if(p[i][j]==0&&map[i][j]=='M')
					{
						cnt++;bfs(i,j);
					}
				}
 for(i=0;i<26;i++)
 {
 if(ans[i]) printf("%c",'A'+i);
 }
 printf("\n");
 }
 return 0;
}
