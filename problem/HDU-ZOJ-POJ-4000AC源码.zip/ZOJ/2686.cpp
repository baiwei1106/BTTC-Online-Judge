#include<stdio.h>
#include<math.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,flag=0;
		scanf("%d",&n);
		int i,j,k,a[30],b[30];
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
			b[n-1-i]=a[i];
		}
		for(i=0;i<n;i++)
		{
			if(a[i]==0)
			{
				if(i%2)
				{
					printf("YES\n");
					flag=1;
				}
					break;
			}
		}
		if(flag==0)
		{
			for(i=0;i<n;i++)
			{
				if(b[i]==0)
				{
					if(i%2)
					{
						printf("YES\n");
						flag=1;
					}
					break;
				}
			}
		}
		if(flag==0)
			printf("NO\n");
	}
	return 0;
}