#include<cstdio>
int main(){
 int T,i,j,k,n,m,x,y;
 scanf("%d",&T);
 while(T--){
 scanf("%d",&n);
 x=y=0;
 for(i=1;i<=n;i++){
 scanf("%d",&j);
 x^=j;
 if(j>1)
 y=1;
 }
 if(x==0)
 puts(y==0?"1":"2");
 else
 puts(y==1?"1":"2");
 }
 return 0;
}
