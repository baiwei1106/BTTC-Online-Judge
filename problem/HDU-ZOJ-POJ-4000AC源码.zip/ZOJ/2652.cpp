#include <string.h>
#include <stdio.h>
#include <iostream>
#include <algorithm>
using namespace std;
int g[109][109];
int colR[109],colC[109],R,C;
#define Inf 100000000
bool visR[109],visC[109];
void dfsC(int j);
int cnt1,cnt2;
void dfsR(int i)
{
	visR[i]=true;
	
	if(colR[i]==0)
		cnt1++;
	else
		cnt2++;
	for(int j=1;j<=C;j++)
	{
		if(!visC[j])
		{
			if(g[i][j]>0)		
				colC[j]=colR[i];		
			else if(g[i][j]<0)
				colC[j]=1-colR[i];
			else
				continue;
			dfsC(j);
		}
	}
}
void dfsC(int j)
{
	visC[j]=true;
	
	if(colC[j]==0)
		cnt1++;
	else
		cnt2++;
	for(int i=1;i<=R;i++)
	{
		if(!visR[i])
		{
			if(g[i][j]>0)
				colR[i]=colC[j];
			else if(g[i][j]<0)
				colR[i]=1-colC[j];
			else
				continue;
			dfsR(i);
		}
	}
}
int solve()
{
	memset(visR,0,sizeof(visR));
	memset(visC,0,sizeof(visC));
	int sum=0;
	for(int i=1;i<=R;i++)
	{
		if(!visR[i])
		{
			colR[i]=0;
			cnt1=cnt2=0;
			dfsR(i);
			sum+=max(cnt1,cnt2);
			//printf("%d %d\n",cnt1,cnt2);
		}
	}

	for(int j=1;j<=C;j++)
	{
		if(!visC[j])
		{
			colC[j]=0;
			cnt1=cnt2=0;
			dfsC(j);
			sum+=max(cnt1,cnt2);
			//printf("%d %d\n",cnt1,cnt2);
		}
	}
	for(int i=1;i<=R;i++)
		for(int j=1;j<=C;j++)
		{
			if(g[i][j]>0&&colR[i]!=colC[j])
				return -1;
			if(g[i][j]<0&&colR[i]==colC[j])
				return -1;
		}
	//printf("sum is %d\n",sum);
	return R+C-sum;
}
int main()
{
	//freopen("1.in","r",stdin);
	for(;;)
	{
		if(scanf("%d%d",&R,&C)==EOF)
			break;
		for(int i=1;i<=R;i++)
			for(int j=1;j<=C;j++)
				scanf("%d",&g[i][j]);
		printf("%d\n",solve());
	}
	return 0;
}