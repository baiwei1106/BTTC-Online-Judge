#include <iostream>
#include <cstdio>
#include <string>
using namespace std;
int main()
{
 string s,sa,sb;
 int t,m,n;
 cin>>t;
 for(int i=0;i<t;i++)
 {
 cin>>n;
 for(int j=0;j<n;j++)
 {
 cin>>s;
 sa+=s[0];
 }
 cin>>m;
 for(int j=0;j<m;j++)
 {
 cin>>s;
 sb+=s[0];
 }
 if(sa.compare(sb)==0)
 {
 printf("SAME\n");
 }
 else
 {
 printf("DIFFERENT\n");
 }
 sa=sb="";
 }
 return 0;
}
