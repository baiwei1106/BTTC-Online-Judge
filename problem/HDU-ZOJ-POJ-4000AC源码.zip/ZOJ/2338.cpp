#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstring>
#include<vector>
using namespace std;

typedef unsigned long long ll;

ll dp[70][70], g[70][70];
vector<int> top[70];
bool vis[70];
int N;

void init() {
 for(int j=1; j<=65; j++) {
 dp[1][j] = 1L;
 }
 for(int i=2; i<=64; i++) {
 for(int j=0; j<=65; j++) {
 dp[i][j] = 1000000000000000L;
 }
 }
 for(int i=2; i<=64; i++) {
 for(int j=3; j<=65; j++) {
 //ll tp = dp[i][j-1];
 for(int k=1; k<i; k++) {
 ll tmp = dp[i-k][j-1] + 2 * dp[k][j];
 if(dp[i][j] > tmp) {
 //tp = tmp;
 dp[i][j] = tmp;
 g[i][j] = k;
 }
 }
 //dp[i][j] = tp;
 }
 }
}

void move(int a, int b) {
 int x = top[a][top[a].size() - 1];
 int size = top[b].size();
 top[a].pop_back();
 if(!size) printf("move %d from %d to %d\n", x, a, b);
 else printf("move %d from %d to %d atop %d\n", x, a, b, top[b][size-1]);
 top[b].push_back(x);
}

void printit(int n, int m, int s, int e) {
 if(n == 0) return ;
 if(n == 1) {
 move(s, e);
 return ;
 }

 int x;
 for(x=1; x<=N; x++) {
 if(x != s && x != e && !vis[x]) break;
 }
 printit(g[n][m], m, s, x);
 vis[x] = 1;
 printit(n - g[n][m], m - 1, s, e);
 vis[x] = 0;
 printit(g[n][m], m, x, e);
}

void gao(int n, int m) {
 N = n;
 cout << dp[n][m] << endl;
 memset(vis, 0, sizeof(vis));
 for(int i=0; i<=65; i++) top[i].clear();
 for(int i=1; i<=n; i++) top[1].push_back(n-i+1);
 printit(n, m, 1, m);
}

int main()
{
 init();
 int T;
 int n, m;
 scanf("%d", &T);
 while(T--) {
 scanf("%d%d", &n, &m);
 gao(n, m);
 if(T >= 1) printf("\n");
 }
 return 0;
}