/*
*	ID : Pallab
* 	PROG : B
* 	LANG : C++
* 	2012-11-12-20.43.44 Monday
*
* 	"I have not failed, I have just found 10000 ways that won't work.
*/
#include <iostream>
#include <algorithm>
#include <vector>
#include <sstream>
#include <fstream>
#include <string>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <numeric>
#include <stack>
#include <functional>
#include <bitset>
#include <iomanip>

#include <ctime>
#include <cassert>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <climits>
#include <cstring>
#include <cstdlib>

using namespace std;

#define foR(i1,st,ed) for(int i1 = st , j1 = ed ; i1 < j1 ; ++i1 )
#define fo(i1,ed) foR( i1 , 0 , ed )
#define foE(i1,st,ed) foR( i1, st, ed+1 )
#define foit(i, x) for (typeof((x).begin()) i = (x).begin(); i != (x).end(); i++)
#define bip system("pause")
#define Int long long
#define pb push_back
#define SZ(X) (int)(X).size()
#define LN(X) (int)(X).length()
#define mk make_pair
#define SET( ARRAY , VALUE ) memset( ARRAY , VALUE , sizeof(ARRAY) )
#define line puts("")

inline void wait(double seconds) {
 double endtime = clock() + (seconds * CLOCKS_PER_SEC);
 while (clock() < endtime) {
 ;
 }
}
#define T int
inline T fastIn() {
 register char c = 0;
 register T a = 0;
 while (c < 33)
 c = getchar();
 while (c > 33) {
 a = (a * 10) + (c - '0');
 c = getchar();
 }
 return a;
}
const int MX = 100005;
int numbers[MX];
int number_count;
inline void read() {
 fo(i,number_count)numbers[i]=fastIn();
}
int M[18][MX];
int n;
inline void ST(int size) {
 n = size;
 for (int i = 0; i < n; i++) {
 M[0][i] = i;
 }
 for (int j = 1;; ++j) {
 int tmp = 1 << j;
 if (tmp > n)
 break;
 int tmp2 = 1 << (j - 1);
 for (int i = 0; i + tmp <= n; i++) {
 if (numbers[M[j - 1][i]] <= numbers[M[j - 1][i + tmp2]]) {
 M[j][i] = M[j - 1][i];
 } else {
 M[j][i] = M[j - 1][i + tmp2];
 }
 }
 }
}
const double lg = log(2.0);
inline int get_min(int a, int b) {
 int k = log(b - a + 1) / lg;
 int bt = 1 << k;
 if (numbers[M[k][a]] <= numbers[M[k][b - bt + 1]])
 return M[k][a];
 else
 return M[k][b - bt + 1];
}

Int presum[MX];
inline Int get_sum(int from, int to) {
 Int sum = presum[to];
 if(from-1>=0)sum-=presum[from-1];
 return sum;
}
struct info {
 int l,r;
 Int v;
 void print() {
 cout<<v<<"\n"<<l+1<<" "<<r+1<<"\n";
 }
};
inline void mymax(info &a, info b) {
 if(b.v>a.v)a=b;
}
info retval;
const Int inf = (1LL<<63)-1;
void dfs(int tl, int tr) {
 if(tl>tr)return ;

 int indx=/*index of minimum value [l,r]*/get_min(tl,tr);
 Int csum=/*cumulative sum of range[l,r]*/get_sum(tl,tr);

 mymax(retval, info {tl,tr, csum* numbers[indx]} );
 dfs(tl,indx-1);
 dfs(indx+1,tr);
}
inline void proc() {
 Int sum=0;
 fo(i,number_count) {
 sum+=numbers[i];
 presum[i]=sum;
 }

 ST(number_count);
 retval = info {0,number_count-1,-inf};
 dfs(0,number_count-1);
 retval.print();
}
int main() {
 int kase = 1;
#if defined( xerxes_pc )
 if (!freopen("in1", "r", stdin))
 puts("error opening file in "), assert(0);
 kase = 1;
#endif
 while(scanf("%d",&number_count)==1) {
 read();
 proc();
 }
 return 0;
}
