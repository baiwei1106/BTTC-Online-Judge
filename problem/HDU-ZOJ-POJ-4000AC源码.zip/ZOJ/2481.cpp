#include <iostream>
#include <cstdio>
#include <set>
using namespace std;

typedef set<int> Set;
typedef Set::iterator It;

int main()
{
	int n, x, i;
	while (scanf("%d", &n) && n)
	{
		Set st;
		for (i = 0; i < n; i++)
		{
			scanf("%d", &x);
			st.insert(x);
		}
		i = 0;
		for (It it = st.begin(); it != st.end(); it++)
		{
			if (i++)
				putchar(32);
			printf("%d", *it);
		}
		putchar(10);
	}
	return 0;
}
