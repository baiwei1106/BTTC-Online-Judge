#include <cstdio>
using namespace std;

int n1, n2;
int a[1010], b[1000010];
void solve(){
 int ans = 0;
 for (int i = 0; i < n2; i){
 if (b[i] == a[0]){
 int len = 1, k, p;
 for (k = n1-1, p = i-1; p >= 0; p--, k--){
 if (k < 0) k = 0;
 if (b[p] != a[k]) break;
 len++;
 }
 for (k = 1, p = i+1; p < n2; p++, k++){
 if (k == n1) k = 0;
 if (b[p] != a[k]) break;
 len++;
 }
 if (len >= n1 && len > ans) ans = len;
 i = p;
 }
 else i++;
 }
 if (ans == 0) puts("bad");
 else printf("%d\n", ans);
}

int main(){
 while (scanf("%d%d", &n1, &n2) != EOF){
 for (int i = 0; i < n1; i++) scanf("%d", &a[i]);
 for (int i = 0; i < n2; i++) scanf("%d", &b[i]);
 solve();
 }
 return 0; 
}
