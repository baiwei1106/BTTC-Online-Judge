#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
bool output_flag = false;
void outputs(int i,int t){
 while(t--){
 if(output_flag)
 cout<<' '<<i;
 else
 cout<<i;
 output_flag = true;
 }
}
class MyStack{
 public:
 int n,d[10000];
 MyStack();
 bool Empty();
 void Push(int i);
 int Pop();
 int View();
};
MyStack::MyStack(){
 memset(d,0,sizeof(d));
 n = 0;
}
bool MyStack::Empty(){
 return n <= 0;
}

void MyStack::Push(int i){
 n++;
 d[n] = i;
}
int MyStack::Pop(){
 n--;
 return d[n+1];
}
int MyStack::View(){
 return d[n];
}
int mainw(long xx){
 output_flag = false;
 long stack_count,i,r,maxn,lis[10000],sorted[10000],tr,sr;
 MyStack stacks[15];
 //cin>>stack_count;
 stack_count = xx;
 maxn = (1<<stack_count);
 for(i=0;i<maxn;i++){
 cin>>lis[i];
 sorted[i] = lis[i];
 }
 sort(sorted,sorted+maxn);
 r = 0;
 sr = 0;
 while(r<maxn){
 tr = r;
 for(i=1;i<=stack_count;i++){
 if(stacks[i].View() == sorted[r]){
 //cout<<"b"<<endl;
 stacks[i].Pop();
 outputs(sorted[r],(stack_count - i)*2+1);
 r++;
 break;
 }
 }
 if(tr != r)
 continue;
 while(lis[sr] != sorted[r]){
 //cout<<"a"<<endl;
 for(i=1;i<=stack_count;i++){
 if(stacks[i].Empty() || stacks[i].View()>lis[sr]){
 outputs(lis[sr],i*2-1);
 stacks[i].Push(lis[sr]);
 sr++;
 break;
 }
 }
 }
 //cout<<sorted[r]<<"===="<<endl;
 sr++;
 outputs(sorted[r],stack_count*2);
 r++;
 }
 return 0;
}
int main(){
 long t;
 cin>>t;
 while(t!=0){
 mainw(t);
 cout<<endl;
 cin>>t;
 }
}
