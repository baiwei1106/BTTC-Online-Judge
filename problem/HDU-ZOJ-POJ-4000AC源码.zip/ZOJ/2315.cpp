#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;

int n;
int deep[500005];
int para[500005];
bool legal[500005];
bool selecttt[500005];

struct Point {
 int id, d;
 Point(int a=0, int b=0): id(a), d(b) {}
 bool operator < (const Point _p) const {
 return d < _p.d;
 }
};

int main()
{
 int T;
 scanf("%d", &T);
 while(T--) {
 scanf("%d", &n);
 priority_queue<Point> Q;
 memset(legal, 0, sizeof(legal));
 memset(selecttt, 0, sizeof(selecttt));
 int x;
 deep[1] = 0;
 for(int i=2; i<=n; i++) {
 scanf("%d", &x);
 deep[i] = deep[x] + 1;
 para[i] = x;
 Q.push(Point(i, deep[i]));
 }

 int ans = 0;
 while(!Q.empty()) {
 //printf("$$\n");
 Point p = Q.top(); Q.pop();
 if(legal[p.id] == 1 || legal[para[p.id]]) continue;
 selecttt[p.id] = 1;
 legal[p.id] = 1;
 legal[para[p.id]] = 1;
 ans ++;
 }

 printf("%d\n", ans*1000);
 for(int i=2; i<=n; i++) {
 if(selecttt[i]) {
 printf("%d", i);
 ans --;
 if(ans == 0) {
 printf("\n");
 break;
 }
 else {
 printf(" ");
 }
 }
 }
 }
 return 0;
}