#include <iostream> 
#include <cstdio>
#include <cstring>
#include <queue>
#include <algorithm>
using namespace std;

const double oo = 1e20;
const int MAXN = 310;
const double eps = 1e-9;

struct Edge {
 int s, e, nx, id;
	double c;

	Edge(int a , int b, double d): s(a), e(b), c(d) {}
	Edge() {}
}E[5010], E1[5010];
int head[MAXN], cnt;

void add(int s, int e, int id, double c) {
		E[cnt].s = s; E[cnt].e = e; E[cnt].c = c; E[cnt].id = id; E[cnt].nx = head[s];
 	head[s] = cnt++;
 	swap(s,e);
 	E[cnt].s = s; E[cnt].e = e; E[cnt].c = c; E[cnt].id = id; E[cnt].nx = head[s];
 	head[s] = cnt++;
}

int d[MAXN], num[MAXN], Stack[MAXN], Top, H[MAXN];

int sgn(double x) {
	return x < -eps ? -1 : x > eps;
}

double isap(int N, int s, int t) {
 	memset(d, 0, sizeof(d));//������
 	memset(num, 0, sizeof(num));//��϶�Ż�
 	num[0] = N;
 	double ans = 0;
 	for(int i = 0; i <= N; i++) {
 	H[i] = head[i];//��ǰ���Ż�
 	}
 	Top = 0;
 	int x;
 	while(d[s] < N) {
 	if(!Top) {
					x = s;
			} else {
				x = E[Stack[Top - 1]].e;
			}
			if(x == t) {
 	double p = E[Stack[0]].c;
 	for(int i = 1; i < Top; i++) {
 	p = min(p, E[Stack[i]].c);
				}
 	ans += p;
 	for(int i = Top - 1; i >= 0; i--) {
 	E[Stack[i]].c -= p;
 	if(E[Stack[i]].c == 0) {
						Top = i;
					}
 	E[Stack[i]^1].c += p;
 	}
			} else {
					for(int i = H[x]; ~i; i = E[i].nx) {
						if(E[i].c > 0 && d[E[i].e] == d[x] - 1) {
 		Stack[Top ++] = i;
 		H[x] = i;
 		goto nx;
						}
					}
					if(--num[d[x]] == 0) {
						return ans;
					}
					int mi = N;
					for(int i = head[x]; ~i; i = E[i].nx) {
 		if(E[i].c > 0 && mi > d[E[i].e]) {
 			mi = d[E[i].e];
 			H[x] = i;
 		}
					}
					d[x] = mi + 1;
					num[d[x]]++;
					if(x != s) {
						Top--;
					}
			}
 	nx:;
 	}
	return ans;
} 

int n, m;

double judge(double x) {
	memset(head, -1, sizeof(head));
	cnt = 0;
	double ans = 0.0;
	for(int i = 1; i <= m; i++) {
		int u = E1[i].s, v = E1[i].e;
		double w = E1[i].c;
		if(sgn(w - x) >= 0) {
			add(u, v, i, w - x);
		}else {
			ans -= (x - w);
		}
	}
	ans += isap(n + 5, 1, n);
//	cout << ans << "**" << endl;
	return ans;
}

int mark[500];
bool vst[500];
queue<int> Q;

void bfs(int st, int id) {
	while(!Q.empty()) {
		Q.pop();
	}
	mark[st] = id;
	Q.push(st);
	vst[st] = 1;
	while(!Q.empty()) {
		int u = Q.front(); Q.pop();
		for(int i = head[u]; ~i; i = E[i].nx) {
			int v = E[i].e;
			double c = E[i].c;
			if(c > 0 && vst[v] == 0) {
				vst[v] = 1;
				Q.push(v);
				mark[v] = id;
			}
		}
	}
}
	
int ans[500], tot;

void gao(double dis) {
	memset(mark, 0, sizeof(mark));
	memset(vst, 0, sizeof(vst));
	bfs(1, 1);
//	for(int i = 1; i <= n; i++) {
//		cout << i << ":" << mark[i] << endl;
//	}
	tot = 0;
	for(int i = 0; i < cnt; i++) {
		int u = E[i].s, v = E[i].e, id = E[i].id;
		if(i % 2 == 0 && mark[u] != mark[v]) {
//			cout << u << "orz hjx" << v << endl;
			ans[++tot] = id;
		}
	}
	for(int i = 1; i <= m; i++) {
		if(sgn(E1[i].c - dis) < 0) {
			ans[++tot] = i;
		}
	}
	sort(ans + 1, ans + tot + 1);
	printf("%d\n", tot);
	for(int i = 1; i <= tot; i++) {
		printf("%d%c", ans[i], (i == tot) ? '\n' : ' ');
	}
}

int main() {
	int cas = 0;
	while(~scanf("%d%d", &n, &m)) {
		cas++;
		if(cas != 1) {
			puts("");
		}
		double L, R;
		L = R = 0;
		for(int i = 1; i <= m; i++) {
			int u, v, w;
			scanf("%d%d%d", &u, &v, &w);
			E1[i] = Edge(u, v, w);
			R += w;
		}
		for(int i = 1; i <= 100; i++) {
			double m = (L + R) / 2;
			double tmp = judge(m);
			if(sgn(tmp) > 0) {
				L = m + eps;
			}else {
				R = m;
			}
		}
//		cout << judge(5.0/3.0) << "fuck" << endl;
//		cout << L << "&&" << endl;
		judge(R);
		gao(L);
	}
	return 0;
}
