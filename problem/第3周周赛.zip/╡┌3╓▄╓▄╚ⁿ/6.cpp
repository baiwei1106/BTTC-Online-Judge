#include <cstdio>
int main(){
	int i,a,b,n,p,q;
	while(scanf("%d",&n)!=EOF){
		if(n==0) break;
		printf("Printing order for %d pages:\n",n);
		if(n==1) printf("Sheet 1, front: Blank, 1\n");
		else{
		a=(n+3)/4;
		b=n%4;
		for(i=1;i<=a;i++,p+=2,q-=2){
			if(i==1){
				switch(b){
				case 0:
					{
						printf("Sheet 1, front: %d, 1\nSheet 1, back : 2, %d\n",n,n-1);
						p=1;q=n;break;
					}
				case 1:
					{
						printf("Sheet 1, front: Blank, 1\nSheet 1, back : 2, Blank\n");
						p=2;q=n+2;break;
					}
				case 2:
					{
						printf("Sheet 1, front: Blank, 1\nSheet 1, back : 2, Blank\n");
						p=1;q=n+2;break;
					}
				case 3:
					{
						printf("Sheet 1, front: Blank, 1\nSheet 1, back : 2, %d\n",n);
						p=1;q=n+1;break;
					}
				}
			}
			else{
				switch(b){
				case 0:
					{
						printf("Sheet %d, front: %d, %d\nSheet %d, back : %d, %d\n",i,q,p,i,p+1,q-1);break;
					}
				case 1:
					{
						if(i==2) printf("Sheet %d, front: Blank, 3\nSheet %d, back : 4, %d\n",i,i,q);
						else printf("Sheet %d, front: %d, %d\nSheet %d, back : %d, %d\n",i,q+1,p-1,i,p,q);break;
					}
				case 2:
					{
						printf("Sheet %d, front: %d, %d\nSheet %d, back : %d, %d\n",i,q,p,i,p+1,q-1);break;
					}
				case 3:
					{
						printf("Sheet %d, front: %d, %d\nSheet %d, back : %d, %d\n",i,q,p,i,p+1,q-1);break;
					}
				}
			}
		}
	}
	}
	return 0;
}
