#include <iostream>
using namespace std;
int main(){
	int N, M;
	int a[25];
	int sum = 0;
	int res = 1<<16;
	cin >> N >> M;
	for (int i = 0; i < N; i++){
		cin >> a[i];
		sum += a[i];
	}
	if (sum < M) cout << "-1" << endl;
	else {
		//������ö�ټ���
		for (int i = 1; i < (1 << N); i++){
			int tmp = 0;
			for (int j = 0; j < N; j++){
				if (1 & (i >> j)){
					tmp += a[j];
				}
			}
			if (tmp >= M){
			 	res = (tmp>res)?res:tmp;
			}
		}
		cout << res << endl;
	}
	return 0;
}
