#include <iostream>
using namespace std;
int a[210][210];
int R, C;
int maxn = 0;
void judge(int &x, int &y,int &n){
	int flag = 1;
	int cnt = 0;
	int i, j;
	for (i = x; i <= x+n; i++){
		for (j = y; j <= y+n; j++){
			if (a[i][j] != a[x][y]){
				flag = 0;
				break;
			}
		}
		if (flag){
			cnt++;
		}
	}
	if (cnt > maxn) maxn = cnt;
}
int main(){
	cin >> R >> C;
	for (int i = 0; i < R; i++){
		for (int j = 0; j < C; j++){
			cin >> a[i][j];
		}
	}
	for (int i = 0; i < R; i++){
		for (int j = 0; j < C; j++){
			int temp = (R - i) > (C - j) ? (C - j) : (R - i);
			for (int z = 0; z < temp; z++){
				judge(i, j,z);
			}
		}
	}
	cout << maxn * maxn << endl;
	return 0;
}
