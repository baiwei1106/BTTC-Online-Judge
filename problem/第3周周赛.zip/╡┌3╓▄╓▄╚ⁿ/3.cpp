#include<cstdio>
int num[1000]; 
int main(){
	int i,j,k,n,wrong,flag;
	while(scanf("%d",&n)!=EOF){
		for(i=1;i<=n;i++)
			scanf("%d",&num[i]);
		for(i=1;i<=n;i++){ 
			for(j=i+1;j<=n;j++){
				wrong=flag=0;
				for(k=1;k<=n;k++){
					if(num[k]>0&&(num[k]==i||num[k]==j)){
						wrong++;
						if(k==i||k==j) flag++;
					}
					else if(num[k]<0&&(num[k]!=-i&&num[k]!=-j)){
						wrong++;
						if(k==i||k==j) flag++;
					}
				}
				if(wrong==2&&flag==1) break;
			}
			if(wrong==2&&flag==1) break;
		} 
		if(i==n+1&&j==n+1) printf("No Solution\n");
		else printf("%d %d\n",i,j);
	}
	return 0;
}
