#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
using namespace std;
#define N 80100	
#define MOD 1000000007
int is[N], prm[N];
int na[N], nb[N];
int res = 0, ans;
int  Getprm(){
	int i, j, k = 0;
	int s, e = (int)(sqrt(N * 1.0) + 1);
	memset(is, 1, sizeof(is));
	prm[k++] = 2;
	is[0] = is[1] = 0;
	for (i = 4; i < N; i += 2) is[i] = 0;
	for (i = 3; i < e; i += 2)
		if (is[i])
		{
			prm[k++] = i;
			for (s = i * 2, j = i * i; j < N; j += s)
				is[j] = 0;
		}
	for (; i < N; i += 2) if (is[i]) prm[k++] = i;
	return k;
}
void init(){
	memset(na, 0, sizeof(na));
	memset(nb, 0, sizeof(nb));
	for (int i = 0; i < ans; i++){
		for (int j = i; j < ans; j++){
			int temp = prm[i] + prm[j];
			if (temp > N) break;
			na[temp] ++;
		}
	}
	for (int i = 0; i < ans; i++){
		for (int j = i; j < ans; j++){
			long long temp = (long long)prm[i] * (long long)prm[j];
			if (temp > N) break;
			nb[temp] ++;
		}
	}
}
int  main(){
	ans = Getprm();
	init();
	int n;
	while (cin>>n){
		res = 0;
		if (is[n]) res++;
		res += na[n] + nb[n];
		int cn = 0;
		for (int i = 0; prm[i] < n; i++){
			cn += na[n - prm[i]];
		}
		for (int i = 0; prm[i] * 2 < n; i++){
			if (is[n - prm[i] * 2]){
				cn++;
				if (prm[i] * 3 == n)
					cn++;
			}
		}
		res = (res + cn / 3) % MOD;
		cn = 0;
		for (int i = 0; prm[i] < n; i++){
			if (n % prm[i]) continue;
			cn += nb[n / prm[i]];
		}
		for (int i = 0; prm[i] * prm[i] <= n; i++){
			if (n % (prm[i] * prm[i])) continue;
			if (is[n / prm[i] / prm[i]]){
				cn++;
				if (prm[i] * prm[i] * prm[i] == n)
					cn++;
			}
		}
		res = (res + cn / 3) % MOD;
		for (int i = 0; prm[i] < n; i++){
			res = res + nb[n - prm[i]];
		}
		printf("%d\n", res  % MOD);
	}
	return 0;
}
