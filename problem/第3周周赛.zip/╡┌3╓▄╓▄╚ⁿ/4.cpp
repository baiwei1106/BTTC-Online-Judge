#include<iostream>
#include<cstdio>
using namespace std;
int a[30];
int main(){
    int k=0,t;
    while(scanf("%d",&t)==1){
        long long maxn=0;
        for(int i=0; i<t; i++)
            cin>>a[i];
        for(int i=0; i<t; i++){
            long long q=1;
            for(int j=i; j<t; j++){
                q=q*a[j];
                if(q>maxn)
                    maxn=q;
            }
        }
        k++;
            printf("Case #%d: The maximum product is %lld.\n",k,maxn);      
            printf("\n");
    }
    return 0;
}
