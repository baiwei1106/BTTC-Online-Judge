#include<cstdio>
int main(){
	printf("2018\nwe gonna win!\n");
	return 0;
} 
