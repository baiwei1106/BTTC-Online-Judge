#define LOCAL
#include<cstdio>
int main(){
	int i;
	#ifdef LOCAL
	freopen("test.in_5-5.txt","w",stdout);	
	#endif
	for(i=0;i<400;i++)
		printf("pCTclnJoRgLrUjkhGFauPewSK");
	return 0;
} 
