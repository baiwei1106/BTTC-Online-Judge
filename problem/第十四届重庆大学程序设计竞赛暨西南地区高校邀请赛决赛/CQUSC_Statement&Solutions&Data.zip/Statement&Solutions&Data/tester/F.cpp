#include<bits/stdc++.h>

#define maxn 1200010
#define maxm 5

using namespace std;

const double PI=acos(-1);

int n,m,k,K,g;

int A[maxn][maxm],B[maxn],Ans[maxn],Ans2[maxn];

int pos[maxn],Pow[maxn];

struct Com{
	double x,y;
	Com(double x=0,double y=0):x(x),y(y) {}
}a[maxn],b[maxn];

Com operator+(const Com &a,const Com &b){return Com(a.x+b.x,a.y+b.y);}
Com operator-(const Com &a,const Com &b){return Com(a.x-b.x,a.y-b.y);}
Com operator*(const Com &a,const Com &b){return Com(a.x*b.x-a.y*b.y,a.x*b.y+a.y*b.x);}

void FFT(Com *a,int f){
	for(int i=0,j=0;i<k;i++){
		if(i>j)swap(a[i],a[j]);
		for(int l=k>>1;(j^=l)<l;l>>=1);
	}
	
	for(int i=1;i<k;i<<=1){Com w(cos(PI/i),f*sin(PI/i));
		for(int j=0;j<k;j+=(i<<1)){Com e(1,0);
			for(int k=0;k<i;k++,e=e*w){Com x,y;
				x=a[j+k];y=a[j+k+i]*e;
				a[j+k]=x+y;a[j+k+i]=x-y;
			}
		}
	}
	
	if(f==-1)for(int i=0;i<k;i++)a[i].x/=k;
}


void Work(){
	for(int i=0;i<n;i++)Ans[0]+=A[i][B[0]];
	for(int i=1;i<n;i++)Ans[i]+=A[0][B[0]];
	for(int i=0;i<m;i++){
		for(k=1;k<=(n*2);k<<=1);
		for(int j=0;j<k;j++)a[j]=b[j]=Com(0,0);
		for(int j=1;j<n;j++)if(B[j]==i)b[pos[j]]=b[pos[j]+n-1]=Com(1,0);
		for(int j=1;j<n;j++)a[n-2-pos[j]]=Com(A[j][i],0);
//		for(int j=0;j<k;j++)cout<<a[j].x<<' ';cout<<endl;
//		for(int j=0;j<k;j++)cout<<b[j].x<<' ';cout<<endl;
		FFT(a,1);FFT(b,1);
		for(int j=0;j<k;j++)a[j]=a[j]*b[j];
		FFT(a,-1);
		for(int j=0;j<n-1;j++)Ans[Pow[j]]+=int(a[j+n-2].x+0.5);
//		for(int j=0;j<k;j++)cout<<int(a[j].x+0.5)<<' ';cout<<endl;
//		cout<<"!\n";
	}
	for(int i=0;i<n;i++)printf("%d ",Ans[i]);
//	for(int i=0;i<n;i++)cout<<Ans[i]<<' ';cout<<endl;
//	for(int i=0;i<n;i++)
//		for(int j=0;j<n;j++)Ans2[i]+=A[j][B[i*j%n]];
//	for(int i=0;i<n;i++)cout<<Ans2[i]<<' ';cout<<endl;
}

int fexp(int x,int t,int P){int ans=1;
	for(;t;t>>=1,x=1LL*x*x%P)if(t&1)ans=1LL*ans*x%P;
	return ans;
}

bool check(int x,int P){
	for(int i=2;1LL*i*i<P-1;i++)
		if(!((P-1)%i))
			if(fexp(x,i,P)==1||fexp(x,(P-1)/i,P)==1)return false;
			
	return true;
}

int solve(int P){
	for(int i=2;;i++)
		if(check(i,P))return i;
}

void Init(){
	scanf("%d%d",&n,&m);g=solve(n);
	int now=1;
	for(int i=0;i<n-1;i++){
		Pow[i]=now;pos[now]=i;
		now=1LL*now*g%n;
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)scanf("%d",&A[i][j]);
	for(int i=0;i<n;i++)scanf("%d",&B[i]);
}

int main(){
	Init();
	Work();
	return 0;
}
