#include <bits/stdc++.h>
using namespace std;
typedef long long LL;

struct fraction {
    LL a, b;
    void simplify()
    {
        LL g = __gcd(a, b);
        a /= g;
        b /= g;
        if(b < 0) {
            b = -b;
            a = -a;
        }
    }
    fraction(LL a = 0, LL b = 1): a(a), b(b)
    {
        simplify();
    }
    fraction operator + (fraction rhs)
    {
        return fraction(a * rhs.b + b * rhs.a, b * rhs.b);
    }
    fraction operator - (fraction rhs)
    {
        rhs.a = -rhs.a;
        return *this + rhs;
    }
    fraction operator * (fraction rhs)
    {
        return fraction(a * rhs.a, b * rhs.b);
    }
    fraction operator / (fraction rhs)
    {
        swap(rhs.a, rhs.b);
        return *this * rhs;
    }
    fraction operator - ()
    {
        fraction tmp = *this;
        tmp.a = -tmp.a;
        return tmp;
    }
    string toString()
    {
        simplify();
        char buf[100];
        if (b == 1 || a == 0)
            sprintf(buf, "%lld", a);
        else
            sprintf(buf, "%lld/%lld", a, b);
        return string(buf);
    }
};

struct opr {
    int type;
    int val;
    opr() = default;
    opr(int type, int val): type(type), val(val) {}

    string toString()
    {
        char buf[100];
        if (type)
            sprintf(buf, "%c ", val);
        else
            sprintf(buf, "%d ", val);
        return string(buf);
    }

    bool operator==(char x)const
    {
        return type == 1 && val == x;
    }

    bool operator!=(char x)const
    {
        return !(*this == x);
    }
};

char chars[][30] = {
    "**** ** ** ****",
    "*****",
    "***  *****  ***",
    "***  ****  ****",
    "* ** ****  *  *",
    "****  ***  ****",
    "****  **** ****",
    "***  *  *  *  *",
    "**** ***** ****",
    "**** ****  ****",
    "    * *** *    ",
    "      ***      ",
    "   * * * * *   ",
    "     * * *     ",
    " * *  *  *   * ",
    " *   *  *  * * ",
    "     *****     *****     "
};

int width[] = {3, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5};
char dict[] = "0123456789+-*/()=";

int getID(char c)
{
    for (int i = 0;; i++)
        if (dict[i] == c)
            return i;
}

void print(const char *src)
{
    for (int line = 0; line < 5; line++) {
        for (int i = 0; src[i]; i++) {
            int id = getID(src[i]);
            if (i > 0)
                cout << "  ";
            for (int j = 0; j < width[id]; j++)
                cout << chars[id][line * width[id] + j];
        }
        puts("");
    }
}

vector<opr> strToMid(string &src)
{
    vector<opr> ans;
    for (int i = 0; i < src.size(); i++) {
        if (isdigit(src[i])) {
            int tmp = 0;
            while (isdigit(src[i])) {
                tmp = tmp * 10 + src[i] - '0';
                i++;
            }
            i--;
            ans.push_back(opr(0, tmp));
        } else {
            ans.push_back(opr(1, src[i]));
        }
    }
    return ans;
}

int getP(opr x)
{
    if (x == '(')
        return 0;
    if (x == '+' || x == '-')
        return 1;
    return 2;
}

vector<opr> midToPost(vector<opr> &src)
{
    vector<opr> ans;
    stack<opr> stk;

    for (auto crt : src) {
        if (!crt.type) {
            ans.push_back(crt);
        } else if (crt == '(') {
            stk.push(crt);
        } else if (crt == ')') {
            while (stk.top() != '(') {
                ans.push_back(stk.top());
                stk.pop();
            }
            stk.pop();
        } else {
            int p = getP(crt);
            while (stk.size() && getP(stk.top()) >= p) {
                ans.push_back(stk.top());
                stk.pop();
            }
            stk.push(crt);
        }
    }
    while (stk.size()) {
        ans.push_back(stk.top());
        stk.pop();
    }
    return ans;
}

fraction calc(vector<opr> &src)
{
    stack<fraction> stk;
    fraction ans;
    for (auto crt : src) {
        if (!crt.type) {
            stk.push(fraction(crt.val));
        } else {
            fraction rhs, lhs;
            rhs = stk.top();
            stk.pop();
            lhs = stk.top();
            stk.pop();
            if (crt == '+') {
                stk.push(lhs + rhs);
            } else if (crt == '-') {
                stk.push(lhs - rhs);
            } else if (crt == '*') {
                stk.push(lhs * rhs);
            } else if (crt == '/') {
                stk.push(lhs / rhs);
            }
        }
    }
    return stk.top();
}

//1+2/(3*4)

char buf[1000100];

int main()
{
    int T;
    scanf("%d", &T);
    while (T--) {
        scanf("%s", buf);
        string tmp = buf;
        auto x = strToMid(tmp);
        x = midToPost(x);
        auto ans = calc(x);
//        cout << ans.toString() << endl;
        string xx = tmp + '=';
        xx += ans.toString();
        print(xx.c_str());
    }
    return 0;
}
