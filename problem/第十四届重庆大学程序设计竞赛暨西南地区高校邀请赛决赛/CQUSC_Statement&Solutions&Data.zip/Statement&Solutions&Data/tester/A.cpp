//
//  Created by Running Photon on 2016-04-30
//  Copyright (c) 2015 Running Photon. All rights reserved.
//
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <string>
#include <sstream>
#include <set>
#include <vector>
#include <stack>
using namespace std;
const int inf = 0x3f3f3f3f;
const int MOD = 1e9 + 7;
const int maxn = 150000 + 10;
const int maxv = 2e2 + 10;
const double eps = 1e-9;
int a[maxn];
int n;
int calc() {
    int res = 0;
    for (int i = 2;i <= n;++i)
        if (a[i] > a[i-1]) res++;
    return res;
}
int b[110];
int main() {
#ifdef LOCAL
	freopen("in.txt", "r", stdin);
//	freopen("out.txt","w",stdout);
#endif
//	ios_base::sync_with_stdio(0);
    int t; cin >> t;
    while(t--) {
        scanf("%d", &n);
        memset(b, 0, sizeof b);
        for (int i = 1;i <= n;++i)
            scanf("%d", &a[i]), b[a[i]] = 1;
        int ans1 = 0, ans2 = 0;
        for (int i = 2;i <= n;++i)
            if (a[i] > a[i-1]) ans1++;
        int c;
        ans2 = ans1;
        for (int i = 1;i <= n;++i) {
            int o = a[i];
            for (int j = 1;j <= 100;++j) {
                a[i] = j;
                if ((c = calc()) > ans2) {
                    ans2 = c;
                }
            }
            a[i] = o;
        }
        cout << ans1 << ' ' << ans2 << endl;
    }
	return 0;
}
