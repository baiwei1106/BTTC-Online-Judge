#include<bits/stdc++.h>
#define LL long long
using namespace std;
const int M = 1e5 + 5;
int n, m;
int dp[20][M];
int A[M];
void init() {
    memset(dp, 0, sizeof(dp));
    for(int j = 1; j <= n; j++) dp[0][j] = A[j];
    for(int j = 1; j < 20; j++) {
        for(int k = 1; k + (1 << j) - 1 <= n; k++) {
            dp[j][k] = max(dp[j - 1][k], dp[j - 1][k + (1 << j - 1)]);
        }
    }
}
int query(int x, int y) {
    int t = 31 - __builtin_clz(y - x + 1);
    //printf("x = %d y = %d t = %d y = %d\n",x,y,t,y-(1<<t)+1);
    return max(dp[t][x], dp[t][y - (1 << t) + 1]);
}
bool check(int x) {
    LL cnt = 0;
    for(int j = 1; j <= n; j += x) {
        int st = j, ed = min(j + x - 1, n);
        cnt += query(st, ed) + 1;
    }
    cnt--;
    return cnt <= m;
}
int main() {
#ifdef LOCAL
    freopen("1.in", "r", stdin);
    freopen("1.out", "w", stdout);
#endif
    int T;
    scanf("%d", &T);
    while(T--) {
        scanf("%d%d", &n, &m);
        for(int j = 1; j <= n; j++) scanf("%d", &A[j]);
        init();
        int ans = 0;
//        printf("123\n");
        for(int j = 1; j <= n; j++) {
            if(check(j)) {
                ans = j;
                break;
            }
        }
        printf("%d\n", ans);
    }
    return 0;
}
