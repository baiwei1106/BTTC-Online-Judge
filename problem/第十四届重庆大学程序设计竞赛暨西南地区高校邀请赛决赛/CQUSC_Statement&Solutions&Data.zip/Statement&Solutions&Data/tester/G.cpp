#include<bits/stdc++.h>
using namespace std;
const int M = 305, INF = 0x3f3f3f3f;
int dp[M][M];
int A[M];
int sum[M];
int main() {
    int T;
    scanf("%d", &T);
    while(T--) {
        int n;
        scanf("%d", &n);
        for(int j = 1; j <= n; j++) scanf("%d", &A[j]), sum[j] = sum[j - 1] + A[j];
        memset(dp, 63, sizeof(dp));
        dp[1][1] = A[1];
        for(int j = 2; j <= n; j++) {
            dp[j][1] = sum[j];
            for(int k = 2; k <= j; k++) {
                for(int i = 1; i <= j; i++) {
                    if(dp[i][k - 1] <= sum[j] - sum[i]) dp[j][k] = min(dp[j][k], sum[j] - sum[i]);
                }
            }
        }
        int ans = 0;
        for(int j = 1; j <= n; j++) if(dp[n][j] != INF) ans = j;
        printf("%d\n", ans);
    }
    return 0;
}
