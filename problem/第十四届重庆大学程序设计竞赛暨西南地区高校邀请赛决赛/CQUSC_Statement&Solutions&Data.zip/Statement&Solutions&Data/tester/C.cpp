#pragma comment(linker, "/STACK:102400000,102400000")
#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <cctype>
#include <map>
#include <set>
#include <queue>
#include <bitset>
#include <string>
#include <complex>
using namespace std;
typedef pair<int,int> Pii;
typedef long long LL;
typedef unsigned long long ULL;
typedef double DBL;
typedef long double LDBL;
#define MST(a,b) memset(a,b,sizeof(a))
#define CLR(a) MST(a,0)
#define SQR(a) ((a)*(a))
#define PCUT puts("\n----------")
#define PRI(x) cout << #x << ":" << x << endl;

const int maxn=110, maxa=9;
char in[maxn];
const char *chr[maxa]=
{
	"84C",
	"626A",
	"6AA",
	"624A",
	"(624A)x2",
	"(624A)x3",
	"2426A",
	"2624A",
	"2626AC"
};
const int val[maxa]={1,3,2,1,2,3,1,8,7};
int main()
{
	#ifdef LOCAL
	freopen("1.in", "r", stdin);
//	freopen("out.txt", "w", stdout);
	#endif

	int T;
	scanf("%d", &T);
	for(int ck=1; ck<=T; ck++)
	{
		CLR(in);
		scanf("%s", in);
//		PRI(in);
		int ans = 0;
		for(int i=0,len; in[i]; i+=len)
		{
			len = 1;
			int j;
			for(j=0; j<maxa; j++) if(!strncmp(chr[j],in+i,strlen(chr[j])))
			{
//				PRI(chr[j]);
				len = strlen(chr[j]);
				ans += val[j];
				break;
			}
			if(j==maxa && isdigit(in[i]) && 'A'<=in[i+1] && in[i+1]<='D')
			{
//				char temp[3]={in[i], in[i+1], 0};
//				PRI(temp);
				len = 2;
				ans += 1;
			}
		}
		if(ans<=1) puts("Oops");
		else printf("%d\n", ans);
//		PCUT;
	}
	return 0;
}

