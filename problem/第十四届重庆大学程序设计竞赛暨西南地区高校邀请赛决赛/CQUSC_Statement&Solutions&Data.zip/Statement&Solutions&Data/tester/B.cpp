#pragma comment(linker, "/STACK:102400000,102400000")
#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <cctype>
#include <map>
#include <set>
#include <queue>
#include <bitset>
#include <string>
#include <complex>
using namespace std;
typedef pair<int,int> Pii;
typedef long long LL;
typedef unsigned long long ULL;
typedef double DBL;
typedef long double LDBL;
#define MST(a,b) memset(a,b,sizeof(a))
#define CLR(a) MST(a,0)
#define SQR(a) ((a)*(a))
#define PCUT puts("\n----------")
#define PRI(x) cout << #x << ":" << x << endl;

const int maxn=1e5+5;
struct Graph
{
	int ndn,edn,last[maxn];
	int u[maxn<<1], v[maxn<<1], nxt[maxn<<1];
	void init(int _n){ndn=_n; edn=0; MST(last,-1);}
	void adde(int _u, int _v)
	{
		u[edn]=_u; v[edn]=_v;
		nxt[edn]=last[_u];
		last[_u]=edn++;
	}
};

Graph G;
int fat[maxn], dis[maxn];

void dfs(int u, int f, int d)
{
	dis[u] = d;
	fat[u] = f;
	for(int e=G.last[u],v; ~e; e=G.nxt[e]) if((v=G.v[e])!=f)
	{
		dfs(v, u, d+1);
	}
}

int Get(int u, int d)
{
	int ans = 0;
	if(dis[u]==d) ans=1;
	for(int e=G.last[u],v; ~e; e=G.nxt[e]) if((v=G.v[e])!=fat[u])
	{
		ans += Get(v, d);
	}
	return ans;
}

int main()
{
	#ifdef LOCAL
//	freopen("1.in", "r", stdin);
//	freopen("out.txt", "w", stdout);
	#endif

	int T;
	scanf("%d", &T);
	for(int ck=1; ck<=T; ck++)
	{
		int N, Q, u, v, d, ans=0;
		scanf("%d", &N);
		G.init(N);
		for(int i=1; i<N; i++)
		{
			scanf("%d%d", &u, &v);
			G.adde(u,v); G.adde(v,u);
		}
		dfs(1,0,0);
		scanf("%d", &Q);
		for(int q=1; q<=Q; q++)
		{
			scanf("%d%d", &u, &d);
			u ^= ans;
			d ^= ans;
			ans = Get(u,d);
			printf("%d%c", ans, "\n"[q==Q]);
		}
	}
	exit(0);
}

