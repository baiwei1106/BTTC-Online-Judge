## Solutions of CQUSC2017

### A. 75%/100%

$intended\ solution$让你写一个$O(n^2\times 100)$。

$O(n)$，枚举每一个数$a_i$，$a_{i-1}\ge a_i$， $a_i$增大，$a_i\ge a_{i+1}$，$a_i$减小

$a_i$减小的情况： 100 (3) 2 ，直接减小，2 (4) 3， 判断是否破坏了之前的上升对

### B. 5%/50%

$O(n+qlogn)$，$vector<int>\ lv[d]:=dfn[u]$， $subtree[u]:= [in[u],\ out[u]] $

$u,\ d$，二分一下$lv[d]$，有多少$dfn$在这个$[in[u],\ out[u]]$。

一万种数据结构做法。

归并树，每个节点存一段区间有多少树上的点的深度，查询它们有多少深度是$d$，$O(nlogn+qlog^2n)$

主席树，每棵权值线段树存的是深度为$d$点有多少个，按照$dfn$开主席树。$O(nlogn+qlogn)$

线段树套平衡树，$KDT$

### C. 20%/100% 

存下来所有特殊招式，贪心的能打就打，$O(n\times \Sigma)$

### D. 38%/70%

先把变成你熟悉的形式，之后先判断不相交，$O(1)$

### E. 1%/30%

中缀表达式$\to$后缀表达式

维护$2$个栈，一个操作数栈，一个是操作符栈，来了一个运算数扔进操作数栈里，来一个运算符，操作符栈里栈顶的符号的优先级，优先级高先变成后缀表达式，再把当前操作符入栈

$1$个栈做后缀表达式，运算数就入栈，碰到运算符就$pop\ 2$个操作数出来，算一下再入栈

分数类， 点阵常量字符串，分母为$1$，不要输出分母，负数

$O(n)$

### F. 0%/1%

$n$是素数，$C[i]=\sum_{j=0}^{n-1} A[j][B[i\times j\ mod\ n]]$ 

枚举每一列$k​$，  $C[i]=\sum_{j=0}^{n-1} A[j][k]\times (B[i\times j\ mod\ n]==k)$

$a^x \times a^y=a^{x+y}$，原根，$g^x\mod p,\ x\in [0,\ p-1)$各不相同， $i==0\ or\ j==0$

找到，$i=g^x,\ j=g^y$， $C[i]=\sum_{j=1}^{n-1} A[y][k]\times (B[g^{x+y}\mod p-1]==k)$，$A映射$

$C[i]=\sum_{j=1}^{n-1} A[-y][k]\times (B[g^{x+y}\mod p-1]==k)$，循环，拷贝一份在后面。

$m$次$FFT$，做完了，$O(mnlogn)$

### G. 13%/50% 

`7 1 8 8 8 8`，$f_{i,j}:=$ $[i,\ j]$选的最后一块的最大的$m$，枚举下一块$[j+1,\ k]$，$f_{1,\ i}=1$

$ans=\max_i f_{i,\ n}$，$O(n^3)$

### H. 1%/10%

直径合并，两个连通块$a,\ b$，$d=\max\lbrace dis(au, av),\ dis(bu,\ bv),\ dis(au,\ bu), dis(au,\ bv),\ dis(av,\ bu),\ dis(av,\ bv) \rbrace$

抠出每个颜色的所有连通块，求它们的直径，然后合并，得到每个颜色的直径。

$lca$， RMQ求$lca$ $O(1)$

虚树，每个颜色抠出搞一颗虚树，$O(颜色)$个，$O(n)$，$lca \to O(nlogn)$

### I.  26%/50%

枚举$x$，$\lceil {n \over x}\rceil $块，每一块求一个最大值，线段树$O(logn)$，RMQ $O(1)$，

$O(\sum_{x=1}^n \lceil {n \over x}\rceil)=O(n\sum {1\over x})=O(nlogn)​$，调和级数。



