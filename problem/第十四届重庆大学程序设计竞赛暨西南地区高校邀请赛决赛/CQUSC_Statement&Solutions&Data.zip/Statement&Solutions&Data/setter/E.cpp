//
//  Created by TaoSama on 2017-04-18
//  Copyright (c) 2017 TaoSama. All rights reserved.
//
#pragma comment(linker, "/STACK:102400000,102400000")
#include <bits/stdc++.h>

using namespace std;
#define pr(x) cerr << #x << " = " << x << "  "
#define prln(x) cerr << #x << " = " << x << endl
const int N = 1e5 + 10, INF = 0x3f3f3f3f, MOD = 1e9 + 7;

const string digit[] = {
    "***",  "*",    "***",  "***",  "* *",   "***",   "***",   "***",   "***",   "***",
    "* *",  "*",    "  *",  "  *",  "* *",   "*  ",   "*  ",   "  *",   "* *",   "* *",
    "* *",  "*",    "***",  "***",  "***",   "***",   "***",   "  *",   "***",   "***",
    "* *",  "*",    "*  ",  "  *",  "  *",   "  *",   "* *",   "  *",   "* *",   "  *",
    "***",  "*",    "***",  "***",  "  *",   "***",   "***",   "  *",   "***",   "***",
};
const string op[] = {
    "   ",  "   ",  "   ",  "   ",  " * ",  " * ",  "     ",   "  ",
    " * ",  "   ",  "* *",  "  *",  "*  ",  "  *",  "*****",   "  ",
    "***",  "***",  " * ",  " * ",  "*  ",  "  *",  "     ",   "  ",
    " * ",  "   ",  "* *",  "*  ",  "*  ",  "  *",  "*****",   "**",
    "   ",  "   ",  "   ",  "   ",  " * ",  " * ",  "     ",   "**",
};
const char* ops = "+-*/()=.";

void RE(bool fuck) {
    if(!fuck) printf("%d\n", *((int*)0));
}

struct Frac {
    int p, q;
    Frac(): p(0), q(1) {}
    Frac(int _p, int _q) : p(_p), q(_q) {
        int g = __gcd(p, q);
        p /= g; q /= g;
        if(q < 0) p = -p, q = -q;
    }
    Frac operator+(const Frac& f) const {
        return Frac(p * f.q + q * f.p, q * f.q);
    }
    Frac operator-(const Frac& f) const {
        return Frac(p * f.q - q * f.p, q * f.q);
    }
    Frac operator*(const Frac& f) const {
        return Frac(p * f.p, q * f.q);
    }
    Frac operator/(const Frac& f) const {
        return Frac(p * f.q, q * f.p);
    }
    void write() {
        printf("%d/%d\n", p, q);
    }
};

int getPriority(char c) {
    if(c == '+' || c == '-') return 1;
    else if(c == '*' || c == '/') return 2;
    return 0;
}

vector<string> inToPost(const string& expr) {
    stack<char> opr;
    vector<string> ret;
    for(int i = 0; i < expr.size(); ++i) {
        char c = expr[i];
        if(c == '(') opr.push(c);
        else if(c == ')') {
            while(true) {
                char top = opr.top(); opr.pop();
                if(top == '(') break;
                ret.push_back(string(1, top));
            }
        } else if(isdigit(c)) {
            string digit;
            for(; i < expr.size() && isdigit(expr[i]); ++i) digit += expr[i];
            ret.push_back(digit);
            --i;
        } else {
            int curP = getPriority(c);
            for(; opr.size() && getPriority(opr.top()) >= curP; opr.pop())
                ret.push_back(string(1, opr.top()));
            opr.push(c);
        }
    }
    for(; opr.size(); opr.pop()) ret.push_back(string(1, opr.top()));
    return ret;
}

Frac calc(const vector<string>& post) {
    stack<Frac> opd;
    for(const auto& s : post) {
//        cout << s << ' ';
        if(isdigit(s[0])) opd.push(Frac(stoi(s), 1));
        else {
            Frac y = opd.top(); opd.pop();
            Frac x = opd.top(); opd.pop();
            if(s[0] == '+') opd.push(x + y);
            else if(s[0] == '-') opd.push(x - y);
            else if(s[0] == '*') opd.push(x * y);
            else opd.push(x / y);
        }
    }
//    cout << endl;
    return opd.top();
}

char s[N];

int main() {
#ifdef LOCAL
    freopen("C:\\Users\\TaoSama\\Desktop\\in.txt", "r", stdin);
//    freopen("C:\\Users\\TaoSama\\Desktop\\out.txt", "w", stdout);
#endif
    ios_base::sync_with_stdio(0);

    int t; scanf("%d", &t);
    while(t--) {
        scanf("%s", s);
        string expr(s);
        auto post = inToPost(expr);
        auto ret = calc(post);
//        ret.write();
        expr += "=";
        expr += to_string(ret.p) + (ret.q != 1 ? "/" + to_string(ret.q) : "");

        vector<string> output(5);
        for(int i = 0; i < expr.size(); ++i) {
            char c = expr[i];
            if(i) for(int j = 0; j < 5; ++j) output[j] += "  ";
            if(isdigit(c)) {
                int x = c - '0';
                for(int j = 0; j < 5; ++j) output[j] += digit[x + j * 10];
            } else {
                int x = strchr(ops, c) - ops;
                for(int j = 0; j < 5; ++j) output[j] += op[x + j * 8];
            }
        }
        for(int i = 0; i < 5; ++i)
            printf("%s\n", output[i].c_str());
    }

    return 0;
}
