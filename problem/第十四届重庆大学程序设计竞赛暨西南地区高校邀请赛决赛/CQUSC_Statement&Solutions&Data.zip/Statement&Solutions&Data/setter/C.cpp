//
//  Created by TaoSama on 2017-05-20
//  Copyright (c) 2017 TaoSama. All rights reserved.
//
#pragma comment(linker, "/STACK:102400000,102400000")
#include <bits/stdc++.h>

using namespace std;
#define pr(x) cerr << #x << " = " << x << "  "
#define prln(x) cerr << #x << " = " << x << endl
const int N = 1e5 + 10, INF = 0x3f3f3f3f, MOD = 1e9 + 7;

int n;
char s[N];

int main() {
#ifdef LOCAL
    freopen("C:\\Users\\TaoSama\\Desktop\\in.txt", "r", stdin);
//  freopen("C:\\Users\\TaoSama\\Desktop\\out.txt","w",stdout);
#endif
    ios_base::sync_with_stdio(0);

    map<string, int> mp = {
        {"626A", 3}, {"6AA", 2}, {"(624A)x2", 2}, {"(624A)x3", 3},
        {"2624A", 8}, {"2626AC", 7}
    };

    int t; scanf("%d", &t);
    while(t--) {
        scanf("%s", s + 1);
        n = strlen(s + 1);
        string hit;
        int ans = 0, b = 0;
        for(int i = 1; i <= n; ++i) {
            hit += s[i];
            if(s[i] == '(') b = 1;
            else if(s[i] == ')') b = 0;
            if(b) continue;

            if(isupper(s[i]) && i + 1 <= n && isupper(s[i + 1]))
                hit += s[++i];

            bool ok = false;
            for(const auto& p : mp) {
                int pos = hit.find(p.first);
                if(pos == -1) continue;
                if(pos + p.first.size() == hit.size()) {
                    ok = true;
                    ans += p.second;
                    hit.clear();
                }
            }
            if(!ok && isupper(s[i])) {
                ++ans;
                hit.clear();
            }
        }
        if(ans <= 1) puts("Oops");
        else printf("%d\n", ans);
    }

    return 0;
}
