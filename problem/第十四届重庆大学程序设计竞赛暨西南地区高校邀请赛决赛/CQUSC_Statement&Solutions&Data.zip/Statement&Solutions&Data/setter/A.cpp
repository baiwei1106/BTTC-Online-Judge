//
//  Created by TaoSama on 2017-05-20
//  Copyright (c) 2017 TaoSama. All rights reserved.
//
#pragma comment(linker, "/STACK:102400000,102400000")
#include <bits/stdc++.h>

using namespace std;
#define pr(x) cerr << #x << " = " << x << "  "
#define prln(x) cerr << #x << " = " << x << endl
const int N = 1e5 + 10, INF = 0x3f3f3f3f, MOD = 1e9 + 7;

int n, a[N];

int main() {
#ifdef LOCAL
//    freopen("C:\\Users\\TaoSama\\Desktop\\in.txt", "r", stdin);
//  freopen("C:\\Users\\TaoSama\\Desktop\\out.txt","w",stdout);
#endif
    ios_base::sync_with_stdio(0);

    int t; scanf("%d", &t);
    while(t--) {
        scanf("%d", &n);
        for(int i = 1; i <= n; ++i) scanf("%d", a + i);
        int ans = 0, more = 0;
        for(int i = 2; i <= n; ++i) ans += a[i] > a[i - 1];
        for(int i = 1; i <= n; ++i) {
            if(i + 1 <= n && !(a[i] < a[i + 1])) {
                if(a[i + 1] - 1 >= 1) {
                    if(i == 1 || a[i - 1] >= a[i]
                       || a[i + 1] - 1 > a[i - 1]) more = 1;
                }
            }
            if(i - 1 >= 1 && !(a[i - 1] < a[i])) {
                if(a[i - 1] + 1 <= 100) {
                    if(i == n || a[i] >= a[i + 1]
                       || a[i - 1] + 1 < a[i + 1]) more = 1;
                }
            }
        }
        printf("%d %d\n", ans, ans + more);
    }
    return 0;
}
