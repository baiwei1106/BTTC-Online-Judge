//
//  Created by TaoSama on 2017-05-20
//  Copyright (c) 2017 TaoSama. All rights reserved.
//
#pragma comment(linker, "/STACK:102400000,102400000")
#include <bits/stdc++.h>

using namespace std;
#define pr(x) cerr << #x << " = " << x << "  "
#define prln(x) cerr << #x << " = " << x << endl
const int N = 300 + 10, INF = 0x3f3f3f3f, MOD = 1e9 + 7;

int n, a[N];
int f[N][N];

int main() {
#ifdef LOCAL
    freopen("C:\\Users\\TaoSama\\Desktop\\in.txt", "r", stdin);
//  freopen("C:\\Users\\TaoSama\\Desktop\\out.txt","w",stdout);
#endif
    ios_base::sync_with_stdio(0);

    int t; scanf("%d", &t);
    while(t--) {
        scanf("%d", &n);
        for(int i = 1; i <= n; ++i) scanf("%d", a + i), a[i] += a[i - 1];
        memset(f, 0xc0, sizeof f);
        for(int i = 1; i <= n; ++i) f[1][i] = 1;
        for(int j = 1; j <= n; ++j) {
            for(int i = 1; i <= j; ++i) {
                for(int k = j + 1; k <= n; ++k) {
                    if(a[k] - a[j] >= a[j] - a[i - 1])
                        f[j + 1][k] = max(f[j + 1][k], f[i][j] + 1);
                }
            }
        }
        int ans = 0;
        for(int i = 1; i <= n; ++i) ans = max(ans, f[i][n]);
        printf("%d\n", ans);
    }

    return 0;
}
