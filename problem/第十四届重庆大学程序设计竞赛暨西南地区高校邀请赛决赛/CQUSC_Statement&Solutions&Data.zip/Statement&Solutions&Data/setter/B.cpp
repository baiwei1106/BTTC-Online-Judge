//
//  Created by TaoSama on 2017-05-20
//  Copyright (c) 2017 TaoSama. All rights reserved.
//
#pragma comment(linker, "/STACK:102400000,102400000")
#include <bits/stdc++.h>

using namespace std;
#define pr(x) cerr << #x << " = " << x << "  "
#define prln(x) cerr << #x << " = " << x << endl
const int N = 1e5 + 10, INF = 0x3f3f3f3f, MOD = 1e9 + 7;

int n, q;
vector<int> G[N], level[N];
int dfsNum, L[N], R[N];

void dfs(int u, int fa, int d) {
    L[u] = ++dfsNum;
    level[d].push_back(L[u]);
    for(int v : G[u]) if(v != fa) dfs(v, u, d + 1);
    R[u] = dfsNum;
}

int main() {
#ifdef LOCAL
    freopen("C:\\Users\\TaoSama\\Desktop\\in.txt", "r", stdin);
//  freopen("C:\\Users\\TaoSama\\Desktop\\out.txt","w",stdout);
#endif
    ios_base::sync_with_stdio(0);

    int t; scanf("%d", &t);
    while(t--) {
        scanf("%d", &n);
        for(int i = 0; i <= n; ++i) G[i].clear(), level[i].clear();
        for(int i = 1; i < n; ++i) {
            int u, v; scanf("%d%d", &u, &v);
            G[u].push_back(v);
            G[v].push_back(u);
        }

        dfsNum = 0;
        dfs(1, -1, 0);

        int ans = 0;
        scanf("%d", &q);
        while(q--) {
            int u, d; scanf("%d%d", &u, &d);
            u ^= ans; d ^= ans;
            ans = upper_bound(level[d].begin(), level[d].end(), R[u])
                  - lower_bound(level[d].begin(), level[d].end(), L[u]);
            printf("%d\n", ans);
        }
    }

    return 0;
}
