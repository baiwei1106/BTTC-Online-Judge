#define LOCAL
#include<cstdio>
#include<algorithm>
using namespace std;
int num1[200000],num2[200000];
int main(){
	int i,j,k,m,n,mid;
	#ifdef LOCAL
	freopen("test.in_2-1.txt","r",stdin);
	freopen("test.out_2-1.txt","w",stdout);	
	#endif
	scanf("%d",&m);
	for(i=0;i<m;i++){
		scanf("%d",&num1[i]);
	}
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&num2[i]);
	}
	i=0;j=0;k=0;
	mid=(m+n-1)/2;
	while(j<m&&k<n){
		if(num1[j]<=num2[k]){
			if (i==mid){
				printf("%d\n",num1[j]);
				break;
			}
			i++;
			j++;
		}
		else if(num1[j]>num2[k]){
			if(i==mid){
				printf("%d\n",num2[k]);
				break;
			}
			i++;
			k++;
		}
	}
	if(j==m)
		printf("%d\n",num2[mid+k-i]);
	else if(k==n)
		printf("%d\n",num1[mid+j-i]);
}
