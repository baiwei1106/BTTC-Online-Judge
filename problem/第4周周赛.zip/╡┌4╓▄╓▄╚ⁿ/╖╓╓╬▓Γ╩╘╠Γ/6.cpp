#define LOCAL 
#include <cstdio>
#include <cstring>
using namespace std;
long long count;
void Merge(long long a[],int s,int m,int e,long long tmp[]){
    int pb=0,p1=s,p2=m+1;
    while(p1<=m&&p2<=e){
        if(a[p1]<=a[p2]){
			tmp[pb++]=a[p1++]; 
		}
        else {tmp[pb++]=a[p2++];count+=m-p1+1;}
    }
    while(p1<=m){
		tmp[pb++]=a[p1++]; 
	}
    while(p2<=e){
		tmp[pb++]=a[p2++]; 
	}
    for(int i=0;i<e-s+1;++i){
        a[s+i]=tmp[i];
    }
}
void Mergesort(long long a[],int s,int e,long long tmp[]){
    if(s<e){
        int m=s+(e-s)/2;
        Mergesort(a,s,m,tmp);
        Mergesort(a,m+1,e,tmp);
        Merge(a,s,m,e,tmp);
    }
}
int main(){
    int n,x,y;
    long long a[100010],b[100010];
    #ifdef LOCAL
	freopen("test.in_6-3.txt","r",stdin);
	freopen("test.out_6-3.txt","w",stdout);	
	#endif
    while(scanf("%d%d%d",&n,&x,&y)!=EOF){
    	memset(a,0,sizeof(a));
    	memset(b,0,sizeof(b));
    	count=0;
    	for(int i=0;i<n;i++){
       		scanf("%lld",&a[i]);
    	}
    	Mergesort(a,0,n-1,b);
    	if(x>y) printf("%lld\n",count*y);
    	else printf("%lld\n",count*x);
	}
	return 0;
}
