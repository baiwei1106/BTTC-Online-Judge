#include<cstdio>
int num1[100000],num2[100000];
int main(){
	int i,j,m,n,flag;
	scanf("%d",&m);
	for(i=0;i<m;i++){
		scanf("%d",&num1[i]);
	}
	scanf("%d",&n);
	for(j=0;j<n;j++){
		scanf("%d",&num2[j]);
	}
	for(i=0,j=0,flag=0;i<m&&j<n;){
		if(num1[i]+num2[j]==10000){
			flag=1;break;
		}
		else if(num1[i]+num2[j]<10000) i++;
		else j++; 
	}
	if(flag) printf("YES\n");
	else printf("NO\n");
	return 0;
} 
