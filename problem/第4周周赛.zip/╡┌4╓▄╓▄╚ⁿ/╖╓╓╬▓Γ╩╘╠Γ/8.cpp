#include<cstdio>
#include<cmath>
int num[16];
int main(){
	int i,n;
	num[0]=1;
	num[1]=3;
	for(i=2;i<=15;i++){
		num[i]=4*num[i-1]-num[i-2];
	}
	while(scanf("%d",&n)!=EOF){
		if(n==-1) break;
		else if(n%2==1) printf("0\n");
		else printf("%d\n",num[n/2]);
	}
	return 0;
} 
