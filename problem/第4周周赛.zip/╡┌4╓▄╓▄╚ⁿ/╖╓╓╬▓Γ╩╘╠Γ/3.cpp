#include<cstdio>
#include<cmath>
#define eps 1e-6
double fx(double x,double y){
	return (6*pow(x,7)+8*pow(x,6)+7*pow(x,3)+5*pow(x,2)-y*x);
}
double gx(double x,double y){
	return (42*pow(x,6)+48*pow(x,5)+21*pow(x,2)+10*x-y);
}
int main(){
	int n;
	double x,y;
	double left,right;
	while(scanf("%d",&n)!=EOF){
		while(n--){
			scanf("%lf",&y);
			left=0;right=100;
			x=(left+right)/2;
			while(fabs(gx(x,y))>=eps){
				if(gx(x,y)>0) right=x;
				else left=x;
				x=(left+right)/2;
			}
			printf("%.4lf\n",fx(x,y));
		}
	}
	return 0;
} 
