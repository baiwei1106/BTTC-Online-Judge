#include<cstdio>
#include<map>
using namespace std;
map<int,int> count;
map<int,int>::iterator it,it1;
int main(){
	int i,n,num,max;
	while(scanf("%d",&n)!=EOF){
		for(i=0;i<n;i++){
			scanf("%d",&num);
			count[num]++;
		}
		for(it=count.begin(),it1=count.begin(),max=0;it!=count.end();it++){
			if(it->second>max){
				max=it->second;
				it1=it;
			}
		}
		printf("%d\n",it1->first);
	}
	return 0;
} 
