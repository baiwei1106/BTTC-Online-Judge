#define LOCAL
#include<cstdio>
#include<cstdlib> 
int main(){
	int i,j,m=1,n;
	#ifdef LOCAL
	freopen("test.in_2-1.txt","w",stdout);	
	#endif
	while(m--){
		printf("999 ");
		for(i=0;i<999;){
			printf("%d ",++i);			
		} 
		printf("\n");
		printf("163000 ");
		for(i=0;i<163000;){
			printf("%d ",++i);			
		} 
		printf("\n");
	}
	return 0;
} 
