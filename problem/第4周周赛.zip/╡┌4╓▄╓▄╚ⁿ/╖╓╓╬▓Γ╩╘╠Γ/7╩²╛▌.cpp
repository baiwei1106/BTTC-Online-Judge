#define LOCAL
#include<cstdio>
#include<cstdlib> 
int main(){
	int i,j,m=1,n;
	#ifdef LOCAL
	freopen("test.in_7-4.txt","w",stdout);	
	#endif
	while(m--){
		printf("100000 160000 %d\n",rand()%10000);
		for(i=0;i<160000;i++){
			printf("%d\n",(rand()%2500)*(rand()%40));
		} 
	}
	return 0;
}
