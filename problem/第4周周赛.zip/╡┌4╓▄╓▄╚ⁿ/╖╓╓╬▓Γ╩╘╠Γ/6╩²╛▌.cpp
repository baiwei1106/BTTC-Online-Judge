#define LOCAL
#include<cstdio>
#include<cstdlib> 
int main(){
	int i,j,m=1,n;
	#ifdef LOCAL
	freopen("test.in_6-3.txt","w",stdout);	
	#endif
	while(m--){
		printf("100000 100000 100000\n");
		for(i=0;i<100000;i++){
			printf("%d ",(rand()%20000)*(rand()%20000));
		} 
	}
	return 0;
}
