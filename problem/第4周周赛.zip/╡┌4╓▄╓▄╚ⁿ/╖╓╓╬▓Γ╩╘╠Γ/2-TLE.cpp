#include<cstdio>
#include<algorithm>
using namespace std;
int num[400000];
int main(){
	int i,m,n;
	scanf("%d",&m);
	for(i=0;i<m;i++){
		scanf("%d",&num[i]);
	}
	scanf("%d",&n);
	for(;i<m+n;i++){
		scanf("%d",&num[i]);
	}
	sort(num,num+(m+n));
	printf("%d\n",num[(m+n-1)/2]);
}
