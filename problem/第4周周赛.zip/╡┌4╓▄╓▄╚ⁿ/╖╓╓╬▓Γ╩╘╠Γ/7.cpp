#define LOCAL 
#include<cstdio> 
#include<algorithm>
using namespace std;
#define maxn 1000000 
int l,m,n;
int num[maxn];
int times(int a){
	int j,k,sum=0;
	for(j=0,k=1;k<m+2;){
		if(num[k]-num[j]>a){
			if(num[k-1]-num[j]<=a&&k-1!=j){
				j=k-1;
				sum++;
			}
			else return n+1;
		}
		else k++;
	}
	return sum;
}
int main(){
	int i,right,left,temp,ans;
	#ifdef LOCAL
	freopen("test.in_7-4.txt","r",stdin);
	freopen("test.out_7-4.txt","w",stdout);	
	#endif
	while(scanf("%d%d%d",&l,&m,&n)!=EOF){
		num[0]=0;
		num[1]=l;
		for(i=2;i<=m+1;i++)
			scanf("%d",&num[i]);
		sort(num,num+(m+2));
		left=1;
		right=num[m+1];
		while(left<=right){
			temp=(left+right)/2;
			if(times(temp)>=n) {left=temp+1;}
			else if(times(temp)<n) {ans=temp;right=temp-1;}
		}
		printf("%d\n",ans);
	}
	return 0;
}
