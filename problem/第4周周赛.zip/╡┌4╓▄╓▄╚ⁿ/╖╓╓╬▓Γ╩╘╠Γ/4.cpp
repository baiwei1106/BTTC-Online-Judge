//#define LOCAL 
#include<cstdio>
int num[1000000];
int main(){
	int i,n,sum,ans,ans1,first,last;
	int zheng,fu,ling;
	#ifdef LOCAL
	freopen("in.txt","r",stdin);
	freopen("out.txt","w",stdout);	
	#endif
	while(scanf("%d",&n)!=EOF){
		zheng=0;fu=0;ling=0;
		for(i=0;i<n;i++){
			scanf("%d",&num[i]);
			if(num[i]>0) zheng=1;
			else if(num[i]<0) fu=1;
			else ling=1;
		}
		first=ans1=0;last=n-1;
		if(fu==1&&zheng==0&&ling==0)
			printf("0 %d %d\n",num[0],num[n-1]);
		else if(fu==1&&zheng==0&&ling==1)
			printf("0 0 0\n");
		else{
			for(i=0,sum=0,ans=0;i<n;i++){
				sum=sum+num[i];
				if(sum>ans) {ans=sum;ans1=first;last=i;}
				else if(sum<0) {sum=0;first=i+1;}
			}
			printf("%d %d %d\n",ans,num[ans1],num[last]);
		}
	}
	return 0;
}
